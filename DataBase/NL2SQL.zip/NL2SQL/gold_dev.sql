qid1	SELECT 近7日成交 WHERE 2011年日均成交 == "3.17" and 城市 == "长沙"	69cc8c0c334311e98692542696d6e445
qid2	SELECT 近7日成交 WHERE 2011年日均成交 == "3.17" and 城市 == "长沙"	69cc8c0c334311e98692542696d6e445
qid3	SELECT 近7日成交 WHERE 2011年日均成交 == "3.17" and 城市 == "长沙"	69cc8c0c334311e98692542696d6e445
qid4	SELECT MAX ( 11/第22周 ) WHERE 城市 == "北京" or 城市 == "上海"	5a4b46fd312b11e9bef0542696d6e445
qid5	SELECT MAX ( 11/第22周 ) WHERE 城市 == "北京" or 城市 == "上海"	5a4b46fd312b11e9bef0542696d6e445
qid6	SELECT 周涨跌幅 WHERE 名称 == "搜房网" or 名称 == "人人网"	4d258a053aaa11e994c3f40f24344a08
qid7	SELECT 周涨跌幅 WHERE 名称 == "搜房网" or 名称 == "人人网"	4d258a053aaa11e994c3f40f24344a08
qid8	SELECT 周涨跌幅 WHERE 名称 == "搜房网" or 名称 == "人人网"	4d258a053aaa11e994c3f40f24344a08
qid9	SELECT 年份 WHERE 商品房新开工面积 > "90000" or 商品房竣工面积 > "50000"	e0ae3902333a11e99bbc542696d6e445
qid10	SELECT 年份 WHERE 商品房新开工面积 > "90000" or 商品房竣工面积 > "50000"	e0ae3902333a11e99bbc542696d6e445
qid11	SELECT 年份 WHERE 商品房新开工面积 > "90000" or 商品房竣工面积 > "50000"	e0ae3902333a11e99bbc542696d6e445
qid12	SELECT 股价 WHERE 证券简称 == "虎牙直播"	4d28c7ca3aaa11e98617f40f24344a08
qid13	SELECT 股价 WHERE 证券简称 == "虎牙直播"	4d28c7ca3aaa11e98617f40f24344a08
qid14	SELECT 股价 WHERE 证券简称 == "虎牙直播"	4d28c7ca3aaa11e98617f40f24344a08
qid15	SELECT 年初至今累计成交 WHERE 上周成交量 < "70" or 当月累计成交量 < "100"	e0ac070c333a11e9849c542696d6e445
qid16	SELECT 年初至今累计成交 WHERE 上周成交量 < "70" or 当月累计成交量 < "100"	e0ac070c333a11e9849c542696d6e445
qid17	SELECT 年初至今累计成交 WHERE 上周成交量 < "70" or 当月累计成交量 < "100"	e0ac070c333a11e9849c542696d6e445
qid18	SELECT 证券简称 WHERE 总市值（亿港元） > "40"	4d242e2b3aaa11e98a7ff40f24344a08
qid19	SELECT 证券简称 WHERE 总市值（亿港元） > "40"	4d242e2b3aaa11e98a7ff40f24344a08
qid20	SELECT 证券简称 WHERE 总市值（亿港元） > "40"	4d242e2b3aaa11e98a7ff40f24344a08
qid21	SELECT 城市 WHERE 本周 > "20" and 上周 > "15"	c98c5ca3332111e980eb542696d6e445
qid22	SELECT 城市 WHERE 本周 > "20" and 上周 > "15"	c98c5ca3332111e980eb542696d6e445
qid23	SELECT 城市 WHERE 本周 > "20" and 上周 > "15"	c98c5ca3332111e980eb542696d6e445
qid24	SELECT 2011年成交面积 WHERE 城市 == "成都" and 2010年成交面积 > "1500"	69d2f98f334311e9814b542696d6e445
qid25	SELECT 2011年成交面积 WHERE 城市 == "成都" and 2010年成交面积 > "1500"	69d2f98f334311e9814b542696d6e445
qid26	SELECT 2011年成交面积 WHERE 城市 == "成都" and 2010年成交面积 > "1500"	69d2f98f334311e9814b542696d6e445
qid27	SELECT 证券代码 WHERE 最新市值（亿港币） > "100" and 最新股价 > "2"	252caeca302e11e9b3ac542696d6e445
qid28	SELECT 证券代码 WHERE 最新市值（亿港币） > "100" and 最新股价 > "2"	252caeca302e11e9b3ac542696d6e445
qid29	SELECT 证券代码 WHERE 最新市值（亿港币） > "100" and 最新股价 > "2"	252caeca302e11e9b3ac542696d6e445
qid30	SELECT 起止城市 WHERE 公里数（km） < "300" or 投资总额（亿元） < "500"	43b1c90c1d7111e9b037f40f24344a08
qid31	SELECT 起止城市 WHERE 公里数（km） < "300" or 投资总额（亿元） < "500"	43b1c90c1d7111e9b037f40f24344a08
qid32	SELECT 起止城市 WHERE 公里数（km） < "300" or 投资总额（亿元） < "500"	43b1c90c1d7111e9b037f40f24344a08
qid33	SELECT 城市 WHERE 库存（套） > "50000" or 库存（万平米） > "1000"	c98e2fe8332111e998d5542696d6e445
qid34	SELECT 城市 WHERE 库存（套） > "50000" or 库存（万平米） > "1000"	c98e2fe8332111e998d5542696d6e445
qid35	SELECT 城市 WHERE 库存（套） > "50000" or 库存（万平米） > "1000"	c98e2fe8332111e998d5542696d6e445
qid36	SELECT 标的 , 子行业 WHERE 2015股息率 > "4"	c5ac415934b411e99edb542696d6e445
qid37	SELECT 标的 , 子行业 WHERE 2015股息率 > "4"	c5ac415934b411e99edb542696d6e445
qid38	SELECT 标的 , 子行业 WHERE 2015股息率 > "4"	c5ac415934b411e99edb542696d6e445
qid39	SELECT 营收 , 廉航公司 WHERE 净利润 > "5"	c5ac847534b411e9bd09542696d6e445
qid40	SELECT 营收 , 廉航公司 WHERE 净利润 > "5"	c5ac847534b411e9bd09542696d6e445
qid41	SELECT 营收 , 廉航公司 WHERE 净利润 > "5"	c5ac847534b411e9bd09542696d6e445
qid42	SELECT 公司 WHERE 业务量(亿件) > "54"	c5ad6a6b34b411e983e3542696d6e445
qid43	SELECT 公司 WHERE 业务量(亿件) > "54"	c5ad6a6b34b411e983e3542696d6e445
qid44	SELECT 公司 WHERE 业务量(亿件) > "54"	c5ad6a6b34b411e983e3542696d6e445
qid45	SELECT 城市 WHERE 日成交 > "1" and 日成交环比 > "1"	69d3e454334311e9831e542696d6e445
qid46	SELECT 城市 WHERE 日成交 > "1" and 日成交环比 > "1"	69d3e454334311e9831e542696d6e445
qid47	SELECT 城市 WHERE 日成交 > "1" and 日成交环比 > "1"	69d3e454334311e9831e542696d6e445
qid48	SELECT 评级 WHERE 股价2018/12/28 < "10" or 收益率 > "1"	e0ac35f8333a11e99688542696d6e445
qid49	SELECT 评级 WHERE 股价2018/12/28 < "10" or 收益率 > "1"	e0ac35f8333a11e99688542696d6e445
qid50	SELECT 评级 WHERE 股价2018/12/28 < "10" or 收益率 > "1"	e0ac35f8333a11e99688542696d6e445
qid51	SELECT 城市 WHERE 7日成交环比 > "6" or 7日成交同比 > "6"	69d0326e334311e98714542696d6e445
qid52	SELECT 城市 WHERE 7日成交环比 > "6" or 7日成交同比 > "6"	69d0326e334311e98714542696d6e445
qid53	SELECT 城市 WHERE 7日成交环比 > "6" or 7日成交同比 > "6"	69d0326e334311e98714542696d6e445
qid54	SELECT EPS2012E WHERE 公司 == "中天城投" or 公司 == "福星股份"	69d13894334311e9acc0542696d6e445
qid55	SELECT EPS2012E WHERE 公司 == "中天城投" or 公司 == "福星股份"	69d13894334311e9acc0542696d6e445
qid56	SELECT EPS2012E WHERE 公司 == "中天城投" or 公司 == "福星股份"	69d13894334311e9acc0542696d6e445
qid57	SELECT 证券代码 WHERE EPS2012E < "8.3" or EPS2013E < "8.3"	69cf9028334311e99d34542696d6e445
qid58	SELECT 证券代码 WHERE EPS2012E < "8.3" or EPS2013E < "8.3"	69cf9028334311e99d34542696d6e445
qid59	SELECT 证券代码 WHERE EPS2012E < "8.3" or EPS2013E < "8.3"	69cf9028334311e99d34542696d6e445
qid60	SELECT 影片 WHERE 类型 == "恐怖" and 北美映期 == "2019-01-04"	4d280ca33aaa11e9b11af40f24344a08
qid61	SELECT 影片 WHERE 类型 == "恐怖" and 北美映期 == "2019-01-04"	4d280ca33aaa11e9b11af40f24344a08
qid62	SELECT 影片 WHERE 类型 == "恐怖" and 北美映期 == "2019-01-04"	4d280ca33aaa11e9b11af40f24344a08
qid63	SELECT 指标 WHERE 绝对量 > "1000" and 同比增长（%） > "10"	c98df9a6332111e98a66542696d6e445
qid64	SELECT 指标 WHERE 绝对量 > "1000" and 同比增长（%） > "10"	c98df9a6332111e98a66542696d6e445
qid65	SELECT 指标 WHERE 绝对量 > "1000" and 同比增长（%） > "10"	c98df9a6332111e98a66542696d6e445
qid66	SELECT 2011供应面积 WHERE 城市 == "北京" and 2010供应面积 == "1709"	69d56680334311e9a917542696d6e445
qid67	SELECT 2011供应面积 WHERE 城市 == "北京" and 2010供应面积 == "1709"	69d56680334311e9a917542696d6e445
qid68	SELECT COUNT ( 证券简称 ) WHERE 总市值 < "100" or 总股本 < "20"	c98daf26332111e99d17542696d6e445
qid69	SELECT COUNT ( 证券简称 ) WHERE 总市值 < "100" or 总股本 < "20"	c98daf26332111e99d17542696d6e445
qid70	SELECT COUNT ( 证券简称 ) WHERE 总市值 < "100" or 总股本 < "20"	c98daf26332111e99d17542696d6e445
qid71	SELECT 出品方 WHERE 收视率（%） < "1"	4d26cce83aaa11e9addaf40f24344a08
qid72	SELECT 出品方 WHERE 收视率（%） < "1"	4d26cce83aaa11e9addaf40f24344a08
qid73	SELECT 出品方 WHERE 收视率（%） < "1"	4d26cce83aaa11e9addaf40f24344a08
qid74	SELECT AVG ( 占比(%) ) WHERE 企业 == "中石油体系" or 企业 == "中石化体系"	43b203731d7111e9ad56f40f24344a08
qid75	SELECT AVG ( 占比(%) ) WHERE 企业 == "中石油体系" or 企业 == "中石化体系"	43b203731d7111e9ad56f40f24344a08
qid76	SELECT AVG ( 占比(%) ) WHERE 企业 == "中石油体系" or 企业 == "中石化体系"	43b203731d7111e9ad56f40f24344a08
qid77	SELECT 证券简称 , 证券代码 WHERE 股价 > "100" and EPS17A > "3"	4d28c7ca3aaa11e98617f40f24344a08
qid78	SELECT 证券简称 , 证券代码 WHERE 股价 > "100" and EPS17A > "3"	4d28c7ca3aaa11e98617f40f24344a08
qid79	SELECT 阶段 WHERE 达美航空 > "10"	c5ac9e2b34b411e9aecf542696d6e445
qid80	SELECT 阶段 WHERE 达美航空 > "10"	c5ac9e2b34b411e9aecf542696d6e445
qid81	SELECT 阶段 WHERE 达美航空 > "10"	c5ac9e2b34b411e9aecf542696d6e445
qid82	SELECT 2017Q1 , 2017Q2 WHERE 公司 == "禾伸堂"	0de5fe57351311e9ab54542696d6e445
qid83	SELECT 2017Q1 , 2017Q2 WHERE 公司 == "禾伸堂"	0de5fe57351311e9ab54542696d6e445
qid84	SELECT 2017Q1 , 2017Q2 WHERE 公司 == "禾伸堂"	0de5fe57351311e9ab54542696d6e445
qid85	SELECT MAX ( 倒挂率 ) WHERE 证券简称 == "方直科技" or 证券简称 == "华宇软件"	4d2643873aaa11e9a81df40f24344a08
qid86	SELECT MAX ( 倒挂率 ) WHERE 证券简称 == "方直科技" or 证券简称 == "华宇软件"	4d2643873aaa11e9a81df40f24344a08
qid87	SELECT MAX ( 倒挂率 ) WHERE 证券简称 == "方直科技" or 证券简称 == "华宇软件"	4d2643873aaa11e9a81df40f24344a08
qid88	SELECT SUM ( 营业收入(亿元) ) WHERE 时间 == "2013" or 时间 == "2014" or 时间 == "2015"	c5ab9c4f34b411e9ab54542696d6e445
qid89	SELECT SUM ( 营业收入(亿元) ) WHERE 时间 == "2013" or 时间 == "2014" or 时间 == "2015"	c5ab9c4f34b411e9ab54542696d6e445
qid90	SELECT SUM ( 营业收入(亿元) ) WHERE 时间 == "2013" or 时间 == "2014" or 时间 == "2015"	c5ab9c4f34b411e9ab54542696d6e445
qid91	SELECT 证券代码 WHERE PE19E < "11"	c5aad99734b411e9a17a542696d6e445
qid92	SELECT 证券代码 WHERE PE19E < "11"	c5aad99734b411e9a17a542696d6e445
qid93	SELECT 证券代码 WHERE PE19E < "11"	c5aad99734b411e9a17a542696d6e445
qid94	SELECT 城市名称 WHERE 溢价 > "30"	252ea2c0302e11e9bee5542696d6e445
qid95	SELECT 城市名称 WHERE 溢价 > "30"	252ea2c0302e11e9bee5542696d6e445
qid96	SELECT 城市名称 WHERE 溢价 > "30"	252ea2c0302e11e9bee5542696d6e445
qid97	SELECT COUNT ( 影片名称 ) WHERE 票房占比（%） > "20"	4d29d0513aaa11e9b911f40f24344a08
qid98	SELECT COUNT ( 影片名称 ) WHERE 票房占比（%） > "20"	4d29d0513aaa11e9b911f40f24344a08
qid99	SELECT 证券简称 , 证券代码 WHERE 最新收盘价 < "5"	4d2628b33aaa11e99964f40f24344a08
qid100	SELECT 证券简称 , 证券代码 WHERE 最新收盘价 < "5"	4d2628b33aaa11e99964f40f24344a08
qid101	SELECT 证券简称 , 证券代码 WHERE 最新收盘价 < "5"	4d2628b33aaa11e99964f40f24344a08
qid102	SELECT 成交住宅土地宗数 , 成交住宅建筑面积（万平米） WHERE 时间 == "2010年"	5a4f33ca312b11e9a836542696d6e445
qid103	SELECT 成交住宅土地宗数 , 成交住宅建筑面积（万平米） WHERE 时间 == "2010年"	5a4f33ca312b11e9a836542696d6e445
qid104	SELECT 成交住宅土地宗数 , 成交住宅建筑面积（万平米） WHERE 时间 == "2010年"	5a4f33ca312b11e9a836542696d6e445
qid105	SELECT COUNT ( 城市类型 ) WHERE 同比(5月全月) > "10" and 同比(2012年累计) > "1"	5a4c4f4a312b11e9b41a542696d6e445
qid106	SELECT COUNT ( 城市类型 ) WHERE 同比(5月全月) > "10" and 同比(2012年累计) > "1"	5a4c4f4a312b11e9b41a542696d6e445
qid107	SELECT COUNT ( 城市类型 ) WHERE 同比(5月全月) > "10" and 同比(2012年累计) > "1"	5a4c4f4a312b11e9b41a542696d6e445
qid108	SELECT 营收（亿美元） WHERE 占总收入比重 < "10" or 人均（总乘客数计） < "100"	733be43834c611e9b078542696d6e445
qid109	SELECT 营收（亿美元） WHERE 占总收入比重 < "10" or 人均（总乘客数计） < "100"	733be43834c611e9b078542696d6e445
qid110	SELECT 营收（亿美元） WHERE 占总收入比重 < "10" or 人均（总乘客数计） < "100"	733be43834c611e9b078542696d6e445
qid111	SELECT 股票代码 , 周涨跌幅（%） WHERE 锂电池公司 == "天能动力"	43b035a81d7111e9a9d4f40f24344a08
qid112	SELECT 股票代码 , 周涨跌幅（%） WHERE 锂电池公司 == "天能动力"	43b035a81d7111e9a9d4f40f24344a08
qid113	SELECT 股票代码 , 周涨跌幅（%） WHERE 锂电池公司 == "天能动力"	43b035a81d7111e9a9d4f40f24344a08
qid114	SELECT 影片名称 WHERE 本周票房（万元） > "1000" and 累计票房（万元） > "20000"	4d2521ba3aaa11e9813cf40f24344a08
qid115	SELECT 影片名称 WHERE 本周票房（万元） > "1000" and 累计票房（万元） > "20000"	4d2521ba3aaa11e9813cf40f24344a08
qid116	SELECT 影片名称 WHERE 本周票房（万元） > "1000" and 累计票房（万元） > "20000"	4d2521ba3aaa11e9813cf40f24344a08
qid117	SELECT 证券代码 WHERE 最新收盘价 > "6" or 增发价格 > "6"	4d25ece33aaa11e986d4f40f24344a08
qid118	SELECT 证券代码 WHERE 最新收盘价 > "6" or 增发价格 > "6"	4d25ece33aaa11e986d4f40f24344a08
qid119	SELECT 证券代码 WHERE 最新收盘价 > "6" or 增发价格 > "6"	4d25ece33aaa11e986d4f40f24344a08
qid120	SELECT MAX ( 去年同期 ) WHERE 本年累计 < "200"	5a4aad40312b11e99ced542696d6e445
qid121	SELECT MAX ( 去年同期 ) WHERE 本年累计 < "200"	5a4aad40312b11e99ced542696d6e445
qid122	SELECT MAX ( 去年同期 ) WHERE 本年累计 < "200"	5a4aad40312b11e99ced542696d6e445
qid123	SELECT 城市 , 销量环比 WHERE 本周销量（套） < "2000" or 本周销量（万平米） < "20"	c98e2fe8332111e998d5542696d6e445
qid124	SELECT 城市 , 销量环比 WHERE 本周销量（套） < "2000" or 本周销量（万平米） < "20"	c98e2fe8332111e998d5542696d6e445
qid125	SELECT 城市 , 销量环比 WHERE 本周销量（套） < "2000" or 本周销量（万平米） < "20"	c98e2fe8332111e998d5542696d6e445
qid126	SELECT 影投公司 WHERE 周票房（万） > "500" and 观影人次（万） > "20"	4d29a3f33aaa11e99236f40f24344a08
qid127	SELECT 影投公司 WHERE 周票房（万） > "500" and 观影人次（万） > "20"	4d29a3f33aaa11e99236f40f24344a08
qid128	SELECT 影投公司 WHERE 周票房（万） > "500" and 观影人次（万） > "20"	4d29a3f33aaa11e99236f40f24344a08
qid129	SELECT 省份 WHERE 堆型 == "AP1000" or 总装机容量(Mwe) == "2x1250"	43b3bf6e1d7111e99aa5f40f24344a08
qid130	SELECT 省份 WHERE 堆型 == "AP1000" or 总装机容量(Mwe) == "2x1250"	43b3bf6e1d7111e99aa5f40f24344a08
qid131	SELECT 省份 WHERE 堆型 == "AP1000" or 总装机容量(Mwe) == "2x1250"	43b3bf6e1d7111e99aa5f40f24344a08
qid132	SELECT 锂电池公司 WHERE 月涨跌幅（%） < "-5" and 年涨跌幅%） < "-10"	43b035a81d7111e9a9d4f40f24344a08
qid133	SELECT 锂电池公司 WHERE 月涨跌幅（%） < "-5" and 年涨跌幅%） < "-10"	43b035a81d7111e9a9d4f40f24344a08
qid134	SELECT 绝对量 WHERE 指标 == "住宅" and 同比增长（%） < "10"	c989cc14332111e9acde542696d6e445
qid135	SELECT 绝对量 WHERE 指标 == "住宅" and 同比增长（%） < "10"	c989cc14332111e9acde542696d6e445
qid136	SELECT 绝对量 WHERE 指标 == "住宅" and 同比增长（%） < "10"	c989cc14332111e9acde542696d6e445
qid137	SELECT 证券代码 WHERE 最新市值（亿元） > "50" and 最新股价 > "5"	252c14c5302e11e9b558542696d6e445
qid138	SELECT 证券代码 WHERE 最新市值（亿元） > "50" and 最新股价 > "5"	252c14c5302e11e9b558542696d6e445
qid139	SELECT 证券代码 WHERE 最新市值（亿元） > "50" and 最新股价 > "5"	252c14c5302e11e9b558542696d6e445
qid140	SELECT 城市 WHERE 月成交量 > "1000" and 同比增长 > "100"	252c22ca302e11e9ba97542696d6e445
qid141	SELECT 城市 WHERE 月成交量 > "1000" and 同比增长 > "100"	252c22ca302e11e9ba97542696d6e445
qid142	SELECT 城市 WHERE 月成交量 > "1000" and 同比增长 > "100"	252c22ca302e11e9ba97542696d6e445
qid143	SELECT 市值 WHERE 2018Q3营收同比增速（%） > "0" and 2018Q3净利润同比增速（%） > "0"	733d8a0c34c611e98d5e542696d6e445
qid144	SELECT 市值 WHERE 2018Q3营收同比增速（%） > "0" and 2018Q3净利润同比增速（%） > "0"	733d8a0c34c611e98d5e542696d6e445
qid145	SELECT 市值 WHERE 2018Q3营收同比增速（%） > "0" and 2018Q3净利润同比增速（%） > "0"	733d8a0c34c611e98d5e542696d6e445
qid146	SELECT 上周 WHERE 城市 == "惠州" and 本周 < "10"	c98ca8b3332111e9b120542696d6e445
qid147	SELECT 上周 WHERE 城市 == "惠州" and 本周 < "10"	c98ca8b3332111e9b120542696d6e445
qid148	SELECT 上周 WHERE 城市 == "惠州" and 本周 < "10"	c98ca8b3332111e9b120542696d6e445
qid149	SELECT 倒挂率 WHERE 证券简称 == "海伦钢琴" or 最新收盘价 > "5"	4d265e5e3aaa11e9ba37f40f24344a08
qid150	SELECT 倒挂率 WHERE 证券简称 == "海伦钢琴" or 最新收盘价 > "5"	4d265e5e3aaa11e9ba37f40f24344a08
qid151	SELECT 频道 WHERE 剧名 == "幕后之王" and 收视率（%） > "0.9"	4d26cce83aaa11e9addaf40f24344a08
qid152	SELECT 频道 WHERE 剧名 == "幕后之王" and 收视率（%） > "0.9"	4d26cce83aaa11e9addaf40f24344a08
qid153	SELECT 频道 WHERE 剧名 == "幕后之王" and 收视率（%） > "0.9"	4d26cce83aaa11e9addaf40f24344a08
qid154	SELECT 航空公司 WHERE 退出宽体机 > "0" and 退出窄体机 > "0"	c5adb61e34b411e984e7542696d6e445
qid155	SELECT 航空公司 WHERE 退出宽体机 > "0" and 退出窄体机 > "0"	c5adb61e34b411e984e7542696d6e445
qid156	SELECT 航空公司 WHERE 退出宽体机 > "0" and 退出窄体机 > "0"	c5adb61e34b411e984e7542696d6e445
qid157	SELECT COUNT ( 证券简称 ) WHERE 总市值 > "100" and 总股本 > "30"	c98dd373332111e9b4fb542696d6e445
qid158	SELECT COUNT ( 证券简称 ) WHERE 总市值 > "100" and 总股本 > "30"	c98dd373332111e9b4fb542696d6e445
qid159	SELECT COUNT ( 证券简称 ) WHERE 总市值 > "100" and 总股本 > "30"	c98dd373332111e9b4fb542696d6e445
qid160	SELECT 证券代码 , 证券简称 WHERE 收益 > "0.8"	733d80fd34c611e98d98542696d6e445
qid161	SELECT 证券代码 , 证券简称 WHERE 收益 > "0.8"	733d80fd34c611e98d98542696d6e445
qid162	SELECT 证券代码 , 证券简称 WHERE 收益 > "0.8"	733d80fd34c611e98d98542696d6e445
qid163	SELECT 高速公司 WHERE EPS18E > "1" and EPS19E > "1" and EPS20E > "1"	733c8cd734c611e9b5b2542696d6e445
qid164	SELECT 高速公司 WHERE EPS18E > "1" and EPS19E > "1" and EPS20E > "1"	733c8cd734c611e9b5b2542696d6e445
qid165	SELECT 高速公司 WHERE EPS18E > "1" and EPS19E > "1" and EPS20E > "1"	733c8cd734c611e9b5b2542696d6e445
qid166	SELECT 总地面积 , 区域 WHERE 公司 == "金融街"	5a4efa23312b11e9b5f9542696d6e445
qid167	SELECT 总地面积 , 区域 WHERE 公司 == "金融街"	5a4efa23312b11e9b5f9542696d6e445
qid168	SELECT 总地面积 , 区域 WHERE 公司 == "金融街"	5a4efa23312b11e9b5f9542696d6e445
qid169	SELECT 最新市值（亿港币） WHERE 证券简称 == "花样年控股集团有限公司" and 最新股价 < "1"	e0aecbae333a11e99e03542696d6e445
qid170	SELECT 最新市值（亿港币） WHERE 证券简称 == "花样年控股集团有限公司" and 最新股价 < "1"	e0aecbae333a11e99e03542696d6e445
qid171	SELECT 最新市值（亿港币） WHERE 证券简称 == "花样年控股集团有限公司" and 最新股价 < "1"	e0aecbae333a11e99e03542696d6e445
qid172	SELECT 证券简称 WHERE 10AEPS > "0.5" and 10APE > "10"	e0ae4abd333a11e9be3d542696d6e445
qid173	SELECT 证券简称 WHERE 10AEPS > "0.5" and 10APE > "10"	e0ae4abd333a11e9be3d542696d6e445
qid174	SELECT 证券简称 WHERE 10AEPS > "0.5" and 10APE > "10"	e0ae4abd333a11e9be3d542696d6e445
qid175	SELECT Q1-Q3业务量 WHERE 公司 == "顺丰"	c5acf7e334b411e986d5542696d6e445
qid176	SELECT Q1-Q3业务量 WHERE 公司 == "顺丰"	c5acf7e334b411e986d5542696d6e445
qid177	SELECT Q1-Q3业务量 WHERE 公司 == "顺丰"	c5acf7e334b411e986d5542696d6e445
qid178	SELECT 子行业 WHERE 子行业市值(亿） > "3,677.69" or 指数涨跌幅 > "-30"	0de5a3b8351311e9ba1b542696d6e445
qid179	SELECT 子行业 WHERE 子行业市值(亿） > "3,677.69" or 指数涨跌幅 > "-30"	0de5a3b8351311e9ba1b542696d6e445
qid180	SELECT 子行业 WHERE 子行业市值(亿） > "3,677.69" or 指数涨跌幅 > "-30"	0de5a3b8351311e9ba1b542696d6e445
qid181	SELECT 净资产（亿元） WHERE 证券简称 == "新华文轩"	4d2855543aaa11e9b545f40f24344a08
qid182	SELECT 净资产（亿元） WHERE 证券简称 == "新华文轩"	4d2855543aaa11e9b545f40f24344a08
qid183	SELECT 净资产（亿元） WHERE 证券简称 == "新华文轩"	4d2855543aaa11e9b545f40f24344a08
qid184	SELECT 城市 WHERE 2012年日均成交 < "5"	69cfbfe3334311e99ef4542696d6e445
qid185	SELECT 城市 WHERE 2012年日均成交 < "5"	69cfbfe3334311e99ef4542696d6e445
qid186	SELECT 城市 WHERE 2012年日均成交 < "5"	69cfbfe3334311e99ef4542696d6e445
qid187	SELECT 城市 WHERE 2010成交面积 > "3333"	69d54b82334311e98c61542696d6e445
qid188	SELECT 城市 WHERE 2010成交面积 > "3333"	69d54b82334311e98c61542696d6e445
qid189	SELECT 城市 WHERE 2010成交面积 > "3333"	69d54b82334311e98c61542696d6e445
qid190	SELECT 代码 , 股价 WHERE 公司 == "柳工"	69cf2175334311e99a42542696d6e445
qid191	SELECT 代码 , 股价 WHERE 公司 == "柳工"	69cf2175334311e99a42542696d6e445
qid192	SELECT 代码 , 股价 WHERE 公司 == "柳工"	69cf2175334311e99a42542696d6e445
qid193	SELECT 指标名称 WHERE 较上月 < "-1" and 较上年 > "1"	c5ae457034b411e98c59542696d6e445
qid194	SELECT 指标名称 WHERE 较上月 < "-1" and 较上年 > "1"	c5ae457034b411e98c59542696d6e445
qid195	SELECT 指标名称 WHERE 较上月 < "-1" and 较上年 > "1"	c5ae457034b411e98c59542696d6e445
qid196	SELECT 证券简称 WHERE 收盘价(元) > "10" and 总股本(亿股) > "20"	69d408a8334311e9ab90542696d6e445
qid197	SELECT 证券简称 WHERE 收盘价(元) > "10" and 总股本(亿股) > "20"	69d408a8334311e9ab90542696d6e445
qid198	SELECT 证券简称 WHERE 收盘价(元) > "10" and 总股本(亿股) > "20"	69d408a8334311e9ab90542696d6e445
qid199	SELECT 证券简称 WHERE 收盘价(元) > "10" and 总股本(亿股) > "20"	69d408a8334311e9ab90542696d6e445
qid200	SELECT 4月27日收盘价 , 5月31日收盘价 WHERE 简称 == "金丰投资"	25328d40302e11e9bf45542696d6e445
qid201	SELECT 4月27日收盘价 , 5月31日收盘价 WHERE 简称 == "金丰投资"	25328d40302e11e9bf45542696d6e445
qid202	SELECT 4月27日收盘价 , 5月31日收盘价 WHERE 简称 == "金丰投资"	25328d40302e11e9bf45542696d6e445
qid203	SELECT 近4周周均成交环比 WHERE 城市 == "济南" and 近4周周均成交 > "500"	69ccadd7334311e99873542696d6e445
qid204	SELECT 近4周周均成交环比 WHERE 城市 == "济南" and 近4周周均成交 > "500"	69ccadd7334311e99873542696d6e445
qid205	SELECT 近4周周均成交环比 WHERE 城市 == "济南" and 近4周周均成交 > "500"	69ccadd7334311e99873542696d6e445
qid206	SELECT 股票代码 , 周涨跌幅 WHERE 股票简称 == "深中华A"	43b2b6a11d7111e9a211f40f24344a08
qid207	SELECT 股票代码 , 周涨跌幅 WHERE 股票简称 == "深中华A"	43b2b6a11d7111e9a211f40f24344a08
qid208	SELECT 股票代码 , 周涨跌幅 WHERE 股票简称 == "深中华A"	43b2b6a11d7111e9a211f40f24344a08
qid209	SELECT 证券代码 WHERE 证券简称 == "凯撒文化" or 证券简称 == "三七互娱"	4d20d9de3aaa11e9a521f40f24344a08
qid210	SELECT 证券代码 WHERE 证券简称 == "凯撒文化" or 证券简称 == "三七互娱"	4d20d9de3aaa11e9a521f40f24344a08
qid211	SELECT 证券代码 WHERE 证券简称 == "凯撒文化" or 证券简称 == "三七互娱"	4d20d9de3aaa11e9a521f40f24344a08
qid212	SELECT 城市 WHERE 本周环比 < "52"	c98c8c9c332111e99ae0542696d6e445
qid213	SELECT 城市 WHERE 本周环比 < "52"	c98c8c9c332111e99ae0542696d6e445
qid214	SELECT 城市 WHERE 本周环比 < "52"	c98c8c9c332111e99ae0542696d6e445
qid215	SELECT 名称 WHERE 收盘价 > "10" and 周涨跌幅 > "10"	4d25793a3aaa11e9b754f40f24344a08
qid216	SELECT 名称 WHERE 收盘价 > "10" and 周涨跌幅 > "10"	4d25793a3aaa11e9b754f40f24344a08
qid217	SELECT 名称 WHERE 收盘价 > "10" and 周涨跌幅 > "10"	4d25793a3aaa11e9b754f40f24344a08
qid218	SELECT 股票代码 WHERE PE-TTM < "0"	43afe8f01d7111e99f11f40f24344a08
qid219	SELECT 股票代码 WHERE PE-TTM < "0"	43afe8f01d7111e99f11f40f24344a08
qid220	SELECT 股票代码 WHERE PE-TTM < "0"	43afe8f01d7111e99f11f40f24344a08
qid221	SELECT 2012年3月成交量环比 WHERE 2012年4月成交量环比 < "5"	69d14c3a334311e9b68e542696d6e445
qid222	SELECT 2012年3月成交量环比 WHERE 2012年4月成交量环比 < "5"	69d14c3a334311e9b68e542696d6e445
qid223	SELECT 2012年3月成交量环比 WHERE 2012年4月成交量环比 < "5"	69d14c3a334311e9b68e542696d6e445
qid224	SELECT COUNT ( 公司名称 ) WHERE PE2013E > "6"	69d2a666334311e9acbf542696d6e445
qid225	SELECT COUNT ( 公司名称 ) WHERE PE2013E > "6"	69d2a666334311e9acbf542696d6e445
qid226	SELECT COUNT ( 公司名称 ) WHERE PE2013E > "6"	69d2a666334311e9acbf542696d6e445
qid227	SELECT SUM ( 营收（亿美元） ) WHERE 辅助业务项目 == "常旅客计划" or 辅助业务项目 == "行李费"	733be43834c611e9b078542696d6e445
qid228	SELECT SUM ( 营收（亿美元） ) WHERE 辅助业务项目 == "常旅客计划" or 辅助业务项目 == "行李费"	733be43834c611e9b078542696d6e445
qid229	SELECT SUM ( 营收（亿美元） ) WHERE 辅助业务项目 == "常旅客计划" or 辅助业务项目 == "行李费"	733be43834c611e9b078542696d6e445
qid230	SELECT 企业 WHERE 扩产产能（吨） > "7000" and 总投资(亿元） > "5"	733bd8c534c611e9ac79542696d6e445
qid231	SELECT 企业 WHERE 扩产产能（吨） > "7000" and 总投资(亿元） > "5"	733bd8c534c611e9ac79542696d6e445
qid232	SELECT 企业 WHERE 扩产产能（吨） > "7000" and 总投资(亿元） > "5"	733bd8c534c611e9ac79542696d6e445
qid233	SELECT SUM ( 播放量（万） ) WHERE 播出平台 == "芒果TV"	4d2922cc3aaa11e9bcc4f40f24344a08
qid234	SELECT SUM ( 播放量（万） ) WHERE 播出平台 == "芒果TV"	4d2922cc3aaa11e9bcc4f40f24344a08
qid235	SELECT SUM ( 播放量（万） ) WHERE 播出平台 == "芒果TV"	4d2922cc3aaa11e9bcc4f40f24344a08
qid236	SELECT SUM ( 播放量（万） ) WHERE 播出平台 == "芒果TV"	4d2922cc3aaa11e9bcc4f40f24344a08
qid237	SELECT SUM ( 播放量（万） ) WHERE 播出平台 == "芒果TV"	4d2922cc3aaa11e9bcc4f40f24344a08
qid238	SELECT COUNT ( 城市 ) WHERE 成交面积同比11年 > "10" and 成交面积同比10年 > "10"	69d4c5f3334311e988bc542696d6e445
qid239	SELECT COUNT ( 城市 ) WHERE 成交面积同比11年 > "10" and 成交面积同比10年 > "10"	69d4c5f3334311e988bc542696d6e445
qid240	SELECT COUNT ( 城市 ) WHERE 成交面积同比11年 > "10" and 成交面积同比10年 > "10"	69d4c5f3334311e988bc542696d6e445
qid241	SELECT 公司名称 WHERE 销售收入排名 < "4" and 同比增长率 < "15"	43b27b231d7111e99c07f40f24344a08
qid242	SELECT 公司名称 WHERE 销售收入排名 < "4" and 同比增长率 < "15"	43b27b231d7111e99c07f40f24344a08
qid243	SELECT 公司名称 WHERE 销售收入排名 < "4" and 同比增长率 < "15"	43b27b231d7111e99c07f40f24344a08
qid244	SELECT MAX ( 上周均成交面积 ) WHERE 本周均成交面积 < "10"	c98e1c19332111e9ab43542696d6e445
qid245	SELECT MAX ( 上周均成交面积 ) WHERE 本周均成交面积 < "10"	c98e1c19332111e9ab43542696d6e445
qid246	SELECT MAX ( 上周均成交面积 ) WHERE 本周均成交面积 < "10"	c98e1c19332111e9ab43542696d6e445
qid247	SELECT AVG ( 同比 ) WHERE 近4周周均成交 > "500" and 近4周周均成交环比 > "1"	69ccadd7334311e99873542696d6e445
qid248	SELECT AVG ( 同比 ) WHERE 近4周周均成交 > "500" and 近4周周均成交环比 > "1"	69ccadd7334311e99873542696d6e445
qid249	SELECT AVG ( 同比 ) WHERE 近4周周均成交 > "500" and 近4周周均成交环比 > "1"	69ccadd7334311e99873542696d6e445
qid250	SELECT 跌股名称 WHERE 周涨幅（%） < "10.07"	43ae7f9c1d7111e9bc7af40f24344a08
qid251	SELECT 跌股名称 WHERE 周涨幅（%） < "10.07"	43ae7f9c1d7111e9bc7af40f24344a08
qid252	SELECT 跌股名称 WHERE 周涨幅（%） < "10.07"	43ae7f9c1d7111e9bc7af40f24344a08
qid253	SELECT 证券代码 , 公司名称 WHERE 最新股价 > "10"	69d2a666334311e9acbf542696d6e445
qid254	SELECT 证券代码 , 公司名称 WHERE 最新股价 > "10"	69d2a666334311e9acbf542696d6e445
qid255	SELECT 证券代码 , 公司名称 WHERE 最新股价 > "10"	69d2a666334311e9acbf542696d6e445
qid256	SELECT 城市 WHERE 日成交 > "2" and 日成交环比 > "10"	69d3ef45334311e9977a542696d6e445
qid257	SELECT 城市 WHERE 日成交 > "2" and 日成交环比 > "10"	69d3ef45334311e9977a542696d6e445
qid258	SELECT 城市 WHERE 日成交 > "2" and 日成交环比 > "10"	69d3ef45334311e9977a542696d6e445
qid259	SELECT 5月均价(元/㎡) WHERE 楼盘名称 == "龙湖长楹天街" or 楼盘名称 == "专家国际公馆"	5a4f9470312b11e9aa31542696d6e445
qid260	SELECT 5月均价(元/㎡) WHERE 楼盘名称 == "龙湖长楹天街" or 楼盘名称 == "专家国际公馆"	5a4f9470312b11e9aa31542696d6e445
qid261	SELECT 5月均价(元/㎡) WHERE 楼盘名称 == "龙湖长楹天街" or 楼盘名称 == "专家国际公馆"	5a4f9470312b11e9aa31542696d6e445
qid262	SELECT COUNT ( 楼盘 ) WHERE 楼盘均价 > "10000" and 楼盘容积率 > "1"	c98987cc332111e9865a542696d6e445
qid263	SELECT COUNT ( 楼盘 ) WHERE 楼盘均价 > "10000" and 楼盘容积率 > "1"	c98987cc332111e9865a542696d6e445
qid264	SELECT COUNT ( 楼盘 ) WHERE 楼盘均价 > "10000" and 楼盘容积率 > "1"	c98987cc332111e9865a542696d6e445
qid265	SELECT 日熔量（吨） WHERE 产线名称 == "迎新二线"	43af9d8c1d7111e99f1ef40f24344a08
qid266	SELECT 日熔量（吨） WHERE 产线名称 == "迎新二线"	43af9d8c1d7111e99f1ef40f24344a08
qid267	SELECT COUNT ( 公司简称 ) WHERE PE-17 > "10" and PE-18E > "5"	0155563d351311e9b279542696d6e445
qid268	SELECT COUNT ( 公司简称 ) WHERE PE-17 > "10" and PE-18E > "5"	0155563d351311e9b279542696d6e445
qid269	SELECT COUNT ( 公司简称 ) WHERE PE-17 > "10" and PE-18E > "5"	0155563d351311e9b279542696d6e445
qid270	SELECT 2017 WHERE 项目/年度 == "净利润(百万元)" and 2016 > "1"	c5ad95dc34b411e9ad08542696d6e445
qid271	SELECT 2017 WHERE 项目/年度 == "净利润(百万元)" and 2016 > "1"	c5ad95dc34b411e9ad08542696d6e445
qid272	SELECT 2017 WHERE 项目/年度 == "净利润(百万元)" and 2016 > "1"	c5ad95dc34b411e9ad08542696d6e445
qid273	SELECT MAX ( 理论PB ) WHERE 股权比例 > "10" and 利润率 > "20"	5a4f2a9e312b11e9b02e542696d6e445
qid274	SELECT MAX ( 理论PB ) WHERE 股权比例 > "10" and 利润率 > "20"	5a4f2a9e312b11e9b02e542696d6e445
qid275	SELECT MAX ( 理论PB ) WHERE 股权比例 > "10" and 利润率 > "20"	5a4f2a9e312b11e9b02e542696d6e445
qid276	SELECT 机场 , 旅客吞吐量（万人） WHERE 城市 == "芝加哥"	c5ac8b7d34b411e99161542696d6e445
qid277	SELECT 机场 , 旅客吞吐量（万人） WHERE 城市 == "芝加哥"	c5ac8b7d34b411e99161542696d6e445
qid278	SELECT 机场 , 旅客吞吐量（万人） WHERE 城市 == "芝加哥"	c5ac8b7d34b411e99161542696d6e445
qid279	SELECT 本周涨跌幅（%） WHERE 本周换手率（%） < "18"	733bc10f34c611e988ef542696d6e445
qid280	SELECT 本周涨跌幅（%） WHERE 本周换手率（%） < "18"	733bc10f34c611e988ef542696d6e445
qid281	SELECT 本周涨跌幅（%） WHERE 本周换手率（%） < "18"	733bc10f34c611e988ef542696d6e445
qid282	SELECT 净利润上限（亿元） WHERE 证券代码 == "光线传媒" or 证券代码 == "鹿港文化"	4d24b4333aaa11e98abbf40f24344a08
qid283	SELECT 净利润上限（亿元） WHERE 证券代码 == "光线传媒" or 证券代码 == "鹿港文化"	4d24b4333aaa11e98abbf40f24344a08
qid284	SELECT 净利润上限（亿元） WHERE 证券代码 == "光线传媒" or 证券代码 == "鹿港文化"	4d24b4333aaa11e98abbf40f24344a08
qid285	SELECT 本周 , 上周 WHERE 城市 == "石家庄"	c98c9430332111e9b83a542696d6e445
qid286	SELECT 本周 , 上周 WHERE 城市 == "石家庄"	c98c9430332111e9b83a542696d6e445
qid287	SELECT 本周 , 上周 WHERE 城市 == "石家庄"	c98c9430332111e9b83a542696d6e445
qid288	SELECT 公司 WHERE 2012年销售额 > "30" and 1H2011销售额 > "30"	69d22bb3334311e981da542696d6e445
qid289	SELECT 公司 WHERE 2012年销售额 > "30" and 1H2011销售额 > "30"	69d22bb3334311e981da542696d6e445
qid290	SELECT 公司 WHERE 2012年销售额 > "30" and 1H2011销售额 > "30"	69d22bb3334311e981da542696d6e445
qid291	SELECT 时间 WHERE 累计值同比增速 > "5" and 一线同比增速 > "10"	e0abf93a333a11e9a104542696d6e445
qid292	SELECT 时间 WHERE 累计值同比增速 > "5" and 一线同比增速 > "10"	e0abf93a333a11e9a104542696d6e445
qid293	SELECT 时间 WHERE 累计值同比增速 > "5" and 一线同比增速 > "10"	e0abf93a333a11e9a104542696d6e445
qid294	SELECT 公司名称 WHERE 最新股价 > "10" or EPS2011 > "1"	69d29a23334311e99c4d542696d6e445
qid295	SELECT 公司名称 WHERE 最新股价 > "10" or EPS2011 > "1"	69d29a23334311e99c4d542696d6e445
qid296	SELECT 公司名称 WHERE 最新股价 > "10" or EPS2011 > "1"	69d29a23334311e99c4d542696d6e445
qid297	SELECT MAX ( 同比 ) WHERE 本周均成交面积 > "2" and 上周均成交面积 > "2"	c98e1c19332111e9ab43542696d6e445
qid298	SELECT MAX ( 同比 ) WHERE 本周均成交面积 > "2" and 上周均成交面积 > "2"	c98e1c19332111e9ab43542696d6e445
qid299	SELECT MAX ( 同比 ) WHERE 本周均成交面积 > "2" and 上周均成交面积 > "2"	c98e1c19332111e9ab43542696d6e445
qid300	SELECT 城市 , 本周均成交面积 WHERE 同比 > "100"	c98e1c19332111e9ab43542696d6e445
qid301	SELECT 城市 , 本周均成交面积 WHERE 同比 > "100"	c98e1c19332111e9ab43542696d6e445
qid302	SELECT 城市 , 本周均成交面积 WHERE 同比 > "100"	c98e1c19332111e9ab43542696d6e445
qid303	SELECT 股票名称 WHERE 收盘价（元） < "5" and 周涨跌（%） < "1"	43ada6801d7111e998e8f40f24344a08
qid304	SELECT 股票名称 WHERE 收盘价（元） < "5" and 周涨跌（%） < "1"	43ada6801d7111e998e8f40f24344a08
qid305	SELECT 股票名称 WHERE 收盘价（元） < "5" and 周涨跌（%） < "1"	43ada6801d7111e998e8f40f24344a08
qid306	SELECT 线路名称 WHERE 线路长度（公里） > "200" and 通车时间 == "2018年底"	43b30e991d7111e98754f40f24344a08
qid307	SELECT 线路名称 WHERE 线路长度（公里） > "200" and 通车时间 == "2018年底"	43b30e991d7111e98754f40f24344a08
qid308	SELECT 线路名称 WHERE 线路长度（公里） > "200" and 通车时间 == "2018年底"	43b30e991d7111e98754f40f24344a08
qid309	SELECT 折价率 WHERE 总市值（亿元） < "100" or PB < "2"	69cf2f21334311e9b2e5542696d6e445
qid310	SELECT 折价率 WHERE 总市值（亿元） < "100" or PB < "2"	69cf2f21334311e9b2e5542696d6e445
qid311	SELECT 折价率 WHERE 总市值（亿元） < "100" or PB < "2"	69cf2f21334311e9b2e5542696d6e445
qid312	SELECT 证券简称 WHERE 定增年度 == "2017" and 增发目的 == "项目融资"	4d263cee3aaa11e989cef40f24344a08
qid313	SELECT 证券简称 WHERE 定增年度 == "2017" and 增发目的 == "项目融资"	4d263cee3aaa11e989cef40f24344a08
qid314	SELECT 证券简称 WHERE 定增年度 == "2017" and 增发目的 == "项目融资"	4d263cee3aaa11e989cef40f24344a08
qid315	SELECT 营业收入 WHERE 证券简称 == "木林森"	0de680cf351311e9bde3542696d6e445
qid316	SELECT 营业收入 WHERE 证券简称 == "木林森"	0de680cf351311e9bde3542696d6e445
qid317	SELECT 营业收入 WHERE 证券简称 == "木林森"	0de680cf351311e9bde3542696d6e445
qid318	SELECT COUNT ( 简称 ) WHERE 本周涨跌幅 < "0" and 本月涨跌幅 < "0" and 年涨跌幅 < "0"	733c4cb334c611e9b645542696d6e445
qid319	SELECT COUNT ( 简称 ) WHERE 本周涨跌幅 < "0" and 本月涨跌幅 < "0" and 年涨跌幅 < "0"	733c4cb334c611e9b645542696d6e445
qid320	SELECT COUNT ( 简称 ) WHERE 本周涨跌幅 < "0" and 本月涨跌幅 < "0" and 年涨跌幅 < "0"	733c4cb334c611e9b645542696d6e445
qid321	SELECT COUNT ( 2016排名 ) WHERE 总部所在地 == "美国"	0156b28f351311e9bc46542696d6e445
qid322	SELECT COUNT ( 2016排名 ) WHERE 总部所在地 == "美国"	0156b28f351311e9bc46542696d6e445
qid323	SELECT COUNT ( 2016排名 ) WHERE 总部所在地 == "美国"	0156b28f351311e9bc46542696d6e445
qid324	SELECT MAX ( 变化率 ) WHERE 区域 == "深圳" and 年初至今累计销售面积 > "100"	69d2f094334311e98009542696d6e445
qid325	SELECT MAX ( 变化率 ) WHERE 区域 == "深圳" and 年初至今累计销售面积 > "100"	69d2f094334311e98009542696d6e445
qid326	SELECT MAX ( 变化率 ) WHERE 区域 == "深圳" and 年初至今累计销售面积 > "100"	69d2f094334311e98009542696d6e445
qid327	SELECT COUNT ( 城市 ) WHERE 本周均成交面积 > "5" and 上周均成交面积 > "5"	c98e25e8332111e994d8542696d6e445
qid328	SELECT COUNT ( 城市 ) WHERE 本周均成交面积 > "5" and 上周均成交面积 > "5"	c98e25e8332111e994d8542696d6e445
qid329	SELECT COUNT ( 城市 ) WHERE 本周均成交面积 > "5" and 上周均成交面积 > "5"	c98e25e8332111e994d8542696d6e445
qid330	SELECT 游戏 WHERE 发行方 == "腾讯"	4d26ad593aaa11e9b923f40f24344a08
qid331	SELECT 游戏 WHERE 发行方 == "腾讯"	4d26ad593aaa11e9b923f40f24344a08
qid332	SELECT 游戏 WHERE 发行方 == "腾讯"	4d26ad593aaa11e9b923f40f24344a08
qid333	SELECT 城市 WHERE 上周成交量（套） < "1000" or 成交量同比增长 < "10"	69d45ec0334311e98719542696d6e445
qid334	SELECT 城市 WHERE 上周成交量（套） < "1000" or 成交量同比增长 < "10"	69d45ec0334311e98719542696d6e445
qid335	SELECT 城市 WHERE 上周成交量（套） < "1000" or 成交量同比增长 < "10"	69d45ec0334311e98719542696d6e445
qid336	SELECT 飞机起降(万架次) WHERE 旅客吞吐量(万人) == "412.45" and 机场 == "深圳机场"	c5acddf334b411e9b79a542696d6e445
qid337	SELECT 飞机起降(万架次) WHERE 旅客吞吐量(万人) == "412.45" and 机场 == "深圳机场"	c5acddf334b411e9b79a542696d6e445
qid338	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 > "3" or 最新涨跌幅 > "2"	c5ad3b9734b411e9a5f6542696d6e445
qid339	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 > "3" or 最新涨跌幅 > "2"	c5ad3b9734b411e9a5f6542696d6e445
qid340	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 > "3" or 最新涨跌幅 > "2"	c5ad3b9734b411e9a5f6542696d6e445
qid341	SELECT MAX ( 收视率% ) WHERE 名称 == "声入人心" or 名称 == "金牌调解"	4d2a21423aaa11e9840af40f24344a08
qid342	SELECT MAX ( 收视率% ) WHERE 名称 == "声入人心" or 名称 == "金牌调解"	4d2a21423aaa11e9840af40f24344a08
qid343	SELECT 营收同比 WHERE 公司 == "韵达股份" and 快递业务营收(亿元) > "10"	c5accda834b411e9beb7542696d6e445
qid344	SELECT 营收同比 WHERE 公司 == "韵达股份" and 快递业务营收(亿元) > "10"	c5accda834b411e9beb7542696d6e445
qid345	SELECT 营收同比 WHERE 公司 == "韵达股份" and 快递业务营收(亿元) > "10"	c5accda834b411e9beb7542696d6e445
qid346	SELECT 公司简称 , 股票代码 WHERE 周涨跌幅（%） > "1" and 月涨跌幅（%） > "1"	e0ac4d54333a11e98222542696d6e445
qid347	SELECT 公司简称 , 股票代码 WHERE 周涨跌幅（%） > "1" and 月涨跌幅（%） > "1"	e0ac4d54333a11e98222542696d6e445
qid348	SELECT 公司简称 , 股票代码 WHERE 周涨跌幅（%） > "1" and 月涨跌幅（%） > "1"	e0ac4d54333a11e98222542696d6e445
qid349	SELECT 指标名称 WHERE 较上年 > "0" or 较上月 > "0"	c5ae457034b411e98c59542696d6e445
qid350	SELECT 指标名称 WHERE 较上年 > "0" or 较上月 > "0"	c5ae457034b411e98c59542696d6e445
qid351	SELECT 指标名称 WHERE 较上年 > "0" or 较上月 > "0"	c5ae457034b411e98c59542696d6e445
qid352	SELECT 股价 , EPS18E WHERE 公司 == "中远海能"	733cc09134c611e9ad68542696d6e445
qid353	SELECT 股价 , EPS18E WHERE 公司 == "中远海能"	733cc09134c611e9ad68542696d6e445
qid354	SELECT 股价 , EPS18E WHERE 公司 == "中远海能"	733cc09134c611e9ad68542696d6e445
qid355	SELECT 证券简称 WHERE EPS17A < "0.5" and EPS18E < "0.5" and EPS19E < "0.5"	4d28b0303aaa11e9bd3ef40f24344a08
qid356	SELECT 证券简称 WHERE EPS17A < "0.5" and EPS18E < "0.5" and EPS19E < "0.5"	4d28b0303aaa11e9bd3ef40f24344a08
qid357	SELECT 证券简称 WHERE EPS17A < "0.5" and EPS18E < "0.5" and EPS19E < "0.5"	4d28b0303aaa11e9bd3ef40f24344a08
qid358	SELECT 变化率 WHERE 本周销售套数 > "1000"	69d2d58a334311e998d7542696d6e445
qid359	SELECT 变化率 WHERE 本周销售套数 > "1000"	69d2d58a334311e998d7542696d6e445
qid360	SELECT 变化率 WHERE 本周销售套数 > "1000"	69d2d58a334311e998d7542696d6e445
qid361	SELECT 公司 WHERE 净利率 > "20" and 资产负债率 > "20"	733ca0d934c611e984ca542696d6e445
qid362	SELECT 公司 WHERE 净利率 > "20" and 资产负债率 > "20"	733ca0d934c611e984ca542696d6e445
qid363	SELECT 公司 WHERE 净利率 > "20" and 资产负债率 > "20"	733ca0d934c611e984ca542696d6e445
qid364	SELECT SUM ( 4月套数 ) WHERE 楼盘名称 == "花语城" and 楼盘名称 == "筑华年"	c98c1885332111e9bc50542696d6e445
qid365	SELECT SUM ( 4月套数 ) WHERE 楼盘名称 == "花语城" and 楼盘名称 == "筑华年"	c98c1885332111e9bc50542696d6e445
qid366	SELECT SUM ( 4月套数 ) WHERE 楼盘名称 == "花语城" and 楼盘名称 == "筑华年"	c98c1885332111e9bc50542696d6e445
qid367	SELECT 货币资金（亿元） WHERE 货币资金/总资产 < "20" and 货币资金/净资产 < "20"	4d2860ab3aaa11e98eb5f40f24344a08
qid368	SELECT 货币资金（亿元） WHERE 货币资金/总资产 < "20" and 货币资金/净资产 < "20"	4d2860ab3aaa11e98eb5f40f24344a08
qid369	SELECT 货币资金（亿元） WHERE 货币资金/总资产 < "20" and 货币资金/净资产 < "20"	4d2860ab3aaa11e98eb5f40f24344a08
qid370	SELECT 所在省份 , 产线名称 WHERE 日熔量（吨） < "600"	43af98331d7111e98888f40f24344a08
qid371	SELECT 所在省份 , 产线名称 WHERE 日熔量（吨） < "600"	43af98331d7111e98888f40f24344a08
qid372	SELECT 所在省份 , 产线名称 WHERE 日熔量（吨） < "600"	43af98331d7111e98888f40f24344a08
qid373	SELECT 证券简称 WHERE 证券代码 == "000802.SZ" or 公告日 == "2019年1月22日"	4d253f0f3aaa11e9b53ff40f24344a08
qid374	SELECT 证券简称 WHERE 证券代码 == "000802.SZ" or 公告日 == "2019年1月22日"	4d253f0f3aaa11e9b53ff40f24344a08
qid375	SELECT 证券简称 WHERE 证券代码 == "000802.SZ" or 公告日 == "2019年1月22日"	4d253f0f3aaa11e9b53ff40f24344a08
qid376	SELECT 证券简称 WHERE 定增价除权后至今价格 > "5" and 定增年度 == "2015"	4d2619f83aaa11e98862f40f24344a08
qid377	SELECT 证券简称 WHERE 定增价除权后至今价格 > "5" and 定增年度 == "2015"	4d2619f83aaa11e98862f40f24344a08
qid378	SELECT 证券简称 WHERE 定增价除权后至今价格 > "5" and 定增年度 == "2015"	4d2619f83aaa11e98862f40f24344a08
qid379	SELECT 证券简称 WHERE 2014 != "1111"	69ce143d334311e9a60a542696d6e445
qid380	SELECT MAX ( 货币资金（亿元） ) WHERE 总资产（亿元） > "100" or 净资产（亿元） > "100"	4d285ad93aaa11e9912bf40f24344a08
qid381	SELECT MAX ( 货币资金（亿元） ) WHERE 总资产（亿元） > "100" or 净资产（亿元） > "100"	4d285ad93aaa11e9912bf40f24344a08
qid382	SELECT MAX ( 货币资金（亿元） ) WHERE 总资产（亿元） > "100" or 净资产（亿元） > "100"	4d285ad93aaa11e9912bf40f24344a08
qid383	SELECT 股价 , EPS17A WHERE 铁路公司 == "广深铁路"	733c977834c611e99f1e542696d6e445
qid384	SELECT 股价 , EPS17A WHERE 铁路公司 == "广深铁路"	733c977834c611e99f1e542696d6e445
qid385	SELECT 股价 , EPS17A WHERE 铁路公司 == "广深铁路"	733c977834c611e99f1e542696d6e445
qid386	SELECT 公司名称 WHERE PB估值 < "1.22"	69cfabd1334311e9bb3b542696d6e445
qid387	SELECT 公司名称 WHERE PB估值 < "1.22"	69cfabd1334311e9bb3b542696d6e445
qid388	SELECT 公司名称 WHERE PB估值 < "1.22"	69cfabd1334311e9bb3b542696d6e445
qid389	SELECT 公司简称 WHERE 总市值 > "100" and 每股净资产 > "10"	5a4f48f8312b11e99b2a542696d6e445
qid390	SELECT 公司简称 WHERE 总市值 > "100" and 每股净资产 > "10"	5a4f48f8312b11e99b2a542696d6e445
qid391	SELECT 公司简称 WHERE 总市值 > "100" and 每股净资产 > "10"	5a4f48f8312b11e99b2a542696d6e445
qid392	SELECT 城市 , 库存-套 WHERE 本周价格较11年均值增长 > "12"	2531a266302e11e98644542696d6e445
qid393	SELECT 城市 , 库存-套 WHERE 本周价格较11年均值增长 > "12"	2531a266302e11e98644542696d6e445
qid394	SELECT 城市 , 库存-套 WHERE 本周价格较11年均值增长 > "12"	2531a266302e11e98644542696d6e445
qid395	SELECT 涨幅（%） WHERE 名称 == "白云机场"	c5ac75e334b411e99e95542696d6e445
qid396	SELECT 涨幅（%） WHERE 名称 == "白云机场"	c5ac75e334b411e99e95542696d6e445
qid397	SELECT 涨幅（%） WHERE 名称 == "白云机场"	c5ac75e334b411e99e95542696d6e445
qid398	SELECT 公司 WHERE 2018E绝对值 > "600" and 2019E绝对值 > "600"	0155ce33351311e9ae3c542696d6e445
qid399	SELECT 公司 WHERE 2018E绝对值 > "600" and 2019E绝对值 > "600"	0155ce33351311e9ae3c542696d6e445
qid400	SELECT 公司 WHERE 2018E绝对值 > "600" and 2019E绝对值 > "600"	0155ce33351311e9ae3c542696d6e445
qid401	SELECT 城市 WHERE 目前 < "8" or 11年底 < "10"	c98bf9d9332111e99583542696d6e445
qid402	SELECT 城市 WHERE 目前 < "8" or 11年底 < "10"	c98bf9d9332111e99583542696d6e445
qid403	SELECT 城市 WHERE 目前 < "8" or 11年底 < "10"	c98bf9d9332111e99583542696d6e445
qid404	SELECT COUNT ( 名称 ) WHERE 线路长度(公里） > "400" and 速度（km/h) == "350"	e0ac610c333a11e99aa7542696d6e445
qid405	SELECT COUNT ( 名称 ) WHERE 线路长度(公里） > "400" and 速度（km/h) == "350"	e0ac610c333a11e99aa7542696d6e445
qid406	SELECT COUNT ( 名称 ) WHERE 线路长度(公里） > "400" and 速度（km/h) == "350"	e0ac610c333a11e99aa7542696d6e445
qid407	SELECT MAX ( 大型金融机构调整幅度 ) WHERE 大型金融机构调整前 > "20" or 大型金融机构调整后 > "20"	5a4eb578312b11e98160542696d6e445
qid408	SELECT MAX ( 大型金融机构调整幅度 ) WHERE 大型金融机构调整前 > "20" or 大型金融机构调整后 > "20"	5a4eb578312b11e98160542696d6e445
qid409	SELECT MAX ( 大型金融机构调整幅度 ) WHERE 大型金融机构调整前 > "20" or 大型金融机构调整后 > "20"	5a4eb578312b11e98160542696d6e445
qid410	SELECT 游戏 , 开发商 WHERE 服务器 > "100"	4d2706753aaa11e9be22f40f24344a08
qid411	SELECT 游戏 , 开发商 WHERE 服务器 > "100"	4d2706753aaa11e9be22f40f24344a08
qid412	SELECT 游戏 , 开发商 WHERE 服务器 > "100"	4d2706753aaa11e9be22f40f24344a08
qid413	SELECT MIN ( 总投资(亿元） ) WHERE 扩产产能（吨） > "5000" or 单位投资（亿元/万吨） > "6"	733bd8c534c611e9ac79542696d6e445
qid414	SELECT MIN ( 总投资(亿元） ) WHERE 扩产产能（吨） > "5000" or 单位投资（亿元/万吨） > "6"	733bd8c534c611e9ac79542696d6e445
qid415	SELECT MIN ( 总投资(亿元） ) WHERE 扩产产能（吨） > "5000" or 单位投资（亿元/万吨） > "6"	733bd8c534c611e9ac79542696d6e445
qid416	SELECT 总市值（亿美元） WHERE 证券简称 == "爱奇艺"	4d2420113aaa11e9b9c1f40f24344a08
qid417	SELECT 总市值（亿美元） WHERE 证券简称 == "爱奇艺"	4d2420113aaa11e9b9c1f40f24344a08
qid418	SELECT 总市值（亿美元） WHERE 证券简称 == "爱奇艺"	4d2420113aaa11e9b9c1f40f24344a08
qid419	SELECT 折价率 , 评级 WHERE 股价 < "10"	69cf6802334311e9aca4542696d6e445
qid420	SELECT 折价率 , 评级 WHERE 股价 < "10"	69cf6802334311e9aca4542696d6e445
qid421	SELECT 折价率 , 评级 WHERE 股价 < "10"	69cf6802334311e9aca4542696d6e445
qid422	SELECT 发行商 WHERE 游戏 == "武动苍穹" or 游戏 == "猛将天下"	4d26b69c3aaa11e998faf40f24344a08
qid423	SELECT 发行商 WHERE 游戏 == "武动苍穹" or 游戏 == "猛将天下"	4d26b69c3aaa11e998faf40f24344a08
qid424	SELECT 发行商 WHERE 游戏 == "武动苍穹" or 游戏 == "猛将天下"	4d26b69c3aaa11e998faf40f24344a08
qid425	SELECT SUM ( PB ) WHERE 证券简称 == "新湖中宝" or 证券简称 == "建发股份"	e0ae97c5333a11e9b7cc542696d6e445
qid426	SELECT SUM ( PB ) WHERE 证券简称 == "新湖中宝" or 证券简称 == "建发股份"	e0ae97c5333a11e9b7cc542696d6e445
qid427	SELECT SUM ( PB ) WHERE 证券简称 == "新湖中宝" or 证券简称 == "建发股份"	e0ae97c5333a11e9b7cc542696d6e445
qid428	SELECT 占2011均值比重 WHERE 2011周平均成交量 < "500" or 成交量同比增长 < "0"	69d452ae334311e98c32542696d6e445
qid429	SELECT 占2011均值比重 WHERE 2011周平均成交量 < "500" or 成交量同比增长 < "0"	69d452ae334311e98c32542696d6e445
qid430	SELECT 占2011均值比重 WHERE 2011周平均成交量 < "500" or 成交量同比增长 < "0"	69d452ae334311e98c32542696d6e445
qid431	SELECT 路桥名称 WHERE 里程 < "100" or 权益 < "100"	c5abb71c34b411e99602542696d6e445
qid432	SELECT 路桥名称 WHERE 里程 < "100" or 权益 < "100"	c5abb71c34b411e99602542696d6e445
qid433	SELECT 路桥名称 WHERE 里程 < "100" or 权益 < "100"	c5abb71c34b411e99602542696d6e445
qid434	SELECT 首映日 , 改编自 WHERE 豆瓣评分 > "7"	4d2a47ee3aaa11e99609f40f24344a08
qid435	SELECT 首映日 , 改编自 WHERE 豆瓣评分 > "7"	4d2a47ee3aaa11e99609f40f24344a08
qid436	SELECT 首映日 , 改编自 WHERE 豆瓣评分 > "7"	4d2a47ee3aaa11e99609f40f24344a08
qid437	SELECT Code , 简称 WHERE 本周指数 > "3000"	733c4cb334c611e9b645542696d6e445
qid438	SELECT Code , 简称 WHERE 本周指数 > "3000"	733c4cb334c611e9b645542696d6e445
qid439	SELECT Code , 简称 WHERE 本周指数 > "3000"	733c4cb334c611e9b645542696d6e445
qid440	SELECT 时间 WHERE Jan > "20"	5a52262b312b11e9b0da542696d6e445
qid441	SELECT 时间 WHERE Jan > "20"	5a52262b312b11e9b0da542696d6e445
qid442	SELECT 时间 WHERE Jan > "20"	5a52262b312b11e9b0da542696d6e445
qid443	SELECT 净利润增速上限（%） WHERE 证券简称 == "300079.SZ"	4d24ebdc3aaa11e99c4af40f24344a08
qid444	SELECT 净利润增速上限（%） WHERE 证券简称 == "300079.SZ"	4d24ebdc3aaa11e99c4af40f24344a08
qid445	SELECT 净利润增速上限（%） WHERE 证券简称 == "300079.SZ"	4d24ebdc3aaa11e99c4af40f24344a08
qid446	SELECT 证券简称 WHERE 定增年度 == "2016" and 增发目的 == "补充流动资金"	4d25be873aaa11e98623f40f24344a08
qid447	SELECT 证券简称 WHERE 定增年度 == "2016" and 增发目的 == "补充流动资金"	4d25be873aaa11e98623f40f24344a08
qid448	SELECT 证券简称 WHERE 定增年度 == "2016" and 增发目的 == "补充流动资金"	4d25be873aaa11e98623f40f24344a08
qid449	SELECT 利润同比增速 WHERE 净利润（亿元） > "5" and 扣非净利润（亿元） > "5"	c5ad0e1434b411e98aeb542696d6e445
qid450	SELECT 利润同比增速 WHERE 净利润（亿元） > "5" and 扣非净利润（亿元） > "5"	c5ad0e1434b411e98aeb542696d6e445
qid451	SELECT 利润同比增速 WHERE 净利润（亿元） > "5" and 扣非净利润（亿元） > "5"	c5ad0e1434b411e98aeb542696d6e445
qid452	SELECT 动车组 WHERE 二等座单价(元/公里） < "0.5" and 一等座单价(元/公里） < "0.60"	c5ad8a9134b411e984f8542696d6e445
qid453	SELECT 动车组 WHERE 二等座单价(元/公里） < "0.5" and 一等座单价(元/公里） < "0.60"	c5ad8a9134b411e984f8542696d6e445
qid454	SELECT 动车组 WHERE 二等座单价(元/公里） < "0.5" and 一等座单价(元/公里） < "0.60"	c5ad8a9134b411e984f8542696d6e445
qid455	SELECT 城市 WHERE 2010成交面积 > "2000" or 2011年成交面积 > "2000"	69d5375c334311e9a939542696d6e445
qid456	SELECT 城市 WHERE 2010成交面积 > "2000" or 2011年成交面积 > "2000"	69d5375c334311e9a939542696d6e445
qid457	SELECT 城市 WHERE 2010成交面积 > "2000" or 2011年成交面积 > "2000"	69d5375c334311e9a939542696d6e445
qid458	SELECT COUNT ( 公司 ) WHERE PE2012E < "20" and PE2013E < "20"	69d5ac6b334311e9af01542696d6e445
qid459	SELECT COUNT ( 公司 ) WHERE PE2012E < "20" and PE2013E < "20"	69d5ac6b334311e9af01542696d6e445
qid460	SELECT COUNT ( 公司 ) WHERE PE2012E < "20" and PE2013E < "20"	69d5ac6b334311e9af01542696d6e445
qid461	SELECT 城市 WHERE 2010成交 > "1000" and 2011年成交 > "1000"	69d5280a334311e99a48542696d6e445
qid462	SELECT 城市 WHERE 2010成交 > "1000" and 2011年成交 > "1000"	69d5280a334311e99a48542696d6e445
qid463	SELECT 城市 WHERE 2010成交 > "1000" and 2011年成交 > "1000"	69d5280a334311e99a48542696d6e445
qid464	SELECT 时间 WHERE Jan > "50" and Feb > "50"	5a518cc7312b11e9a18d542696d6e445
qid465	SELECT 时间 WHERE Jan > "50" and Feb > "50"	5a518cc7312b11e9a18d542696d6e445
qid466	SELECT 时间 WHERE Jan > "50" and Feb > "50"	5a518cc7312b11e9a18d542696d6e445
qid467	SELECT 本周均成交面积 WHERE 城市 == "南昌" or 城市 == "武汉"	c98e25e8332111e994d8542696d6e445
qid468	SELECT 本周均成交面积 WHERE 城市 == "南昌" or 城市 == "武汉"	c98e25e8332111e994d8542696d6e445
qid469	SELECT 本周均成交面积 WHERE 城市 == "南昌" or 城市 == "武汉"	c98e25e8332111e994d8542696d6e445
qid470	SELECT 项目 WHERE 2013 > "5" and 2014 > "5"	733d090534c611e99606542696d6e445
qid471	SELECT 项目 WHERE 2013 > "5" and 2014 > "5"	733d090534c611e99606542696d6e445
qid472	SELECT 项目 WHERE 2013 > "5" and 2014 > "5"	733d090534c611e99606542696d6e445
qid473	SELECT 土地购置面积（亿平） , 投资（万亿） WHERE 时间 == "2011年"	5a4e3859312b11e989db542696d6e445
qid474	SELECT 土地购置面积（亿平） , 投资（万亿） WHERE 时间 == "2011年"	5a4e3859312b11e989db542696d6e445
qid475	SELECT 土地购置面积（亿平） , 投资（万亿） WHERE 时间 == "2011年"	5a4e3859312b11e989db542696d6e445
qid476	SELECT 旅客吞吐量(万人) WHERE 机场 == "白云机场" or 机场 == "深圳机场"	c5ace14734b411e98f60542696d6e445
qid477	SELECT 旅客吞吐量(万人) WHERE 机场 == "白云机场" or 机场 == "深圳机场"	c5ace14734b411e98f60542696d6e445
qid478	SELECT 旅客吞吐量(万人) WHERE 机场 == "白云机场" or 机场 == "深圳机场"	c5ace14734b411e98f60542696d6e445
qid479	SELECT 倒挂率 WHERE 证券简称 == "新南洋"	4d25b71c3aaa11e9961bf40f24344a08
qid480	SELECT 倒挂率 WHERE 证券简称 == "新南洋"	4d25b71c3aaa11e9961bf40f24344a08
qid481	SELECT 倒挂率 WHERE 证券简称 == "新南洋"	4d25b71c3aaa11e9961bf40f24344a08
qid482	SELECT 最新收盘价 WHERE 增发目的 == "融资收购其他资产" and 证券简称 == "拓维信息"	4d266aca3aaa11e9a197f40f24344a08
qid483	SELECT 最新收盘价 WHERE 增发目的 == "融资收购其他资产" and 证券简称 == "拓维信息"	4d266aca3aaa11e9a197f40f24344a08
qid484	SELECT 城市 WHERE 2012/4成交面积 > "10" and 11年均值 > "10"	69cd73d9334311e9acb4542696d6e445
qid485	SELECT 城市 WHERE 2012/4成交面积 > "10" and 11年均值 > "10"	69cd73d9334311e9acb4542696d6e445
qid486	SELECT 城市 WHERE 2012/4成交面积 > "10" and 11年均值 > "10"	69cd73d9334311e9acb4542696d6e445
qid487	SELECT 城市 WHERE 2012/4成交面积 > "10" and 11年均值 > "10"	69cd73d9334311e9acb4542696d6e445
qid488	SELECT COUNT ( 城市名 ) WHERE 去年同期28日均成交 > "400"	2531bea6302e11e9814f542696d6e445
qid489	SELECT COUNT ( 城市名 ) WHERE 去年同期28日均成交 > "400"	2531bea6302e11e9814f542696d6e445
qid490	SELECT COUNT ( 城市名 ) WHERE 去年同期28日均成交 > "400"	2531bea6302e11e9814f542696d6e445
qid491	SELECT 期限 WHERE 调整前 > "3" and 调整后 > "3"	5a4f8500312b11e981d0542696d6e445
qid492	SELECT 期限 WHERE 调整前 > "3" and 调整后 > "3"	5a4f8500312b11e981d0542696d6e445
qid493	SELECT MAX ( 播放量（亿） ) WHERE 剧集名称 == "义海" or 剧集名称 == "启航"	4d29e25c3aaa11e99093f40f24344a08
qid494	SELECT MAX ( 播放量（亿） ) WHERE 剧集名称 == "义海" or 剧集名称 == "启航"	4d29e25c3aaa11e99093f40f24344a08
qid495	SELECT MAX ( 播放量（亿） ) WHERE 剧集名称 == "义海" or 剧集名称 == "启航"	4d29e25c3aaa11e99093f40f24344a08
qid496	SELECT COUNT ( 公司名称 ) WHERE 股价 < "10"	69cf9028334311e99d34542696d6e445
qid497	SELECT COUNT ( 公司名称 ) WHERE 股价 < "10"	69cf9028334311e99d34542696d6e445
qid498	SELECT COUNT ( 公司名称 ) WHERE 股价 < "10"	69cf9028334311e99d34542696d6e445
qid499	SELECT 公司 WHERE 业务量(亿件) > "10" and 快递业务营收(亿元) > "100"	c5ad6a6b34b411e983e3542696d6e445
qid500	SELECT 公司 WHERE 业务量(亿件) > "10" and 快递业务营收(亿元) > "100"	c5ad6a6b34b411e983e3542696d6e445
qid501	SELECT 公司 WHERE 业务量(亿件) > "10" and 快递业务营收(亿元) > "100"	c5ad6a6b34b411e983e3542696d6e445
qid502	SELECT 销售金额 WHERE 公司简称 == "恒大地产" and 销售面积 == "268"	c989a1e3332111e98586542696d6e445
qid503	SELECT 销售金额 WHERE 公司简称 == "恒大地产" and 销售面积 == "268"	c989a1e3332111e98586542696d6e445
qid504	SELECT COUNT ( 城市 ) WHERE 本周成交面积 > "5" and 上本周成交面积 > "10"	c98e109e332111e9ad7f542696d6e445
qid505	SELECT COUNT ( 城市 ) WHERE 本周成交面积 > "5" and 上本周成交面积 > "10"	c98e109e332111e9ad7f542696d6e445
qid506	SELECT COUNT ( 城市 ) WHERE 本周成交面积 > "5" and 上本周成交面积 > "10"	c98e109e332111e9ad7f542696d6e445
qid507	SELECT 股票名称 WHERE PB < "3"	5a4f04c2312b11e99fe7542696d6e445
qid508	SELECT 股票名称 WHERE PB < "3"	5a4f04c2312b11e99fe7542696d6e445
qid509	SELECT 股票名称 WHERE PB < "3"	5a4f04c2312b11e99fe7542696d6e445
qid510	SELECT 商誉A（亿元） WHERE 商誉A/净资产 > "30" and 商誉A/净利润 > "1000"	4d27d49e3aaa11e98715f40f24344a08
qid511	SELECT 商誉A（亿元） WHERE 商誉A/净资产 > "30" and 商誉A/净利润 > "1000"	4d27d49e3aaa11e98715f40f24344a08
qid512	SELECT 商誉A（亿元） WHERE 商誉A/净资产 > "30" and 商誉A/净利润 > "1000"	4d27d49e3aaa11e98715f40f24344a08
qid513	SELECT 最新股价 WHERE 最新市值（亿元） == "100" and 证券简称 == "北辰实业"	5a508682312b11e9b885542696d6e445
qid514	SELECT 最新股价 WHERE 最新市值（亿元） == "100" and 证券简称 == "北辰实业"	5a508682312b11e9b885542696d6e445
qid515	SELECT 最新股价 WHERE 最新市值（亿元） == "100" and 证券简称 == "北辰实业"	5a508682312b11e9b885542696d6e445
qid516	SELECT Q1-Q3单票收入 WHERE 公司 == "顺丰"	c5ad011c34b411e98c23542696d6e445
qid517	SELECT Q1-Q3单票收入 WHERE 公司 == "顺丰"	c5ad011c34b411e98c23542696d6e445
qid518	SELECT Q1-Q3单票收入 WHERE 公司 == "顺丰"	c5ad011c34b411e98c23542696d6e445
qid519	SELECT 证券简称 WHERE 净利润上限（亿元） > "2" and 净利润增速上限（%） > "100"	4d24cf803aaa11e98789f40f24344a08
qid520	SELECT 证券简称 WHERE 净利润上限（亿元） > "2" and 净利润增速上限（%） > "100"	4d24cf803aaa11e98789f40f24344a08
qid521	SELECT 证券简称 WHERE 净利润上限（亿元） > "2" and 净利润增速上限（%） > "100"	4d24cf803aaa11e98789f40f24344a08
qid522	SELECT 月环比涨幅 WHERE 楼盘名称 == "恒大绿洲" or 楼盘名称 == "达镖国际商务公寓"	c98c2fe1332111e992dc542696d6e445
qid523	SELECT 月环比涨幅 WHERE 楼盘名称 == "恒大绿洲" or 楼盘名称 == "达镖国际商务公寓"	c98c2fe1332111e992dc542696d6e445
qid524	SELECT 月环比涨幅 WHERE 楼盘名称 == "恒大绿洲" or 楼盘名称 == "达镖国际商务公寓"	c98c2fe1332111e992dc542696d6e445
qid525	SELECT 证券代码 , 证券简称 WHERE 定增价除权后至今价格 > "10"	4d26714f3aaa11e9a4bcf40f24344a08
qid526	SELECT 证券代码 , 证券简称 WHERE 定增价除权后至今价格 > "10"	4d26714f3aaa11e9a4bcf40f24344a08
qid527	SELECT 证券代码 , 证券简称 WHERE 定增价除权后至今价格 > "10"	4d26714f3aaa11e9a4bcf40f24344a08
qid528	SELECT B名称 WHERE B收盘价 > "5" and B涨跌幅 > "3"	4d27460c3aaa11e9bb82f40f24344a08
qid529	SELECT B名称 WHERE B收盘价 > "5" and B涨跌幅 > "3"	4d27460c3aaa11e9bb82f40f24344a08
qid530	SELECT B名称 WHERE B收盘价 > "5" and B涨跌幅 > "3"	4d27460c3aaa11e9bb82f40f24344a08
qid531	SELECT 名称 , 上市地点 WHERE 收盘价 > "20"	4d27611e3aaa11e9b6ddf40f24344a08
qid532	SELECT 名称 , 上市地点 WHERE 收盘价 > "20"	4d27611e3aaa11e9b6ddf40f24344a08
qid533	SELECT 名称 , 上市地点 WHERE 收盘价 > "20"	4d27611e3aaa11e9b6ddf40f24344a08
qid534	SELECT 本周环比 , 本周同比 WHERE 累计同比 > "0"	c98cba33332111e99841542696d6e445
qid535	SELECT 本周环比 , 本周同比 WHERE 累计同比 > "0"	c98cba33332111e99841542696d6e445
qid536	SELECT 本周环比 , 本周同比 WHERE 累计同比 > "0"	c98cba33332111e99841542696d6e445
qid537	SELECT 城市 WHERE 7日成交环比 < "4" and 7日成交同比 < "4"	69d3e454334311e9831e542696d6e445
qid538	SELECT 城市 WHERE 7日成交环比 < "4" and 7日成交同比 < "4"	69d3e454334311e9831e542696d6e445
qid539	SELECT 城市 WHERE 7日成交环比 < "4" and 7日成交同比 < "4"	69d3e454334311e9831e542696d6e445
qid540	SELECT COUNT ( 公司 ) WHERE 2014（亿元） > "20" and 2015（亿元） > "20" and 2016（亿元） > "20"	0de63d33351311e9aa68542696d6e445
qid541	SELECT COUNT ( 公司 ) WHERE 2014（亿元） > "20" and 2015（亿元） > "20" and 2016（亿元） > "20"	0de63d33351311e9aa68542696d6e445
qid542	SELECT COUNT ( 公司 ) WHERE 2014（亿元） > "20" and 2015（亿元） > "20" and 2016（亿元） > "20"	0de63d33351311e9aa68542696d6e445
qid543	SELECT 2018Q3 WHERE 2018Q1 < "10" and 2018Q2 < "10"	c5ad055434b411e980b1542696d6e445
qid544	SELECT 2018Q3 WHERE 2018Q1 < "10" and 2018Q2 < "10"	c5ad055434b411e980b1542696d6e445
qid545	SELECT 2018Q3 WHERE 2018Q1 < "10" and 2018Q2 < "10"	c5ad055434b411e980b1542696d6e445
qid546	SELECT 简称 WHERE 本月涨跌幅 < "0" or 本周涨跌幅 < "0"	c5ac5f6e34b411e9b645542696d6e445
qid547	SELECT 简称 WHERE 本月涨跌幅 < "0" or 本周涨跌幅 < "0"	c5ac5f6e34b411e9b645542696d6e445
qid548	SELECT 简称 WHERE 本月涨跌幅 < "0" or 本周涨跌幅 < "0"	c5ac5f6e34b411e9b645542696d6e445
qid549	SELECT 公司简称 WHERE 周涨跌幅（%） > "10" and 月涨跌幅（%） > "10"	e0ac4d54333a11e98222542696d6e445
qid550	SELECT 公司简称 WHERE 周涨跌幅（%） > "10" and 月涨跌幅（%） > "10"	e0ac4d54333a11e98222542696d6e445
qid551	SELECT 公司简称 WHERE 周涨跌幅（%） > "10" and 月涨跌幅（%） > "10"	e0ac4d54333a11e98222542696d6e445
qid552	SELECT PB WHERE 公司简称 == "金融街" and 股价 < "10"	5a4f3afa312b11e98402542696d6e445
qid553	SELECT PB WHERE 公司简称 == "金融街" and 股价 < "10"	5a4f3afa312b11e98402542696d6e445
qid554	SELECT PB WHERE 公司简称 == "金融街" and 股价 < "10"	5a4f3afa312b11e98402542696d6e445
qid555	SELECT COUNT ( 证券 ) WHERE EPS2017A > "0.5" and EPS2018E > "0.5"	015637de351311e9a016542696d6e445
qid556	SELECT COUNT ( 证券 ) WHERE EPS2017A > "0.5" and EPS2018E > "0.5"	015637de351311e9a016542696d6e445
qid557	SELECT COUNT ( 证券 ) WHERE EPS2017A > "0.5" and EPS2018E > "0.5"	015637de351311e9a016542696d6e445
qid558	SELECT 10AEPS , 10APE WHERE 证券简称 == "首开股份"	e0ad794a333a11e99f2c542696d6e445
qid559	SELECT 10AEPS , 10APE WHERE 证券简称 == "首开股份"	e0ad794a333a11e99f2c542696d6e445
qid560	SELECT 10AEPS , 10APE WHERE 证券简称 == "首开股份"	e0ad794a333a11e99f2c542696d6e445
qid561	SELECT 时间 WHERE 2018 > "30" or 2017 > "20"	733ceea834c611e9a24c542696d6e445
qid562	SELECT 时间 WHERE 2018 > "30" or 2017 > "20"	733ceea834c611e9a24c542696d6e445
qid563	SELECT 时间 WHERE 2018 > "30" or 2017 > "20"	733ceea834c611e9a24c542696d6e445
qid564	SELECT 周票房（万） WHERE 影投公司 == "香港百老汇" or 影投公司 == "太平洋影管"	4d29a3f33aaa11e99236f40f24344a08
qid565	SELECT 周票房（万） WHERE 影投公司 == "香港百老汇" or 影投公司 == "太平洋影管"	4d29a3f33aaa11e99236f40f24344a08
qid566	SELECT 周票房（万） WHERE 影投公司 == "香港百老汇" or 影投公司 == "太平洋影管"	4d29a3f33aaa11e99236f40f24344a08
qid567	SELECT MAX ( 播放量（万） ) WHERE 排名 < "11"	4d29ed6b3aaa11e9a5d8f40f24344a08
qid568	SELECT MAX ( 播放量（万） ) WHERE 排名 < "11"	4d29ed6b3aaa11e9a5d8f40f24344a08
qid569	SELECT MAX ( 播放量（万） ) WHERE 排名 < "11"	4d29ed6b3aaa11e9a5d8f40f24344a08
qid570	SELECT 影片名称 WHERE 周票房（万） > "2557.5" and 票房占比（%） > "5" and 场均人次 > "5"	4d293d913aaa11e9b888f40f24344a08
qid571	SELECT 影片名称 WHERE 周票房（万） > "2557.5" and 票房占比（%） > "5" and 场均人次 > "5"	4d293d913aaa11e9b888f40f24344a08
qid572	SELECT 影片名称 WHERE 周票房（万） > "2557.5" and 票房占比（%） > "5" and 场均人次 > "5"	4d293d913aaa11e9b888f40f24344a08
qid573	SELECT 证券简称 WHERE 总收入（万元） > "9000000" or 净利润（万元） > "200000"	c5ad47a834b411e996f0542696d6e445
qid574	SELECT 证券简称 WHERE 总收入（万元） > "9000000" or 净利润（万元） > "200000"	c5ad47a834b411e996f0542696d6e445
qid575	SELECT 证券简称 WHERE 总收入（万元） > "9000000" or 净利润（万元） > "200000"	c5ad47a834b411e996f0542696d6e445
qid576	SELECT 上周 WHERE 本期 == "1900" and 指标名称 == "山西兰花"	c5ae959934b411e99783542696d6e445
qid577	SELECT 上周 WHERE 本期 == "1900" and 指标名称 == "山西兰花"	c5ae959934b411e99783542696d6e445
qid578	SELECT 上周 WHERE 本期 == "1900" and 指标名称 == "山西兰花"	c5ae959934b411e99783542696d6e445
qid579	SELECT 单价 WHERE 对应时间 == "一年约400小时" and 标签 == "视频"	4d244aa63aaa11e991aff40f24344a08
qid580	SELECT 单价 WHERE 对应时间 == "一年约400小时" and 标签 == "视频"	4d244aa63aaa11e991aff40f24344a08
qid581	SELECT 单价 WHERE 对应时间 == "一年约400小时" and 标签 == "视频"	4d244aa63aaa11e991aff40f24344a08
qid582	SELECT 客车占比 WHERE 总计 == "1089471" and 高速 == "阳茂高速"	733d581434c611e994a8542696d6e445
qid583	SELECT 客车占比 WHERE 总计 == "1089471" and 高速 == "阳茂高速"	733d581434c611e994a8542696d6e445
qid584	SELECT COUNT ( 股票名称 ) WHERE PE17 > "15" or PB17 > "2"	6e614ce634ce11e991e5542696d6e445
qid585	SELECT COUNT ( 股票名称 ) WHERE PE17 > "15" or PB17 > "2"	6e614ce634ce11e991e5542696d6e445
qid586	SELECT COUNT ( 股票名称 ) WHERE PE17 > "15" or PB17 > "2"	6e614ce634ce11e991e5542696d6e445
qid587	SELECT COUNT ( 城市 ) WHERE 2011年日均成交 > "2" and 2012年日均成交 > "2"	69cd108c334311e9b577542696d6e445
qid588	SELECT COUNT ( 城市 ) WHERE 2011年日均成交 > "2" and 2012年日均成交 > "2"	69cd108c334311e9b577542696d6e445
qid589	SELECT COUNT ( 城市 ) WHERE 2011年日均成交 > "2" and 2012年日均成交 > "2"	69cd108c334311e9b577542696d6e445
qid590	SELECT 收视率% WHERE 频道 == "江苏卫视" and 名称 == "最美的时光"	4d29e75e3aaa11e98c68f40f24344a08
qid591	SELECT 收视率% WHERE 频道 == "江苏卫视" and 名称 == "最美的时光"	4d29e75e3aaa11e98c68f40f24344a08
qid592	SELECT 收视率% WHERE 频道 == "江苏卫视" and 名称 == "最美的时光"	4d29e75e3aaa11e98c68f40f24344a08
qid593	SELECT 总市值（亿元） WHERE 证券简称 == "分众传媒"	4d23f09c3aaa11e99904f40f24344a08
qid594	SELECT 总市值（亿元） WHERE 证券简称 == "分众传媒"	4d23f09c3aaa11e99904f40f24344a08
qid595	SELECT 总市值（亿元） WHERE 证券简称 == "分众传媒"	4d23f09c3aaa11e99904f40f24344a08
qid596	SELECT 线路名称 WHERE 线路长度（公里） > "100" and 投资金额（亿元） > "500"	43b317d11d7111e9a717f40f24344a08
qid597	SELECT 线路名称 WHERE 线路长度（公里） > "100" and 投资金额（亿元） > "500"	43b317d11d7111e9a717f40f24344a08
qid598	SELECT 线路名称 WHERE 线路长度（公里） > "100" and 投资金额（亿元） > "500"	43b317d11d7111e9a717f40f24344a08
qid599	SELECT 公司 WHERE 2017 > "20" or 2017H1 > "20"	c5ad159e34b411e9aaef542696d6e445
qid600	SELECT 公司 WHERE 2017 > "20" or 2017H1 > "20"	c5ad159e34b411e9aaef542696d6e445
qid601	SELECT 公司 WHERE 2017 > "20" or 2017H1 > "20"	c5ad159e34b411e9aaef542696d6e445
qid602	SELECT 证券简称 WHERE 10APE > "17" and 11APE > "17"	c98daf26332111e99d17542696d6e445
qid603	SELECT 证券简称 WHERE 10APE > "17" and 11APE > "17"	c98daf26332111e99d17542696d6e445
qid604	SELECT 证券简称 WHERE 10APE > "17" and 11APE > "17"	c98daf26332111e99d17542696d6e445
qid605	SELECT 发热量/规格 WHERE 上月 > "1000" or 上年 > "1000"	c5ae457034b411e98c59542696d6e445
qid606	SELECT 发热量/规格 WHERE 上月 > "1000" or 上年 > "1000"	c5ae457034b411e98c59542696d6e445
qid607	SELECT 发热量/规格 WHERE 上月 > "1000" or 上年 > "1000"	c5ae457034b411e98c59542696d6e445
qid608	SELECT 股票名称 WHERE EPS(元)2011A > "1" and EPS(元)2012E > "1"	252c9099302e11e9a413542696d6e445
qid609	SELECT 股票名称 WHERE EPS(元)2011A > "1" and EPS(元)2012E > "1"	252c9099302e11e9a413542696d6e445
qid610	SELECT 股票名称 WHERE EPS(元)2011A > "1" and EPS(元)2012E > "1"	252c9099302e11e9a413542696d6e445
qid611	SELECT 收视率% , 频道 WHERE 剧名 == "梦想的声音3"	4d2532a33aaa11e9b4def40f24344a08
qid612	SELECT 收视率% , 频道 WHERE 剧名 == "梦想的声音3"	4d2532a33aaa11e9b4def40f24344a08
qid613	SELECT 收视率% , 频道 WHERE 剧名 == "梦想的声音3"	4d2532a33aaa11e9b4def40f24344a08
qid614	SELECT 线路 WHERE 公里数（km） > "200" and 投资总额（亿元） < "300"	43b1c90c1d7111e9b037f40f24344a08
qid615	SELECT 线路 WHERE 公里数（km） > "200" and 投资总额（亿元） < "300"	43b1c90c1d7111e9b037f40f24344a08
qid616	SELECT 线路 WHERE 公里数（km） > "200" and 投资总额（亿元） < "300"	43b1c90c1d7111e9b037f40f24344a08
qid617	SELECT 代码 WHERE 收盘价 > "40" and 周涨跌幅 > "3"	4d27611e3aaa11e9b6ddf40f24344a08
qid618	SELECT 代码 WHERE 收盘价 > "40" and 周涨跌幅 > "3"	4d27611e3aaa11e9b6ddf40f24344a08
qid619	SELECT 代码 WHERE 收盘价 > "40" and 周涨跌幅 > "3"	4d27611e3aaa11e9b6ddf40f24344a08
qid620	SELECT 公司 , 国家/地区 WHERE 同比增速 < "0"	0de5b538351311e99b5f542696d6e445
qid621	SELECT 公司 , 国家/地区 WHERE 同比增速 < "0"	0de5b538351311e99b5f542696d6e445
qid622	SELECT 公司 , 国家/地区 WHERE 同比增速 < "0"	0de5b538351311e99b5f542696d6e445
qid623	SELECT 股价（元） WHERE PE17A < "100"	43b0e8de1d7111e9bad6f40f24344a08
qid624	SELECT 股价（元） WHERE PE17A < "100"	43b0e8de1d7111e9bad6f40f24344a08
qid625	SELECT 股价（元） WHERE PE17A < "100"	43b0e8de1d7111e9bad6f40f24344a08
qid626	SELECT 公司代码 , 股价(元) WHERE 公司简称 == "石化机械"	69ce6de3334311e98ba1542696d6e445
qid627	SELECT 公司代码 , 股价(元) WHERE 公司简称 == "石化机械"	69ce6de3334311e98ba1542696d6e445
qid628	SELECT 公司代码 , 股价(元) WHERE 公司简称 == "石化机械"	69ce6de3334311e98ba1542696d6e445
qid629	SELECT SUM ( 收盘价 ) WHERE PE2019E > "20" and PE2020E > "20"	01562780351311e995f2542696d6e445
qid630	SELECT SUM ( 收盘价 ) WHERE PE2019E > "20" and PE2020E > "20"	01562780351311e995f2542696d6e445
qid631	SELECT SUM ( 收盘价 ) WHERE PE2019E > "20" and PE2020E > "20"	01562780351311e995f2542696d6e445
qid632	SELECT 预计可售建筑面积（万平米） WHERE 时间 == "2012年"	5a4eeb57312b11e99af8542696d6e445
qid633	SELECT 预计可售建筑面积（万平米） WHERE 时间 == "2012年"	5a4eeb57312b11e99af8542696d6e445
qid634	SELECT 预计可售建筑面积（万平米） WHERE 时间 == "2012年"	5a4eeb57312b11e99af8542696d6e445
qid635	SELECT 客座率 WHERE 公司 == "吉祥航空"	c5acd8c034b411e9aad9542696d6e445
qid636	SELECT 客座率 WHERE 公司 == "吉祥航空"	c5acd8c034b411e9aad9542696d6e445
qid637	SELECT 客座率 WHERE 公司 == "吉祥航空"	c5acd8c034b411e9aad9542696d6e445
qid638	SELECT 同比增长（%） WHERE 指标 == "住宅" and 绝对量 > "1000"	c989d6e6332111e99529542696d6e445
qid639	SELECT 同比增长（%） WHERE 指标 == "住宅" and 绝对量 > "1000"	c989d6e6332111e99529542696d6e445
qid640	SELECT 同比增长（%） WHERE 指标 == "住宅" and 绝对量 > "1000"	c989d6e6332111e99529542696d6e445
qid641	SELECT 公司 WHERE EPS2018E > "0.3" and EPS2019E > "0.3"	69cf0a23334311e9a862542696d6e445
qid642	SELECT 公司 WHERE EPS2018E > "0.3" and EPS2019E > "0.3"	69cf0a23334311e9a862542696d6e445
qid643	SELECT 公司 WHERE EPS2018E > "0.3" and EPS2019E > "0.3"	69cf0a23334311e9a862542696d6e445
qid644	SELECT COUNT ( 成交面积 ) WHERE 城市名称 == "重庆市" and 城市名称 == "青岛市"	2532acee302e11e9826b542696d6e445
qid645	SELECT COUNT ( 成交面积 ) WHERE 城市名称 == "重庆市" and 城市名称 == "青岛市"	2532acee302e11e9826b542696d6e445
qid646	SELECT COUNT ( 成交面积 ) WHERE 城市名称 == "重庆市" and 城市名称 == "青岛市"	2532acee302e11e9826b542696d6e445
qid647	SELECT 剧集名称 WHERE 播出平台 == "芒果TV"	4d29ed6b3aaa11e9a5d8f40f24344a08
qid648	SELECT 剧集名称 WHERE 播出平台 == "芒果TV"	4d29ed6b3aaa11e9a5d8f40f24344a08
qid649	SELECT 剧集名称 WHERE 播出平台 == "芒果TV"	4d29ed6b3aaa11e9a5d8f40f24344a08
qid650	SELECT MAX ( 最新股价 ) WHERE 本周跌幅后十 < "0" or 最新市值（亿元） < "100"	5a4b7f3d312b11e98d49542696d6e445
qid651	SELECT MAX ( 最新股价 ) WHERE 本周跌幅后十 < "0" or 最新市值（亿元） < "100"	5a4b7f3d312b11e98d49542696d6e445
qid652	SELECT MAX ( 最新股价 ) WHERE 本周跌幅后十 < "0" or 最新市值（亿元） < "100"	5a4b7f3d312b11e98d49542696d6e445
qid653	SELECT 2010年成交面积 , 2011年成交面积 WHERE 城市 == "佛山"	69d31c5e334311e9b9d1542696d6e445
qid654	SELECT 2010年成交面积 , 2011年成交面积 WHERE 城市 == "佛山"	69d31c5e334311e9b9d1542696d6e445
qid655	SELECT 2010年成交面积 , 2011年成交面积 WHERE 城市 == "佛山"	69d31c5e334311e9b9d1542696d6e445
qid656	SELECT COUNT ( 城市 ) WHERE 拟周成交 > "3443" and 近4周周均成交 > "1000"	c98a4e45332111e9bc29542696d6e445
qid657	SELECT COUNT ( 城市 ) WHERE 拟周成交 > "3443" and 近4周周均成交 > "1000"	c98a4e45332111e9bc29542696d6e445
qid658	SELECT COUNT ( 城市 ) WHERE 拟周成交 > "3443" and 近4周周均成交 > "1000"	c98a4e45332111e9bc29542696d6e445
qid659	SELECT 名称 WHERE 2016销量市占率 > "8.05"	43b3c5e11d7111e98d54f40f24344a08
qid660	SELECT 名称 WHERE 2016销量市占率 > "8.05"	43b3c5e11d7111e98d54f40f24344a08
qid661	SELECT 名称 WHERE 2016销量市占率 > "8.05"	43b3c5e11d7111e98d54f40f24344a08
qid662	SELECT 同比 WHERE 城市 == "汕头" and 周均成交面积 < "2"	e0ad708a333a11e9ac99542696d6e445
qid663	SELECT 同比 WHERE 城市 == "汕头" and 周均成交面积 < "2"	e0ad708a333a11e9ac99542696d6e445
qid664	SELECT 同比 WHERE 城市 == "汕头" and 周均成交面积 < "2"	e0ad708a333a11e9ac99542696d6e445
qid665	SELECT 简称 , 股价（元） WHERE EPS19E > "0.5" and EPS20E > "0.5"	c5acb13a34b411e9abd8542696d6e445
qid666	SELECT 简称 , 股价（元） WHERE EPS19E > "0.5" and EPS20E > "0.5"	c5acb13a34b411e9abd8542696d6e445
qid667	SELECT 简称 , 股价（元） WHERE EPS19E > "0.5" and EPS20E > "0.5"	c5acb13a34b411e9abd8542696d6e445
qid668	SELECT COUNT ( 公司简称 ) WHERE 销售面积 > "80"	c989a1e3332111e98586542696d6e445
qid669	SELECT COUNT ( 公司简称 ) WHERE 销售面积 > "80"	c989a1e3332111e98586542696d6e445
qid670	SELECT COUNT ( 公司简称 ) WHERE 销售面积 > "80"	c989a1e3332111e98586542696d6e445
qid671	SELECT 股价 WHERE 市值(亿元） > "500"	733cd10c34c611e99216542696d6e445
qid672	SELECT 股价 WHERE 市值(亿元） > "500"	733cd10c34c611e99216542696d6e445
qid673	SELECT 股价 WHERE 市值(亿元） > "500"	733cd10c34c611e99216542696d6e445
qid674	SELECT 公司简称 , 评级 WHERE 土地储备 > "500"	5a4b20e8312b11e99dc3542696d6e445
qid675	SELECT 公司简称 , 评级 WHERE 土地储备 > "500"	5a4b20e8312b11e99dc3542696d6e445
qid676	SELECT 公司简称 , 评级 WHERE 土地储备 > "500"	5a4b20e8312b11e99dc3542696d6e445
qid677	SELECT 时间 WHERE 2018 > "20" or 2017 > "20"	733cf6ab34c611e991f6542696d6e445
qid678	SELECT 时间 WHERE 2018 > "20" or 2017 > "20"	733cf6ab34c611e991f6542696d6e445
qid679	SELECT 时间 WHERE 2018 > "20" or 2017 > "20"	733cf6ab34c611e991f6542696d6e445
qid680	SELECT AVG ( 销售额同比增长 ) WHERE 销售面积绝对数 > "10000" or 销售额绝对数 > "10000"	c989e207332111e9ba26542696d6e445
qid681	SELECT AVG ( 销售额同比增长 ) WHERE 销售面积绝对数 > "10000" or 销售额绝对数 > "10000"	c989e207332111e9ba26542696d6e445
qid682	SELECT AVG ( 销售额同比增长 ) WHERE 销售面积绝对数 > "10000" or 销售额绝对数 > "10000"	c989e207332111e9ba26542696d6e445
qid683	SELECT 苏州 WHERE 时间 == "2011/6/4" and 北京 == "52.77"	e0aca163333a11e99d33542696d6e445
qid684	SELECT 苏州 WHERE 时间 == "2011/6/4" and 北京 == "52.77"	e0aca163333a11e99d33542696d6e445
qid685	SELECT 公司名称 , 代码 WHERE PE17 > "22"	c5adcb1134b411e9bc24542696d6e445
qid686	SELECT 公司名称 , 代码 WHERE PE17 > "22"	c5adcb1134b411e9bc24542696d6e445
qid687	SELECT 公司名称 , 代码 WHERE PE17 > "22"	c5adcb1134b411e9bc24542696d6e445
qid688	SELECT COUNT ( 城市 ) WHERE 2012年2月成交量环比 > "10" and 2012年1月成交量环比 < "1"	69d16454334311e99bd8542696d6e445
qid689	SELECT COUNT ( 城市 ) WHERE 2012年2月成交量环比 > "10" and 2012年1月成交量环比 < "1"	69d16454334311e99bd8542696d6e445
qid690	SELECT COUNT ( 城市 ) WHERE 2012年2月成交量环比 > "10" and 2012年1月成交量环比 < "1"	69d16454334311e99bd8542696d6e445
qid691	SELECT 游戏 WHERE 研发方 == "腾讯魔方工作室" or 发行方 == "腾讯"	4d26aaee3aaa11e9978cf40f24344a08
qid692	SELECT 游戏 WHERE 研发方 == "腾讯魔方工作室" or 发行方 == "腾讯"	4d26aaee3aaa11e9978cf40f24344a08
qid693	SELECT 游戏 WHERE 研发方 == "腾讯魔方工作室" or 发行方 == "腾讯"	4d26aaee3aaa11e9978cf40f24344a08
qid694	SELECT 楼盘名称 WHERE 5月均价(元/㎡) > "10000" and 月环比涨幅 > "5"	c98c2ca1332111e99c14542696d6e445
qid695	SELECT 楼盘名称 WHERE 5月均价(元/㎡) > "10000" and 月环比涨幅 > "5"	c98c2ca1332111e99c14542696d6e445
qid696	SELECT 楼盘名称 WHERE 5月均价(元/㎡) > "10000" and 月环比涨幅 > "5"	c98c2ca1332111e99c14542696d6e445
qid697	SELECT 楼盘名称 WHERE 5月均价(元/㎡) > "10000" and 月环比涨幅 > "5"	c98c2ca1332111e99c14542696d6e445
qid698	SELECT COUNT ( 省份 ) WHERE 股息率 > "4" and 2017年分红比例 > "40"	733c7e8a34c611e9a7d9542696d6e445
qid699	SELECT COUNT ( 省份 ) WHERE 股息率 > "4" and 2017年分红比例 > "40"	733c7e8a34c611e9a7d9542696d6e445
qid700	SELECT COUNT ( 省份 ) WHERE 股息率 > "4" and 2017年分红比例 > "40"	733c7e8a34c611e9a7d9542696d6e445
qid701	SELECT SUM ( 05.14-05.20一手房成交 ) WHERE 城市 == "北京"	5a4b1151312b11e9bbd7542696d6e445
qid702	SELECT SUM ( 05.14-05.20一手房成交 ) WHERE 城市 == "北京"	5a4b1151312b11e9bbd7542696d6e445
qid703	SELECT SUM ( 05.14-05.20一手房成交 ) WHERE 城市 == "北京"	5a4b1151312b11e9bbd7542696d6e445
qid704	SELECT COUNT ( 名称 ) WHERE 收盘价 > "15" and 涨跌幅 > "20"	43aef8ca1d7111e99c38f40f24344a08
qid705	SELECT COUNT ( 名称 ) WHERE 收盘价 > "15" and 涨跌幅 > "20"	43aef8ca1d7111e99c38f40f24344a08
qid706	SELECT COUNT ( 名称 ) WHERE 收盘价 > "15" and 涨跌幅 > "20"	43aef8ca1d7111e99c38f40f24344a08
qid707	SELECT 证券简称 WHERE 周收盘(美元) > "10" and 周涨跌幅% < "5"	4d2426403aaa11e9a2f8f40f24344a08
qid708	SELECT 证券简称 WHERE 周收盘(美元) > "10" and 周涨跌幅% < "5"	4d2426403aaa11e9a2f8f40f24344a08
qid709	SELECT 证券简称 WHERE 周收盘(美元) > "10" and 周涨跌幅% < "5"	4d2426403aaa11e9a2f8f40f24344a08
qid710	SELECT COUNT ( 剧名 ) WHERE 收视率（%） > "0.5"	4d26cce83aaa11e9addaf40f24344a08
qid711	SELECT COUNT ( 剧名 ) WHERE 收视率（%） > "0.5"	4d26cce83aaa11e9addaf40f24344a08
qid712	SELECT COUNT ( 剧名 ) WHERE 收视率（%） > "0.5"	4d26cce83aaa11e9addaf40f24344a08
qid713	SELECT 公司 WHERE 2014 < "-1" and 15H1 < "-1"	733bee0f34c611e9a1f3542696d6e445
qid714	SELECT 公司 WHERE 2014 < "-1" and 15H1 < "-1"	733bee0f34c611e9a1f3542696d6e445
qid715	SELECT 公司 WHERE 2014 < "-1" and 15H1 < "-1"	733bee0f34c611e9a1f3542696d6e445
qid716	SELECT 年份 WHERE 商品房新开工面积 > "20000" and 商品房竣工面积 > "20000"	e0ae2930333a11e9b0c6542696d6e445
qid717	SELECT 年份 WHERE 商品房新开工面积 > "20000" and 商品房竣工面积 > "20000"	e0ae2930333a11e9b0c6542696d6e445
qid718	SELECT 年份 WHERE 商品房新开工面积 > "20000" and 商品房竣工面积 > "20000"	e0ae2930333a11e9b0c6542696d6e445
qid719	SELECT AVG ( 去年同期 ) WHERE 11年H2 > "10" and 11年H1 > "10"	c98ce5f3332111e9afee542696d6e445
qid720	SELECT AVG ( 去年同期 ) WHERE 11年H2 > "10" and 11年H1 > "10"	c98ce5f3332111e9afee542696d6e445
qid721	SELECT AVG ( 去年同期 ) WHERE 11年H2 > "10" and 11年H1 > "10"	c98ce5f3332111e9afee542696d6e445
qid722	SELECT 股票名称 , 股票代码 WHERE EPS(元)2011A > "1.1"	252c9099302e11e9a413542696d6e445
qid723	SELECT 股票名称 , 股票代码 WHERE EPS(元)2011A > "1.1"	252c9099302e11e9a413542696d6e445
qid724	SELECT 股票名称 , 股票代码 WHERE EPS(元)2011A > "1.1"	252c9099302e11e9a413542696d6e445
qid725	SELECT 地点 WHERE 机场名称 == "萧山国际机场"	0156028c351311e9b6bb542696d6e445
qid726	SELECT 地点 WHERE 机场名称 == "萧山国际机场"	0156028c351311e9b6bb542696d6e445
qid727	SELECT 公司 , 分项 WHERE 2017 < "1000"	69ceb361334311e99ade542696d6e445
qid728	SELECT 公司 , 分项 WHERE 2017 < "1000"	69ceb361334311e99ade542696d6e445
qid729	SELECT 公司 , 分项 WHERE 2017 < "1000"	69ceb361334311e99ade542696d6e445
qid730	SELECT 10年H2 WHERE 10年H1 < "10"	c98ccf54332111e98508542696d6e445
qid731	SELECT 10年H2 WHERE 10年H1 < "10"	c98ccf54332111e98508542696d6e445
qid732	SELECT 10年H2 WHERE 10年H1 < "10"	c98ccf54332111e98508542696d6e445
qid733	SELECT 名称 WHERE 收盘价 < "19" or 目标价（元） < "25"	43ade7071d7111e9a4b0f40f24344a08
qid734	SELECT 名称 WHERE 收盘价 < "19" or 目标价（元） < "25"	43ade7071d7111e9a4b0f40f24344a08
qid735	SELECT 名称 WHERE 收盘价 < "19" or 目标价（元） < "25"	43ade7071d7111e9a4b0f40f24344a08
qid736	SELECT 证券简称 WHERE 10AEPS > "0.5" and 11AEPS > "0.5" and 12EEPS > "0.5"	e0ad8a21333a11e9a5f8542696d6e445
qid737	SELECT 证券简称 WHERE 10AEPS > "0.5" and 11AEPS > "0.5" and 12EEPS > "0.5"	e0ad8a21333a11e9a5f8542696d6e445
qid738	SELECT 证券简称 WHERE 10AEPS > "0.5" and 11AEPS > "0.5" and 12EEPS > "0.5"	e0ad8a21333a11e9a5f8542696d6e445
qid739	SELECT SUM ( 周票房（万） ) WHERE 影投公司 == "万达电影" and 影投公司 == "大地影院"	4d29a3f33aaa11e99236f40f24344a08
qid740	SELECT SUM ( 周票房（万） ) WHERE 影投公司 == "万达电影" and 影投公司 == "大地影院"	4d29a3f33aaa11e99236f40f24344a08
qid741	SELECT SUM ( 周票房（万） ) WHERE 影投公司 == "万达电影" and 影投公司 == "大地影院"	4d29a3f33aaa11e99236f40f24344a08
qid742	SELECT MAX ( 股份（手） ) WHERE 权重 > "10"	69d0a74c334311e9ad2d542696d6e445
qid743	SELECT MAX ( 股份（手） ) WHERE 权重 > "10"	69d0a74c334311e9ad2d542696d6e445
qid744	SELECT MAX ( 股份（手） ) WHERE 权重 > "10"	69d0a74c334311e9ad2d542696d6e445
qid745	SELECT 扩建计划 WHERE 当前设计旅客吞吐量 > "8000" or 扩建后旅客吞吐量 > "8000"	733d160034c611e988e4542696d6e445
qid746	SELECT 扩建计划 WHERE 当前设计旅客吞吐量 > "8000" or 扩建后旅客吞吐量 > "8000"	733d160034c611e988e4542696d6e445
qid747	SELECT 扩建计划 WHERE 当前设计旅客吞吐量 > "8000" or 扩建后旅客吞吐量 > "8000"	733d160034c611e988e4542696d6e445
qid748	SELECT 试点概率较大的园区 WHERE 成立时间 == "1988年5月" and 主导产业 == "电子信息、先进制造、新能源、新材料、生物技术"	5a4f2182312b11e98341542696d6e445
qid749	SELECT 试点概率较大的园区 WHERE 成立时间 == "1988年5月" and 主导产业 == "电子信息、先进制造、新能源、新材料、生物技术"	5a4f2182312b11e98341542696d6e445
qid750	SELECT 试点概率较大的园区 WHERE 成立时间 == "1988年5月" and 主导产业 == "电子信息、先进制造、新能源、新材料、生物技术"	5a4f2182312b11e98341542696d6e445
qid751	SELECT EPS2017A , EPS2018E WHERE 证券 == "南方航空"	01562780351311e995f2542696d6e445
qid752	SELECT EPS2017A , EPS2018E WHERE 证券 == "南方航空"	01562780351311e995f2542696d6e445
qid753	SELECT EPS2017A , EPS2018E WHERE 证券 == "南方航空"	01562780351311e995f2542696d6e445
qid754	SELECT 公司 , 代码 WHERE PE2018E < "20" and PE2019E < "20"	69cf0a23334311e9a862542696d6e445
qid755	SELECT 公司 , 代码 WHERE PE2018E < "20" and PE2019E < "20"	69cf0a23334311e9a862542696d6e445
qid756	SELECT 公司 , 代码 WHERE PE2018E < "20" and PE2019E < "20"	69cf0a23334311e9a862542696d6e445
qid757	SELECT 内部收益率 WHERE 扩建时间（年） == "2015-2019" and 机场 == "上海机场"	733d0f1c34c611e99b4f542696d6e445
qid758	SELECT 内部收益率 WHERE 扩建时间（年） == "2015-2019" and 机场 == "上海机场"	733d0f1c34c611e99b4f542696d6e445
qid759	SELECT 内部收益率 WHERE 扩建时间（年） == "2015-2019" and 机场 == "上海机场"	733d0f1c34c611e99b4f542696d6e445
qid760	SELECT 跌股票 WHERE 跌股收盘价 > "3"	43ae8f941d7111e98e72f40f24344a08
qid761	SELECT 跌股票 WHERE 跌股收盘价 > "3"	43ae8f941d7111e98e72f40f24344a08
qid762	SELECT 跌股票 WHERE 跌股收盘价 > "3"	43ae8f941d7111e98e72f40f24344a08
qid763	SELECT 2018总收入同比增长率(%) WHERE 证券简称 == "中远海能" and 2017总收入同比增长率(%) < "10"	c5ad47a834b411e996f0542696d6e445
qid764	SELECT 2018总收入同比增长率(%) WHERE 证券简称 == "中远海能" and 2017总收入同比增长率(%) < "10"	c5ad47a834b411e996f0542696d6e445
qid765	SELECT 2018总收入同比增长率(%) WHERE 证券简称 == "中远海能" and 2017总收入同比增长率(%) < "10"	c5ad47a834b411e996f0542696d6e445
qid766	SELECT 代码 , 名称 WHERE 收盘价 > "10"	4d25793a3aaa11e9b754f40f24344a08
qid767	SELECT 代码 , 名称 WHERE 收盘价 > "10"	4d25793a3aaa11e9b754f40f24344a08
qid768	SELECT 代码 , 名称 WHERE 收盘价 > "10"	4d25793a3aaa11e9b754f40f24344a08
qid769	SELECT 线路名称 WHERE 线路长度（公里） > "100" and 投资金额（亿元） > "100"	43b317d11d7111e9a717f40f24344a08
qid770	SELECT 线路名称 WHERE 线路长度（公里） > "100" and 投资金额（亿元） > "100"	43b317d11d7111e9a717f40f24344a08
qid771	SELECT 线路名称 WHERE 线路长度（公里） > "100" and 投资金额（亿元） > "100"	43b317d11d7111e9a717f40f24344a08
qid772	SELECT AVG ( 2010成交面积 ) WHERE 2011同期 > "100" or 2012至今 > "50"	69d5567a334311e99539542696d6e445
qid773	SELECT AVG ( 2010成交面积 ) WHERE 2011同期 > "100" or 2012至今 > "50"	69d5567a334311e99539542696d6e445
qid774	SELECT AVG ( 2010成交面积 ) WHERE 2011同期 > "100" or 2012至今 > "50"	69d5567a334311e99539542696d6e445
qid775	SELECT 本月涨跌幅 WHERE 简称 == "铁路运输Ⅱ(申万)" and 本周涨跌幅 > "1"	733c4cb334c611e9b645542696d6e445
qid776	SELECT 本月涨跌幅 WHERE 简称 == "铁路运输Ⅱ(申万)" and 本周涨跌幅 > "1"	733c4cb334c611e9b645542696d6e445
qid777	SELECT 本月涨跌幅 WHERE 简称 == "铁路运输Ⅱ(申万)" and 本周涨跌幅 > "1"	733c4cb334c611e9b645542696d6e445
qid778	SELECT 总市值 WHERE 0601股价 > "3.61" or 证券简称 == "华联控股"	e0adae75333a11e9a131542696d6e445
qid779	SELECT 总市值 WHERE 0601股价 > "3.61" or 证券简称 == "华联控股"	e0adae75333a11e9a131542696d6e445
qid780	SELECT 总市值 WHERE 0601股价 > "3.61" or 证券简称 == "华联控股"	e0adae75333a11e9a131542696d6e445
qid781	SELECT 2010成交面积 WHERE 2011年成交面积 > "10" and 2011同期 > "10"	69d5227d334311e9a09c542696d6e445
qid782	SELECT 2010成交面积 WHERE 2011年成交面积 > "10" and 2011同期 > "10"	69d5227d334311e9a09c542696d6e445
qid783	SELECT 2010成交面积 WHERE 2011年成交面积 > "10" and 2011同期 > "10"	69d5227d334311e9a09c542696d6e445
qid784	SELECT 股票代码 WHERE 周涨跌（%） > "0.5" and 市值（亿元） < "30"	43ada6801d7111e998e8f40f24344a08
qid785	SELECT 股票代码 WHERE 周涨跌（%） > "0.5" and 市值（亿元） < "30"	43ada6801d7111e998e8f40f24344a08
qid786	SELECT 股票代码 WHERE 周涨跌（%） > "0.5" and 市值（亿元） < "30"	43ada6801d7111e998e8f40f24344a08
qid787	SELECT 股价（元） WHERE 公司名称 == "三环集团" or 公司名称 == "海康威视"	0de74861351311e9bf58542696d6e445
qid788	SELECT 股价（元） WHERE 公司名称 == "三环集团" or 公司名称 == "海康威视"	0de74861351311e9bf58542696d6e445
qid789	SELECT 股价（元） WHERE 公司名称 == "三环集团" or 公司名称 == "海康威视"	0de74861351311e9bf58542696d6e445
qid790	SELECT 收益率 , EPS19E WHERE 简称 == "中信证券" and 股票代码 == "600030.SH"	e0ac35f8333a11e99688542696d6e445
qid791	SELECT 收益率 , EPS19E WHERE 简称 == "中信证券" and 股票代码 == "600030.SH"	e0ac35f8333a11e99688542696d6e445
qid792	SELECT 收益率 , EPS19E WHERE 简称 == "中信证券" and 股票代码 == "600030.SH"	e0ac35f8333a11e99688542696d6e445
qid793	SELECT 消化时间 WHERE 周均成交同比 < "0" or 本周成交环比 < "0"	69d06085334311e9ac7e542696d6e445
qid794	SELECT 消化时间 WHERE 周均成交同比 < "0" or 本周成交环比 < "0"	69d06085334311e9ac7e542696d6e445
qid795	SELECT 降价幅度 WHERE 项目 == "保利海上五月花" and 备注 == "楼面价2981元/平米，高层价格约9000元/平，别墅未开盘。、"	5a4f2fa8312b11e98edd542696d6e445
qid796	SELECT 降价幅度 WHERE 项目 == "保利海上五月花" and 备注 == "楼面价2981元/平米，高层价格约9000元/平，别墅未开盘。、"	5a4f2fa8312b11e98edd542696d6e445
qid797	SELECT COUNT ( 剧集名称 ) WHERE 播放量（万） > "1000"	4d2a3de33aaa11e9bfe7f40f24344a08
qid798	SELECT COUNT ( 剧集名称 ) WHERE 播放量（万） > "1000"	4d2a3de33aaa11e9bfe7f40f24344a08
qid799	SELECT COUNT ( 剧集名称 ) WHERE 播放量（万） > "1000"	4d2a3de33aaa11e9bfe7f40f24344a08
qid800	SELECT COUNT ( 剧集名称 ) WHERE 播放量（万） > "1000"	4d2a3de33aaa11e9bfe7f40f24344a08
qid801	SELECT COUNT ( 剧集名称 ) WHERE 播放量（万） > "1000"	4d2a3de33aaa11e9bfe7f40f24344a08
qid802	SELECT 证券简称 WHERE 收盘价(元) > "4" and 总市值(亿元) > "4" and 总股本(亿股) > "4"	69d3faa1334311e9a5bf542696d6e445
qid803	SELECT 证券简称 WHERE 收盘价(元) > "4" and 总市值(亿元) > "4" and 总股本(亿股) > "4"	69d3faa1334311e9a5bf542696d6e445
qid804	SELECT 证券简称 WHERE 收盘价(元) > "4" and 总市值(亿元) > "4" and 总股本(亿股) > "4"	69d3faa1334311e9a5bf542696d6e445
qid805	SELECT PB WHERE EPS19E < "1" and 盈利增长率19E < "100" and PE19E < "20"	463e64ee351411e99af2542696d6e445
qid806	SELECT PB WHERE EPS19E < "1" and 盈利增长率19E < "100" and PE19E < "20"	463e64ee351411e99af2542696d6e445
qid807	SELECT PB WHERE EPS19E < "1" and 盈利增长率19E < "100" and PE19E < "20"	463e64ee351411e99af2542696d6e445
qid808	SELECT COUNT ( 证券简称 ) WHERE 定增年度 == "2017" and 增发目的 == "配套融资"	4d263cee3aaa11e989cef40f24344a08
qid809	SELECT COUNT ( 证券简称 ) WHERE 定增年度 == "2017" and 增发目的 == "配套融资"	4d263cee3aaa11e989cef40f24344a08
qid810	SELECT COUNT ( 证券简称 ) WHERE 定增年度 == "2017" and 增发目的 == "配套融资"	4d263cee3aaa11e989cef40f24344a08
qid811	SELECT 区域 WHERE 环比上上周 > "10"	69d508ca334311e9bf0c542696d6e445
qid812	SELECT 区域 WHERE 环比上上周 > "10"	69d508ca334311e9bf0c542696d6e445
qid813	SELECT 区域 WHERE 环比上上周 > "10"	69d508ca334311e9bf0c542696d6e445
qid814	SELECT COUNT ( 城市 ) WHERE 城市 < "14城合计"	e0ac070c333a11e9849c542696d6e445
qid815	SELECT 股票代码 WHERE 周涨跌幅（%） < "0" or 年涨跌幅%） > "0"	43b0145e1d7111e9841af40f24344a08
qid816	SELECT 股票代码 WHERE 周涨跌幅（%） < "0" or 年涨跌幅%） > "0"	43b0145e1d7111e9841af40f24344a08
qid817	SELECT 股票代码 WHERE 周涨跌幅（%） < "0" or 年涨跌幅%） > "0"	43b0145e1d7111e9841af40f24344a08
qid818	SELECT 2016A市盈率(x) WHERE 公司简称 == "应流股份" and 市值(亿元) > "10"	69ce918f334311e99023542696d6e445
qid819	SELECT 2016A市盈率(x) WHERE 公司简称 == "应流股份" and 市值(亿元) > "10"	69ce918f334311e99023542696d6e445
qid820	SELECT 2016A市盈率(x) WHERE 公司简称 == "应流股份" and 市值(亿元) > "10"	69ce918f334311e99023542696d6e445
qid821	SELECT 频道 WHERE 收视率% > "0.5" or 市场份额% > "2"	4d2532a33aaa11e9b4def40f24344a08
qid822	SELECT 频道 WHERE 收视率% > "0.5" or 市场份额% > "2"	4d2532a33aaa11e9b4def40f24344a08
qid823	SELECT 频道 WHERE 收视率% > "0.5" or 市场份额% > "2"	4d2532a33aaa11e9b4def40f24344a08
qid824	SELECT 2011周平均成交量 WHERE 城市 == "成都"	69d46851334311e9a9e1542696d6e445
qid825	SELECT 2011周平均成交量 WHERE 城市 == "成都"	69d46851334311e9a9e1542696d6e445
qid826	SELECT 2011周平均成交量 WHERE 城市 == "成都"	69d46851334311e9a9e1542696d6e445
qid827	SELECT MIN ( PB ) WHERE 公司简称 == "申通快递" and 股价（元） > "10"	463e7e59351411e994e3542696d6e445
qid828	SELECT MIN ( PB ) WHERE 公司简称 == "申通快递" and 股价（元） > "10"	463e7e59351411e994e3542696d6e445
qid829	SELECT MIN ( PB ) WHERE 公司简称 == "申通快递" and 股价（元） > "10"	463e7e59351411e994e3542696d6e445
qid830	SELECT 数据上调时间 WHERE 贷款利率调整前 > "6" and 贷款利率调整后 > "6"	5a4ea2c2312b11e9a25b542696d6e445
qid831	SELECT 数据上调时间 WHERE 贷款利率调整前 > "6" and 贷款利率调整后 > "6"	5a4ea2c2312b11e9a25b542696d6e445
qid832	SELECT 数据上调时间 WHERE 贷款利率调整前 > "6" and 贷款利率调整后 > "6"	5a4ea2c2312b11e9a25b542696d6e445
qid833	SELECT 城市 WHERE 2011同期 > "200" and 2012至今 > "200"	69d56ffd334311e9a90e542696d6e445
qid834	SELECT 城市 WHERE 2011同期 > "200" and 2012至今 > "200"	69d56ffd334311e9a90e542696d6e445
qid835	SELECT 城市 WHERE 2011同期 > "200" and 2012至今 > "200"	69d56ffd334311e9a90e542696d6e445
qid836	SELECT AVG ( 2017年分红比例 ) WHERE 市盈率PE > "10" or 股息率 > "5"	733c7e8a34c611e9a7d9542696d6e445
qid837	SELECT AVG ( 2017年分红比例 ) WHERE 市盈率PE > "10" or 股息率 > "5"	733c7e8a34c611e9a7d9542696d6e445
qid838	SELECT AVG ( 2017年分红比例 ) WHERE 市盈率PE > "10" or 股息率 > "5"	733c7e8a34c611e9a7d9542696d6e445
qid839	SELECT 导演 WHERE 类型 == "歌舞/喜剧"	4d2823613aaa11e9ab7df40f24344a08
qid840	SELECT 导演 WHERE 类型 == "歌舞/喜剧"	4d2823613aaa11e9ab7df40f24344a08
qid841	SELECT 导演 WHERE 类型 == "歌舞/喜剧"	4d2823613aaa11e9ab7df40f24344a08
qid842	SELECT COUNT ( 证券简称 ) WHERE 11AEPS > "0.6" and 10AEPS > "0.6"	e0af35d1333a11e99d28542696d6e445
qid843	SELECT COUNT ( 证券简称 ) WHERE 11AEPS > "0.6" and 10AEPS > "0.6"	e0af35d1333a11e99d28542696d6e445
qid844	SELECT COUNT ( 证券简称 ) WHERE 11AEPS > "0.6" and 10AEPS > "0.6"	e0af35d1333a11e99d28542696d6e445
qid845	SELECT 收盘价 WHERE 代码 == "CCIH.O" or 代码 == "JOBS.O"	4d2580e13aaa11e995c8f40f24344a08
qid846	SELECT 收盘价 WHERE 代码 == "CCIH.O" or 代码 == "JOBS.O"	4d2580e13aaa11e995c8f40f24344a08
qid847	SELECT 收盘价 WHERE 代码 == "CCIH.O" or 代码 == "JOBS.O"	4d2580e13aaa11e995c8f40f24344a08
qid848	SELECT 北京 WHERE 深圳 == "104.15" and 时间 == "2011/6/25"	c98a9959332111e9b08b542696d6e445
qid849	SELECT 北京 WHERE 深圳 == "104.15" and 时间 == "2011/6/25"	c98a9959332111e9b08b542696d6e445
qid850	SELECT 银行 WHERE 本周相对大盘收益 > "1" and 本周涨跌幅 > "1"	43aec1971d7111e99f21f40f24344a08
qid851	SELECT 银行 WHERE 本周相对大盘收益 > "1" and 本周涨跌幅 > "1"	43aec1971d7111e99f21f40f24344a08
qid852	SELECT 银行 WHERE 本周相对大盘收益 > "1" and 本周涨跌幅 > "1"	43aec1971d7111e99f21f40f24344a08
qid853	SELECT 公司 WHERE PE19E > "20" or PE20E > "20"	01553ea6351311e981b5542696d6e445
qid854	SELECT 公司 WHERE PE19E > "20" or PE20E > "20"	01553ea6351311e981b5542696d6e445
qid855	SELECT 公司 WHERE PE19E > "20" or PE20E > "20"	01553ea6351311e981b5542696d6e445
qid856	SELECT SUM ( 业务量(亿件) ) WHERE 公司 == "申通快递" or 公司 == "韵达股份"	c5ad627334b411e9ba90542696d6e445
qid857	SELECT SUM ( 业务量(亿件) ) WHERE 公司 == "申通快递" or 公司 == "韵达股份"	c5ad627334b411e9ba90542696d6e445
qid858	SELECT SUM ( 业务量(亿件) ) WHERE 公司 == "申通快递" or 公司 == "韵达股份"	c5ad627334b411e9ba90542696d6e445
qid859	SELECT 城市 WHERE 2012年2月成交量环比 > "10" and 2011年12月成交量环比 < "10"	69d14c3a334311e9b68e542696d6e445
qid860	SELECT 城市 WHERE 2012年2月成交量环比 > "10" and 2011年12月成交量环比 < "10"	69d14c3a334311e9b68e542696d6e445
qid861	SELECT 城市 WHERE 2012年2月成交量环比 > "10" and 2011年12月成交量环比 < "10"	69d14c3a334311e9b68e542696d6e445
qid862	SELECT 公司名称 WHERE PE2011 > "0.6" and PE2012 > "0.6"	69cf2f21334311e9b2e5542696d6e445
qid863	SELECT 公司名称 WHERE PE2011 > "0.6" and PE2012 > "0.6"	69cf2f21334311e9b2e5542696d6e445
qid864	SELECT 公司名称 WHERE PE2011 > "0.6" and PE2012 > "0.6"	69cf2f21334311e9b2e5542696d6e445
qid865	SELECT 证券简称 WHERE 10AEPS > "0.2" and 11AEPS > "0.2"	e0ad8a21333a11e9a5f8542696d6e445
qid866	SELECT 证券简称 WHERE 10AEPS > "0.2" and 11AEPS > "0.2"	e0ad8a21333a11e9a5f8542696d6e445
qid867	SELECT 证券简称 WHERE 10AEPS > "0.2" and 11AEPS > "0.2"	e0ad8a21333a11e9a5f8542696d6e445
qid868	SELECT 楼盘名称 WHERE 5月均价(元/㎡) > "40000" and 月环比涨幅 > "7"	5a4fa280312b11e9b78d542696d6e445
qid869	SELECT 楼盘名称 WHERE 5月均价(元/㎡) > "40000" and 月环比涨幅 > "7"	5a4fa280312b11e9b78d542696d6e445
qid870	SELECT 楼盘名称 WHERE 5月均价(元/㎡) > "40000" and 月环比涨幅 > "7"	5a4fa280312b11e9b78d542696d6e445
qid871	SELECT 收盘价(元) WHERE 每股预收(元) > "6" or 证券简称 == "保利地产"	69d3faa1334311e9a5bf542696d6e445
qid872	SELECT 收盘价(元) WHERE 每股预收(元) > "6" or 证券简称 == "保利地产"	69d3faa1334311e9a5bf542696d6e445
qid873	SELECT 收盘价(元) WHERE 每股预收(元) > "6" or 证券简称 == "保利地产"	69d3faa1334311e9a5bf542696d6e445
qid874	SELECT 最高罚款额 WHERE 规则 == "SECA" and 国家/地区 == "丹麦"	c5aad01734b411e9adef542696d6e445
qid875	SELECT 最高罚款额 WHERE 规则 == "SECA" and 国家/地区 == "丹麦"	c5aad01734b411e9adef542696d6e445
qid876	SELECT 最高罚款额 WHERE 规则 == "SECA" and 国家/地区 == "丹麦"	c5aad01734b411e9adef542696d6e445
qid877	SELECT 公司 WHERE 2016Q1 > "0" and 2016Q2 > "0"	0de5cff0351311e9a456542696d6e445
qid878	SELECT 公司 WHERE 2016Q1 > "0" and 2016Q2 > "0"	0de5cff0351311e9a456542696d6e445
qid879	SELECT 公司 WHERE 2016Q1 > "0" and 2016Q2 > "0"	0de5cff0351311e9a456542696d6e445
qid880	SELECT AVG ( 去年同期 ) WHERE 本期 > "1" and 上期 > "1"	5a4a8bcc312b11e9a932542696d6e445
qid881	SELECT AVG ( 去年同期 ) WHERE 本期 > "1" and 上期 > "1"	5a4a8bcc312b11e9a932542696d6e445
qid882	SELECT AVG ( 去年同期 ) WHERE 本期 > "1" and 上期 > "1"	5a4a8bcc312b11e9a932542696d6e445
qid883	SELECT 城市 WHERE 2011年12月成交量环比 < "10" and 2011年11月成交量环比 < "5"	69d14c3a334311e9b68e542696d6e445
qid884	SELECT 城市 WHERE 2011年12月成交量环比 < "10" and 2011年11月成交量环比 < "5"	69d14c3a334311e9b68e542696d6e445
qid885	SELECT 城市 WHERE 2011年12月成交量环比 < "10" and 2011年11月成交量环比 < "5"	69d14c3a334311e9b68e542696d6e445
qid886	SELECT 股价 WHERE PB估值 < "3"	69d4b4c5334311e99dff542696d6e445
qid887	SELECT 股价 WHERE PB估值 < "3"	69d4b4c5334311e99dff542696d6e445
qid888	SELECT 股价 WHERE PB估值 < "3"	69d4b4c5334311e99dff542696d6e445
qid889	SELECT COUNT ( 公司名称 ) WHERE 国家 == "日本"	0de5bd30351311e9b355542696d6e445
qid890	SELECT COUNT ( 公司名称 ) WHERE 国家 == "日本"	0de5bd30351311e9b355542696d6e445
qid891	SELECT COUNT ( 公司名称 ) WHERE 国家 == "日本"	0de5bd30351311e9b355542696d6e445
qid892	SELECT 时间 WHERE 成交住宅建筑面积（万平米） > "30" and 成交住宅土地宗数 > "3"	5a4edf57312b11e9b253542696d6e445
qid893	SELECT 时间 WHERE 成交住宅建筑面积（万平米） > "30" and 成交住宅土地宗数 > "3"	5a4edf57312b11e9b253542696d6e445
qid894	SELECT 时间 WHERE 成交住宅建筑面积（万平米） > "30" and 成交住宅土地宗数 > "3"	5a4edf57312b11e9b253542696d6e445
qid895	SELECT 2012年周均成交 WHERE 城市 == "杭州" and 2011年周均成交 < "10"	69d05545334311e99eda542696d6e445
qid896	SELECT 2012年周均成交 WHERE 城市 == "杭州" and 2011年周均成交 < "10"	69d05545334311e99eda542696d6e445
qid897	SELECT 2012年周均成交 WHERE 城市 == "杭州" and 2011年周均成交 < "10"	69d05545334311e99eda542696d6e445
qid898	SELECT 城市 WHERE 10年H1 < "10"	c98c6547332111e9a739542696d6e445
qid899	SELECT 城市 WHERE 10年H1 < "10"	c98c6547332111e9a739542696d6e445
qid900	SELECT 城市 WHERE 10年H1 < "10"	c98c6547332111e9a739542696d6e445
qid901	SELECT 模拟组合 WHERE 最新市价（百万元） > "20" and 最新股价（元/股） > "10" and 持股数量（万股） > "150"	5a509c8a312b11e9a922542696d6e445
qid902	SELECT 模拟组合 WHERE 最新市价（百万元） > "20" and 最新股价（元/股） > "10" and 持股数量（万股） > "150"	5a509c8a312b11e9a922542696d6e445
qid903	SELECT 模拟组合 WHERE 最新市价（百万元） > "20" and 最新股价（元/股） > "10" and 持股数量（万股） > "150"	5a509c8a312b11e9a922542696d6e445
qid904	SELECT 城市 WHERE 上周成交量（套） > "100" or 成交量同比增长 > "100"	69d452ae334311e98c32542696d6e445
qid905	SELECT 城市 WHERE 上周成交量（套） > "100" or 成交量同比增长 > "100"	69d452ae334311e98c32542696d6e445
qid906	SELECT 城市 WHERE 上周成交量（套） > "100" or 成交量同比增长 > "100"	69d452ae334311e98c32542696d6e445
qid907	SELECT AVG ( 净利润增速上限（%） ) WHERE 净利润上限（亿元） > "5" and 净利润下限（亿元） > "5"	4d24bfe13aaa11e992f0f40f24344a08
qid908	SELECT AVG ( 净利润增速上限（%） ) WHERE 净利润上限（亿元） > "5" and 净利润下限（亿元） > "5"	4d24bfe13aaa11e992f0f40f24344a08
qid909	SELECT AVG ( 净利润增速上限（%） ) WHERE 净利润上限（亿元） > "5" and 净利润下限（亿元） > "5"	4d24bfe13aaa11e992f0f40f24344a08
qid910	SELECT 总市值 WHERE 公司 == "华夏幸福"	69d35214334311e9be23542696d6e445
qid911	SELECT 总市值 WHERE 公司 == "华夏幸福"	69d35214334311e9be23542696d6e445
qid912	SELECT 总市值 WHERE 公司 == "华夏幸福"	69d35214334311e9be23542696d6e445
qid913	SELECT AVG ( 累计同比（%） ) WHERE 上周成交量 > "10" and 当月累计成交量 > "100"	e0ac070c333a11e9849c542696d6e445
qid914	SELECT AVG ( 累计同比（%） ) WHERE 上周成交量 > "10" and 当月累计成交量 > "100"	e0ac070c333a11e9849c542696d6e445
qid915	SELECT AVG ( 累计同比（%） ) WHERE 上周成交量 > "10" and 当月累计成交量 > "100"	e0ac070c333a11e9849c542696d6e445
qid916	SELECT 公司简称 WHERE PE18E > "30" and PE19E > "30"	463e7307351411e9b12b542696d6e445
qid917	SELECT 公司简称 WHERE PE18E > "30" and PE19E > "30"	463e7307351411e9b12b542696d6e445
qid918	SELECT 公司简称 WHERE PE18E > "30" and PE19E > "30"	463e7307351411e9b12b542696d6e445
qid919	SELECT 燃料电池公司名称 WHERE 周涨跌幅（%） < "15.24" and 月涨跌幅（%） > "-7.91"	43b0145e1d7111e9841af40f24344a08
qid920	SELECT 燃料电池公司名称 WHERE 周涨跌幅（%） < "15.24" and 月涨跌幅（%） > "-7.91"	43b0145e1d7111e9841af40f24344a08
qid921	SELECT 燃料电池公司名称 WHERE 周涨跌幅（%） < "15.24" and 月涨跌幅（%） > "-7.91"	43b0145e1d7111e9841af40f24344a08
qid922	SELECT 评级 WHERE 股价(元) == "24.09" and 公司简称 == "捷捷微电"	0de68cc5351311e991be542696d6e445
qid923	SELECT 评级 WHERE 股价(元) == "24.09" and 公司简称 == "捷捷微电"	0de68cc5351311e991be542696d6e445
qid924	SELECT 评级 WHERE 股价(元) == "24.09" and 公司简称 == "捷捷微电"	0de68cc5351311e991be542696d6e445
qid925	SELECT 股价 WHERE P/B > "1" or 每股净资产 > "5"	0155563d351311e9b279542696d6e445
qid926	SELECT 股价 WHERE P/B > "1" or 每股净资产 > "5"	0155563d351311e9b279542696d6e445
qid927	SELECT 股价 WHERE P/B > "1" or 每股净资产 > "5"	0155563d351311e9b279542696d6e445
qid928	SELECT 公司 WHERE 产能（万吨） > "10" and 市场占有率 > "1"	43adca851d7111e9b2ccf40f24344a08
qid929	SELECT 公司 WHERE 产能（万吨） > "10" and 市场占有率 > "1"	43adca851d7111e9b2ccf40f24344a08
qid930	SELECT 公司 WHERE 产能（万吨） > "10" and 市场占有率 > "1"	43adca851d7111e9b2ccf40f24344a08
qid931	SELECT 公司名称 WHERE 股价（元） > "10" and 市值（亿元） > "70"	43b0e8de1d7111e9bad6f40f24344a08
qid932	SELECT 公司名称 WHERE 股价（元） > "10" and 市值（亿元） > "70"	43b0e8de1d7111e9bad6f40f24344a08
qid933	SELECT 公司名称 WHERE 股价（元） > "10" and 市值（亿元） > "70"	43b0e8de1d7111e9bad6f40f24344a08
qid934	SELECT 发行方 WHERE 游戏 == "QQ飞车"	4d26a5ee3aaa11e9be8df40f24344a08
qid935	SELECT 发行方 WHERE 游戏 == "QQ飞车"	4d26a5ee3aaa11e9be8df40f24344a08
qid936	SELECT 发行方 WHERE 游戏 == "QQ飞车"	4d26a5ee3aaa11e9be8df40f24344a08
qid937	SELECT 首付 WHERE 贷款利率 > "5" or 月度还款额 > "10000"	5a4e7cb5312b11e9a2fa542696d6e445
qid938	SELECT 首付 WHERE 贷款利率 > "5" or 月度还款额 > "10000"	5a4e7cb5312b11e9a2fa542696d6e445
qid939	SELECT 首付 WHERE 贷款利率 > "5" or 月度还款额 > "10000"	5a4e7cb5312b11e9a2fa542696d6e445
qid940	SELECT 公司名称 , 租赁收入（万元） WHERE 物业面积（万方） > "80"	5a4f254c312b11e981f7542696d6e445
qid941	SELECT 公司名称 , 租赁收入（万元） WHERE 物业面积（万方） > "80"	5a4f254c312b11e981f7542696d6e445
qid942	SELECT 公司名称 , 租赁收入（万元） WHERE 物业面积（万方） > "80"	5a4f254c312b11e981f7542696d6e445
qid943	SELECT COUNT ( 剧集名称 ) WHERE 播放量（亿） > "3"	4d29122b3aaa11e99decf40f24344a08
qid944	SELECT COUNT ( 剧集名称 ) WHERE 播放量（亿） > "3"	4d29122b3aaa11e99decf40f24344a08
qid945	SELECT COUNT ( 剧集名称 ) WHERE 播放量（亿） > "3"	4d29122b3aaa11e99decf40f24344a08
qid946	SELECT COUNT ( 区域 ) WHERE 3Q18/2Q18 > "5" and 3Q18/3817 > "10"	0de65b47351311e99df6542696d6e445
qid947	SELECT COUNT ( 区域 ) WHERE 3Q18/2Q18 > "5" and 3Q18/3817 > "10"	0de65b47351311e99df6542696d6e445
qid948	SELECT COUNT ( 区域 ) WHERE 3Q18/2Q18 > "5" and 3Q18/3817 > "10"	0de65b47351311e99df6542696d6e445
qid949	SELECT COUNT ( 剧集名称 ) WHERE 播出平台 == "芒果TV"	4d2a2fe83aaa11e99004f40f24344a08
qid950	SELECT COUNT ( 剧集名称 ) WHERE 播出平台 == "芒果TV"	4d2a2fe83aaa11e99004f40f24344a08
qid951	SELECT COUNT ( 剧集名称 ) WHERE 播出平台 == "芒果TV"	4d2a2fe83aaa11e99004f40f24344a08
qid952	SELECT COUNT ( 证券简称 ) WHERE 总股本 > "10"	e0af35d1333a11e99d28542696d6e445
qid953	SELECT COUNT ( 证券简称 ) WHERE 总股本 > "10"	e0af35d1333a11e99d28542696d6e445
qid954	SELECT COUNT ( 证券简称 ) WHERE 总股本 > "10"	e0af35d1333a11e99d28542696d6e445
qid955	SELECT MAX ( 总市值 ) WHERE P/R-V < "0.98" or RNAV < "10.0"	69d116a1334311e9ac14542696d6e445
qid956	SELECT MAX ( 总市值 ) WHERE P/R-V < "0.98" or RNAV < "10.0"	69d116a1334311e9ac14542696d6e445
qid957	SELECT MAX ( 总市值 ) WHERE P/R-V < "0.98" or RNAV < "10.0"	69d116a1334311e9ac14542696d6e445
qid958	SELECT 货币资金/总资产 WHERE 货币资金（亿元） < "100" or 总资产（亿元） < "100"	4d285ad93aaa11e9912bf40f24344a08
qid959	SELECT 货币资金/总资产 WHERE 货币资金（亿元） < "100" or 总资产（亿元） < "100"	4d285ad93aaa11e9912bf40f24344a08
qid960	SELECT 货币资金/总资产 WHERE 货币资金（亿元） < "100" or 总资产（亿元） < "100"	4d285ad93aaa11e9912bf40f24344a08
qid961	SELECT 主要产品 , 应用领域 WHERE 单位名称 == "北方华创"	0de75e9c351311e99afb542696d6e445
qid962	SELECT 主要产品 , 应用领域 WHERE 单位名称 == "北方华创"	0de75e9c351311e99afb542696d6e445
qid963	SELECT 主要产品 , 应用领域 WHERE 单位名称 == "北方华创"	0de75e9c351311e99afb542696d6e445
qid964	SELECT 最新收盘价 , 本周涨跌幅 WHERE 证券简称 == "中远海特"	c5ad3b9734b411e9a5f6542696d6e445
qid965	SELECT 最新收盘价 , 本周涨跌幅 WHERE 证券简称 == "中远海特"	c5ad3b9734b411e9a5f6542696d6e445
qid966	SELECT 最新收盘价 , 本周涨跌幅 WHERE 证券简称 == "中远海特"	c5ad3b9734b411e9a5f6542696d6e445
qid967	SELECT 城市 WHERE 环比 < "0"	c98e109e332111e9ad7f542696d6e445
qid968	SELECT 城市 WHERE 环比 < "0"	c98e109e332111e9ad7f542696d6e445
qid969	SELECT 城市 WHERE 环比 < "0"	c98e109e332111e9ad7f542696d6e445
qid970	SELECT 指标 WHERE 绝对量 > "10" and 同比增长（%） > "10"	c989c535332111e9a279542696d6e445
qid971	SELECT 指标 WHERE 绝对量 > "10" and 同比增长（%） > "10"	c989c535332111e9a279542696d6e445
qid972	SELECT 指标 WHERE 绝对量 > "10" and 同比增长（%） > "10"	c989c535332111e9a279542696d6e445
qid973	SELECT MAX ( 累计同比 ) WHERE 2010成交面积 > "500" and 2011年成交面积 > "500"	69d52dd1334311e9920c542696d6e445
qid974	SELECT MAX ( 累计同比 ) WHERE 2010成交面积 > "500" and 2011年成交面积 > "500"	69d52dd1334311e9920c542696d6e445
qid975	SELECT MAX ( 累计同比 ) WHERE 2010成交面积 > "500" and 2011年成交面积 > "500"	69d52dd1334311e9920c542696d6e445
qid976	SELECT 注释 WHERE 可售环比 < "0" or 可售去化时间 < "36"	c98ac519332111e9b2b0542696d6e445
qid977	SELECT 注释 WHERE 可售环比 < "0" or 可售去化时间 < "36"	c98ac519332111e9b2b0542696d6e445
qid978	SELECT 注释 WHERE 可售环比 < "0" or 可售去化时间 < "36"	c98ac519332111e9b2b0542696d6e445
qid979	SELECT 2011年12月成交量同比 WHERE 城市 == "扬州"	69d17e94334311e9a999542696d6e445
qid980	SELECT 2011年12月成交量同比 WHERE 城市 == "扬州"	69d17e94334311e9a999542696d6e445
qid981	SELECT 2011年12月成交量同比 WHERE 城市 == "扬州"	69d17e94334311e9a999542696d6e445
qid982	SELECT COUNT ( 区域 ) WHERE 本周销售套数 < "300"	69d2e7c0334311e98dcf542696d6e445
qid983	SELECT COUNT ( 区域 ) WHERE 本周销售套数 < "300"	69d2e7c0334311e98dcf542696d6e445
qid984	SELECT COUNT ( 区域 ) WHERE 本周销售套数 < "300"	69d2e7c0334311e98dcf542696d6e445
qid985	SELECT COUNT ( 院线 ) WHERE 2018年票房（亿元） > "50" or 单银幕票房（万元） > "100"	4d2786593aaa11e9bd56f40f24344a08
qid986	SELECT COUNT ( 院线 ) WHERE 2018年票房（亿元） > "50" or 单银幕票房（万元） > "100"	4d2786593aaa11e9bd56f40f24344a08
qid987	SELECT COUNT ( 院线 ) WHERE 2018年票房（亿元） > "50" or 单银幕票房（万元） > "100"	4d2786593aaa11e9bd56f40f24344a08
qid988	SELECT COUNT ( 城市名 ) WHERE 环比 > "1" or 近8日日均环比 > "1"	252d4394302e11e985af542696d6e445
qid989	SELECT COUNT ( 城市名 ) WHERE 环比 > "1" or 近8日日均环比 > "1"	252d4394302e11e985af542696d6e445
qid990	SELECT COUNT ( 城市名 ) WHERE 环比 > "1" or 近8日日均环比 > "1"	252d4394302e11e985af542696d6e445
qid991	SELECT 区域 WHERE 上周 > "100" and 累计同比 > "10"	69d50473334311e98b32542696d6e445
qid992	SELECT 区域 WHERE 上周 > "100" and 累计同比 > "10"	69d50473334311e98b32542696d6e445
qid993	SELECT 区域 WHERE 上周 > "100" and 累计同比 > "10"	69d50473334311e98b32542696d6e445
qid994	SELECT 周收盘价(元) WHERE 证券简称 == "东方财富" and 周前收盘价(元) > "12"	4d23bd663aaa11e99219f40f24344a08
qid995	SELECT 周收盘价(元) WHERE 证券简称 == "东方财富" and 周前收盘价(元) > "12"	4d23bd663aaa11e99219f40f24344a08
qid996	SELECT 周收盘价(元) WHERE 证券简称 == "东方财富" and 周前收盘价(元) > "12"	4d23bd663aaa11e99219f40f24344a08
qid997	SELECT 累计值 , 一线城市 WHERE 同比增速 < "0"	e0ac9099333a11e987e7542696d6e445
qid998	SELECT 累计值 , 一线城市 WHERE 同比增速 < "0"	e0ac9099333a11e987e7542696d6e445
qid999	SELECT 累计值 , 一线城市 WHERE 同比增速 < "0"	e0ac9099333a11e987e7542696d6e445
qid1000	SELECT 城市 WHERE 2011年周均成交 < "10" and 2012年周均成交 < "10"	69d06085334311e9ac7e542696d6e445
qid1001	SELECT 城市 WHERE 2011年周均成交 < "10" and 2012年周均成交 < "10"	69d06085334311e9ac7e542696d6e445
qid1002	SELECT 城市 WHERE 2011年周均成交 < "10" and 2012年周均成交 < "10"	69d06085334311e9ac7e542696d6e445
qid1003	SELECT Code WHERE 年涨跌幅 < "0"	c5ac5f6e34b411e9b645542696d6e445
qid1004	SELECT Code WHERE 年涨跌幅 < "0"	c5ac5f6e34b411e9b645542696d6e445
qid1005	SELECT Code WHERE 年涨跌幅 < "0"	c5ac5f6e34b411e9b645542696d6e445
qid1006	SELECT COUNT ( 证券简称 ) WHERE 周成交额(亿元) > "10"	4d23bd663aaa11e99219f40f24344a08
qid1007	SELECT COUNT ( 证券简称 ) WHERE 周成交额(亿元) > "10"	4d23bd663aaa11e99219f40f24344a08
qid1008	SELECT COUNT ( 证券简称 ) WHERE 周成交额(亿元) > "10"	4d23bd663aaa11e99219f40f24344a08
qid1009	SELECT 市值(USDmn) , 代码 WHERE 股票名称 == "新加坡航空"	6e61880034ce11e99a3b542696d6e445
qid1010	SELECT 市值(USDmn) , 代码 WHERE 股票名称 == "新加坡航空"	6e61880034ce11e99a3b542696d6e445
qid1011	SELECT 市值(USDmn) , 代码 WHERE 股票名称 == "新加坡航空"	6e61880034ce11e99a3b542696d6e445
qid1012	SELECT COUNT ( 线路名称 ) WHERE 里程(公里) > "150"	6e61364a34ce11e9a4dd542696d6e445
qid1013	SELECT COUNT ( 线路名称 ) WHERE 里程(公里) > "150"	6e61364a34ce11e9a4dd542696d6e445
qid1014	SELECT COUNT ( 线路名称 ) WHERE 里程(公里) > "150"	6e61364a34ce11e9a4dd542696d6e445
qid1015	SELECT 证券简称2 WHERE 商誉/净资产2 > "10" and 商誉/净利润2 > "10"	4d2488543aaa11e98fdbf40f24344a08
qid1016	SELECT 证券简称2 WHERE 商誉/净资产2 > "10" and 商誉/净利润2 > "10"	4d2488543aaa11e98fdbf40f24344a08
qid1017	SELECT 证券简称2 WHERE 商誉/净资产2 > "10" and 商誉/净利润2 > "10"	4d2488543aaa11e98fdbf40f24344a08
qid1018	SELECT COUNT ( 影院名称 ) WHERE 单日单厅票房（元） > "10000" and 单日单厅场次 > "5"	4d28e2513aaa11e996b7f40f24344a08
qid1019	SELECT COUNT ( 影院名称 ) WHERE 单日单厅票房（元） > "10000" and 单日单厅场次 > "5"	4d28e2513aaa11e996b7f40f24344a08
qid1020	SELECT COUNT ( 影院名称 ) WHERE 单日单厅票房（元） > "10000" and 单日单厅场次 > "5"	4d28e2513aaa11e996b7f40f24344a08
qid1021	SELECT 楼盘名称 WHERE 3月套数 > "50" and 3月均价 > "100"	5a4fe330312b11e99eaf542696d6e445
qid1022	SELECT 楼盘名称 WHERE 3月套数 > "50" and 3月均价 > "100"	5a4fe330312b11e99eaf542696d6e445
qid1023	SELECT 楼盘名称 WHERE 3月套数 > "50" and 3月均价 > "100"	5a4fe330312b11e99eaf542696d6e445
qid1024	SELECT 城市 WHERE 上周成交面积 > "20" and 本周成交面积 > "5"	252ebee1302e11e98294542696d6e445
qid1025	SELECT 城市 WHERE 上周成交面积 > "20" and 本周成交面积 > "5"	252ebee1302e11e98294542696d6e445
qid1026	SELECT 城市 WHERE 上周成交面积 > "20" and 本周成交面积 > "5"	252ebee1302e11e98294542696d6e445
qid1027	SELECT 需进行一致性评价企业数（家） , 药品数（个） WHERE 批文数占比（%） < "7.2"	43afc99c1d7111e9936af40f24344a08
qid1028	SELECT 需进行一致性评价企业数（家） , 药品数（个） WHERE 批文数占比（%） < "7.2"	43afc99c1d7111e9936af40f24344a08
qid1029	SELECT 需进行一致性评价企业数（家） , 药品数（个） WHERE 批文数占比（%） < "7.2"	43afc99c1d7111e9936af40f24344a08
qid1030	SELECT SUM ( 周票房（万） ) WHERE 影片名称 == "大黄蜂" or 影片名称 == "海王"	4d29d0513aaa11e9b911f40f24344a08
qid1031	SELECT SUM ( 周票房（万） ) WHERE 影片名称 == "大黄蜂" or 影片名称 == "海王"	4d29d0513aaa11e9b911f40f24344a08
qid1032	SELECT SUM ( 周票房（万） ) WHERE 影片名称 == "大黄蜂" or 影片名称 == "海王"	4d29d0513aaa11e9b911f40f24344a08
qid1033	SELECT 股票名称 WHERE 周涨跌（%） < "3" or 收盘价（元） < "15"	43ad93211d7111e998d9f40f24344a08
qid1034	SELECT 股票名称 WHERE 周涨跌（%） < "3" or 收盘价（元） < "15"	43ad93211d7111e998d9f40f24344a08
qid1035	SELECT 股票名称 WHERE 周涨跌（%） < "3" or 收盘价（元） < "15"	43ad93211d7111e998d9f40f24344a08
qid1036	SELECT 城市 WHERE 前一周成交 > "1000" and 近4周周均成交 > "1000" and 上一年度同期成交 > "1000"	69cca5a3334311e986ba542696d6e445
qid1037	SELECT 城市 WHERE 前一周成交 > "1000" and 近4周周均成交 > "1000" and 上一年度同期成交 > "1000"	69cca5a3334311e986ba542696d6e445
qid1038	SELECT 城市 WHERE 前一周成交 > "1000" and 近4周周均成交 > "1000" and 上一年度同期成交 > "1000"	69cca5a3334311e986ba542696d6e445
qid1039	SELECT 增发目的 WHERE 最新收盘价 < "6" or 倒挂率 < "50"	4d264feb3aaa11e9a402f40f24344a08
qid1040	SELECT 增发目的 WHERE 最新收盘价 < "6" or 倒挂率 < "50"	4d264feb3aaa11e9a402f40f24344a08
qid1041	SELECT 增发目的 WHERE 最新收盘价 < "6" or 倒挂率 < "50"	4d264feb3aaa11e9a402f40f24344a08
qid1042	SELECT 公司 WHERE PE2012E < "10" and PE2013E < "10"	69d116a1334311e9ac14542696d6e445
qid1043	SELECT 公司 WHERE PE2012E < "10" and PE2013E < "10"	69d116a1334311e9ac14542696d6e445
qid1044	SELECT 公司 WHERE PE2012E < "10" and PE2013E < "10"	69d116a1334311e9ac14542696d6e445
qid1045	SELECT AVG ( 倒挂率 ) WHERE 定增价除权后至今价格 > "10" and 增发价格 > "20"	4d26371c3aaa11e99687f40f24344a08
qid1046	SELECT AVG ( 倒挂率 ) WHERE 定增价除权后至今价格 > "10" and 增发价格 > "20"	4d26371c3aaa11e99687f40f24344a08
qid1047	SELECT AVG ( 倒挂率 ) WHERE 定增价除权后至今价格 > "10" and 增发价格 > "20"	4d26371c3aaa11e99687f40f24344a08
qid1048	SELECT 代码 WHERE 最新股价 > "10" and PB估值 > "3"	69cf9bb8334311e9bf43542696d6e445
qid1049	SELECT 代码 WHERE 最新股价 > "10" and PB估值 > "3"	69cf9bb8334311e9bf43542696d6e445
qid1050	SELECT 代码 WHERE 最新股价 > "10" and PB估值 > "3"	69cf9bb8334311e9bf43542696d6e445
qid1051	SELECT 股票名称 WHERE 本周换手率（%） > "5" or 2018年动态PE > "10"	c5aed12b34b411e9841a542696d6e445
qid1052	SELECT 股票名称 WHERE 本周换手率（%） > "5" or 2018年动态PE > "10"	c5aed12b34b411e9841a542696d6e445
qid1053	SELECT 股票名称 WHERE 本周换手率（%） > "5" or 2018年动态PE > "10"	c5aed12b34b411e9841a542696d6e445
qid1054	SELECT COUNT ( 城市 ) WHERE 周均成交同比 > "10" and 备注 == "商品住宅"	69d26fde334311e99590542696d6e445
qid1055	SELECT COUNT ( 城市 ) WHERE 周均成交同比 > "10" and 备注 == "商品住宅"	69d26fde334311e99590542696d6e445
qid1056	SELECT COUNT ( 城市 ) WHERE 周均成交同比 > "10" and 备注 == "商品住宅"	69d26fde334311e99590542696d6e445
qid1057	SELECT COUNT ( 证券简称 ) WHERE 0608股价 > "10" or 总市值 > "200"	c98dd373332111e9b4fb542696d6e445
qid1058	SELECT COUNT ( 证券简称 ) WHERE 0608股价 > "10" or 总市值 > "200"	c98dd373332111e9b4fb542696d6e445
qid1059	SELECT COUNT ( 证券简称 ) WHERE 0608股价 > "10" or 总市值 > "200"	c98dd373332111e9b4fb542696d6e445
qid1060	SELECT 容积率 , 成交总价 WHERE 楼面价 > "40000"	c989f997332111e981bf542696d6e445
qid1061	SELECT 容积率 , 成交总价 WHERE 楼面价 > "40000"	c989f997332111e981bf542696d6e445
qid1062	SELECT 容积率 , 成交总价 WHERE 楼面价 > "40000"	c989f997332111e981bf542696d6e445
qid1063	SELECT 证券简称 WHERE 最新市值（亿元） > "60" and 最新股价 > "10"	252c0ccc302e11e9a24c542696d6e445
qid1064	SELECT 证券简称 WHERE 最新市值（亿元） > "60" and 最新股价 > "10"	252c0ccc302e11e9a24c542696d6e445
qid1065	SELECT 证券简称 WHERE 最新市值（亿元） > "60" and 最新股价 > "10"	252c0ccc302e11e9a24c542696d6e445
qid1066	SELECT 证券简称 WHERE 总市值 > "500" or 总股本 > "50"	e0add3f3333a11e9b6d6542696d6e445
qid1067	SELECT 证券简称 WHERE 总市值 > "500" or 总股本 > "50"	e0add3f3333a11e9b6d6542696d6e445
qid1068	SELECT 证券简称 WHERE 总市值 > "500" or 总股本 > "50"	e0add3f3333a11e9b6d6542696d6e445
qid1069	SELECT 周收盘价(元) WHERE 证券简称 == "新华网" or 证券简称 == "人民网"	4d23e7a83aaa11e9926ef40f24344a08
qid1070	SELECT 周收盘价(元) WHERE 证券简称 == "新华网" or 证券简称 == "人民网"	4d23e7a83aaa11e9926ef40f24344a08
qid1071	SELECT 周收盘价(元) WHERE 证券简称 == "新华网" or 证券简称 == "人民网"	4d23e7a83aaa11e9926ef40f24344a08
qid1072	SELECT 公司 WHERE 收入 > "100" or 净利润 > "20"	c5ad099434b411e9b4da542696d6e445
qid1073	SELECT 公司 WHERE 收入 > "100" or 净利润 > "20"	c5ad099434b411e9b4da542696d6e445
qid1074	SELECT 公司 WHERE 收入 > "100" or 净利润 > "20"	c5ad099434b411e9b4da542696d6e445
qid1075	SELECT 市值(USDmn) WHERE 股票名称 == "北欧航空"	6e617a4034ce11e99ef2542696d6e445
qid1076	SELECT 市值(USDmn) WHERE 股票名称 == "北欧航空"	6e617a4034ce11e99ef2542696d6e445
qid1077	SELECT 市值(USDmn) WHERE 股票名称 == "北欧航空"	6e617a4034ce11e99ef2542696d6e445
qid1078	SELECT COUNT ( 地产公司 ) WHERE 今年趋势 == "降低余地不大"	c9899dd4332111e9b4ca542696d6e445
qid1079	SELECT COUNT ( 地产公司 ) WHERE 今年趋势 == "降低余地不大"	c9899dd4332111e9b4ca542696d6e445
qid1080	SELECT COUNT ( 地产公司 ) WHERE 今年趋势 == "降低余地不大"	c9899dd4332111e9b4ca542696d6e445
qid1081	SELECT 总房价(万元) , 首付（30%） WHERE 降息前月还款额10年 < "10000"	5a4e9730312b11e98007542696d6e445
qid1082	SELECT 总房价(万元) , 首付（30%） WHERE 降息前月还款额10年 < "10000"	5a4e9730312b11e98007542696d6e445
qid1083	SELECT 总房价(万元) , 首付（30%） WHERE 降息前月还款额10年 < "10000"	5a4e9730312b11e98007542696d6e445
qid1084	SELECT 院线 WHERE 目前影院数量 > "100" and 2018年底银幕数量 > "600"	4d279b353aaa11e9b320f40f24344a08
qid1085	SELECT 院线 WHERE 目前影院数量 > "100" and 2018年底银幕数量 > "600"	4d279b353aaa11e9b320f40f24344a08
qid1086	SELECT 院线 WHERE 目前影院数量 > "100" and 2018年底银幕数量 > "600"	4d279b353aaa11e9b320f40f24344a08
qid1087	SELECT 收费车型 WHERE 平均费率（元/公里） > "20" or 日均全程交通量（辆/日） > "20000000"	733d6c1734c611e980b0542696d6e445
qid1088	SELECT 收费车型 WHERE 平均费率（元/公里） > "20" or 日均全程交通量（辆/日） > "20000000"	733d6c1734c611e980b0542696d6e445
qid1089	SELECT 收费车型 WHERE 平均费率（元/公里） > "20" or 日均全程交通量（辆/日） > "20000000"	733d6c1734c611e980b0542696d6e445
qid1090	SELECT 证券代码 WHERE 市盈率 > "10" and 市净率 > "1"	733d8a0c34c611e98d5e542696d6e445
qid1091	SELECT 证券代码 WHERE 市盈率 > "10" and 市净率 > "1"	733d8a0c34c611e98d5e542696d6e445
qid1092	SELECT 证券代码 WHERE 市盈率 > "10" and 市净率 > "1"	733d8a0c34c611e98d5e542696d6e445
qid1093	SELECT SUM ( 本周票房（万元） ) WHERE 影片名称 == "1.海王" or 影片名称 == "2.龙猫"	4d2521ba3aaa11e9813cf40f24344a08
qid1094	SELECT SUM ( 本周票房（万元） ) WHERE 影片名称 == "1.海王" or 影片名称 == "2.龙猫"	4d2521ba3aaa11e9813cf40f24344a08
qid1095	SELECT SUM ( 本周票房（万元） ) WHERE 影片名称 == "1.海王" or 影片名称 == "2.龙猫"	4d2521ba3aaa11e9813cf40f24344a08
qid1096	SELECT 月涨跌幅 WHERE 名称 == "聚美优品" and 收盘价 > "2"	4d2769993aaa11e98eb6f40f24344a08
qid1097	SELECT 月涨跌幅 WHERE 名称 == "聚美优品" and 收盘价 > "2"	4d2769993aaa11e98eb6f40f24344a08
qid1098	SELECT 月涨跌幅 WHERE 名称 == "聚美优品" and 收盘价 > "2"	4d2769993aaa11e98eb6f40f24344a08
qid1099	SELECT 2017分红比例 WHERE 2017股息率 == "6.1" and 标的 == "大秦铁路"	c5ac45f534b411e9878b542696d6e445
qid1100	SELECT 2017分红比例 WHERE 2017股息率 == "6.1" and 标的 == "大秦铁路"	c5ac45f534b411e9878b542696d6e445
qid1101	SELECT 2017分红比例 WHERE 2017股息率 == "6.1" and 标的 == "大秦铁路"	c5ac45f534b411e9878b542696d6e445
qid1102	SELECT 证券简称 WHERE 周涨跌幅% > "20" and 周换手率% > "2"	4d242e2b3aaa11e98a7ff40f24344a08
qid1103	SELECT 证券简称 WHERE 周涨跌幅% > "20" and 周换手率% > "2"	4d242e2b3aaa11e98a7ff40f24344a08
qid1104	SELECT 证券简称 WHERE 周涨跌幅% > "20" and 周换手率% > "2"	4d242e2b3aaa11e98a7ff40f24344a08
qid1105	SELECT COUNT ( 城市 ) WHERE 累计同比 > "0"	c98c70ae332111e98c41542696d6e445
qid1106	SELECT COUNT ( 城市 ) WHERE 累计同比 > "0"	c98c70ae332111e98c41542696d6e445
qid1107	SELECT COUNT ( 城市 ) WHERE 累计同比 > "0"	c98c70ae332111e98c41542696d6e445
qid1108	SELECT 本周涨跌幅（%） WHERE 股票名称 == "飞马国际" or 股票名称 == "珠海港"	c5aed12b34b411e9841a542696d6e445
qid1109	SELECT 本周涨跌幅（%） WHERE 股票名称 == "飞马国际" or 股票名称 == "珠海港"	c5aed12b34b411e9841a542696d6e445
qid1110	SELECT 本周涨跌幅（%） WHERE 股票名称 == "飞马国际" or 股票名称 == "珠海港"	c5aed12b34b411e9841a542696d6e445
qid1111	SELECT 时间 WHERE Jan > "9" or Feb > "10"	5a523e30312b11e98b92542696d6e445
qid1112	SELECT 时间 WHERE Jan > "9" or Feb > "10"	5a523e30312b11e98b92542696d6e445
qid1113	SELECT 时间 WHERE Jan > "9" or Feb > "10"	5a523e30312b11e98b92542696d6e445
qid1114	SELECT 证券代码 , 证券简称 WHERE 最新市值（亿元） < "204"	252ca859302e11e9947d542696d6e445
qid1115	SELECT 证券代码 , 证券简称 WHERE 最新市值（亿元） < "204"	252ca859302e11e9947d542696d6e445
qid1116	SELECT 证券代码 , 证券简称 WHERE 最新市值（亿元） < "204"	252ca859302e11e9947d542696d6e445
qid1117	SELECT 城市 , 上周成交面积 WHERE 本周成交面积 > "6"	252ebee1302e11e98294542696d6e445
qid1118	SELECT 城市 , 上周成交面积 WHERE 本周成交面积 > "6"	252ebee1302e11e98294542696d6e445
qid1119	SELECT 城市 , 上周成交面积 WHERE 本周成交面积 > "6"	252ebee1302e11e98294542696d6e445
qid1120	SELECT 城市 , 上周成交面积 WHERE 本周成交面积 > "6"	252ebee1302e11e98294542696d6e445
qid1121	SELECT 证券简称 WHERE 最新市值（亿元） > "50" or 最新股价 > "10"	252c0ccc302e11e9a24c542696d6e445
qid1122	SELECT 证券简称 WHERE 最新市值（亿元） > "50" or 最新股价 > "10"	252c0ccc302e11e9a24c542696d6e445
qid1123	SELECT 证券简称 WHERE 最新市值（亿元） > "50" or 最新股价 > "10"	252c0ccc302e11e9a24c542696d6e445
qid1124	SELECT 2011周平均成交量 WHERE 城市 == "天津" and 上周成交量（套） > "1200"	69d44ca1334311e990f4542696d6e445
qid1125	SELECT 2011周平均成交量 WHERE 城市 == "天津" and 上周成交量（套） > "1200"	69d44ca1334311e990f4542696d6e445
qid1126	SELECT 2011周平均成交量 WHERE 城市 == "天津" and 上周成交量（套） > "1200"	69d44ca1334311e990f4542696d6e445
qid1127	SELECT MAX ( 总市值(亿人民币） ) WHERE PE-TTM > "1" and PB > "0.5" and PS > "0.5"	43b2d3d91d7111e9b7daf40f24344a08
qid1128	SELECT MAX ( 总市值(亿人民币） ) WHERE PE-TTM > "1" and PB > "0.5" and PS > "0.5"	43b2d3d91d7111e9b7daf40f24344a08
qid1129	SELECT MAX ( 总市值(亿人民币） ) WHERE PE-TTM > "1" and PB > "0.5" and PS > "0.5"	43b2d3d91d7111e9b7daf40f24344a08
qid1130	SELECT 时间 WHERE 一线城市 < "40000"	e0ac9099333a11e987e7542696d6e445
qid1131	SELECT 时间 WHERE 一线城市 < "40000"	e0ac9099333a11e987e7542696d6e445
qid1132	SELECT 时间 WHERE 一线城市 < "40000"	e0ac9099333a11e987e7542696d6e445
qid1133	SELECT 去年同期 WHERE 城市 == "深圳" or 城市 == "杭州"	c98cf451332111e98aef542696d6e445
qid1134	SELECT 去年同期 WHERE 城市 == "深圳" or 城市 == "杭州"	c98cf451332111e98aef542696d6e445
qid1135	SELECT 去年同期 WHERE 城市 == "深圳" or 城市 == "杭州"	c98cf451332111e98aef542696d6e445
qid1136	SELECT SUM ( 上周成交面积 ) WHERE 城市 == "昆明" or 城市 == "三亚"	252eb080302e11e9b489542696d6e445
qid1137	SELECT SUM ( 上周成交面积 ) WHERE 城市 == "昆明" or 城市 == "三亚"	252eb080302e11e9b489542696d6e445
qid1138	SELECT SUM ( 上周成交面积 ) WHERE 城市 == "昆明" or 城市 == "三亚"	252eb080302e11e9b489542696d6e445
qid1139	SELECT COUNT ( 公司名称 ) WHERE EPS2011 > "0.2" and EPS2012E > "0.2" and EPS2013E > "0.2"	69cfabd1334311e9bb3b542696d6e445
qid1140	SELECT COUNT ( 公司名称 ) WHERE EPS2011 > "0.2" and EPS2012E > "0.2" and EPS2013E > "0.2"	69cfabd1334311e9bb3b542696d6e445
qid1141	SELECT COUNT ( 公司名称 ) WHERE EPS2011 > "0.2" and EPS2012E > "0.2" and EPS2013E > "0.2"	69cfabd1334311e9bb3b542696d6e445
qid1142	SELECT 证券代码 , 证券简称 WHERE 本周跌幅后十 < "0"	e0ae228c333a11e9abc0542696d6e445
qid1143	SELECT 证券代码 , 证券简称 WHERE 本周跌幅后十 < "0"	e0ae228c333a11e9abc0542696d6e445
qid1144	SELECT 证券代码 , 证券简称 WHERE 本周跌幅后十 < "0"	e0ae228c333a11e9abc0542696d6e445
qid1145	SELECT 证券简称 WHERE 0612股价 > "5" or 总市值 > "50"	e0ae7bee333a11e99031542696d6e445
qid1146	SELECT 证券简称 WHERE 0612股价 > "5" or 总市值 > "50"	e0ae7bee333a11e99031542696d6e445
qid1147	SELECT 证券简称 WHERE 0612股价 > "5" or 总市值 > "50"	e0ae7bee333a11e99031542696d6e445
qid1148	SELECT 名称 WHERE 跌幅（%） > "-6" and PE > "20"	c5ac7c0f34b411e9a895542696d6e445
qid1149	SELECT 名称 WHERE 跌幅（%） > "-6" and PE > "20"	c5ac7c0f34b411e9a895542696d6e445
qid1150	SELECT 名称 WHERE 跌幅（%） > "-6" and PE > "20"	c5ac7c0f34b411e9a895542696d6e445
qid1151	SELECT 2019年TOP5 WHERE 平均票价（元，含服务费） > "40"	4d26d4b03aaa11e9acf2f40f24344a08
qid1152	SELECT 2019年TOP5 WHERE 平均票价（元，含服务费） > "40"	4d26d4b03aaa11e9acf2f40f24344a08
qid1153	SELECT 2019年TOP5 WHERE 平均票价（元，含服务费） > "40"	4d26d4b03aaa11e9acf2f40f24344a08
qid1154	SELECT 月环比涨幅 WHERE 楼盘名称 == "银河湾" and 5月均价(元/㎡) > "100"	c98c2ca1332111e99c14542696d6e445
qid1155	SELECT 月环比涨幅 WHERE 楼盘名称 == "银河湾" and 5月均价(元/㎡) > "100"	c98c2ca1332111e99c14542696d6e445
qid1156	SELECT 月环比涨幅 WHERE 楼盘名称 == "银河湾" and 5月均价(元/㎡) > "100"	c98c2ca1332111e99c14542696d6e445
qid1157	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 < "10"	4d2643873aaa11e9a81df40f24344a08
qid1158	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 < "10"	4d2643873aaa11e9a81df40f24344a08
qid1159	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 < "10"	4d2643873aaa11e9a81df40f24344a08
qid1160	SELECT 区域 WHERE 本周销售面积 > "20" and 本周销售套数 > "1000"	69d2d58a334311e998d7542696d6e445
qid1161	SELECT 区域 WHERE 本周销售面积 > "20" and 本周销售套数 > "1000"	69d2d58a334311e998d7542696d6e445
qid1162	SELECT 区域 WHERE 本周销售面积 > "20" and 本周销售套数 > "1000"	69d2d58a334311e998d7542696d6e445
qid1163	SELECT 公司名称 WHERE 销售收入（百万美元） > "1000" or 同比增长率 > "10"	43b27b231d7111e99c07f40f24344a08
qid1164	SELECT 公司名称 WHERE 销售收入（百万美元） > "1000" or 同比增长率 > "10"	43b27b231d7111e99c07f40f24344a08
qid1165	SELECT 公司名称 WHERE 销售收入（百万美元） > "1000" or 同比增长率 > "10"	43b27b231d7111e99c07f40f24344a08
qid1166	SELECT 上映时间 WHERE 影片名 == "夺命杀机"	4d253d383aaa11e9b259f40f24344a08
qid1167	SELECT 上映时间 WHERE 影片名 == "夺命杀机"	4d253d383aaa11e9b259f40f24344a08
qid1168	SELECT 上映时间 WHERE 影片名 == "夺命杀机"	4d253d383aaa11e9b259f40f24344a08
qid1169	SELECT 证券简称 WHERE PB > "1" or NAV > "8"	5a4daa47312b11e9923a542696d6e445
qid1170	SELECT 证券简称 WHERE PB > "1" or NAV > "8"	5a4daa47312b11e9923a542696d6e445
qid1171	SELECT 证券简称 WHERE PB > "1" or NAV > "8"	5a4daa47312b11e9923a542696d6e445
qid1172	SELECT 2018Q3 WHERE 2016Q4 < "50" or 2017Q4 < "10"	0de60b82351311e9b473542696d6e445
qid1173	SELECT 2018Q3 WHERE 2016Q4 < "50" or 2017Q4 < "10"	0de60b82351311e9b473542696d6e445
qid1174	SELECT 2018Q3 WHERE 2016Q4 < "50" or 2017Q4 < "10"	0de60b82351311e9b473542696d6e445
qid1175	SELECT 最新收盘价 WHERE 证券简称 == "华录百纳" or 证券简称 == "联创互联"	4d25ece33aaa11e986d4f40f24344a08
qid1176	SELECT 最新收盘价 WHERE 证券简称 == "华录百纳" or 证券简称 == "联创互联"	4d25ece33aaa11e986d4f40f24344a08
qid1177	SELECT 最新收盘价 WHERE 证券简称 == "华录百纳" or 证券简称 == "联创互联"	4d25ece33aaa11e986d4f40f24344a08
qid1178	SELECT MAX ( EPS2011A ) WHERE 名称 == "招商地产" or 名称 == "新湖中宝"	69d38e97334311e9affa542696d6e445
qid1179	SELECT MAX ( EPS2011A ) WHERE 名称 == "招商地产" or 名称 == "新湖中宝"	69d38e97334311e9affa542696d6e445
qid1180	SELECT MAX ( EPS2011A ) WHERE 名称 == "招商地产" or 名称 == "新湖中宝"	69d38e97334311e9affa542696d6e445
qid1181	SELECT 年初以来市值 WHERE 公司 == "中天城投"	69d08e45334311e99755542696d6e445
qid1182	SELECT 年初以来市值 WHERE 公司 == "中天城投"	69d08e45334311e99755542696d6e445
qid1183	SELECT 年初以来市值 WHERE 公司 == "中天城投"	69d08e45334311e99755542696d6e445
qid1184	SELECT COUNT ( 公司名称 ) WHERE 股东权益价值（亿元） > "100" or 股权占比 > "10"	6e612f0f34ce11e9bf9c542696d6e445
qid1185	SELECT COUNT ( 公司名称 ) WHERE 股东权益价值（亿元） > "100" or 股权占比 > "10"	6e612f0f34ce11e9bf9c542696d6e445
qid1186	SELECT COUNT ( 公司名称 ) WHERE 股东权益价值（亿元） > "100" or 股权占比 > "10"	6e612f0f34ce11e9bf9c542696d6e445
qid1187	SELECT 同比 WHERE 城市名 == "杭州" and 环比 < "10"	c98a335c332111e99ca4542696d6e445
qid1188	SELECT 同比 WHERE 城市名 == "杭州" and 环比 < "10"	c98a335c332111e99ca4542696d6e445
qid1189	SELECT 同比 WHERE 城市名 == "杭州" and 环比 < "10"	c98a335c332111e99ca4542696d6e445
qid1190	SELECT 项目名称 WHERE 开盘套数 > "200" and 已签约套数 > "40"	c9859e63332111e9a926542696d6e445
qid1191	SELECT 项目名称 WHERE 开盘套数 > "200" and 已签约套数 > "40"	c9859e63332111e9a926542696d6e445
qid1192	SELECT 项目名称 WHERE 开盘套数 > "200" and 已签约套数 > "40"	c9859e63332111e9a926542696d6e445
qid1193	SELECT 市盈率 , 市净率 WHERE 市值 < "40"	733d74f334c611e9b31d542696d6e445
qid1194	SELECT 市盈率 , 市净率 WHERE 市值 < "40"	733d74f334c611e9b31d542696d6e445
qid1195	SELECT 市盈率 , 市净率 WHERE 市值 < "40"	733d74f334c611e9b31d542696d6e445
qid1196	SELECT 近7日日均成交环比 WHERE 去年同期28日成交 < "100" or 近7日日均交 < "100"	c98a335c332111e99ca4542696d6e445
qid1197	SELECT 近7日日均成交环比 WHERE 去年同期28日成交 < "100" or 近7日日均交 < "100"	c98a335c332111e99ca4542696d6e445
qid1198	SELECT 近7日日均成交环比 WHERE 去年同期28日成交 < "100" or 近7日日均交 < "100"	c98a335c332111e99ca4542696d6e445
qid1199	SELECT 年涨跌幅%） WHERE 股票代码 == "1811.hk"	43b0145e1d7111e9841af40f24344a08
qid1200	SELECT 年涨跌幅%） WHERE 股票代码 == "1811.hk"	43b0145e1d7111e9841af40f24344a08
qid1201	SELECT 年涨跌幅%） WHERE 股票代码 == "1811.hk"	43b0145e1d7111e9841af40f24344a08
qid1202	SELECT 周前收盘价(元) WHERE 证券简称 == "新华网"	4d23e7a83aaa11e9926ef40f24344a08
qid1203	SELECT 周前收盘价(元) WHERE 证券简称 == "新华网"	4d23e7a83aaa11e9926ef40f24344a08
qid1204	SELECT 周前收盘价(元) WHERE 证券简称 == "新华网"	4d23e7a83aaa11e9926ef40f24344a08
qid1205	SELECT 营收 , 净利润 WHERE 廉航公司 == "祥鹏航空"	c5ac847534b411e9bd09542696d6e445
qid1206	SELECT 营收 , 净利润 WHERE 廉航公司 == "祥鹏航空"	c5ac847534b411e9bd09542696d6e445
qid1207	SELECT 营收 , 净利润 WHERE 廉航公司 == "祥鹏航空"	c5ac847534b411e9bd09542696d6e445
qid1208	SELECT 楼盘均价 WHERE 楼盘 == "保利上河雅颂" or 楼盘 == "国际城月伴湾"	c9897bf5332111e9ab61542696d6e445
qid1209	SELECT 楼盘均价 WHERE 楼盘 == "保利上河雅颂" or 楼盘 == "国际城月伴湾"	c9897bf5332111e9ab61542696d6e445
qid1210	SELECT 楼盘均价 WHERE 楼盘 == "保利上河雅颂" or 楼盘 == "国际城月伴湾"	c9897bf5332111e9ab61542696d6e445
qid1211	SELECT COUNT ( 院线 ) WHERE 2018年票房（亿元） > "20"	4d278c853aaa11e9aeb5f40f24344a08
qid1212	SELECT COUNT ( 院线 ) WHERE 2018年票房（亿元） > "20"	4d278c853aaa11e9aeb5f40f24344a08
qid1213	SELECT 锂电池公司 WHERE 股票代码 == "1188.hk"	43b035a81d7111e9a9d4f40f24344a08
qid1214	SELECT 锂电池公司 WHERE 股票代码 == "1188.hk"	43b035a81d7111e9a9d4f40f24344a08
qid1215	SELECT 锂电池公司 WHERE 股票代码 == "1188.hk"	43b035a81d7111e9a9d4f40f24344a08
qid1216	SELECT 生产线 WHERE 总产能 < "100" or 在产产能 < "100"	43adbb781d7111e98e48f40f24344a08
qid1217	SELECT 生产线 WHERE 总产能 < "100" or 在产产能 < "100"	43adbb781d7111e98e48f40f24344a08
qid1218	SELECT 生产线 WHERE 总产能 < "100" or 在产产能 < "100"	43adbb781d7111e98e48f40f24344a08
qid1219	SELECT 公司名称 , 代码 WHERE 主要业务 == "电容" and PE < "10"	0de5bd30351311e9b355542696d6e445
qid1220	SELECT 公司名称 , 代码 WHERE 主要业务 == "电容" and PE < "10"	0de5bd30351311e9b355542696d6e445
qid1221	SELECT 公司名称 , 代码 WHERE 主要业务 == "电容" and PE < "10"	0de5bd30351311e9b355542696d6e445
qid1222	SELECT AVG ( 成交面积 ) WHERE 楼面价 > "1000" or 溢价 > "0"	252ea2c0302e11e9bee5542696d6e445
qid1223	SELECT AVG ( 成交面积 ) WHERE 楼面价 > "1000" or 溢价 > "0"	252ea2c0302e11e9bee5542696d6e445
qid1224	SELECT AVG ( 成交面积 ) WHERE 楼面价 > "1000" or 溢价 > "0"	252ea2c0302e11e9bee5542696d6e445
qid1225	SELECT Jun WHERE Mar > "50" and Apr > "50"	5a51c36e312b11e9aa9b542696d6e445
qid1226	SELECT Jun WHERE Mar > "50" and Apr > "50"	5a51c36e312b11e9aa9b542696d6e445
qid1227	SELECT Jun WHERE Mar > "50" and Apr > "50"	5a51c36e312b11e9aa9b542696d6e445
qid1228	SELECT 2017年前免税运营商 WHERE 机场 == "首都机场" and 到期时间 == "2015年底"	733d2b6634c611e9933c542696d6e445
qid1229	SELECT 2017年前免税运营商 WHERE 机场 == "首都机场" and 到期时间 == "2015年底"	733d2b6634c611e9933c542696d6e445
qid1230	SELECT 2017年前免税运营商 WHERE 机场 == "首都机场" and 到期时间 == "2015年底"	733d2b6634c611e9933c542696d6e445
qid1231	SELECT 城市 WHERE 前一周成交 < "2327" or 环比 < "38.9"	252c7b6b302e11e995ee542696d6e445
qid1232	SELECT 城市 WHERE 前一周成交 < "2327" or 环比 < "38.9"	252c7b6b302e11e995ee542696d6e445
qid1233	SELECT 城市 WHERE 前一周成交 < "2327" or 环比 < "38.9"	252c7b6b302e11e995ee542696d6e445
qid1234	SELECT 本周收盘价 WHERE 股票简称 == "当代东方" or 股票简称 == "印纪传媒"	4d26a0303aaa11e99111f40f24344a08
qid1235	SELECT 本周收盘价 WHERE 股票简称 == "当代东方" or 股票简称 == "印纪传媒"	4d26a0303aaa11e99111f40f24344a08
qid1236	SELECT 本周收盘价 WHERE 股票简称 == "当代东方" or 股票简称 == "印纪传媒"	4d26a0303aaa11e99111f40f24344a08
qid1237	SELECT 总市值（亿元） WHERE 股票简称 == "富春股份" and 本周收盘价 < "30"	4d26a0303aaa11e99111f40f24344a08
qid1238	SELECT 总市值（亿元） WHERE 股票简称 == "富春股份" and 本周收盘价 < "30"	4d26a0303aaa11e99111f40f24344a08
qid1239	SELECT 总市值（亿元） WHERE 股票简称 == "富春股份" and 本周收盘价 < "30"	4d26a0303aaa11e99111f40f24344a08
qid1240	SELECT COUNT ( 公司名称 ) WHERE 股价 < "10"	69d4b4c5334311e99dff542696d6e445
qid1241	SELECT COUNT ( 公司名称 ) WHERE 股价 < "10"	69d4b4c5334311e99dff542696d6e445
qid1242	SELECT COUNT ( 公司名称 ) WHERE 股价 < "10"	69d4b4c5334311e99dff542696d6e445
qid1243	SELECT COUNT ( 公司名称 ) WHERE 股价 < "10"	69d4b4c5334311e99dff542696d6e445
qid1244	SELECT COUNT ( 公司名称 ) WHERE 股价 < "10"	69d4b4c5334311e99dff542696d6e445
qid1245	SELECT 评级 , 折价率 WHERE 股价 > "8"	69cf9028334311e99d34542696d6e445
qid1246	SELECT 评级 , 折价率 WHERE 股价 > "8"	69cf9028334311e99d34542696d6e445
qid1247	SELECT 评级 , 折价率 WHERE 股价 > "8"	69cf9028334311e99d34542696d6e445
qid1248	SELECT AVG ( 日成交 ) WHERE 2011年日均成交 > "1" and 2012年日均成交 > "1"	69d3db42334311e988df542696d6e445
qid1249	SELECT AVG ( 日成交 ) WHERE 2011年日均成交 > "1" and 2012年日均成交 > "1"	69d3db42334311e988df542696d6e445
qid1250	SELECT AVG ( 日成交 ) WHERE 2011年日均成交 > "1" and 2012年日均成交 > "1"	69d3db42334311e988df542696d6e445
qid1251	SELECT 股价 WHERE 公司 == "杰瑞股份"	43b3612e1d7111e9a29bf40f24344a08
qid1252	SELECT 股价 WHERE 公司 == "杰瑞股份"	43b3612e1d7111e9a29bf40f24344a08
qid1253	SELECT 股价 WHERE 公司 == "杰瑞股份"	43b3612e1d7111e9a29bf40f24344a08
qid1254	SELECT 简称 WHERE PE17A < "20" and PE18E < "20" and PE19E < "20"	e0ac35f8333a11e99688542696d6e445
qid1255	SELECT 简称 WHERE PE17A < "20" and PE18E < "20" and PE19E < "20"	e0ac35f8333a11e99688542696d6e445
qid1256	SELECT 简称 WHERE PE17A < "20" and PE18E < "20" and PE19E < "20"	e0ac35f8333a11e99688542696d6e445
qid1257	SELECT MAX ( 市占率 ) WHERE 2018 > "20" and 2017 > "15"	733ce2e334c611e9b33b542696d6e445
qid1258	SELECT MAX ( 市占率 ) WHERE 2018 > "20" and 2017 > "15"	733ce2e334c611e9b33b542696d6e445
qid1259	SELECT MAX ( 市占率 ) WHERE 2018 > "20" and 2017 > "15"	733ce2e334c611e9b33b542696d6e445
qid1260	SELECT 增发目的 WHERE 证券简称 == "美盛文化" or 证券代码 == "002502.SZ"	4d2612a13aaa11e9b721f40f24344a08
qid1261	SELECT 增发目的 WHERE 证券简称 == "美盛文化" or 证券代码 == "002502.SZ"	4d2612a13aaa11e9b721f40f24344a08
qid1262	SELECT 增发目的 WHERE 证券简称 == "美盛文化" or 证券代码 == "002502.SZ"	4d2612a13aaa11e9b721f40f24344a08
qid1263	SELECT 名称 WHERE 市盈率PE > "11" and GDP增速 > "5"	c5ae16c234b411e9a75c542696d6e445
qid1264	SELECT 名称 WHERE 市盈率PE > "11" and GDP增速 > "5"	c5ae16c234b411e9a75c542696d6e445
qid1265	SELECT 名称 WHERE 市盈率PE > "11" and GDP增速 > "5"	c5ae16c234b411e9a75c542696d6e445
qid1266	SELECT 机场 WHERE 跑道数量（条） > "3"	733d1dc234c611e99e1a542696d6e445
qid1267	SELECT 机场 WHERE 跑道数量（条） > "3"	733d1dc234c611e99e1a542696d6e445
qid1268	SELECT 机场 WHERE 跑道数量（条） > "3"	733d1dc234c611e99e1a542696d6e445
qid1269	SELECT 锂电池公司 WHERE 周涨跌幅（%） < "5" and 月涨跌幅（%） < "5"	43b035a81d7111e9a9d4f40f24344a08
qid1270	SELECT 锂电池公司 WHERE 周涨跌幅（%） < "5" and 月涨跌幅（%） < "5"	43b035a81d7111e9a9d4f40f24344a08
qid1271	SELECT 锂电池公司 WHERE 周涨跌幅（%） < "5" and 月涨跌幅（%） < "5"	43b035a81d7111e9a9d4f40f24344a08
qid1272	SELECT 净利润上限（亿元） , 净利润下限（亿元） WHERE 证券代码 == "恺英网络"	4d24bfe13aaa11e992f0f40f24344a08
qid1273	SELECT 净利润上限（亿元） , 净利润下限（亿元） WHERE 证券代码 == "恺英网络"	4d24bfe13aaa11e992f0f40f24344a08
qid1274	SELECT 净利润上限（亿元） , 净利润下限（亿元） WHERE 证券代码 == "恺英网络"	4d24bfe13aaa11e992f0f40f24344a08
qid1275	SELECT 10年高点 WHERE 城市 == "南京" and 09年高点 > "1000"	c98be5a8332111e9be62542696d6e445
qid1276	SELECT 10年高点 WHERE 城市 == "南京" and 09年高点 > "1000"	c98be5a8332111e9be62542696d6e445
qid1277	SELECT 10年高点 WHERE 城市 == "南京" and 09年高点 > "1000"	c98be5a8332111e9be62542696d6e445
qid1278	SELECT 公司 WHERE EPS2011 > "0.1" and EPS2012E > "0.3" and EPS2013E > "0.5"	69d378e8334311e9bb4a542696d6e445
qid1279	SELECT 公司 WHERE EPS2011 > "0.1" and EPS2012E > "0.3" and EPS2013E > "0.5"	69d378e8334311e9bb4a542696d6e445
qid1280	SELECT 公司 WHERE EPS2011 > "0.1" and EPS2012E > "0.3" and EPS2013E > "0.5"	69d378e8334311e9bb4a542696d6e445
qid1281	SELECT 阶段 WHERE 联合大陆航空 > "100" and 美国航空 > "100"	c5ac9e2b34b411e9aecf542696d6e445
qid1282	SELECT 阶段 WHERE 联合大陆航空 > "100" and 美国航空 > "100"	c5ac9e2b34b411e9aecf542696d6e445
qid1283	SELECT 阶段 WHERE 联合大陆航空 > "100" and 美国航空 > "100"	c5ac9e2b34b411e9aecf542696d6e445
qid1284	SELECT COUNT ( 股票名称 ) WHERE 2018年动态PE > "10"	c5aec93d34b411e98514542696d6e445
qid1285	SELECT COUNT ( 股票名称 ) WHERE 2018年动态PE > "10"	c5aec93d34b411e98514542696d6e445
qid1286	SELECT COUNT ( 股票名称 ) WHERE 2018年动态PE > "10"	c5aec93d34b411e98514542696d6e445
qid1287	SELECT SUM ( 11年底 ) WHERE 城市 == "长春" or 城市 == "南昌"	c98bf0de332111e9b450542696d6e445
qid1288	SELECT SUM ( 11年底 ) WHERE 城市 == "长春" or 城市 == "南昌"	c98bf0de332111e9b450542696d6e445
qid1289	SELECT SUM ( 11年底 ) WHERE 城市 == "长春" or 城市 == "南昌"	c98bf0de332111e9b450542696d6e445
qid1290	SELECT AVG ( 2018E ) WHERE 飞机净增长 > "8" and 座位增长 > "8"	c5adb61e34b411e984e7542696d6e445
qid1291	SELECT AVG ( 2018E ) WHERE 飞机净增长 > "8" and 座位增长 > "8"	c5adb61e34b411e984e7542696d6e445
qid1292	SELECT AVG ( 2018E ) WHERE 飞机净增长 > "8" and 座位增长 > "8"	c5adb61e34b411e984e7542696d6e445
qid1293	SELECT 公里数（km） WHERE 起止城市 == "乌兰察布-呼和浩特东段"	43b1c90c1d7111e9b037f40f24344a08
qid1294	SELECT 公里数（km） WHERE 起止城市 == "乌兰察布-呼和浩特东段"	43b1c90c1d7111e9b037f40f24344a08
qid1295	SELECT 公里数（km） WHERE 起止城市 == "乌兰察布-呼和浩特东段"	43b1c90c1d7111e9b037f40f24344a08
qid1296	SELECT 同比增长（%） WHERE 指标 == "房地产开发投资(亿元)" and 绝对量 > "1000"	c98df9a6332111e98a66542696d6e445
qid1297	SELECT 同比增长（%） WHERE 指标 == "房地产开发投资(亿元)" and 绝对量 > "1000"	c98df9a6332111e98a66542696d6e445
qid1298	SELECT 同比增长（%） WHERE 指标 == "房地产开发投资(亿元)" and 绝对量 > "1000"	c98df9a6332111e98a66542696d6e445
qid1299	SELECT EPS17A WHERE 简称 == "上海机场"	c5acbc2834b411e9b03b542696d6e445
qid1300	SELECT EPS17A WHERE 简称 == "上海机场"	c5acbc2834b411e9b03b542696d6e445
qid1301	SELECT EPS17A WHERE 简称 == "上海机场"	c5acbc2834b411e9b03b542696d6e445
qid1302	SELECT 证券简称 WHERE EPS2017 > "0.1" and EPS2018E > "0.1" and EPS2019E > "0.1"	4d2689913aaa11e9a9f2f40f24344a08
qid1303	SELECT 证券简称 WHERE EPS2017 > "0.1" and EPS2018E > "0.1" and EPS2019E > "0.1"	4d2689913aaa11e9a9f2f40f24344a08
qid1304	SELECT 证券简称 WHERE EPS2017 > "0.1" and EPS2018E > "0.1" and EPS2019E > "0.1"	4d2689913aaa11e9a9f2f40f24344a08
qid1305	SELECT 累计同比 WHERE 城市 == "上海" or 城市 == "北京"	69d56680334311e9a917542696d6e445
qid1306	SELECT 累计同比 WHERE 城市 == "上海" or 城市 == "北京"	69d56680334311e9a917542696d6e445
qid1307	SELECT 累计同比 WHERE 城市 == "上海" or 城市 == "北京"	69d56680334311e9a917542696d6e445
qid1308	SELECT 游戏 , 开发商 WHERE 排名 == "6" or 排名 == "7"	4d26b9f83aaa11e9add4f40f24344a08
qid1309	SELECT 游戏 , 开发商 WHERE 排名 == "6" or 排名 == "7"	4d26b9f83aaa11e9add4f40f24344a08
qid1310	SELECT 游戏 , 开发商 WHERE 排名 == "6" or 排名 == "7"	4d26b9f83aaa11e9add4f40f24344a08
qid1311	SELECT 名称 , 股票代码 WHERE 收盘价 > "10"	69cdfd82334311e98809542696d6e445
qid1312	SELECT 名称 , 股票代码 WHERE 收盘价 > "10"	69cdfd82334311e98809542696d6e445
qid1313	SELECT 名称 , 股票代码 WHERE 收盘价 > "10"	69cdfd82334311e98809542696d6e445
qid1314	SELECT 证券简称 WHERE 营业收入 < "24"	0de680cf351311e9bde3542696d6e445
qid1315	SELECT 证券简称 WHERE 营业收入 < "24"	0de680cf351311e9bde3542696d6e445
qid1316	SELECT 证券简称 WHERE 营业收入 < "24"	0de680cf351311e9bde3542696d6e445
qid1317	SELECT 证券 WHERE 收盘价 > "20" or PEG > "1"	0156172b351311e986b3542696d6e445
qid1318	SELECT 证券 WHERE 收盘价 > "20" or PEG > "1"	0156172b351311e986b3542696d6e445
qid1319	SELECT 证券 WHERE 收盘价 > "20" or PEG > "1"	0156172b351311e986b3542696d6e445
qid1320	SELECT 财务报表（百万元） WHERE 2017A > "0" or 2018E < "0"	c5aea2a634b411e98f09542696d6e445
qid1321	SELECT 财务报表（百万元） WHERE 2017A > "0" or 2018E < "0"	c5aea2a634b411e98f09542696d6e445
qid1322	SELECT 财务报表（百万元） WHERE 2017A > "0" or 2018E < "0"	c5aea2a634b411e98f09542696d6e445
qid1323	SELECT 月环比涨幅 WHERE 楼盘名称 == "恒大绿洲" and 5月均价(元/㎡) > "10000"	5a4f9b3a312b11e9bf96542696d6e445
qid1324	SELECT 月环比涨幅 WHERE 楼盘名称 == "恒大绿洲" and 5月均价(元/㎡) > "10000"	5a4f9b3a312b11e9bf96542696d6e445
qid1325	SELECT 月环比涨幅 WHERE 楼盘名称 == "恒大绿洲" and 5月均价(元/㎡) > "10000"	5a4f9b3a312b11e9bf96542696d6e445
qid1326	SELECT 本月涨跌幅 , 本周涨跌幅 WHERE A-H股溢价率 < "20"	43aec1971d7111e99f21f40f24344a08
qid1327	SELECT 本月涨跌幅 , 本周涨跌幅 WHERE A-H股溢价率 < "20"	43aec1971d7111e99f21f40f24344a08
qid1328	SELECT 本月涨跌幅 , 本周涨跌幅 WHERE A-H股溢价率 < "20"	43aec1971d7111e99f21f40f24344a08
qid1329	SELECT 公司 WHERE 月产能（K/月） < "80" or 生产项目 == "逻辑芯片"	43b1ead71d7111e98a9ef40f24344a08
qid1330	SELECT 公司 WHERE 月产能（K/月） < "80" or 生产项目 == "逻辑芯片"	43b1ead71d7111e98a9ef40f24344a08
qid1331	SELECT 公司 WHERE 月产能（K/月） < "80" or 生产项目 == "逻辑芯片"	43b1ead71d7111e98a9ef40f24344a08
qid1332	SELECT 总市值(亿元) WHERE PE2012E > "10" and PE2013E > "10"	69d41833334311e99c97542696d6e445
qid1333	SELECT 总市值(亿元) WHERE PE2012E > "10" and PE2013E > "10"	69d41833334311e99c97542696d6e445
qid1334	SELECT 总市值(亿元) WHERE PE2012E > "10" and PE2013E > "10"	69d41833334311e99c97542696d6e445
qid1335	SELECT COUNT ( 研发方 ) WHERE 研发方 == "腾讯"	4d26f39e3aaa11e995c3f40f24344a08
qid1336	SELECT COUNT ( 研发方 ) WHERE 研发方 == "腾讯"	4d26f39e3aaa11e995c3f40f24344a08
qid1337	SELECT COUNT ( 研发方 ) WHERE 研发方 == "腾讯"	4d26f39e3aaa11e995c3f40f24344a08
qid1338	SELECT 证券 WHERE PE2018E < "24" and PE2019E < "24" and PE2020E < "24"	0156172b351311e986b3542696d6e445
qid1339	SELECT 证券 WHERE PE2018E < "24" and PE2019E < "24" and PE2020E < "24"	0156172b351311e986b3542696d6e445
qid1340	SELECT 证券 WHERE PE2018E < "24" and PE2019E < "24" and PE2020E < "24"	0156172b351311e986b3542696d6e445
qid1341	SELECT 净利润上限（亿元） , 净利润下限（亿元） WHERE 证券代码 == "骅威文化"	4d24ae573aaa11e9b499f40f24344a08
qid1342	SELECT 净利润上限（亿元） , 净利润下限（亿元） WHERE 证券代码 == "骅威文化"	4d24ae573aaa11e9b499f40f24344a08
qid1343	SELECT COUNT ( 高速 ) WHERE 一类车 > "1000000" and 二类车 > "10000"	733d581434c611e994a8542696d6e445
qid1344	SELECT COUNT ( 高速 ) WHERE 一类车 > "1000000" and 二类车 > "10000"	733d581434c611e994a8542696d6e445
qid1345	SELECT COUNT ( 高速 ) WHERE 一类车 > "1000000" and 二类车 > "10000"	733d581434c611e994a8542696d6e445
qid1346	SELECT 城市 WHERE 2012年4月成交量环比 > "5" and 2012年2月成交量环比 < "10"	69d156f8334311e9af6e542696d6e445
qid1347	SELECT 城市 WHERE 2012年4月成交量环比 > "5" and 2012年2月成交量环比 < "10"	69d156f8334311e9af6e542696d6e445
qid1348	SELECT 城市 WHERE 2012年4月成交量环比 > "5" and 2012年2月成交量环比 < "10"	69d156f8334311e9af6e542696d6e445
qid1349	SELECT 板块名称 WHERE 成分股个数 < "300" or 板块代码 == "000300.SH"	4d251cf53aaa11e9bce2f40f24344a08
qid1350	SELECT 板块名称 WHERE 成分股个数 < "300" or 板块代码 == "000300.SH"	4d251cf53aaa11e9bce2f40f24344a08
qid1351	SELECT 板块名称 WHERE 成分股个数 < "300" or 板块代码 == "000300.SH"	4d251cf53aaa11e9bce2f40f24344a08
qid1352	SELECT COUNT ( 影片名称 ) WHERE 周票房（万） > "2000" or 票房占比（%） > "10" or 场均人次 > "10"	4d2a0a543aaa11e99ec0f40f24344a08
qid1353	SELECT COUNT ( 影片名称 ) WHERE 周票房（万） > "2000" or 票房占比（%） > "10" or 场均人次 > "10"	4d2a0a543aaa11e99ec0f40f24344a08
qid1354	SELECT COUNT ( 影片名称 ) WHERE 周票房（万） > "2000" or 票房占比（%） > "10" or 场均人次 > "10"	4d2a0a543aaa11e99ec0f40f24344a08
qid1355	SELECT 播放量（万） WHERE 播出平台 == "芒果TV" and 剧集名称 == "即刻电音"	4d29c5573aaa11e9a1d6f40f24344a08
qid1356	SELECT 播放量（万） WHERE 播出平台 == "芒果TV" and 剧集名称 == "即刻电音"	4d29c5573aaa11e9a1d6f40f24344a08
qid1357	SELECT 播放量（万） WHERE 播出平台 == "芒果TV" and 剧集名称 == "即刻电音"	4d29c5573aaa11e9a1d6f40f24344a08
qid1358	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 > "5"	4d25e6403aaa11e9bdbbf40f24344a08
qid1359	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 > "5"	4d25e6403aaa11e9bdbbf40f24344a08
qid1360	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 > "5"	4d25e6403aaa11e9bdbbf40f24344a08
qid1361	SELECT 影片名称 WHERE 场均人次 > "5"	4d29d0513aaa11e9b911f40f24344a08
qid1362	SELECT 影片名称 WHERE 场均人次 > "5"	4d29d0513aaa11e9b911f40f24344a08
qid1363	SELECT 影片名称 WHERE 场均人次 > "5"	4d29d0513aaa11e9b911f40f24344a08
qid1364	SELECT 国内客运量占比 WHERE 公司 == "西南航空（美股）" and 市值（亿元） > "1000"	c5ac817334b411e9a62e542696d6e445
qid1365	SELECT 国内客运量占比 WHERE 公司 == "西南航空（美股）" and 市值（亿元） > "1000"	c5ac817334b411e9a62e542696d6e445
qid1366	SELECT 国内客运量占比 WHERE 公司 == "西南航空（美股）" and 市值（亿元） > "1000"	c5ac817334b411e9a62e542696d6e445
qid1367	SELECT 游戏 WHERE 排名 == "11" or 排名 == "12"	4d2709e33aaa11e9aaf9f40f24344a08
qid1368	SELECT 游戏 WHERE 排名 == "11" or 排名 == "12"	4d2709e33aaa11e9aaf9f40f24344a08
qid1369	SELECT 游戏 WHERE 排名 == "11" or 排名 == "12"	4d2709e33aaa11e9aaf9f40f24344a08
qid1370	SELECT 股票名称 WHERE PE2011A > "10"	69d06cfa334311e988c1542696d6e445
qid1371	SELECT 股票名称 WHERE PE2011A > "10"	69d06cfa334311e988c1542696d6e445
qid1372	SELECT 股票名称 WHERE PE2011A > "10"	69d06cfa334311e988c1542696d6e445
qid1373	SELECT 城市 WHERE 去年同期 > "40"	2530c65e302e11e98f90542696d6e445
qid1374	SELECT 城市 WHERE 去年同期 > "40"	2530c65e302e11e98f90542696d6e445
qid1375	SELECT 城市 WHERE 去年同期 > "40"	2530c65e302e11e98f90542696d6e445
qid1376	SELECT 日成交环比 WHERE 城市 == "南京" and 日成交 > "1"	69cd1778334311e99046542696d6e445
qid1377	SELECT 日成交环比 WHERE 城市 == "南京" and 日成交 > "1"	69cd1778334311e99046542696d6e445
qid1378	SELECT 日成交环比 WHERE 城市 == "南京" and 日成交 > "1"	69cd1778334311e99046542696d6e445
qid1379	SELECT 建安费用的拉动作用 , 新开工面积的拉动作用 WHERE 房地产开发投资完成额同比 < "20"	5a4b4ef5312b11e99e4a542696d6e445
qid1380	SELECT 建安费用的拉动作用 , 新开工面积的拉动作用 WHERE 房地产开发投资完成额同比 < "20"	5a4b4ef5312b11e99e4a542696d6e445
qid1381	SELECT 建安费用的拉动作用 , 新开工面积的拉动作用 WHERE 房地产开发投资完成额同比 < "20"	5a4b4ef5312b11e99e4a542696d6e445
qid1382	SELECT 2012年累计成交面积 WHERE 城市 == "广州" and 4月成交面积 > "40"	69d25c07334311e98b24542696d6e445
qid1383	SELECT 2012年累计成交面积 WHERE 城市 == "广州" and 4月成交面积 > "40"	69d25c07334311e98b24542696d6e445
qid1384	SELECT 2012年累计成交面积 WHERE 城市 == "广州" and 4月成交面积 > "40"	69d25c07334311e98b24542696d6e445
qid1385	SELECT 预计上市建筑面积（万平米） WHERE 时间 == "2012年"	5a4f388f312b11e99bd0542696d6e445
qid1386	SELECT 预计上市建筑面积（万平米） WHERE 时间 == "2012年"	5a4f388f312b11e99bd0542696d6e445
qid1387	SELECT 预计上市建筑面积（万平米） WHERE 时间 == "2012年"	5a4f388f312b11e99bd0542696d6e445
qid1388	SELECT 加入组合时间 WHERE 证券简称 == "深圳机场"	733d705734c611e9b720542696d6e445
qid1389	SELECT 加入组合时间 WHERE 证券简称 == "深圳机场"	733d705734c611e9b720542696d6e445
qid1390	SELECT 加入组合时间 WHERE 证券简称 == "深圳机场"	733d705734c611e9b720542696d6e445
qid1391	SELECT COUNT ( 影片 ) WHERE 北美映期 == "2019-01-11"	4d280ca33aaa11e9b11af40f24344a08
qid1392	SELECT COUNT ( 影片 ) WHERE 北美映期 == "2019-01-11"	4d280ca33aaa11e9b11af40f24344a08
qid1393	SELECT COUNT ( 影片 ) WHERE 北美映期 == "2019-01-11"	4d280ca33aaa11e9b11af40f24344a08
qid1394	SELECT SUM ( 播放量（万） ) WHERE 播出平台 == "芒果TV"	4d29c00a3aaa11e990d5f40f24344a08
qid1395	SELECT SUM ( 播放量（万） ) WHERE 播出平台 == "芒果TV"	4d29c00a3aaa11e990d5f40f24344a08
qid1396	SELECT SUM ( 播放量（万） ) WHERE 播出平台 == "芒果TV"	4d29c00a3aaa11e990d5f40f24344a08
qid1397	SELECT SUM ( 播放量（万） ) WHERE 播出平台 == "芒果TV"	4d29c00a3aaa11e990d5f40f24344a08
qid1398	SELECT SUM ( 播放量（万） ) WHERE 播出平台 == "芒果TV"	4d29c00a3aaa11e990d5f40f24344a08
qid1399	SELECT PEG WHERE EPS2017A < "1" and PE2017A < "20"	01564d28351311e9ada4542696d6e445
qid1400	SELECT PEG WHERE EPS2017A < "1" and PE2017A < "20"	01564d28351311e9ada4542696d6e445
qid1401	SELECT PEG WHERE EPS2017A < "1" and PE2017A < "20"	01564d28351311e9ada4542696d6e445
qid1402	SELECT 公司名称 WHERE 市值（亿元） < "100"	43b0e8de1d7111e9bad6f40f24344a08
qid1403	SELECT 公司名称 WHERE 市值（亿元） < "100"	43b0e8de1d7111e9bad6f40f24344a08
qid1404	SELECT 公司名称 WHERE 市值（亿元） < "100"	43b0e8de1d7111e9bad6f40f24344a08
qid1405	SELECT MIN ( 观影人次（万） ) WHERE 周票房（万） > "500" or 场均人次 > "20"	4d29a3f33aaa11e99236f40f24344a08
qid1406	SELECT MIN ( 观影人次（万） ) WHERE 周票房（万） > "500" or 场均人次 > "20"	4d29a3f33aaa11e99236f40f24344a08
qid1407	SELECT MIN ( 观影人次（万） ) WHERE 周票房（万） > "500" or 场均人次 > "20"	4d29a3f33aaa11e99236f40f24344a08
qid1408	SELECT 名称 WHERE 收视率% > "0.1" or 市场份额% > "2"	4d29b9003aaa11e989dff40f24344a08
qid1409	SELECT 名称 WHERE 收视率% > "0.1" or 市场份额% > "2"	4d29b9003aaa11e989dff40f24344a08
qid1410	SELECT 名称 WHERE 收视率% > "0.1" or 市场份额% > "2"	4d29b9003aaa11e989dff40f24344a08
qid1411	SELECT 类型 WHERE 导演 == "查德·斯塔赫斯基" or 主演 == "瑞恩·雷诺兹、贾斯蒂斯·史密斯"	4d2815473aaa11e9858ff40f24344a08
qid1412	SELECT 类型 WHERE 导演 == "查德·斯塔赫斯基" or 主演 == "瑞恩·雷诺兹、贾斯蒂斯·史密斯"	4d2815473aaa11e9858ff40f24344a08
qid1413	SELECT 类型 WHERE 导演 == "查德·斯塔赫斯基" or 主演 == "瑞恩·雷诺兹、贾斯蒂斯·史密斯"	4d2815473aaa11e9858ff40f24344a08
qid1414	SELECT 证券 WHERE 收盘价 > "7.7"	01564d28351311e9ada4542696d6e445
qid1415	SELECT 证券 WHERE 收盘价 > "7.7"	01564d28351311e9ada4542696d6e445
qid1416	SELECT 证券 WHERE 收盘价 > "7.7"	01564d28351311e9ada4542696d6e445
qid1417	SELECT 最新市值（亿港币） WHERE 证券简称 == "新世界中国地产有限公司" and 最新股价 < "5"	252caeca302e11e9b3ac542696d6e445
qid1418	SELECT 最新市值（亿港币） WHERE 证券简称 == "新世界中国地产有限公司" and 最新股价 < "5"	252caeca302e11e9b3ac542696d6e445
qid1419	SELECT 最新市值（亿港币） WHERE 证券简称 == "新世界中国地产有限公司" and 最新股价 < "5"	252caeca302e11e9b3ac542696d6e445
qid1420	SELECT 城市 WHERE 2010成交面积 > "10" and 2011年成交面积 > "10" and 累计同比 > "10"	69d5567a334311e99539542696d6e445
qid1421	SELECT 城市 WHERE 2010成交面积 > "10" and 2011年成交面积 > "10" and 累计同比 > "10"	69d5567a334311e99539542696d6e445
qid1422	SELECT 城市 WHERE 2010成交面积 > "10" and 2011年成交面积 > "10" and 累计同比 > "10"	69d5567a334311e99539542696d6e445
qid1423	SELECT 2018年票房（亿元） WHERE 目前影院数量 < "1000" and 2018年底银幕数量 < "5000"	4d2786593aaa11e9bd56f40f24344a08
qid1424	SELECT 2018年票房（亿元） WHERE 目前影院数量 < "1000" and 2018年底银幕数量 < "5000"	4d2786593aaa11e9bd56f40f24344a08
qid1425	SELECT 2018年票房（亿元） WHERE 目前影院数量 < "1000" and 2018年底银幕数量 < "5000"	4d2786593aaa11e9bd56f40f24344a08
qid1426	SELECT 楼盘容积率 WHERE 楼盘 == "龙湖香醍溪岸" or 楼盘 == "保利新茉莉公馆"	c9896075332111e9ab1b542696d6e445
qid1427	SELECT 楼盘容积率 WHERE 楼盘 == "龙湖香醍溪岸" or 楼盘 == "保利新茉莉公馆"	c9896075332111e9ab1b542696d6e445
qid1428	SELECT 楼盘容积率 WHERE 楼盘 == "龙湖香醍溪岸" or 楼盘 == "保利新茉莉公馆"	c9896075332111e9ab1b542696d6e445
qid1429	SELECT 总房价(万元) WHERE 降息前月还款额10年 > "8000" and 降息前月还款额20年 > "8000"	5a4e9730312b11e98007542696d6e445
qid1430	SELECT 总房价(万元) WHERE 降息前月还款额10年 > "8000" and 降息前月还款额20年 > "8000"	5a4e9730312b11e98007542696d6e445
qid1431	SELECT 总房价(万元) WHERE 降息前月还款额10年 > "8000" and 降息前月还款额20年 > "8000"	5a4e9730312b11e98007542696d6e445
qid1432	SELECT 本周涨幅前十 WHERE 证券简称 == "龙湖地产有限公司"	252caeca302e11e9b3ac542696d6e445
qid1433	SELECT 本周涨幅前十 WHERE 证券简称 == "龙湖地产有限公司"	252caeca302e11e9b3ac542696d6e445
qid1434	SELECT 本周涨幅前十 WHERE 证券简称 == "龙湖地产有限公司"	252caeca302e11e9b3ac542696d6e445
qid1435	SELECT 院线 , 目前影院数量 WHERE 2018年票房（亿元） > "15"	4d278c853aaa11e9aeb5f40f24344a08
qid1436	SELECT 院线 , 目前影院数量 WHERE 2018年票房（亿元） > "15"	4d278c853aaa11e9aeb5f40f24344a08
qid1437	SELECT 院线 , 目前影院数量 WHERE 2018年票房（亿元） > "15"	4d278c853aaa11e9aeb5f40f24344a08
qid1438	SELECT COUNT ( 航空公司 ) WHERE 引进宽体机 > "10" and 引进窄体机 > "50"	c5adb61e34b411e984e7542696d6e445
qid1439	SELECT COUNT ( 航空公司 ) WHERE 引进宽体机 > "10" and 引进窄体机 > "50"	c5adb61e34b411e984e7542696d6e445
qid1440	SELECT COUNT ( 航空公司 ) WHERE 引进宽体机 > "10" and 引进窄体机 > "50"	c5adb61e34b411e984e7542696d6e445
qid1441	SELECT MAX ( 存款利率调整幅度 ) WHERE 存款利率调整前 > "2" and 存款利率调整后 > "2"	5a4ea2c2312b11e9a25b542696d6e445
qid1442	SELECT MAX ( 存款利率调整幅度 ) WHERE 存款利率调整前 > "2" and 存款利率调整后 > "2"	5a4ea2c2312b11e9a25b542696d6e445
qid1443	SELECT MAX ( 存款利率调整幅度 ) WHERE 存款利率调整前 > "2" and 存款利率调整后 > "2"	5a4ea2c2312b11e9a25b542696d6e445
qid1444	SELECT COUNT ( 院线公司 ) WHERE 2018年票房（亿） > "5"	4d2981e13aaa11e99af3f40f24344a08
qid1445	SELECT COUNT ( 院线公司 ) WHERE 2018年票房（亿） > "5"	4d2981e13aaa11e99af3f40f24344a08
qid1446	SELECT COUNT ( 院线公司 ) WHERE 2018年票房（亿） > "5"	4d2981e13aaa11e99af3f40f24344a08
qid1447	SELECT 上周成交量（套） , 占2011均值比重 WHERE 城市 == "佛山"	69d452ae334311e98c32542696d6e445
qid1448	SELECT 上周成交量（套） , 占2011均值比重 WHERE 城市 == "佛山"	69d452ae334311e98c32542696d6e445
qid1449	SELECT 上周成交量（套） , 占2011均值比重 WHERE 城市 == "佛山"	69d452ae334311e98c32542696d6e445
qid1450	SELECT 城市 WHERE 2011年成交面积 > "10" and 2011同期 > "10"	69d54163334311e99a59542696d6e445
qid1451	SELECT 城市 WHERE 2011年成交面积 > "10" and 2011同期 > "10"	69d54163334311e99a59542696d6e445
qid1452	SELECT 城市 WHERE 2011年成交面积 > "10" and 2011同期 > "10"	69d54163334311e99a59542696d6e445
qid1453	SELECT 本周涨幅前十 WHERE 证券简称 == "中体产业"	252c0ccc302e11e9a24c542696d6e445
qid1454	SELECT 本周涨幅前十 WHERE 证券简称 == "中体产业"	252c0ccc302e11e9a24c542696d6e445
qid1455	SELECT 本周涨幅前十 WHERE 证券简称 == "中体产业"	252c0ccc302e11e9a24c542696d6e445
qid1456	SELECT COUNT ( 影片名称 ) WHERE 票房占比（%） > "2"	4d2a0a543aaa11e99ec0f40f24344a08
qid1457	SELECT COUNT ( 影片名称 ) WHERE 票房占比（%） > "2"	4d2a0a543aaa11e99ec0f40f24344a08
qid1458	SELECT COUNT ( 影片名称 ) WHERE 票房占比（%） > "2"	4d2a0a543aaa11e99ec0f40f24344a08
qid1459	SELECT 城市 , 2011年成交面积 WHERE 2010成交面积 > "200"	69d5567a334311e99539542696d6e445
qid1460	SELECT 城市 , 2011年成交面积 WHERE 2010成交面积 > "200"	69d5567a334311e99539542696d6e445
qid1461	SELECT 城市 , 2011年成交面积 WHERE 2010成交面积 > "200"	69d5567a334311e99539542696d6e445
qid1462	SELECT 城市 , 2011年成交面积 WHERE 2010成交面积 > "200"	69d5567a334311e99539542696d6e445
qid1463	SELECT 公司名称 WHERE EPS2012 < "2" and PE2012 < "10"	69cf4763334311e99a84542696d6e445
qid1464	SELECT 公司名称 WHERE EPS2012 < "2" and PE2012 < "10"	69cf4763334311e99a84542696d6e445
qid1465	SELECT 公司名称 WHERE EPS2012 < "2" and PE2012 < "10"	69cf4763334311e99a84542696d6e445
qid1466	SELECT 公司 WHERE 国内客运量占比 > "10" or 市值（亿元） > "1000"	c5ac817334b411e9a62e542696d6e445
qid1467	SELECT 公司 WHERE 国内客运量占比 > "10" or 市值（亿元） > "1000"	c5ac817334b411e9a62e542696d6e445
qid1468	SELECT 公司 WHERE 国内客运量占比 > "10" or 市值（亿元） > "1000"	c5ac817334b411e9a62e542696d6e445
qid1469	SELECT 证券简称 WHERE 最新收盘价 > "3" and 增发价格 > "20"	4d265e5e3aaa11e9ba37f40f24344a08
qid1470	SELECT 证券简称 WHERE 最新收盘价 > "3" and 增发价格 > "20"	4d265e5e3aaa11e9ba37f40f24344a08
qid1471	SELECT 证券简称 WHERE 最新收盘价 > "3" and 增发价格 > "20"	4d265e5e3aaa11e9ba37f40f24344a08
qid1472	SELECT 股价 WHERE 公司名称 == "世茂股份" or 公司名称 == "凤凰股份"	69d4941c334311e9aefd542696d6e445
qid1473	SELECT 股价 WHERE 公司名称 == "世茂股份" or 公司名称 == "凤凰股份"	69d4941c334311e9aefd542696d6e445
qid1474	SELECT 股价 WHERE 公司名称 == "世茂股份" or 公司名称 == "凤凰股份"	69d4941c334311e9aefd542696d6e445
qid1475	SELECT 企业中文名 WHERE 产量 == "4,482" or 药品规格 == "10ml:90mg"	43afd1e61d7111e9bddef40f24344a08
qid1476	SELECT 企业中文名 WHERE 产量 == "4,482" or 药品规格 == "10ml:90mg"	43afd1e61d7111e9bddef40f24344a08
qid1477	SELECT 企业中文名 WHERE 产量 == "4,482" or 药品规格 == "10ml:90mg"	43afd1e61d7111e9bddef40f24344a08
qid1478	SELECT 公司 WHERE 收入 > "100" and 净利润 > "15"	c5ad099434b411e9b4da542696d6e445
qid1479	SELECT 公司 WHERE 收入 > "100" and 净利润 > "15"	c5ad099434b411e9b4da542696d6e445
qid1480	SELECT 公司 WHERE 收入 > "100" and 净利润 > "15"	c5ad099434b411e9b4da542696d6e445
qid1481	SELECT 公司名称 WHERE 最新股价 > "6" or PB估值 > "2"	69d2b69c334311e99bf9542696d6e445
qid1482	SELECT 公司名称 WHERE 最新股价 > "6" or PB估值 > "2"	69d2b69c334311e99bf9542696d6e445
qid1483	SELECT 公司名称 WHERE 最新股价 > "6" or PB估值 > "2"	69d2b69c334311e99bf9542696d6e445
qid1484	SELECT MAX ( EPS2011 ) WHERE 公司名称 == "中粮地产" or 公司名称 == "信达地产"	69d49f66334311e9abca542696d6e445
qid1485	SELECT MAX ( EPS2011 ) WHERE 公司名称 == "中粮地产" or 公司名称 == "信达地产"	69d49f66334311e9abca542696d6e445
qid1486	SELECT MAX ( EPS2011 ) WHERE 公司名称 == "中粮地产" or 公司名称 == "信达地产"	69d49f66334311e9abca542696d6e445
qid1487	SELECT 其他三四线城市 WHERE 商品房销售额:累计 < "133701"	43ad7ef81d7111e99933f40f24344a08
qid1488	SELECT 其他三四线城市 WHERE 商品房销售额:累计 < "133701"	43ad7ef81d7111e99933f40f24344a08
qid1489	SELECT 其他三四线城市 WHERE 商品房销售额:累计 < "133701"	43ad7ef81d7111e99933f40f24344a08
qid1490	SELECT MIN ( 2018年底银幕数量 ) WHERE 目前影院数量 > "800" or 单银幕票房（万元） > "100" or 2018年票房（亿元） > "50"	4d2786593aaa11e9bd56f40f24344a08
qid1491	SELECT MIN ( 2018年底银幕数量 ) WHERE 目前影院数量 > "800" or 单银幕票房（万元） > "100" or 2018年票房（亿元） > "50"	4d2786593aaa11e9bd56f40f24344a08
qid1492	SELECT MIN ( 2018年底银幕数量 ) WHERE 目前影院数量 > "800" or 单银幕票房（万元） > "100" or 2018年票房（亿元） > "50"	4d2786593aaa11e9bd56f40f24344a08
qid1493	SELECT AVG ( 同比 ) WHERE 去年同期28日日均环比 > "100" and 近8日日均环比 > "1"	252d4394302e11e985af542696d6e445
qid1494	SELECT AVG ( 同比 ) WHERE 去年同期28日日均环比 > "100" and 近8日日均环比 > "1"	252d4394302e11e985af542696d6e445
qid1495	SELECT AVG ( 同比 ) WHERE 去年同期28日日均环比 > "100" and 近8日日均环比 > "1"	252d4394302e11e985af542696d6e445
qid1496	SELECT MAX ( 累计同比 ) WHERE 2011同期 > "100" or 2012至今 > "100"	69d52dd1334311e9920c542696d6e445
qid1497	SELECT MAX ( 累计同比 ) WHERE 2011同期 > "100" or 2012至今 > "100"	69d52dd1334311e9920c542696d6e445
qid1498	SELECT MAX ( 累计同比 ) WHERE 2011同期 > "100" or 2012至今 > "100"	69d52dd1334311e9920c542696d6e445
qid1499	SELECT 土地面积 WHERE 成交时间 == "2007年12月6日"	c989f997332111e981bf542696d6e445
qid1500	SELECT 土地面积 WHERE 成交时间 == "2007年12月6日"	c989f997332111e981bf542696d6e445
qid1501	SELECT 土地面积 WHERE 成交时间 == "2007年12月6日"	c989f997332111e981bf542696d6e445
qid1502	SELECT 调整前 WHERE 首付成数 > "40" or 每月减少还 > "100"	c98c3e87332111e991c4542696d6e445
qid1503	SELECT 调整前 WHERE 首付成数 > "40" or 每月减少还 > "100"	c98c3e87332111e991c4542696d6e445
qid1504	SELECT 调整前 WHERE 首付成数 > "40" or 每月减少还 > "100"	c98c3e87332111e991c4542696d6e445
qid1505	SELECT 剧名 , 频道 WHERE 收视率% < "0.3" or 市场份额% < "2"	4d2532a33aaa11e9b4def40f24344a08
qid1506	SELECT 剧名 , 频道 WHERE 收视率% < "0.3" or 市场份额% < "2"	4d2532a33aaa11e9b4def40f24344a08
qid1507	SELECT 剧名 , 频道 WHERE 收视率% < "0.3" or 市场份额% < "2"	4d2532a33aaa11e9b4def40f24344a08
qid1508	SELECT COUNT ( 证券简称 ) WHERE 投资评级 == "增持" and 总市值 > "500"	c98d468c332111e9939d542696d6e445
qid1509	SELECT COUNT ( 证券简称 ) WHERE 投资评级 == "增持" and 总市值 > "500"	c98d468c332111e9939d542696d6e445
qid1510	SELECT COUNT ( 证券简称 ) WHERE 投资评级 == "增持" and 总市值 > "500"	c98d468c332111e9939d542696d6e445
qid1511	SELECT 本月涨跌幅（%） WHERE 本周涨跌幅（%） == "2.96" and 股票名称 == "四川成渝"	733bb92834c611e981f3542696d6e445
qid1512	SELECT 本月涨跌幅（%） WHERE 本周涨跌幅（%） == "2.96" and 股票名称 == "四川成渝"	733bb92834c611e981f3542696d6e445
qid1513	SELECT 本月涨跌幅（%） WHERE 本周涨跌幅（%） == "2.96" and 股票名称 == "四川成渝"	733bb92834c611e981f3542696d6e445
qid1514	SELECT 市值 WHERE 证券代码 == "R.N"	733d74f334c611e9b31d542696d6e445
qid1515	SELECT 市值 WHERE 证券代码 == "R.N"	733d74f334c611e9b31d542696d6e445
qid1516	SELECT 市值 WHERE 证券代码 == "R.N"	733d74f334c611e9b31d542696d6e445
qid1517	SELECT 公司名称 WHERE PE2010 < "23" and PE2012 < "23"	69cf4763334311e99a84542696d6e445
qid1518	SELECT 公司名称 WHERE PE2010 < "23" and PE2012 < "23"	69cf4763334311e99a84542696d6e445
qid1519	SELECT 公司名称 WHERE PE2010 < "23" and PE2012 < "23"	69cf4763334311e99a84542696d6e445
qid1520	SELECT COUNT ( 公司 ) WHERE 2018E绝对值 > "700" and 2019E绝对值 > "700"	0155ce33351311e9ae3c542696d6e445
qid1521	SELECT COUNT ( 公司 ) WHERE 2018E绝对值 > "700" and 2019E绝对值 > "700"	0155ce33351311e9ae3c542696d6e445
qid1522	SELECT COUNT ( 公司 ) WHERE 2018E绝对值 > "700" and 2019E绝对值 > "700"	0155ce33351311e9ae3c542696d6e445
qid1523	SELECT COUNT ( 公司名称 ) WHERE EPS2011 > "1" and EPS2012E > "1" and EPS2013E > "1"	69d29a23334311e99c4d542696d6e445
qid1524	SELECT COUNT ( 公司名称 ) WHERE EPS2011 > "1" and EPS2012E > "1" and EPS2013E > "1"	69d29a23334311e99c4d542696d6e445
qid1525	SELECT COUNT ( 公司名称 ) WHERE EPS2011 > "1" and EPS2012E > "1" and EPS2013E > "1"	69d29a23334311e99c4d542696d6e445
qid1526	SELECT 日熔量（吨） WHERE 所在省份 == "河北"	43af90e31d7111e98357f40f24344a08
qid1527	SELECT 日熔量（吨） WHERE 所在省份 == "河北"	43af90e31d7111e98357f40f24344a08
qid1528	SELECT 日熔量（吨） WHERE 所在省份 == "河北"	43af90e31d7111e98357f40f24344a08
qid1529	SELECT 公司 WHERE EPS2018E > "0.1" and EPS2019E > "0.1" and EPS2020E > "0.1"	015690ba351311e9ac4a542696d6e445
qid1530	SELECT 公司 WHERE EPS2018E > "0.1" and EPS2019E > "0.1" and EPS2020E > "0.1"	015690ba351311e9ac4a542696d6e445
qid1531	SELECT 公司 WHERE EPS2018E > "0.1" and EPS2019E > "0.1" and EPS2020E > "0.1"	015690ba351311e9ac4a542696d6e445
qid1532	SELECT MAX ( 最新收盘价 ) WHERE 证券简称 == "骅威文化" or 证券简称 == "美盛文化"	4d2612a13aaa11e9b721f40f24344a08
qid1533	SELECT MAX ( 最新收盘价 ) WHERE 证券简称 == "骅威文化" or 证券简称 == "美盛文化"	4d2612a13aaa11e9b721f40f24344a08
qid1534	SELECT MAX ( 最新收盘价 ) WHERE 证券简称 == "骅威文化" or 证券简称 == "美盛文化"	4d2612a13aaa11e9b721f40f24344a08
qid1535	SELECT 2011周平均成交量 WHERE 城市 == "深圳" and 上周成交量（套） > "100"	69d452ae334311e98c32542696d6e445
qid1536	SELECT 2011周平均成交量 WHERE 城市 == "深圳" and 上周成交量（套） > "100"	69d452ae334311e98c32542696d6e445
qid1537	SELECT 2011周平均成交量 WHERE 城市 == "深圳" and 上周成交量（套） > "100"	69d452ae334311e98c32542696d6e445
qid1538	SELECT 城市 , 上周成交量（套） WHERE 成交量环比增长 < "0"	69d46851334311e9a9e1542696d6e445
qid1539	SELECT 城市 , 上周成交量（套） WHERE 成交量环比增长 < "0"	69d46851334311e9a9e1542696d6e445
qid1540	SELECT 城市 , 上周成交量（套） WHERE 成交量环比增长 < "0"	69d46851334311e9a9e1542696d6e445
qid1541	SELECT 周票房（万） WHERE 观影人次（万） > "30" or 平均票价 > "30"	4d299dee3aaa11e9b903f40f24344a08
qid1542	SELECT 周票房（万） WHERE 观影人次（万） > "30" or 平均票价 > "30"	4d299dee3aaa11e9b903f40f24344a08
qid1543	SELECT 周票房（万） WHERE 观影人次（万） > "30" or 平均票价 > "30"	4d299dee3aaa11e9b903f40f24344a08
qid1544	SELECT MIN ( 股价 ) WHERE 总市值（亿元） > "30" or 流通市值（亿元） > "20"	4d28b0303aaa11e9bd3ef40f24344a08
qid1545	SELECT MIN ( 股价 ) WHERE 总市值（亿元） > "30" or 流通市值（亿元） > "20"	4d28b0303aaa11e9bd3ef40f24344a08
qid1546	SELECT MIN ( 股价 ) WHERE 总市值（亿元） > "30" or 流通市值（亿元） > "20"	4d28b0303aaa11e9bd3ef40f24344a08
qid1547	SELECT 公司简称 WHERE EPS18E > "0.4" and EPS19E > "0.4" and EPS20E > "0.4"	463e7307351411e9b12b542696d6e445
qid1548	SELECT 公司简称 WHERE EPS18E > "0.4" and EPS19E > "0.4" and EPS20E > "0.4"	463e7307351411e9b12b542696d6e445
qid1549	SELECT 公司简称 WHERE EPS18E > "0.4" and EPS19E > "0.4" and EPS20E > "0.4"	463e7307351411e9b12b542696d6e445
qid1550	SELECT 公司 WHERE PE2012E < "55" and PE2013E < "55"	69d1246b334311e9a6e6542696d6e445
qid1551	SELECT 公司 WHERE PE2012E < "55" and PE2013E < "55"	69d1246b334311e9a6e6542696d6e445
qid1552	SELECT 公司 WHERE PE2012E < "55" and PE2013E < "55"	69d1246b334311e9a6e6542696d6e445
qid1553	SELECT 公司 WHERE 应收周转率 > "41.61" or 归母净利润(亿元) < "10"	c5ab812834b411e9a8bf542696d6e445
qid1554	SELECT 公司 WHERE 应收周转率 > "41.61" or 归母净利润(亿元) < "10"	c5ab812834b411e9a8bf542696d6e445
qid1555	SELECT 公司 WHERE 应收周转率 > "41.61" or 归母净利润(亿元) < "10"	c5ab812834b411e9a8bf542696d6e445
qid1556	SELECT SUM ( 10APE ) WHERE 证券简称 == "香江控股" or 证券简称 == "万通地产"	e0adae75333a11e9a131542696d6e445
qid1557	SELECT SUM ( 10APE ) WHERE 证券简称 == "香江控股" or 证券简称 == "万通地产"	e0adae75333a11e9a131542696d6e445
qid1558	SELECT SUM ( 10APE ) WHERE 证券简称 == "香江控股" or 证券简称 == "万通地产"	e0adae75333a11e9a131542696d6e445
qid1559	SELECT 一手房每周交易数据 WHERE 上周成交量（万平米） > "100" or 环比上周（%） > "20"	43ae32751d7111e9a5abf40f24344a08
qid1560	SELECT 一手房每周交易数据 WHERE 上周成交量（万平米） > "100" or 环比上周（%） > "20"	43ae32751d7111e9a5abf40f24344a08
qid1561	SELECT 一手房每周交易数据 WHERE 上周成交量（万平米） > "100" or 环比上周（%） > "20"	43ae32751d7111e9a5abf40f24344a08
qid1562	SELECT 土地出让金(亿元) WHERE 规划建筑面积(万㎡) > "180000"	43ad6bdc1d7111e988a6f40f24344a08
qid1563	SELECT 土地出让金(亿元) WHERE 规划建筑面积(万㎡) > "180000"	43ad6bdc1d7111e988a6f40f24344a08
qid1564	SELECT 土地出让金(亿元) WHERE 规划建筑面积(万㎡) > "180000"	43ad6bdc1d7111e988a6f40f24344a08
qid1565	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 > "5" and 定增价除权后至今价格 > "5"	4d25be873aaa11e98623f40f24344a08
qid1566	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 > "5" and 定增价除权后至今价格 > "5"	4d25be873aaa11e98623f40f24344a08
qid1567	SELECT COUNT ( 证券简称 ) WHERE 最新收盘价 > "5" and 定增价除权后至今价格 > "5"	4d25be873aaa11e98623f40f24344a08
qid1568	SELECT 总市值（亿元） WHERE 证券简称 == "爱奇艺" or 证券简称 == "哔哩哔哩"	4d28c7ca3aaa11e98617f40f24344a08
qid1569	SELECT 总市值（亿元） WHERE 证券简称 == "爱奇艺" or 证券简称 == "哔哩哔哩"	4d28c7ca3aaa11e98617f40f24344a08
qid1570	SELECT 总市值（亿元） WHERE 证券简称 == "爱奇艺" or 证券简称 == "哔哩哔哩"	4d28c7ca3aaa11e98617f40f24344a08
qid1571	SELECT 城市 WHERE 环比上周（%） > "5" and 环比上月（%） > "1"	e0ac070c333a11e9849c542696d6e445
qid1572	SELECT 城市 WHERE 环比上周（%） > "5" and 环比上月（%） > "1"	e0ac070c333a11e9849c542696d6e445
qid1573	SELECT 城市 WHERE 环比上周（%） > "5" and 环比上月（%） > "1"	e0ac070c333a11e9849c542696d6e445
qid1574	SELECT 城市名 WHERE 日成交 > "500" or 前一日成交 > "500"	c98a335c332111e99ca4542696d6e445
qid1575	SELECT 城市名 WHERE 日成交 > "500" or 前一日成交 > "500"	c98a335c332111e99ca4542696d6e445
qid1576	SELECT 城市名 WHERE 日成交 > "500" or 前一日成交 > "500"	c98a335c332111e99ca4542696d6e445
qid1577	SELECT 一线城市 WHERE 累计值 > "150000" or 累计值同比增速 > "10"	e0abf93a333a11e9a104542696d6e445
qid1578	SELECT 一线城市 WHERE 累计值 > "150000" or 累计值同比增速 > "10"	e0abf93a333a11e9a104542696d6e445
qid1579	SELECT 一线城市 WHERE 累计值 > "150000" or 累计值同比增速 > "10"	e0abf93a333a11e9a104542696d6e445
qid1580	SELECT SUM ( 流通市值（亿元） ) WHERE 股价 > "10" and PETTM > "10"	4d28a13a3aaa11e98590f40f24344a08
qid1581	SELECT SUM ( 流通市值（亿元） ) WHERE 股价 > "10" and PETTM > "10"	4d28a13a3aaa11e98590f40f24344a08
qid1582	SELECT SUM ( 流通市值（亿元） ) WHERE 股价 > "10" and PETTM > "10"	4d28a13a3aaa11e98590f40f24344a08
qid1583	SELECT 导演 , 主演 WHERE 影片 == "爱宠大机密2"	4d28174f3aaa11e9b1fdf40f24344a08
qid1584	SELECT 导演 , 主演 WHERE 影片 == "爱宠大机密2"	4d28174f3aaa11e9b1fdf40f24344a08
qid1585	SELECT 导演 , 主演 WHERE 影片 == "爱宠大机密2"	4d28174f3aaa11e9b1fdf40f24344a08
qid1586	SELECT 2012至今 WHERE 城市 == "广州"	69d56680334311e9a917542696d6e445
qid1587	SELECT 2012至今 WHERE 城市 == "广州"	69d56680334311e9a917542696d6e445
qid1588	SELECT 2012至今 WHERE 城市 == "广州"	69d56680334311e9a917542696d6e445
qid1589	SELECT 12EPE WHERE 证券简称 == "卧龙地产" and 11EPE > "10"	e0ae7bee333a11e99031542696d6e445
qid1590	SELECT 12EPE WHERE 证券简称 == "卧龙地产" and 11EPE > "10"	e0ae7bee333a11e99031542696d6e445
qid1591	SELECT 12EPE WHERE 证券简称 == "卧龙地产" and 11EPE > "10"	e0ae7bee333a11e99031542696d6e445
qid1592	SELECT 机场 , 当前设计旅客吞吐量 WHERE 扩建后旅客吞吐量 > "8000"	733d160034c611e988e4542696d6e445
qid1593	SELECT 机场 , 当前设计旅客吞吐量 WHERE 扩建后旅客吞吐量 > "8000"	733d160034c611e988e4542696d6e445
qid1594	SELECT 机场 , 当前设计旅客吞吐量 WHERE 扩建后旅客吞吐量 > "8000"	733d160034c611e988e4542696d6e445
qid1595	SELECT AVG ( 最新股价 ) WHERE PB估值 < "2"	69d2a666334311e9acbf542696d6e445
qid1596	SELECT AVG ( 最新股价 ) WHERE PB估值 < "2"	69d2a666334311e9acbf542696d6e445
qid1597	SELECT 研发方 WHERE 游戏 == "欢乐斗地主" or 游戏 == "问道"	4d27000c3aaa11e99112f40f24344a08
qid1598	SELECT 研发方 WHERE 游戏 == "欢乐斗地主" or 游戏 == "问道"	4d27000c3aaa11e99112f40f24344a08
qid1599	SELECT 研发方 WHERE 游戏 == "欢乐斗地主" or 游戏 == "问道"	4d27000c3aaa11e99112f40f24344a08
qid1600	SELECT 公司 WHERE EPS2017 > "0.2" or PE2017 > "30"	015690ba351311e9ac4a542696d6e445
qid1601	SELECT 公司 WHERE EPS2017 > "0.2" or PE2017 > "30"	015690ba351311e9ac4a542696d6e445
qid1602	SELECT 公司 WHERE EPS2017 > "0.2" or PE2017 > "30"	015690ba351311e9ac4a542696d6e445
qid1603	SELECT 楼盘名称 , 5月均价(元/㎡) WHERE 月环比涨幅 > "5"	c98c3640332111e9b3fe542696d6e445
qid1604	SELECT 楼盘名称 , 5月均价(元/㎡) WHERE 月环比涨幅 > "5"	c98c3640332111e9b3fe542696d6e445
qid1605	SELECT 楼盘名称 , 5月均价(元/㎡) WHERE 月环比涨幅 > "5"	c98c3640332111e9b3fe542696d6e445
qid1606	SELECT AVG ( 市值（亿元） ) WHERE EPS2017 > "0.5" and EPS2018E > "0.5"	4d267ff53aaa11e9a96bf40f24344a08
qid1607	SELECT AVG ( 市值（亿元） ) WHERE EPS2017 > "0.5" and EPS2018E > "0.5"	4d267ff53aaa11e9a96bf40f24344a08
qid1608	SELECT AVG ( 市值（亿元） ) WHERE EPS2017 > "0.5" and EPS2018E > "0.5"	4d267ff53aaa11e9a96bf40f24344a08
qid1609	SELECT 城市 WHERE 目前 > "400" or 11年底 > "400"	c98bf0de332111e9b450542696d6e445
qid1610	SELECT 城市 WHERE 目前 > "400" or 11年底 > "400"	c98bf0de332111e9b450542696d6e445
qid1611	SELECT 城市 WHERE 目前 > "400" or 11年底 > "400"	c98bf0de332111e9b450542696d6e445
qid1612	SELECT 公司名称 WHERE 主要业务 == "电容" and 17年营收/亿美元 > "20"	0de5c761351311e989dc542696d6e445
qid1613	SELECT 公司名称 WHERE 主要业务 == "电容" and 17年营收/亿美元 > "20"	0de5c761351311e989dc542696d6e445
qid1614	SELECT 公司名称 WHERE 主要业务 == "电容" and 17年营收/亿美元 > "20"	0de5c761351311e989dc542696d6e445
qid1615	SELECT 周换手率% WHERE 证券简称 == "芒果超媒" and 周涨跌幅% < "10"	4d23f9fa3aaa11e9b316f40f24344a08
qid1616	SELECT 周换手率% WHERE 证券简称 == "芒果超媒" and 周涨跌幅% < "10"	4d23f9fa3aaa11e9b316f40f24344a08
qid1617	SELECT 周换手率% WHERE 证券简称 == "芒果超媒" and 周涨跌幅% < "10"	4d23f9fa3aaa11e9b316f40f24344a08
qid1618	SELECT 楼盘名称 WHERE 4月套数 > "100" and 4月均价 > "20000"	5a4fe330312b11e99eaf542696d6e445
qid1619	SELECT 楼盘名称 WHERE 4月套数 > "100" and 4月均价 > "20000"	5a4fe330312b11e99eaf542696d6e445
qid1620	SELECT 楼盘名称 WHERE 4月套数 > "100" and 4月均价 > "20000"	5a4fe330312b11e99eaf542696d6e445
qid1621	SELECT 2010成交面积 WHERE 城市 == "广州" or 城市 == "深圳"	69d53278334311e9a50a542696d6e445
qid1622	SELECT 2010成交面积 WHERE 城市 == "广州" or 城市 == "深圳"	69d53278334311e9a50a542696d6e445
qid1623	SELECT 2010成交面积 WHERE 城市 == "广州" or 城市 == "深圳"	69d53278334311e9a50a542696d6e445
qid1624	SELECT 证券简称 WHERE 营业收入同比增长率 > "50" or 归母净利润同比 > "30"	0de680cf351311e9bde3542696d6e445
qid1625	SELECT 证券简称 WHERE 营业收入同比增长率 > "50" or 归母净利润同比 > "30"	0de680cf351311e9bde3542696d6e445
qid1626	SELECT 证券简称 WHERE 营业收入同比增长率 > "50" or 归母净利润同比 > "30"	0de680cf351311e9bde3542696d6e445
qid1627	SELECT 周票房（万） , 场均人次 WHERE 影片名称 == "大黄蜂"	4d2999003aaa11e99af6f40f24344a08
qid1628	SELECT 周票房（万） , 场均人次 WHERE 影片名称 == "大黄蜂"	4d2999003aaa11e99af6f40f24344a08
qid1629	SELECT 周票房（万） , 场均人次 WHERE 影片名称 == "大黄蜂"	4d2999003aaa11e99af6f40f24344a08
qid1630	SELECT 2016A市盈率(x) , 最新每股净资产(元/股) WHERE 2016A每股收益(元/股) > "1"	69ce5f78334311e9813f542696d6e445
qid1631	SELECT 2016A市盈率(x) , 最新每股净资产(元/股) WHERE 2016A每股收益(元/股) > "1"	69ce5f78334311e9813f542696d6e445
qid1632	SELECT 2016A市盈率(x) , 最新每股净资产(元/股) WHERE 2016A每股收益(元/股) > "1"	69ce5f78334311e9813f542696d6e445
qid1633	SELECT MAX ( 倒挂率 ) WHERE 定增价除权后至今价格 < "20" and 增发价格 < "20"	4d262f9c3aaa11e9a172f40f24344a08
qid1634	SELECT MAX ( 倒挂率 ) WHERE 定增价除权后至今价格 < "20" and 增发价格 < "20"	4d262f9c3aaa11e9a172f40f24344a08
qid1635	SELECT MAX ( 倒挂率 ) WHERE 定增价除权后至今价格 < "20" and 增发价格 < "20"	4d262f9c3aaa11e9a172f40f24344a08
qid1636	SELECT 5月均价(元/㎡) WHERE 楼盘名称 == "贝尚湾"	c98c32eb332111e9a241542696d6e445
qid1637	SELECT 5月均价(元/㎡) WHERE 楼盘名称 == "贝尚湾"	c98c32eb332111e9a241542696d6e445
qid1638	SELECT 5月均价(元/㎡) WHERE 楼盘名称 == "贝尚湾"	c98c32eb332111e9a241542696d6e445
qid1639	SELECT 证券 , 收盘价 WHERE PE2019E < "20" or PE2020E < "20"	0156172b351311e986b3542696d6e445
qid1640	SELECT 证券 , 收盘价 WHERE PE2019E < "20" or PE2020E < "20"	0156172b351311e986b3542696d6e445
qid1641	SELECT 证券 , 收盘价 WHERE PE2019E < "20" or PE2020E < "20"	0156172b351311e986b3542696d6e445
qid1642	SELECT 子行业 WHERE 市值 > "300" or 收益 > "0.8"	733d80fd34c611e98d98542696d6e445
qid1643	SELECT 子行业 WHERE 市值 > "300" or 收益 > "0.8"	733d80fd34c611e98d98542696d6e445
qid1644	SELECT 子行业 WHERE 市值 > "300" or 收益 > "0.8"	733d80fd34c611e98d98542696d6e445
qid1645	SELECT 公司 , 区域 WHERE 总地面积 > "10" and 建筑面积 > "10"	5a4efa23312b11e9b5f9542696d6e445
qid1646	SELECT 公司 , 区域 WHERE 总地面积 > "10" and 建筑面积 > "10"	5a4efa23312b11e9b5f9542696d6e445
qid1647	SELECT 公司 , 区域 WHERE 总地面积 > "10" and 建筑面积 > "10"	5a4efa23312b11e9b5f9542696d6e445
qid1648	SELECT COUNT ( 公司名称 ) WHERE PE2011 > "10" and PE2012E > "10"	69d2873a334311e9bb9b542696d6e445
qid1649	SELECT COUNT ( 公司名称 ) WHERE PE2011 > "10" and PE2012E > "10"	69d2873a334311e9bb9b542696d6e445
qid1650	SELECT COUNT ( 公司名称 ) WHERE PE2011 > "10" and PE2012E > "10"	69d2873a334311e9bb9b542696d6e445
qid1651	SELECT 城市 WHERE 本周同比 > "30" and 本周环比 > "30"	c98c70ae332111e98c41542696d6e445
qid1652	SELECT 城市 WHERE 本周同比 > "30" and 本周环比 > "30"	c98c70ae332111e98c41542696d6e445
qid1653	SELECT 城市 WHERE 本周同比 > "30" and 本周环比 > "30"	c98c70ae332111e98c41542696d6e445
qid1654	SELECT 城市 WHERE 本周 > "10" or 上周 > "10"	c98ce5f3332111e9afee542696d6e445
qid1655	SELECT 城市 WHERE 本周 > "10" or 上周 > "10"	c98ce5f3332111e9afee542696d6e445
qid1656	SELECT 城市 WHERE 本周 > "10" or 上周 > "10"	c98ce5f3332111e9afee542696d6e445
qid1657	SELECT COUNT ( 公司 ) WHERE PE2018E < "20" and PE2019E < "20"	43b3612e1d7111e9a29bf40f24344a08
qid1658	SELECT COUNT ( 公司 ) WHERE PE2018E < "20" and PE2019E < "20"	43b3612e1d7111e9a29bf40f24344a08
qid1659	SELECT COUNT ( 公司 ) WHERE PE2018E < "20" and PE2019E < "20"	43b3612e1d7111e9a29bf40f24344a08
qid1660	SELECT 时间 WHERE 铁路客运(春运） > "10" or 民航客运(春运） > "10"	733c1f5934c611e98e23542696d6e445
qid1661	SELECT 时间 WHERE 铁路客运(春运） > "10" or 民航客运(春运） > "10"	733c1f5934c611e98e23542696d6e445
qid1662	SELECT 时间 WHERE 铁路客运(春运） > "10" or 民航客运(春运） > "10"	733c1f5934c611e98e23542696d6e445
qid1663	SELECT 年涨跌幅（%） WHERE 周涨跌幅（%） > "0" and 月涨跌幅（%） > "0"	e0ac4d54333a11e98222542696d6e445
qid1664	SELECT 年涨跌幅（%） WHERE 周涨跌幅（%） > "0" and 月涨跌幅（%） > "0"	e0ac4d54333a11e98222542696d6e445
qid1665	SELECT 年涨跌幅（%） WHERE 周涨跌幅（%） > "0" and 月涨跌幅（%） > "0"	e0ac4d54333a11e98222542696d6e445
qid1666	SELECT COUNT ( 指标名称 ) WHERE 上月 > "500" and 上年 > "500"	c5ae301c34b411e9965f542696d6e445
qid1667	SELECT COUNT ( 指标名称 ) WHERE 上月 > "500" and 上年 > "500"	c5ae301c34b411e9965f542696d6e445
qid1668	SELECT COUNT ( 指标名称 ) WHERE 上月 > "500" and 上年 > "500"	c5ae301c34b411e9965f542696d6e445
qid1669	SELECT COUNT ( 影片 ) WHERE 北美映期 == "2019-02-14"	4d280f0f3aaa11e998b0f40f24344a08
qid1670	SELECT COUNT ( 影片 ) WHERE 北美映期 == "2019-02-14"	4d280f0f3aaa11e998b0f40f24344a08
qid1671	SELECT COUNT ( 影片 ) WHERE 北美映期 == "2019-02-14"	4d280f0f3aaa11e998b0f40f24344a08
qid1672	SELECT MIN ( 累计同比 ) WHERE 11年H2 > "10" and 10年H2 > "10"	5a4aad40312b11e99ced542696d6e445
qid1673	SELECT MIN ( 累计同比 ) WHERE 11年H2 > "10" and 10年H2 > "10"	5a4aad40312b11e99ced542696d6e445
qid1674	SELECT MIN ( 累计同比 ) WHERE 11年H2 > "10" and 10年H2 > "10"	5a4aad40312b11e99ced542696d6e445
qid1675	SELECT 公司 WHERE Q1-Q3业务量 > "30" or Q1-Q3份额 > "10"	c5acf7e334b411e986d5542696d6e445
qid1676	SELECT 公司 WHERE Q1-Q3业务量 > "30" or Q1-Q3份额 > "10"	c5acf7e334b411e986d5542696d6e445
qid1677	SELECT 公司 WHERE Q1-Q3业务量 > "30" or Q1-Q3份额 > "10"	c5acf7e334b411e986d5542696d6e445
qid1678	SELECT 股票代码 WHERE PE-TTM > "120" and PB > "1.5"	43b2932b1d7111e9a434f40f24344a08
qid1679	SELECT 股票代码 WHERE PE-TTM > "120" and PB > "1.5"	43b2932b1d7111e9a434f40f24344a08
qid1680	SELECT 股票代码 WHERE PE-TTM > "120" and PB > "1.5"	43b2932b1d7111e9a434f40f24344a08
qid1681	SELECT 证券简称 WHERE 10APE > "0.56" or 11APE > "0.56"	c98dd373332111e9b4fb542696d6e445
qid1682	SELECT 证券简称 WHERE 10APE > "0.56" or 11APE > "0.56"	c98dd373332111e9b4fb542696d6e445
qid1683	SELECT 证券简称 WHERE 10APE > "0.56" or 11APE > "0.56"	c98dd373332111e9b4fb542696d6e445
qid1684	SELECT MAX ( 本周成交面积 ) WHERE 城市 == "中山" and 上周成交面积 > "10"	c98a1340332111e98914542696d6e445
qid1685	SELECT MAX ( 本周成交面积 ) WHERE 城市 == "中山" and 上周成交面积 > "10"	c98a1340332111e98914542696d6e445
qid1686	SELECT MAX ( 本周成交面积 ) WHERE 城市 == "中山" and 上周成交面积 > "10"	c98a1340332111e98914542696d6e445
qid1687	SELECT 航空公司 WHERE 2018E > "5" and 2019E > "10"	c5ab254a34b411e9a32c542696d6e445
qid1688	SELECT 航空公司 WHERE 2018E > "5" and 2019E > "10"	c5ab254a34b411e9a32c542696d6e445
qid1689	SELECT 航空公司 WHERE 2018E > "5" and 2019E > "10"	c5ab254a34b411e9a32c542696d6e445
qid1690	SELECT SUM ( 成交面积（万平方米） ) WHERE 城市名称 == "大连市" or 城市名称 == "沈阳市"	c98dfe73332111e99574542696d6e445
qid1691	SELECT SUM ( 成交面积（万平方米） ) WHERE 城市名称 == "大连市" or 城市名称 == "沈阳市"	c98dfe73332111e99574542696d6e445
qid1692	SELECT SUM ( 成交面积（万平方米） ) WHERE 城市名称 == "大连市" or 城市名称 == "沈阳市"	c98dfe73332111e99574542696d6e445
qid1693	SELECT 名称 WHERE 2018年底银幕数量 > "500" or 2018年票房（亿元） > "7"	4d2780663aaa11e994d4f40f24344a08
qid1694	SELECT 名称 WHERE 2018年底银幕数量 > "500" or 2018年票房（亿元） > "7"	4d2780663aaa11e994d4f40f24344a08
qid1695	SELECT 名称 WHERE 2018年底银幕数量 > "500" or 2018年票房（亿元） > "7"	4d2780663aaa11e994d4f40f24344a08
qid1696	SELECT 容积率 WHERE 项目名称 == "万科五玠坊" and 已签约套数 > "30"	c9896670332111e99719542696d6e445
qid1697	SELECT 容积率 WHERE 项目名称 == "万科五玠坊" and 已签约套数 > "30"	c9896670332111e99719542696d6e445
qid1698	SELECT 容积率 WHERE 项目名称 == "万科五玠坊" and 已签约套数 > "30"	c9896670332111e99719542696d6e445
qid1699	SELECT AVG ( May ) WHERE Mar > "20" or Apr > "20"	5a52262b312b11e9b0da542696d6e445
qid1700	SELECT AVG ( May ) WHERE Mar > "20" or Apr > "20"	5a52262b312b11e9b0da542696d6e445
qid1701	SELECT AVG ( May ) WHERE Mar > "20" or Apr > "20"	5a52262b312b11e9b0da542696d6e445
qid1702	SELECT 城市 WHERE 本周环比 > "0" and 本周同比 > "0"	c98cba33332111e99841542696d6e445
qid1703	SELECT 城市 WHERE 本周环比 > "0" and 本周同比 > "0"	c98cba33332111e99841542696d6e445
qid1704	SELECT 城市 WHERE 本周环比 > "0" and 本周同比 > "0"	c98cba33332111e99841542696d6e445
qid1705	SELECT COUNT ( 证券 ) WHERE 收盘价 > "10"	01562780351311e995f2542696d6e445
qid1706	SELECT COUNT ( 证券 ) WHERE 收盘价 > "10"	01562780351311e995f2542696d6e445
qid1707	SELECT COUNT ( 证券 ) WHERE 收盘价 > "10"	01562780351311e995f2542696d6e445
qid1708	SELECT 证券简称 WHERE RNAV > "20"	c98dd373332111e9b4fb542696d6e445
qid1709	SELECT 证券简称 WHERE RNAV > "20"	c98dd373332111e9b4fb542696d6e445
qid1710	SELECT 证券简称 WHERE RNAV > "20"	c98dd373332111e9b4fb542696d6e445
qid1711	SELECT PE19E WHERE 公司 == "中国国航" and PE18E > "10"	01553ea6351311e981b5542696d6e445
qid1712	SELECT PE19E WHERE 公司 == "中国国航" and PE18E > "10"	01553ea6351311e981b5542696d6e445
qid1713	SELECT PE19E WHERE 公司 == "中国国航" and PE18E > "10"	01553ea6351311e981b5542696d6e445
qid1714	SELECT 北美映期 WHERE 类型 == "惊悚/悬疑" and 影片 == "忌日快乐2"	4d280f0f3aaa11e998b0f40f24344a08
qid1715	SELECT 北美映期 WHERE 类型 == "惊悚/悬疑" and 影片 == "忌日快乐2"	4d280f0f3aaa11e998b0f40f24344a08
qid1716	SELECT 北美映期 WHERE 类型 == "惊悚/悬疑" and 影片 == "忌日快乐2"	4d280f0f3aaa11e998b0f40f24344a08
qid1717	SELECT 证券代码 , 资产负债率（%） WHERE 证券简称 == "鲁商置业"	5a4e8845312b11e98619542696d6e445
qid1718	SELECT 证券代码 , 资产负债率（%） WHERE 证券简称 == "鲁商置业"	5a4e8845312b11e98619542696d6e445
qid1719	SELECT 证券代码 , 资产负债率（%） WHERE 证券简称 == "鲁商置业"	5a4e8845312b11e98619542696d6e445
qid1720	SELECT 名称 , 代码 WHERE 变动百分比2012 > "2" or 变动百分比2013 > "2"	69d3b0c5334311e99a4a542696d6e445
qid1721	SELECT 名称 , 代码 WHERE 变动百分比2012 > "2" or 变动百分比2013 > "2"	69d3b0c5334311e99a4a542696d6e445
qid1722	SELECT 名称 , 代码 WHERE 变动百分比2012 > "2" or 变动百分比2013 > "2"	69d3b0c5334311e99a4a542696d6e445
qid1723	SELECT 总市值（亿元） WHERE 证券简称 == "勤上股份" and 股价 > "1"	4d28b0303aaa11e9bd3ef40f24344a08
qid1724	SELECT 总市值（亿元） WHERE 证券简称 == "勤上股份" and 股价 > "1"	4d28b0303aaa11e9bd3ef40f24344a08
qid1725	SELECT 总市值（亿元） WHERE 证券简称 == "勤上股份" and 股价 > "1"	4d28b0303aaa11e9bd3ef40f24344a08
qid1726	SELECT 项目名称 , 开工时间 WHERE 工程投资（亿） > "100"	0151f30c351311e9ba68542696d6e445
qid1727	SELECT 项目名称 , 开工时间 WHERE 工程投资（亿） > "100"	0151f30c351311e9ba68542696d6e445
qid1728	SELECT 项目名称 , 开工时间 WHERE 工程投资（亿） > "100"	0151f30c351311e9ba68542696d6e445
qid1729	SELECT 机场（代码） , 基地航空公司 WHERE 2017年旅客吞吐量（万人次） > "8000"	733d128234c611e9a0fa542696d6e445
qid1730	SELECT 机场（代码） , 基地航空公司 WHERE 2017年旅客吞吐量（万人次） > "8000"	733d128234c611e9a0fa542696d6e445
qid1731	SELECT 机场（代码） , 基地航空公司 WHERE 2017年旅客吞吐量（万人次） > "8000"	733d128234c611e9a0fa542696d6e445
qid1732	SELECT 周涨跌幅（%） WHERE 股票代码 == "002454.sz"	e0ac4d54333a11e98222542696d6e445
qid1733	SELECT 周涨跌幅（%） WHERE 股票代码 == "002454.sz"	e0ac4d54333a11e98222542696d6e445
qid1734	SELECT 周涨跌幅（%） WHERE 股票代码 == "002454.sz"	e0ac4d54333a11e98222542696d6e445
qid1735	SELECT 占比 WHERE 主要设备 == "换流阀" and 订单量（亿） == "92.4"	463e61cc351411e9b29b542696d6e445
qid1736	SELECT 占比 WHERE 主要设备 == "换流阀" and 订单量（亿） == "92.4"	463e61cc351411e9b29b542696d6e445
qid1737	SELECT 航空公司 WHERE 2019E < "500"	c5adb61e34b411e984e7542696d6e445
qid1738	SELECT 航空公司 WHERE 2019E < "500"	c5adb61e34b411e984e7542696d6e445
qid1739	SELECT 航空公司 WHERE 2019E < "500"	c5adb61e34b411e984e7542696d6e445
qid1740	SELECT 溢价率 , 涨幅 WHERE 证券简称 == "建发股份"	c98daf26332111e99d17542696d6e445
qid1741	SELECT 溢价率 , 涨幅 WHERE 证券简称 == "建发股份"	c98daf26332111e99d17542696d6e445
qid1742	SELECT 溢价率 , 涨幅 WHERE 证券简称 == "建发股份"	c98daf26332111e99d17542696d6e445
qid1743	SELECT COUNT ( 航空公司 ) WHERE 1月 > "5" and 2月 > "5" and 3月 > "5"	c5ac137d34b411e9a777542696d6e445
qid1744	SELECT COUNT ( 航空公司 ) WHERE 1月 > "5" and 2月 > "5" and 3月 > "5"	c5ac137d34b411e9a777542696d6e445
qid1745	SELECT COUNT ( 航空公司 ) WHERE 1月 > "5" and 2月 > "5" and 3月 > "5"	c5ac137d34b411e9a777542696d6e445
qid1746	SELECT Q1-Q3业务量 WHERE 公司 == "顺丰"	c5acf7e334b411e986d5542696d6e445
qid1747	SELECT Q1-Q3业务量 WHERE 公司 == "顺丰"	c5acf7e334b411e986d5542696d6e445
qid1748	SELECT Q1-Q3业务量 WHERE 公司 == "顺丰"	c5acf7e334b411e986d5542696d6e445
qid1749	SELECT 本周涨跌幅（%） , 2018年动态PE WHERE 股票名称 == "飞马国际"	c5aed12b34b411e9841a542696d6e445
qid1750	SELECT 本周涨跌幅（%） , 2018年动态PE WHERE 股票名称 == "飞马国际"	c5aed12b34b411e9841a542696d6e445
qid1751	SELECT 本周涨跌幅（%） , 2018年动态PE WHERE 股票名称 == "飞马国际"	c5aed12b34b411e9841a542696d6e445
qid1752	SELECT 主基地 WHERE 18冬春航班数量 < "20000"	c5ac847534b411e9bd09542696d6e445
qid1753	SELECT 主基地 WHERE 18冬春航班数量 < "20000"	c5ac847534b411e9bd09542696d6e445
qid1754	SELECT 主基地 WHERE 18冬春航班数量 < "20000"	c5ac847534b411e9bd09542696d6e445
qid1755	SELECT 销售收入排名 WHERE 同比增长率 > "10" and 销售收入（百万美元） > "3000"	43b27b231d7111e99c07f40f24344a08
qid1756	SELECT 销售收入排名 WHERE 同比增长率 > "10" and 销售收入（百万美元） > "3000"	43b27b231d7111e99c07f40f24344a08
qid1757	SELECT 销售收入排名 WHERE 同比增长率 > "10" and 销售收入（百万美元） > "3000"	43b27b231d7111e99c07f40f24344a08
qid1758	SELECT AVG ( 成交住宅建筑面积（万平米） ) WHERE 时间 == "2012年3月" or 时间 == "2012年1月"	5a4edf57312b11e9b253542696d6e445
qid1759	SELECT AVG ( 成交住宅建筑面积（万平米） ) WHERE 时间 == "2012年3月" or 时间 == "2012年1月"	5a4edf57312b11e9b253542696d6e445
qid1760	SELECT AVG ( 成交住宅建筑面积（万平米） ) WHERE 时间 == "2012年3月" or 时间 == "2012年1月"	5a4edf57312b11e9b253542696d6e445
qid1761	SELECT COUNT ( 院线名称 ) WHERE 观影人次（万） > "120"	4d2a10753aaa11e98aacf40f24344a08
qid1762	SELECT COUNT ( 院线名称 ) WHERE 观影人次（万） > "120"	4d2a10753aaa11e98aacf40f24344a08
qid1763	SELECT COUNT ( 院线名称 ) WHERE 观影人次（万） > "120"	4d2a10753aaa11e98aacf40f24344a08
qid1764	SELECT 证券简称 , 证券代码 WHERE 市值 < "100"	733d74f334c611e9b31d542696d6e445
qid1765	SELECT 证券简称 , 证券代码 WHERE 市值 < "100"	733d74f334c611e9b31d542696d6e445
qid1766	SELECT 证券简称 , 证券代码 WHERE 市值 < "100"	733d74f334c611e9b31d542696d6e445
qid1767	SELECT 指标 WHERE 2012:1-5月累计值 > "50000" and 2012:1-5月累计同比 > "1"	69d60517334311e99464542696d6e445
qid1768	SELECT 指标 WHERE 2012:1-5月累计值 > "50000" and 2012:1-5月累计同比 > "1"	69d60517334311e99464542696d6e445
qid1769	SELECT 指标 WHERE 2012:1-5月累计值 > "50000" and 2012:1-5月累计同比 > "1"	69d60517334311e99464542696d6e445
qid1770	SELECT 客车占比 WHERE 高速 == "水官高速"	733d489434c611e9ab84542696d6e445
qid1771	SELECT 客车占比 WHERE 高速 == "水官高速"	733d489434c611e9ab84542696d6e445
qid1772	SELECT 客车占比 WHERE 高速 == "水官高速"	733d489434c611e9ab84542696d6e445
qid1773	SELECT EPS2013E WHERE 公司 == "华夏幸福" and EPS2012E > "1"	69d35214334311e9be23542696d6e445
qid1774	SELECT EPS2013E WHERE 公司 == "华夏幸福" and EPS2012E > "1"	69d35214334311e9be23542696d6e445
qid1775	SELECT EPS2013E WHERE 公司 == "华夏幸福" and EPS2012E > "1"	69d35214334311e9be23542696d6e445
qid1776	SELECT 2011供应面积 WHERE 城市 == "一线城市" and 2010供应面积 == "4526"	69d56130334311e981e2542696d6e445
qid1777	SELECT 2011供应面积 WHERE 城市 == "一线城市" and 2010供应面积 == "4526"	69d56130334311e981e2542696d6e445
qid1778	SELECT 2011供应面积 WHERE 城市 == "一线城市" and 2010供应面积 == "4526"	69d56130334311e981e2542696d6e445
qid1779	SELECT COUNT ( 高速公司 ) WHERE EPS18E > "0.5" and EPS19E > "0.5"	733c8cd734c611e9b5b2542696d6e445
qid1780	SELECT COUNT ( 高速公司 ) WHERE EPS18E > "0.5" and EPS19E > "0.5"	733c8cd734c611e9b5b2542696d6e445
qid1781	SELECT COUNT ( 高速公司 ) WHERE EPS18E > "0.5" and EPS19E > "0.5"	733c8cd734c611e9b5b2542696d6e445
qid1782	SELECT COUNT ( 区域 ) WHERE 可售数量 < "60000"	c98ac519332111e9b2b0542696d6e445
qid1783	SELECT COUNT ( 区域 ) WHERE 可售数量 < "60000"	c98ac519332111e9b2b0542696d6e445
qid1784	SELECT COUNT ( 区域 ) WHERE 可售数量 < "60000"	c98ac519332111e9b2b0542696d6e445
qid1785	SELECT 地区 WHERE 投资额（亿元） > "5000" or 住宅投资额 > "5000"	c989e6c0332111e9949d542696d6e445
qid1786	SELECT 地区 WHERE 投资额（亿元） > "5000" or 住宅投资额 > "5000"	c989e6c0332111e9949d542696d6e445
qid1787	SELECT 地区 WHERE 投资额（亿元） > "5000" or 住宅投资额 > "5000"	c989e6c0332111e9949d542696d6e445
qid1788	SELECT 名称 , 代码 WHERE 变动百分比2012 > "1" and 变动百分比2013 > "1"	69d3cdca334311e9bd4b542696d6e445
qid1789	SELECT 名称 , 代码 WHERE 变动百分比2012 > "1" and 变动百分比2013 > "1"	69d3cdca334311e9bd4b542696d6e445
qid1790	SELECT 名称 , 代码 WHERE 变动百分比2012 > "1" and 变动百分比2013 > "1"	69d3cdca334311e9bd4b542696d6e445
qid1791	SELECT 营业收入 WHERE 证券简称 == "木林森" or 证券简称 == "欧普照明"	0de680cf351311e9bde3542696d6e445
qid1792	SELECT 营业收入 WHERE 证券简称 == "木林森" or 证券简称 == "欧普照明"	0de680cf351311e9bde3542696d6e445
qid1793	SELECT 营业收入 WHERE 证券简称 == "木林森" or 证券简称 == "欧普照明"	0de680cf351311e9bde3542696d6e445
qid1794	SELECT 指标 WHERE PTFE < "2" or TPPE < "2" or CE < "2"	0de5af1e351311e9b442542696d6e445
qid1795	SELECT 指标 WHERE PTFE < "2" or TPPE < "2" or CE < "2"	0de5af1e351311e9b442542696d6e445
qid1796	SELECT 指标 WHERE PTFE < "2" or TPPE < "2" or CE < "2"	0de5af1e351311e9b442542696d6e445
qid1797	SELECT 评级 WHERE PB2011 > "3" or 股价 > "10"	69d07847334311e9807a542696d6e445
qid1798	SELECT 评级 WHERE PB2011 > "3" or 股价 > "10"	69d07847334311e9807a542696d6e445
qid1799	SELECT 评级 WHERE PB2011 > "3" or 股价 > "10"	69d07847334311e9807a542696d6e445
qid1800	SELECT COUNT ( 城市 ) WHERE 本周均成交面积 > "10"	c98e1c19332111e9ab43542696d6e445
qid1801	SELECT COUNT ( 城市 ) WHERE 本周均成交面积 > "10"	c98e1c19332111e9ab43542696d6e445
qid1802	SELECT COUNT ( 城市 ) WHERE 本周均成交面积 > "10"	c98e1c19332111e9ab43542696d6e445
qid1803	SELECT 简称 , 证券代码 WHERE 月涨幅% > "30" or 市净率 > "5"	25328521302e11e994e0542696d6e445
qid1804	SELECT 简称 , 证券代码 WHERE 月涨幅% > "30" or 市净率 > "5"	25328521302e11e994e0542696d6e445
qid1805	SELECT 简称 , 证券代码 WHERE 月涨幅% > "30" or 市净率 > "5"	25328521302e11e994e0542696d6e445
qid1806	SELECT EPS2011 , 最新股价 WHERE 公司名称 == "泛海建设"	69cf9bb8334311e9bf43542696d6e445
qid1807	SELECT EPS2011 , 最新股价 WHERE 公司名称 == "泛海建设"	69cf9bb8334311e9bf43542696d6e445
qid1808	SELECT EPS2011 , 最新股价 WHERE 公司名称 == "泛海建设"	69cf9bb8334311e9bf43542696d6e445
qid1809	SELECT 2011年成交面积 WHERE 城市 == "温州" or 城市 == "金华"	69d31c5e334311e9b9d1542696d6e445
qid1810	SELECT 2011年成交面积 WHERE 城市 == "温州" or 城市 == "金华"	69d31c5e334311e9b9d1542696d6e445
qid1811	SELECT 2011年成交面积 WHERE 城市 == "温州" or 城市 == "金华"	69d31c5e334311e9b9d1542696d6e445
qid1812	SELECT 证券简称 WHERE 2016 > "10" and 2017 > "10"	4d2844613aaa11e9895cf40f24344a08
qid1813	SELECT 证券简称 WHERE 2016 > "10" and 2017 > "10"	4d2844613aaa11e9895cf40f24344a08
qid1814	SELECT 证券简称 WHERE 2016 > "10" and 2017 > "10"	4d2844613aaa11e9895cf40f24344a08
qid1815	SELECT 项目 , 降价幅度 WHERE 售价 == "10000" and 位置 == "仓山区"	5a4edb7a312b11e9b158542696d6e445
qid1816	SELECT 项目 , 降价幅度 WHERE 售价 == "10000" and 位置 == "仓山区"	5a4edb7a312b11e9b158542696d6e445
qid1817	SELECT 项目 , 降价幅度 WHERE 售价 == "10000" and 位置 == "仓山区"	5a4edb7a312b11e9b158542696d6e445
qid1818	SELECT 定增年度 , 增发目的 WHERE 证券简称 == "欢瑞世纪" or 证券简称 == "分众传媒"	4d25be873aaa11e98623f40f24344a08
qid1819	SELECT 定增年度 , 增发目的 WHERE 证券简称 == "欢瑞世纪" or 证券简称 == "分众传媒"	4d25be873aaa11e98623f40f24344a08
qid1820	SELECT 定增年度 , 增发目的 WHERE 证券简称 == "欢瑞世纪" or 证券简称 == "分众传媒"	4d25be873aaa11e98623f40f24344a08
qid1821	SELECT AVG ( 客车占比 ) WHERE 一类车 < "200000" or 二类车 < "200000"	733d489434c611e9ab84542696d6e445
qid1822	SELECT AVG ( 客车占比 ) WHERE 一类车 < "200000" or 二类车 < "200000"	733d489434c611e9ab84542696d6e445
qid1823	SELECT AVG ( 客车占比 ) WHERE 一类车 < "200000" or 二类车 < "200000"	733d489434c611e9ab84542696d6e445
qid1824	SELECT COUNT ( 影片 ) WHERE 类型 == "超级英雄"	4d28174f3aaa11e9b1fdf40f24344a08
qid1825	SELECT COUNT ( 影片 ) WHERE 类型 == "超级英雄"	4d28174f3aaa11e9b1fdf40f24344a08
qid1826	SELECT COUNT ( 影片 ) WHERE 类型 == "超级英雄"	4d28174f3aaa11e9b1fdf40f24344a08
qid1827	SELECT 股票名称 , 代码 WHERE PE17 > "10" and PB17 > "2"	6e616aa834ce11e9a75a542696d6e445
qid1828	SELECT 股票名称 , 代码 WHERE PE17 > "10" and PB17 > "2"	6e616aa834ce11e9a75a542696d6e445
qid1829	SELECT 股票名称 , 代码 WHERE PE17 > "10" and PB17 > "2"	6e616aa834ce11e9a75a542696d6e445
qid1830	SELECT 指标名称 WHERE 发热量/规格 > "6000"	c5ae457034b411e98c59542696d6e445
qid1831	SELECT 指标名称 WHERE 发热量/规格 > "6000"	c5ae457034b411e98c59542696d6e445
qid1832	SELECT 指标名称 WHERE 发热量/规格 > "6000"	c5ae457034b411e98c59542696d6e445
qid1833	SELECT 上周成交量（套） WHERE 城市 == "重庆"	69d46851334311e9a9e1542696d6e445
qid1834	SELECT 上周成交量（套） WHERE 城市 == "重庆"	69d46851334311e9a9e1542696d6e445
qid1835	SELECT 上周成交量（套） WHERE 城市 == "重庆"	69d46851334311e9a9e1542696d6e445
qid1836	SELECT 股票简称 WHERE 总市值（亿元） > "20" and 市盈率(TTM) > "10"	4d26e6303aaa11e9932df40f24344a08
qid1837	SELECT 股票简称 WHERE 总市值（亿元） > "20" and 市盈率(TTM) > "10"	4d26e6303aaa11e9932df40f24344a08
qid1838	SELECT 股票简称 WHERE 总市值（亿元） > "20" and 市盈率(TTM) > "10"	4d26e6303aaa11e9932df40f24344a08
qid1839	SELECT 收视率% WHERE 频道 == "北京卫视" and 剧名 == "上新了故宫"	4d2532a33aaa11e9b4def40f24344a08
qid1840	SELECT 收视率% WHERE 频道 == "北京卫视" and 剧名 == "上新了故宫"	4d2532a33aaa11e9b4def40f24344a08
qid1841	SELECT 收视率% WHERE 频道 == "北京卫视" and 剧名 == "上新了故宫"	4d2532a33aaa11e9b4def40f24344a08
qid1842	SELECT 环比 WHERE 城市 == "杭州" and 近4周周均成交 > "10"	c98a4e45332111e9bc29542696d6e445
qid1843	SELECT 环比 WHERE 城市 == "杭州" and 近4周周均成交 > "10"	c98a4e45332111e9bc29542696d6e445
qid1844	SELECT 环比 WHERE 城市 == "杭州" and 近4周周均成交 > "10"	c98a4e45332111e9bc29542696d6e445
qid1845	SELECT 企业名称 WHERE 生产日期/批号 == "2015-02" and 产品名称 == "WCDMA数字移动电话机"	aac6e9c73b0611e9b344f40f24344a08
qid1846	SELECT 企业名称 WHERE 生产日期/批号 == "2015-02" and 产品名称 == "WCDMA数字移动电话机"	aac6e9c73b0611e9b344f40f24344a08
qid1847	SELECT 企业名称 WHERE 生产日期/批号 == "2015-02" and 产品名称 == "WCDMA数字移动电话机"	aac6e9c73b0611e9b344f40f24344a08
qid1848	SELECT 企业名称 WHERE 产品名称 == "空气净化机"	a7b5f29c3b0611e9908bf40f24344a08
qid1849	SELECT 企业名称 WHERE 产品名称 == "空气净化机"	a7b5f29c3b0611e9908bf40f24344a08
qid1850	SELECT 企业名称 WHERE 产品名称 == "空气净化机"	a7b5f29c3b0611e9908bf40f24344a08
qid1851	SELECT COUNT ( 网站名称 ) WHERE 结果 == "合格"	f5be5838453d11e98932f40f24344a08
qid1852	SELECT COUNT ( 网站名称 ) WHERE 结果 == "合格"	f5be5838453d11e98932f40f24344a08
qid1853	SELECT COUNT ( 网站名称 ) WHERE 结果 == "合格"	f5be5838453d11e98932f40f24344a08
qid1854	SELECT 到期日期 WHERE 设备名称 == "蒸汽锅炉" and 规格型号 == "DHS30-1.25-Q"	f2776f23453d11e9833ef40f24344a08
qid1855	SELECT 到期日期 WHERE 设备名称 == "蒸汽锅炉" and 规格型号 == "DHS30-1.25-Q"	f2776f23453d11e9833ef40f24344a08
qid1856	SELECT 到期日期 WHERE 设备名称 == "蒸汽锅炉" and 规格型号 == "DHS30-1.25-Q"	f2776f23453d11e9833ef40f24344a08
qid1857	SELECT 发行公司 , 片长 WHERE 片名 == "女神跟我走"	f68c28fa453d11e98721f40f24344a08
qid1858	SELECT 发行公司 , 片长 WHERE 片名 == "女神跟我走"	f68c28fa453d11e98721f40f24344a08
qid1859	SELECT 发行公司 , 片长 WHERE 片名 == "女神跟我走"	f68c28fa453d11e98721f40f24344a08
qid1860	SELECT 食品名称 WHERE 标识生产企业名称 == "上海永安乳品有限公司"	a9652cc03b0611e9966af40f24344a08
qid1861	SELECT 食品名称 WHERE 标识生产企业名称 == "上海永安乳品有限公司"	a9652cc03b0611e9966af40f24344a08
qid1862	SELECT 服务对象及所需提交证明材料 WHERE 服务地点 == "乡镇卫生院、社区卫生服务机构" and 服务项目 == "儿童健康管理"	ab8995703b0611e9a764f40f24344a08
qid1863	SELECT 服务对象及所需提交证明材料 WHERE 服务地点 == "乡镇卫生院、社区卫生服务机构" and 服务项目 == "儿童健康管理"	ab8995703b0611e9a764f40f24344a08
qid1864	SELECT 书名 WHERE ISBN == "9.78755815139e+12" or ISBN == "9.78754883418e+12"	a82b86c53b0611e99591f40f24344a08
qid1865	SELECT 书名 WHERE ISBN == "9.78755815139e+12" or ISBN == "9.78754883418e+12"	a82b86c53b0611e99591f40f24344a08
qid1866	SELECT 书名 WHERE ISBN == "9.78755815139e+12" or ISBN == "9.78754883418e+12"	a82b86c53b0611e99591f40f24344a08
qid1867	SELECT 食品名称 WHERE 标称生产企业地址 == "龙口市北马镇唐家泊村" and 标称生产企业名称 == "龙口市照龙粉丝有限公司"	aac1213a3b0611e98715f40f24344a08
qid1868	SELECT 食品名称 WHERE 标称生产企业地址 == "龙口市北马镇唐家泊村" and 标称生产企业名称 == "龙口市照龙粉丝有限公司"	aac1213a3b0611e98715f40f24344a08
qid1869	SELECT 食品名称 WHERE 标称生产企业地址 == "龙口市北马镇唐家泊村" and 标称生产企业名称 == "龙口市照龙粉丝有限公司"	aac1213a3b0611e98715f40f24344a08
qid1870	SELECT SUM ( 招聘人数 ) WHERE 岗位名称 == "麻醉科医师" or 岗位名称 == "口腔科医师"	f68a6acf453d11e9a7a5f40f24344a08
qid1871	SELECT SUM ( 招聘人数 ) WHERE 岗位名称 == "麻醉科医师" or 岗位名称 == "口腔科医师"	f68a6acf453d11e9a7a5f40f24344a08
qid1872	SELECT SUM ( 招聘人数 ) WHERE 岗位名称 == "麻醉科医师" or 岗位名称 == "口腔科医师"	f68a6acf453d11e9a7a5f40f24344a08
qid1873	SELECT 招聘人数 WHERE 院部名称 == "软件学院" and 招聘岗位 == "专职教师"	aad1a8853b0611e9be4bf40f24344a08
qid1874	SELECT 招聘人数 WHERE 院部名称 == "软件学院" and 招聘岗位 == "专职教师"	aad1a8853b0611e9be4bf40f24344a08
qid1875	SELECT 招聘人数 WHERE 院部名称 == "软件学院" and 招聘岗位 == "专职教师"	aad1a8853b0611e9be4bf40f24344a08
qid1876	SELECT 招聘人数（人） WHERE 主管部门 == "滦县卫计局" and 招聘岗位名称 == "专技岗位D"	aa1075753b0611e9b445f40f24344a08
qid1877	SELECT 招聘人数（人） WHERE 主管部门 == "滦县卫计局" and 招聘岗位名称 == "专技岗位D"	aa1075753b0611e9b445f40f24344a08
qid1878	SELECT 招聘人数（人） WHERE 主管部门 == "滦县卫计局" and 招聘岗位名称 == "专技岗位D"	aa1075753b0611e9b445f40f24344a08
qid1879	SELECT 企业名称 , 产品名称 WHERE 抽查结果 == "不合格" and 承检机构 == "国家电子信息产品质量监督检验中心"	f6a283c0453d11e99c89f40f24344a08
qid1880	SELECT 企业名称 , 产品名称 WHERE 抽查结果 == "不合格" and 承检机构 == "国家电子信息产品质量监督检验中心"	f6a283c0453d11e99c89f40f24344a08
qid1881	SELECT 企业名称 , 产品名称 WHERE 抽查结果 == "不合格" and 承检机构 == "国家电子信息产品质量监督检验中心"	f6a283c0453d11e99c89f40f24344a08
qid1882	SELECT 学科门类 WHERE 专业名称 == "电子信息工程" or 专业名称 == "通信工程"	f1eeb43d453d11e98a6ff40f24344a08
qid1883	SELECT 学科门类 WHERE 专业名称 == "电子信息工程" or 专业名称 == "通信工程"	f1eeb43d453d11e98a6ff40f24344a08
qid1884	SELECT 学科门类 WHERE 专业名称 == "电子信息工程" or 专业名称 == "通信工程"	f1eeb43d453d11e98a6ff40f24344a08
qid1885	SELECT 作者 WHERE 书名 == "十一种孤独"	f00c5305453d11e9af23f40f24344a08
qid1886	SELECT 作者 WHERE 书名 == "十一种孤独"	f00c5305453d11e9af23f40f24344a08
qid1887	SELECT 作者 WHERE 书名 == "十一种孤独"	f00c5305453d11e9af23f40f24344a08
qid1888	SELECT 专业 WHERE 部门 == "演出团" and 岗位 == "京剧伴奏"	a94cc2663b0611e98fdbf40f24344a08
qid1889	SELECT 专业 WHERE 部门 == "演出团" and 岗位 == "京剧伴奏"	a94cc2663b0611e98fdbf40f24344a08
qid1890	SELECT 专业 WHERE 部门 == "演出团" and 岗位 == "京剧伴奏"	a94cc2663b0611e98fdbf40f24344a08
qid1891	SELECT 生产日期/批号 WHERE 食品名称 == "全鲜乳"	f5bad74f453d11e99311f40f24344a08
qid1892	SELECT 生产日期/批号 WHERE 食品名称 == "全鲜乳"	f5bad74f453d11e99311f40f24344a08
qid1893	SELECT 生产日期/批号 WHERE 食品名称 == "全鲜乳"	f5bad74f453d11e99311f40f24344a08
qid1894	SELECT 文献条码号 WHERE 书名 == "走读胡适"	ee7df491453d11e99867f40f24344a08
qid1895	SELECT 文献条码号 WHERE 书名 == "走读胡适"	ee7df491453d11e99867f40f24344a08
qid1896	SELECT 文献条码号 WHERE 书名 == "走读胡适"	ee7df491453d11e99867f40f24344a08
qid1897	SELECT 集数 WHERE 剧名 == "铁旗门"	f10c11eb453d11e9a907f40f24344a08
qid1898	SELECT 集数 WHERE 剧名 == "铁旗门"	f10c11eb453d11e9a907f40f24344a08
qid1899	SELECT 专业 , 学历 WHERE 职位名称 == "音乐教师"	f6e0875e453d11e984d3f40f24344a08
qid1900	SELECT 专业 , 学历 WHERE 职位名称 == "音乐教师"	f6e0875e453d11e984d3f40f24344a08
qid1901	SELECT 专业 , 学历 WHERE 职位名称 == "音乐教师"	f6e0875e453d11e984d3f40f24344a08
qid1902	SELECT 开放时间 WHERE 区县 == "黄浦" and 博物馆 == "上海博物馆"	ab8a242e3b0611e98972f40f24344a08
qid1903	SELECT 开放时间 WHERE 区县 == "黄浦" and 博物馆 == "上海博物馆"	ab8a242e3b0611e98972f40f24344a08
qid1904	SELECT 开放时间 WHERE 区县 == "黄浦" and 博物馆 == "上海博物馆"	ab8a242e3b0611e98972f40f24344a08
qid1905	SELECT 货币中文名称 WHERE 国别 == "阿富汗"	f107ce66453d11e9ac3ff40f24344a08
qid1906	SELECT 货币中文名称 WHERE 国别 == "阿富汗"	f107ce66453d11e9ac3ff40f24344a08
qid1907	SELECT 货币中文名称 WHERE 国别 == "阿富汗"	f107ce66453d11e9ac3ff40f24344a08
qid1908	SELECT 报考单位 , 岗位 WHERE 入围面试人数 > "0"	f3bbfd87453d11e99c51f40f24344a08
qid1909	SELECT 报考单位 , 岗位 WHERE 入围面试人数 > "0"	f3bbfd87453d11e99c51f40f24344a08
qid1910	SELECT 报考单位 , 岗位 WHERE 入围面试人数 > "0"	f3bbfd87453d11e99c51f40f24344a08
qid1911	SELECT 索书号 WHERE 书名 == "日本的众神" or 书名 == "大雨将至"	ee33fe2e453d11e9b45ef40f24344a08
qid1912	SELECT 索书号 WHERE 书名 == "日本的众神" or 书名 == "大雨将至"	ee33fe2e453d11e9b45ef40f24344a08
qid1913	SELECT 索书号 WHERE 书名 == "日本的众神" or 书名 == "大雨将至"	ee33fe2e453d11e9b45ef40f24344a08
qid1914	SELECT 型号规格 WHERE 生产日期或批号 == "2014-11-13/20141113001" and 产品名称 == "水性金属面漆"	a8c726383b0611e980d2f40f24344a08
qid1915	SELECT 型号规格 WHERE 生产日期或批号 == "2014-11-13/20141113001" and 产品名称 == "水性金属面漆"	a8c726383b0611e980d2f40f24344a08
qid1916	SELECT 型号规格 WHERE 生产日期或批号 == "2014-11-13/20141113001" and 产品名称 == "水性金属面漆"	a8c726383b0611e980d2f40f24344a08
qid1917	SELECT 报考学历 , 专业要求 WHERE 岗位名称 == "全科医生"	f10b6b0c453d11e98d92f40f24344a08
qid1918	SELECT 报考学历 , 专业要求 WHERE 岗位名称 == "全科医生"	f10b6b0c453d11e98d92f40f24344a08
qid1919	SELECT 报考学历 , 专业要求 WHERE 岗位名称 == "全科医生"	f10b6b0c453d11e98d92f40f24344a08
qid1920	SELECT COUNT ( 企业名称 ) WHERE 抽查结果 == "合格" and 产品名称 == "沙发"	f4bac6d9453d11e9a692f40f24344a08
qid1921	SELECT COUNT ( 企业名称 ) WHERE 抽查结果 == "合格" and 产品名称 == "沙发"	f4bac6d9453d11e9a692f40f24344a08
qid1922	SELECT COUNT ( 企业名称 ) WHERE 抽查结果 == "合格" and 产品名称 == "沙发"	f4bac6d9453d11e9a692f40f24344a08
qid1923	SELECT 课程名称 WHERE 时间 == "2010年3月1日至5日" and 培训地点 == "虹桥机场中货航大楼"	f53e5cdc453d11e9ab43f40f24344a08
qid1924	SELECT 课程名称 WHERE 时间 == "2010年3月1日至5日" and 培训地点 == "虹桥机场中货航大楼"	f53e5cdc453d11e9ab43f40f24344a08
qid1925	SELECT 课程名称 WHERE 时间 == "2010年3月1日至5日" and 培训地点 == "虹桥机场中货航大楼"	f53e5cdc453d11e9ab43f40f24344a08
qid1926	SELECT 集数 WHERE 剧名 == "延禧攻略"	f4748b78453d11e98518f40f24344a08
qid1927	SELECT 集数 WHERE 剧名 == "延禧攻略"	f4748b78453d11e98518f40f24344a08
qid1928	SELECT 集数 WHERE 剧名 == "延禧攻略"	f4748b78453d11e98518f40f24344a08
qid1929	SELECT 不合格项目 WHERE 商标 == "容声" and 产品名称 == "厨下式RO机"	ef33af54453d11e9b28ff40f24344a08
qid1930	SELECT 不合格项目 WHERE 商标 == "容声" and 产品名称 == "厨下式RO机"	ef33af54453d11e9b28ff40f24344a08
qid1931	SELECT 不合格项目 WHERE 商标 == "容声" and 产品名称 == "厨下式RO机"	ef33af54453d11e9b28ff40f24344a08
qid1932	SELECT 资料名称 WHERE 密级 == "机密"	a81a797d3b0611e99ae9f40f24344a08
qid1933	SELECT 资料名称 WHERE 密级 == "机密"	a81a797d3b0611e99ae9f40f24344a08
qid1934	SELECT 拟聘职务 WHERE 专业领域 == "美学专业" or 年龄要求 == "35以下"	f0a00fb0453d11e9accaf40f24344a08
qid1935	SELECT 拟聘职务 WHERE 专业领域 == "美学专业" or 年龄要求 == "35以下"	f0a00fb0453d11e9accaf40f24344a08
qid1936	SELECT 拟聘职务 WHERE 专业领域 == "美学专业" or 年龄要求 == "35以下"	f0a00fb0453d11e9accaf40f24344a08
qid1937	SELECT 药类 WHERE 症别 == "肠胃" and 病状 == "重腹泻"	f63f36ee453d11e9ae21f40f24344a08
qid1938	SELECT 药类 WHERE 症别 == "肠胃" and 病状 == "重腹泻"	f63f36ee453d11e9ae21f40f24344a08
qid1939	SELECT 药类 WHERE 症别 == "肠胃" and 病状 == "重腹泻"	f63f36ee453d11e9ae21f40f24344a08
qid1940	SELECT 专家审核未通过及原因 WHERE 省份 == "广东" and 企业名称 == "广东茂名绿银农化有限公司"	a888794c3b0611e99e50f40f24344a08
qid1941	SELECT 专家审核未通过及原因 WHERE 省份 == "广东" and 企业名称 == "广东茂名绿银农化有限公司"	a888794c3b0611e99e50f40f24344a08
qid1942	SELECT 专家审核未通过及原因 WHERE 省份 == "广东" and 企业名称 == "广东茂名绿银农化有限公司"	a888794c3b0611e99e50f40f24344a08
qid1943	SELECT 数量 WHERE 商品名称 == "吉他" and 单位 == "把"	f4e094e3453d11e984ddf40f24344a08
qid1944	SELECT 数量 WHERE 商品名称 == "吉他" and 单位 == "把"	f4e094e3453d11e984ddf40f24344a08
qid1945	SELECT 数量 WHERE 商品名称 == "吉他" and 单位 == "把"	f4e094e3453d11e984ddf40f24344a08
qid1946	SELECT *数量 , 定价 WHERE 书名 == "我为什么还是很忧郁？"	abae65c03b0611e993c1f40f24344a08
qid1947	SELECT *数量 , 定价 WHERE 书名 == "我为什么还是很忧郁？"	abae65c03b0611e993c1f40f24344a08
qid1948	SELECT *数量 , 定价 WHERE 书名 == "我为什么还是很忧郁？"	abae65c03b0611e993c1f40f24344a08
qid1949	SELECT 标示生产单位名称 WHERE 生产/加工/购进日期 == "20180203" and 食品通用名 == "香爆脆香烤猪排味干脆面"	eec8ee59453d11e98ea6f40f24344a08
qid1950	SELECT 标示生产单位名称 WHERE 生产/加工/购进日期 == "20180203" and 食品通用名 == "香爆脆香烤猪排味干脆面"	eec8ee59453d11e98ea6f40f24344a08
qid1951	SELECT 课题 , 班级 WHERE 奖项 == "一等奖"	a8366b2b3b0611e9b0d1f40f24344a08
qid1952	SELECT 课题 , 班级 WHERE 奖项 == "一等奖"	a8366b2b3b0611e9b0d1f40f24344a08
qid1953	SELECT 课题 , 班级 WHERE 奖项 == "一等奖"	a8366b2b3b0611e9b0d1f40f24344a08
qid1954	SELECT 页码 WHERE 书名 == "珠算长青"	a7baefae3b0611e9a879f40f24344a08
qid1955	SELECT 页码 WHERE 书名 == "珠算长青"	a7baefae3b0611e9a879f40f24344a08
qid1956	SELECT 页码 WHERE 书名 == "珠算长青"	a7baefae3b0611e9a879f40f24344a08
qid1957	SELECT 著作名称 , 撰写字数 WHERE 出版单位 == "石油工业出版社"	efd35aeb453d11e9a88cf40f24344a08
qid1958	SELECT 著作名称 , 撰写字数 WHERE 出版单位 == "石油工业出版社"	efd35aeb453d11e9a88cf40f24344a08
qid1959	SELECT 著作名称 , 撰写字数 WHERE 出版单位 == "石油工业出版社"	efd35aeb453d11e9a88cf40f24344a08
qid1960	SELECT 发表/出版时间 WHERE 论文题目 == "TheRegisterRestraintonCharactoristicsinChineseText"	a847a1cc3b0611e9831ef40f24344a08
qid1961	SELECT 发表/出版时间 WHERE 论文题目 == "TheRegisterRestraintonCharactoristicsinChineseText"	a847a1cc3b0611e9831ef40f24344a08
qid1962	SELECT 发表/出版时间 WHERE 论文题目 == "TheRegisterRestraintonCharactoristicsinChineseText"	a847a1cc3b0611e9831ef40f24344a08
qid1963	SELECT 商品名称 WHERE 商品条码 == "4026600176" or 商品代码 == "4027400264"	f5a8c8ee453d11e9bcdef40f24344a08
qid1964	SELECT 商品名称 WHERE 商品条码 == "4026600176" or 商品代码 == "4027400264"	f5a8c8ee453d11e9bcdef40f24344a08
qid1965	SELECT 商品名称 WHERE 商品条码 == "4026600176" or 商品代码 == "4027400264"	f5a8c8ee453d11e9bcdef40f24344a08
qid1966	SELECT 出版社 WHERE 作者笔名 == "叶檀" and 授权书名 == "拿什么拯救中国经济？"	ee6c50c7453d11e9b32ff40f24344a08
qid1967	SELECT 出版社 WHERE 作者笔名 == "叶檀" and 授权书名 == "拿什么拯救中国经济？"	ee6c50c7453d11e9b32ff40f24344a08
qid1968	SELECT 出版社 WHERE 作者笔名 == "叶檀" and 授权书名 == "拿什么拯救中国经济？"	ee6c50c7453d11e9b32ff40f24344a08
qid1969	SELECT 出版社 WHERE 作者 == "孙秋菊" and 书名 == "现代物流概论"	ed6289c2453d11e99d33f40f24344a08
qid1970	SELECT 出版社 WHERE 作者 == "孙秋菊" and 书名 == "现代物流概论"	ed6289c2453d11e99d33f40f24344a08
qid1971	SELECT 出版社 WHERE 作者 == "孙秋菊" and 书名 == "现代物流概论"	ed6289c2453d11e99d33f40f24344a08
qid1972	SELECT 作者 WHERE 书名 == "山枣红了" or 书名 == "时间机器"	a7e0e4fd3b0611e9971ef40f24344a08
qid1973	SELECT 作者 WHERE 书名 == "山枣红了" or 书名 == "时间机器"	a7e0e4fd3b0611e9971ef40f24344a08
qid1974	SELECT 作者 WHERE 书名 == "山枣红了" or 书名 == "时间机器"	a7e0e4fd3b0611e9971ef40f24344a08
qid1975	SELECT 总录取人数 WHERE 学院名称 == "地学院" and 专业名称 == "地球物理学"	a9bb55143b0611e9aaeaf40f24344a08
qid1976	SELECT 总录取人数 WHERE 学院名称 == "地学院" and 专业名称 == "地球物理学"	a9bb55143b0611e9aaeaf40f24344a08
qid1977	SELECT 总录取人数 WHERE 学院名称 == "地学院" and 专业名称 == "地球物理学"	a9bb55143b0611e9aaeaf40f24344a08
qid1978	SELECT 地址 WHERE 主办网点名称 == "工商银行福清福塘支行"	ed4b5494453d11e9b3c5f40f24344a08
qid1979	SELECT 地址 WHERE 主办网点名称 == "工商银行福清福塘支行"	ed4b5494453d11e9b3c5f40f24344a08
qid1980	SELECT 岗位名称 WHERE 学历 == "本科" and 人数 > "20"	abbf13ab3b0611e9a6d1f40f24344a08
qid1981	SELECT 岗位名称 WHERE 学历 == "本科" and 人数 > "20"	abbf13ab3b0611e9a6d1f40f24344a08
qid1982	SELECT 岗位名称 WHERE 学历 == "本科" and 人数 > "20"	abbf13ab3b0611e9a6d1f40f24344a08
qid1983	SELECT 学费标准（元/学年） WHERE 专业名称（新目录） == "护理"	f533fc6b453d11e98142f40f24344a08
qid1984	SELECT 学费标准（元/学年） WHERE 专业名称（新目录） == "护理"	f533fc6b453d11e98142f40f24344a08
qid1985	SELECT 学费标准（元/学年） WHERE 专业名称（新目录） == "护理"	f533fc6b453d11e98142f40f24344a08
qid1986	SELECT 第一作者 , 出版社名称 WHERE 书名（正书名） == "沽婚"	a7d039543b0611e98893f40f24344a08
qid1987	SELECT 第一作者 , 出版社名称 WHERE 书名（正书名） == "沽婚"	a7d039543b0611e98893f40f24344a08
qid1988	SELECT 第一作者 , 出版社名称 WHERE 书名（正书名） == "沽婚"	a7d039543b0611e98893f40f24344a08
qid1989	SELECT 书名 , 业务分类 WHERE 估定价 > "50"	a80607c73b0611e9a7e6f40f24344a08
qid1990	SELECT 书名 , 业务分类 WHERE 估定价 > "50"	a80607c73b0611e9a7e6f40f24344a08
qid1991	SELECT 书名 , 业务分类 WHERE 估定价 > "50"	a80607c73b0611e9a7e6f40f24344a08
qid1992	SELECT ISBN WHERE 题名 == "近思录"	a8cb308c3b0611e983bcf40f24344a08
qid1993	SELECT ISBN WHERE 题名 == "近思录"	a8cb308c3b0611e983bcf40f24344a08
qid1994	SELECT ISBN WHERE 题名 == "近思录"	a8cb308c3b0611e983bcf40f24344a08
qid1995	SELECT 产品名称 WHERE 企业名称 == "深圳市东琛电器实业有限公司" and 生产日期/批号 == "2014-05"	a81b3c353b0611e9a666f40f24344a08
qid1996	SELECT 产品名称 WHERE 企业名称 == "深圳市东琛电器实业有限公司" and 生产日期/批号 == "2014-05"	a81b3c353b0611e9a666f40f24344a08
qid1997	SELECT 产品名称 WHERE 企业名称 == "深圳市东琛电器实业有限公司" and 生产日期/批号 == "2014-05"	a81b3c353b0611e9a666f40f24344a08
qid1998	SELECT 规格型号 WHERE 被抽样单位名称 == "上海长发购物中心有限公司" or 被抽样单位所在省份 == "上海市"	a7dad8453b0611e9bc69f40f24344a08
qid1999	SELECT 规格型号 WHERE 被抽样单位名称 == "上海长发购物中心有限公司" or 被抽样单位所在省份 == "上海市"	a7dad8453b0611e9bc69f40f24344a08
qid2000	SELECT 规格型号 WHERE 被抽样单位名称 == "上海长发购物中心有限公司" or 被抽样单位所在省份 == "上海市"	a7dad8453b0611e9bc69f40f24344a08
qid2001	SELECT 题名 WHERE 出版社 == "东方出版社"	aaa142d73b0611e9bbd2f40f24344a08
qid2002	SELECT 题名 WHERE 出版社 == "东方出版社"	aaa142d73b0611e9bbd2f40f24344a08
qid2003	SELECT 题名 WHERE 出版社 == "东方出版社"	aaa142d73b0611e9bbd2f40f24344a08
qid2004	SELECT 出版年月 WHERE 书名 == "装修水电工简明实用手册"	ab6593f33b0611e980d5f40f24344a08
qid2005	SELECT 出版年月 WHERE 书名 == "装修水电工简明实用手册"	ab6593f33b0611e980d5f40f24344a08
qid2006	SELECT 出版年月 WHERE 书名 == "装修水电工简明实用手册"	ab6593f33b0611e980d5f40f24344a08
qid2007	SELECT 作者 WHERE ISBN == "978-7-03-053742-3" or ISBN == "978-7-03-053743-0"	aa784a973b0611e99e9df40f24344a08
qid2008	SELECT 作者 WHERE ISBN == "978-7-03-053742-3" or ISBN == "978-7-03-053743-0"	aa784a973b0611e99e9df40f24344a08
qid2009	SELECT 作者 WHERE ISBN == "978-7-03-053742-3" or ISBN == "978-7-03-053743-0"	aa784a973b0611e99e9df40f24344a08
qid2010	SELECT 人数 WHERE 用人单位 == "综合材料生态处置中心" and 岗位 == "安全员"	f48016fd453d11e9a1adf40f24344a08
qid2011	SELECT 人数 WHERE 用人单位 == "综合材料生态处置中心" and 岗位 == "安全员"	f48016fd453d11e9a1adf40f24344a08
qid2012	SELECT 人数 WHERE 用人单位 == "综合材料生态处置中心" and 岗位 == "安全员"	f48016fd453d11e9a1adf40f24344a08
qid2013	SELECT 食品名称 WHERE 标称生产企业名称 == "海南禾日香食品有限公司" and 生产日期/批号 == "2017-07-01"	ef3af9e6453d11e99796f40f24344a08
qid2014	SELECT 食品名称 WHERE 标称生产企业名称 == "海南禾日香食品有限公司" and 生产日期/批号 == "2017-07-01"	ef3af9e6453d11e99796f40f24344a08
qid2015	SELECT 食品名称 WHERE 标称生产企业名称 == "海南禾日香食品有限公司" and 生产日期/批号 == "2017-07-01"	ef3af9e6453d11e99796f40f24344a08
qid2016	SELECT 抽查时间 WHERE 被抽查单位 == "佛山市高明高森木业有限公司" and 被抽查产品名称 == "普通型中密度纤维板MDF-GPREG"	f5563687453d11e9b586f40f24344a08
qid2017	SELECT 抽查时间 WHERE 被抽查单位 == "佛山市高明高森木业有限公司" and 被抽查产品名称 == "普通型中密度纤维板MDF-GPREG"	f5563687453d11e9b586f40f24344a08
qid2018	SELECT 抽查时间 WHERE 被抽查单位 == "佛山市高明高森木业有限公司" and 被抽查产品名称 == "普通型中密度纤维板MDF-GPREG"	f5563687453d11e9b586f40f24344a08
qid2019	SELECT 作者 WHERE 书名 == "派出所长" and 分类 == "长篇小说"	f46b406b453d11e9b8c5f40f24344a08
qid2020	SELECT 作者 WHERE 书名 == "派出所长" and 分类 == "长篇小说"	f46b406b453d11e9b8c5f40f24344a08
qid2021	SELECT 作者 WHERE 书名 == "派出所长" and 分类 == "长篇小说"	f46b406b453d11e9b8c5f40f24344a08
qid2022	SELECT 队名 WHERE 队长 == "唐彦卫" or 队长 == "范红杰"	ed100621453d11e9aae6f40f24344a08
qid2023	SELECT 队名 WHERE 队长 == "唐彦卫" or 队长 == "范红杰"	ed100621453d11e9aae6f40f24344a08
qid2024	SELECT 队名 WHERE 队长 == "唐彦卫" or 队长 == "范红杰"	ed100621453d11e9aae6f40f24344a08
qid2025	SELECT 岗位名称 WHERE 专业要求 == "临床医学" or 最低学历 == "全日制大专"	a8794cc53b0611e9b7def40f24344a08
qid2026	SELECT 岗位名称 WHERE 专业要求 == "临床医学" or 最低学历 == "全日制大专"	a8794cc53b0611e9b7def40f24344a08
qid2027	SELECT 岗位名称 WHERE 专业要求 == "临床医学" or 最低学历 == "全日制大专"	a8794cc53b0611e9b7def40f24344a08
qid2028	SELECT COUNT ( 课程名称 ) WHERE 授课对象 == "法学博士"	aaadf20f3b0611e9a857f40f24344a08
qid2029	SELECT COUNT ( 课程名称 ) WHERE 授课对象 == "法学博士"	aaadf20f3b0611e9a857f40f24344a08
qid2030	SELECT COUNT ( 课程名称 ) WHERE 授课对象 == "法学博士"	aaadf20f3b0611e9a857f40f24344a08
qid2031	SELECT 作者 WHERE 题名 == "中国改革开放30年" or 题名 == "两种改革开放观"	ab46ee8c3b0611e9a0dbf40f24344a08
qid2032	SELECT 作者 WHERE 题名 == "中国改革开放30年" or 题名 == "两种改革开放观"	ab46ee8c3b0611e9a0dbf40f24344a08
qid2033	SELECT 作者 WHERE 题名 == "中国改革开放30年" or 题名 == "两种改革开放观"	ab46ee8c3b0611e9a0dbf40f24344a08
qid2034	SELECT 专业 WHERE 学分 > "2" and 理论学时 > "32" and 计划学期 > "5"	a812e5873b0611e98060f40f24344a08
qid2035	SELECT 专业 WHERE 学分 > "2" and 理论学时 > "32" and 计划学期 > "5"	a812e5873b0611e98060f40f24344a08
qid2036	SELECT 专业 WHERE 学分 > "2" and 理论学时 > "32" and 计划学期 > "5"	a812e5873b0611e98060f40f24344a08
qid2037	SELECT 日期 , 时间 WHERE 活动内容 == "动漫游戏与技术展示会"	a9fb33b53b0611e99e07f40f24344a08
qid2038	SELECT 日期 , 时间 WHERE 活动内容 == "动漫游戏与技术展示会"	a9fb33b53b0611e99e07f40f24344a08
qid2039	SELECT 日期 , 时间 WHERE 活动内容 == "动漫游戏与技术展示会"	a9fb33b53b0611e99e07f40f24344a08
qid2040	SELECT 其中免试人数 WHERE 院系 == "哲学系" and 专业 == "马克思主义哲学"	f69daf75453d11e9abe0f40f24344a08
qid2041	SELECT 其中免试人数 WHERE 院系 == "哲学系" and 专业 == "马克思主义哲学"	f69daf75453d11e9abe0f40f24344a08
qid2042	SELECT 项目名称 WHERE 批复经费 > "500"	aaf3b4ee3b0611e9a74cf40f24344a08
qid2043	SELECT 项目名称 WHERE 批复经费 > "500"	aaf3b4ee3b0611e9a74cf40f24344a08
qid2044	SELECT 项目名称 WHERE 批复经费 > "500"	aaf3b4ee3b0611e9a74cf40f24344a08
qid2045	SELECT 书名 WHERE 出版社 == "山东文艺出版社"	a97453573b0611e9a363f40f24344a08
qid2046	SELECT 书名 WHERE 出版社 == "山东文艺出版社"	a97453573b0611e9a363f40f24344a08
qid2047	SELECT 书名 WHERE 出版社 == "山东文艺出版社"	a97453573b0611e9a363f40f24344a08
qid2048	SELECT 学分 WHERE 课程名 == "城镇景观设计" or 课程名 == "高低压电器"	ef5f0cb5453d11e9bc98f40f24344a08
qid2049	SELECT 学分 WHERE 课程名 == "城镇景观设计" or 课程名 == "高低压电器"	ef5f0cb5453d11e9bc98f40f24344a08
qid2050	SELECT 学分 WHERE 课程名 == "城镇景观设计" or 课程名 == "高低压电器"	ef5f0cb5453d11e9bc98f40f24344a08
qid2051	SELECT 商户名称 , 商户地址 WHERE 国家/地区 == "香港"	aa2288c53b0611e9800af40f24344a08
qid2052	SELECT 商户名称 , 商户地址 WHERE 国家/地区 == "香港"	aa2288c53b0611e9800af40f24344a08
qid2053	SELECT 商户名称 , 商户地址 WHERE 国家/地区 == "香港"	aa2288c53b0611e9800af40f24344a08
qid2054	SELECT 枚数 WHERE 邮票名称 == "拜年"	a885dc003b0611e98b51f40f24344a08
qid2055	SELECT 枚数 WHERE 邮票名称 == "拜年"	a885dc003b0611e98b51f40f24344a08
qid2056	SELECT 过刊截止年 WHERE ISSN == "0002-0729" or eISSN == "1741-7260"	a9ad32b83b0611e99b45f40f24344a08
qid2057	SELECT 过刊截止年 WHERE ISSN == "0002-0729" or eISSN == "1741-7260"	a9ad32b83b0611e99b45f40f24344a08
qid2058	SELECT 过刊截止年 WHERE ISSN == "0002-0729" or eISSN == "1741-7260"	a9ad32b83b0611e99b45f40f24344a08
qid2059	SELECT 作品名称 , 作者 WHERE 奖项 == "一等奖"	a7d146303b0611e9af65f40f24344a08
qid2060	SELECT 作品名称 , 作者 WHERE 奖项 == "一等奖"	a7d146303b0611e9af65f40f24344a08
qid2061	SELECT 作品名称 , 作者 WHERE 奖项 == "一等奖"	a7d146303b0611e9af65f40f24344a08
qid2062	SELECT COUNT ( 项目名称 ) WHERE 编码 == "120400002*2X" or 备案价格（元） > "30"	aa22d7c03b0611e98476f40f24344a08
qid2063	SELECT COUNT ( 项目名称 ) WHERE 编码 == "120400002*2X" or 备案价格（元） > "30"	aa22d7c03b0611e98476f40f24344a08
qid2064	SELECT COUNT ( 项目名称 ) WHERE 编码 == "120400002*2X" or 备案价格（元） > "30"	aa22d7c03b0611e98476f40f24344a08
qid2065	SELECT 计算公式 WHERE 图形名称 == "弓形" and 名称 == "弦长（c）"	f636a48f453d11e9a22bf40f24344a08
qid2066	SELECT 计算公式 WHERE 图形名称 == "弓形" and 名称 == "弦长（c）"	f636a48f453d11e9a22bf40f24344a08
qid2067	SELECT 计算公式 WHERE 图形名称 == "弓形" and 名称 == "弦长（c）"	f636a48f453d11e9a22bf40f24344a08
qid2068	SELECT 店铺地址 WHERE 城市 == "广州" and 店名 == "东海堂机场店"	f466756b453d11e99540f40f24344a08
qid2069	SELECT 店铺地址 WHERE 城市 == "广州" and 店名 == "东海堂机场店"	f466756b453d11e99540f40f24344a08
qid2070	SELECT 店铺地址 WHERE 城市 == "广州" and 店名 == "东海堂机场店"	f466756b453d11e99540f40f24344a08
qid2071	SELECT COUNT ( 职位名称 ) WHERE 是否组织专业考试 == "是" and 部门名称 == "中央办公厅"	f1d81b14453d11e980ebf40f24344a08
qid2072	SELECT COUNT ( 职位名称 ) WHERE 是否组织专业考试 == "是" and 部门名称 == "中央办公厅"	f1d81b14453d11e980ebf40f24344a08
qid2073	SELECT COUNT ( 职位名称 ) WHERE 是否组织专业考试 == "是" and 部门名称 == "中央办公厅"	f1d81b14453d11e980ebf40f24344a08
qid2074	SELECT 项目名称 , 试验示范站（基地） WHERE 依托单位 == "农学院"	a8aff1173b0611e9bbb1f40f24344a08
qid2075	SELECT 项目名称 , 试验示范站（基地） WHERE 依托单位 == "农学院"	a8aff1173b0611e9bbb1f40f24344a08
qid2076	SELECT 项目名称 , 试验示范站（基地） WHERE 依托单位 == "农学院"	a8aff1173b0611e9bbb1f40f24344a08
qid2077	SELECT 招聘数量 WHERE 用人单位 == "三峡碧江公司" and 招聘岗位 == "污水运行工"	a7b5108c3b0611e98ad7f40f24344a08
qid2078	SELECT 招聘数量 WHERE 用人单位 == "三峡碧江公司" and 招聘岗位 == "污水运行工"	a7b5108c3b0611e98ad7f40f24344a08
qid2079	SELECT 招聘数量 WHERE 用人单位 == "三峡碧江公司" and 招聘岗位 == "污水运行工"	a7b5108c3b0611e98ad7f40f24344a08
qid2080	SELECT 出版社 WHERE 著作名称 == "清物十志：文人之物的意义世界" or 著作名称 == "刑事政策社会化"	a962e5453b0611e9950cf40f24344a08
qid2081	SELECT 出版社 WHERE 著作名称 == "清物十志：文人之物的意义世界" or 著作名称 == "刑事政策社会化"	a962e5453b0611e9950cf40f24344a08
qid2082	SELECT 出版社 WHERE 著作名称 == "清物十志：文人之物的意义世界" or 著作名称 == "刑事政策社会化"	a962e5453b0611e9950cf40f24344a08
qid2083	SELECT Publisher WHERE Author == "苑春鸣" and Title == "汉英经贸分类词典"	efc0e1c7453d11e99a81f40f24344a08
qid2084	SELECT Publisher WHERE Author == "苑春鸣" and Title == "汉英经贸分类词典"	efc0e1c7453d11e99a81f40f24344a08
qid2085	SELECT Publisher WHERE Author == "苑春鸣" and Title == "汉英经贸分类词典"	efc0e1c7453d11e99a81f40f24344a08
qid2086	SELECT 编号 WHERE 仪器名称及规格 == "打孔器" or 仪器名称及规格 == "仪器车"	eee80f91453d11e9a529f40f24344a08
qid2087	SELECT 编号 WHERE 仪器名称及规格 == "打孔器" or 仪器名称及规格 == "仪器车"	eee80f91453d11e9a529f40f24344a08
qid2088	SELECT 编号 WHERE 仪器名称及规格 == "打孔器" or 仪器名称及规格 == "仪器车"	eee80f91453d11e9a529f40f24344a08
qid2089	SELECT 所在地 WHERE 企业名称 == "谷实农牧集团股份有限公司" or 企业名称 == "林甸伊利乳业有限责任公司"	aaea1f233b0611e99e87f40f24344a08
qid2090	SELECT 所在地 WHERE 企业名称 == "谷实农牧集团股份有限公司" or 企业名称 == "林甸伊利乳业有限责任公司"	aaea1f233b0611e99e87f40f24344a08
qid2091	SELECT 所在地 WHERE 企业名称 == "谷实农牧集团股份有限公司" or 企业名称 == "林甸伊利乳业有限责任公司"	aaea1f233b0611e99e87f40f24344a08
qid2092	SELECT 课程名称 WHERE 课程代码 == "02110081" or 课程代码 == "021E0010"	abb4f6f33b0611e9ace2f40f24344a08
qid2093	SELECT 课程名称 WHERE 课程代码 == "02110081" or 课程代码 == "021E0010"	abb4f6f33b0611e9ace2f40f24344a08
qid2094	SELECT 课程名称 WHERE 课程代码 == "02110081" or 课程代码 == "021E0010"	abb4f6f33b0611e9ace2f40f24344a08
qid2095	SELECT 道路名称 WHERE 长度(m) > "5000"	aa2487003b0611e99beff40f24344a08
qid2096	SELECT 道路名称 WHERE 长度(m) > "5000"	aa2487003b0611e99beff40f24344a08
qid2097	SELECT 岗位代码 WHERE 用人部门 == "作曲系" and 岗位名称 == "专任教师"	a8fba5e83b0611e9affaf40f24344a08
qid2098	SELECT 岗位代码 WHERE 用人部门 == "作曲系" and 岗位名称 == "专任教师"	a8fba5e83b0611e9affaf40f24344a08
qid2099	SELECT 岗位代码 WHERE 用人部门 == "作曲系" and 岗位名称 == "专任教师"	a8fba5e83b0611e9affaf40f24344a08
qid2100	SELECT 作者 , 书号（ISBN） WHERE 书名 == "钱学森传"	a9bc37053b0611e99da7f40f24344a08
qid2101	SELECT 作者 , 书号（ISBN） WHERE 书名 == "钱学森传"	a9bc37053b0611e99da7f40f24344a08
qid2102	SELECT 作者 , 书号（ISBN） WHERE 书名 == "钱学森传"	a9bc37053b0611e99da7f40f24344a08
qid2103	SELECT 剧名 , 集数 WHERE 发证机关 == "北京局"	f4748b78453d11e98518f40f24344a08
qid2104	SELECT 剧名 , 集数 WHERE 发证机关 == "北京局"	f4748b78453d11e98518f40f24344a08
qid2105	SELECT 剧名 , 集数 WHERE 发证机关 == "北京局"	f4748b78453d11e98518f40f24344a08
qid2106	SELECT 英文课程名 WHERE 课程名 == "《红楼梦》与中国文化" or 课程名 == "《计算机网络》课程设计"	abf42a993b0611e9be83f40f24344a08
qid2107	SELECT 英文课程名 WHERE 课程名 == "《红楼梦》与中国文化" or 课程名 == "《计算机网络》课程设计"	abf42a993b0611e9be83f40f24344a08
qid2108	SELECT 英文课程名 WHERE 课程名 == "《红楼梦》与中国文化" or 课程名 == "《计算机网络》课程设计"	abf42a993b0611e9be83f40f24344a08
qid2109	SELECT 出版社 WHERE 图书名称 == "月亮的味道"	ef3f5c28453d11e98595f40f24344a08
qid2110	SELECT 出版社 WHERE 图书名称 == "月亮的味道"	ef3f5c28453d11e98595f40f24344a08
qid2111	SELECT 出版社 WHERE 图书名称 == "月亮的味道"	ef3f5c28453d11e98595f40f24344a08
qid2112	SELECT 所在国家 WHERE 大学(中文名) == "耶鲁大学" or 大学(中文名) == "康奈尔大学"	a9482dc73b0611e99210f40f24344a08
qid2113	SELECT 所在国家 WHERE 大学(中文名) == "耶鲁大学" or 大学(中文名) == "康奈尔大学"	a9482dc73b0611e99210f40f24344a08
qid2114	SELECT 所在国家 WHERE 大学(中文名) == "耶鲁大学" or 大学(中文名) == "康奈尔大学"	a9482dc73b0611e99210f40f24344a08
qid2115	SELECT 推荐单位 WHERE 学校名称 == "安徽职业技术学院"	aa95d2333b0611e980a6f40f24344a08
qid2116	SELECT 推荐单位 WHERE 学校名称 == "安徽职业技术学院"	aa95d2333b0611e980a6f40f24344a08
qid2117	SELECT 推荐单位 WHERE 学校名称 == "安徽职业技术学院"	aa95d2333b0611e980a6f40f24344a08
qid2118	SELECT COUNT ( 动画名称 ) WHERE 频道名称 == "央视少儿频道" or 频道名称 == "BTV卡酷频道"	f40fcc07453d11e9aa2df40f24344a08
qid2119	SELECT COUNT ( 动画名称 ) WHERE 频道名称 == "央视少儿频道" or 频道名称 == "BTV卡酷频道"	f40fcc07453d11e9aa2df40f24344a08
qid2120	SELECT COUNT ( 动画名称 ) WHERE 频道名称 == "央视少儿频道" or 频道名称 == "BTV卡酷频道"	f40fcc07453d11e9aa2df40f24344a08
qid2121	SELECT 招聘岗位 WHERE 招聘单位 == "沂源县第一中学"	a920e2403b0611e99e82f40f24344a08
qid2122	SELECT 招聘岗位 WHERE 招聘单位 == "沂源县第一中学"	a920e2403b0611e99e82f40f24344a08
qid2123	SELECT 招聘岗位 WHERE 招聘单位 == "沂源县第一中学"	a920e2403b0611e99e82f40f24344a08
qid2124	SELECT 项目名称 , 项目负责人 WHERE 类别 == "国家级创新团队"	abf005f03b0611e99876f40f24344a08
qid2125	SELECT 项目名称 , 项目负责人 WHERE 类别 == "国家级创新团队"	abf005f03b0611e99876f40f24344a08
qid2126	SELECT 项目名称 , 项目负责人 WHERE 类别 == "国家级创新团队"	abf005f03b0611e99876f40f24344a08
qid2127	SELECT 规格型号 WHERE 企业名称 == "大连沃连特种油品有限公司" or 产品名称 == "46#抗磨液压油"	f4c9420a453d11e98018f40f24344a08
qid2128	SELECT 规格型号 WHERE 企业名称 == "大连沃连特种油品有限公司" or 产品名称 == "46#抗磨液压油"	f4c9420a453d11e98018f40f24344a08
qid2129	SELECT 规格型号 WHERE 企业名称 == "大连沃连特种油品有限公司" or 产品名称 == "46#抗磨液压油"	f4c9420a453d11e98018f40f24344a08
qid2130	SELECT 作者 WHERE 书名 == "早起魔法" or 书名 == "你为什么不道歉"	ab6593f33b0611e980d5f40f24344a08
qid2131	SELECT 作者 WHERE 书名 == "早起魔法" or 书名 == "你为什么不道歉"	ab6593f33b0611e980d5f40f24344a08
qid2132	SELECT 作者 WHERE 书名 == "早起魔法" or 书名 == "你为什么不道歉"	ab6593f33b0611e980d5f40f24344a08
qid2133	SELECT 人数 WHERE 招聘单位 == "浙江工商大学" and 岗位名称 == "专任教师" and 专业或学科方向 == "经济学类"	a94c536b3b0611e9b701f40f24344a08
qid2134	SELECT 人数 WHERE 招聘单位 == "浙江工商大学" and 岗位名称 == "专任教师" and 专业或学科方向 == "经济学类"	a94c536b3b0611e9b701f40f24344a08
qid2135	SELECT 人数 WHERE 招聘单位 == "浙江工商大学" and 岗位名称 == "专任教师" and 专业或学科方向 == "经济学类"	a94c536b3b0611e9b701f40f24344a08
qid2136	SELECT 数量 WHERE 购置日期 == "2001.01" and 设备名称 == "碎纸机"	a83dc3fa3b0611e996b3f40f24344a08
qid2137	SELECT 数量 WHERE 购置日期 == "2001.01" and 设备名称 == "碎纸机"	a83dc3fa3b0611e996b3f40f24344a08
qid2138	SELECT 专业 WHERE 职位名称 == "初中美术教师" or 职位名称 == "初中音乐教师"	f296e207453d11e9aea5f40f24344a08
qid2139	SELECT 专业 WHERE 职位名称 == "初中美术教师" or 职位名称 == "初中音乐教师"	f296e207453d11e9aea5f40f24344a08
qid2140	SELECT 专业 WHERE 职位名称 == "初中美术教师" or 职位名称 == "初中音乐教师"	f296e207453d11e9aea5f40f24344a08
qid2141	SELECT 作者 WHERE 出版社 == "科学出版社" and 参考书 == "数理统计"	f34ecbab453d11e98a5df40f24344a08
qid2142	SELECT 作者 WHERE 出版社 == "科学出版社" and 参考书 == "数理统计"	f34ecbab453d11e98a5df40f24344a08
qid2143	SELECT 作者 WHERE 出版社 == "科学出版社" and 参考书 == "数理统计"	f34ecbab453d11e98a5df40f24344a08
qid2144	SELECT 出版年 WHERE 题名 == "阅读至上" and 责任者 == "武庆新著"	a9522d303b0611e99408f40f24344a08
qid2145	SELECT 出版年 WHERE 题名 == "阅读至上" and 责任者 == "武庆新著"	a9522d303b0611e99408f40f24344a08
qid2146	SELECT 出版年 WHERE 题名 == "阅读至上" and 责任者 == "武庆新著"	a9522d303b0611e99408f40f24344a08
qid2147	SELECT 项目名称 WHERE 负责人 == "蔡万进"	f1c6af2b453d11e992b3f40f24344a08
qid2148	SELECT 项目名称 WHERE 负责人 == "蔡万进"	f1c6af2b453d11e992b3f40f24344a08
qid2149	SELECT 申报课程类型 WHERE 申报课程名称 == "外国文学诺奖作品深度解读"	f20082ae453d11e9a966f40f24344a08
qid2150	SELECT 申报课程类型 WHERE 申报课程名称 == "外国文学诺奖作品深度解读"	f20082ae453d11e9a966f40f24344a08
qid2151	SELECT 申报课程类型 WHERE 申报课程名称 == "外国文学诺奖作品深度解读"	f20082ae453d11e9a966f40f24344a08
qid2152	SELECT 招聘人数 WHERE 单位全称 == "黄果树水库管理所" and 岗位名称 == "专业技术岗位"	f0de08c5453d11e9bc90f40f24344a08
qid2153	SELECT 招聘人数 WHERE 单位全称 == "黄果树水库管理所" and 岗位名称 == "专业技术岗位"	f0de08c5453d11e9bc90f40f24344a08
qid2154	SELECT 招聘人数 WHERE 单位全称 == "黄果树水库管理所" and 岗位名称 == "专业技术岗位"	f0de08c5453d11e9bc90f40f24344a08
qid2155	SELECT 批准号 WHERE 项目名称 == "温州戏曲瓦当与南戏"	a959c4513b0611e9863bf40f24344a08
qid2156	SELECT 批准号 WHERE 项目名称 == "温州戏曲瓦当与南戏"	a959c4513b0611e9863bf40f24344a08
qid2157	SELECT 批准号 WHERE 项目名称 == "温州戏曲瓦当与南戏"	a959c4513b0611e9863bf40f24344a08
qid2158	SELECT 招聘人数 WHERE 岗位 == "长沙货运中心货运服务岗位"	ed38c6fa453d11e9b344f40f24344a08
qid2159	SELECT 招聘人数 WHERE 岗位 == "长沙货运中心货运服务岗位"	ed38c6fa453d11e9b344f40f24344a08
qid2160	SELECT 招聘人数 WHERE 岗位 == "长沙货运中心货运服务岗位"	ed38c6fa453d11e9b344f40f24344a08
qid2161	SELECT 规格型号 WHERE 生产日期/批号 == "2017/6/11//" and 食品名称 == "小喜鹊赤霞珠干红葡萄酒"	f1517168453d11e9bb24f40f24344a08
qid2162	SELECT 规格型号 WHERE 生产日期/批号 == "2017/6/11//" and 食品名称 == "小喜鹊赤霞珠干红葡萄酒"	f1517168453d11e9bb24f40f24344a08
qid2163	SELECT 规格型号 WHERE 生产日期/批号 == "2017/6/11//" and 食品名称 == "小喜鹊赤霞珠干红葡萄酒"	f1517168453d11e9bb24f40f24344a08
qid2164	SELECT 政治面貌 WHERE 岗位名称 == "动物营养与饲料学研究室科研岗位" and 招聘人数 == "1"	a98c6f683b0611e9aa8ff40f24344a08
qid2165	SELECT 政治面貌 WHERE 岗位名称 == "动物营养与饲料学研究室科研岗位" and 招聘人数 == "1"	a98c6f683b0611e9aa8ff40f24344a08
qid2166	SELECT 政治面貌 WHERE 岗位名称 == "动物营养与饲料学研究室科研岗位" and 招聘人数 == "1"	a98c6f683b0611e9aa8ff40f24344a08
qid2167	SELECT 课程名称 WHERE 考场 == "教402" and 开课学院 == "数统"	f464183a453d11e98060f40f24344a08
qid2168	SELECT 课程名称 WHERE 考场 == "教402" and 开课学院 == "数统"	f464183a453d11e98060f40f24344a08
qid2169	SELECT 课程名称 WHERE 考场 == "教402" and 开课学院 == "数统"	f464183a453d11e98060f40f24344a08
qid2170	SELECT 书名/Title WHERE 索书号/CallNo. == "BF637.U53C555=12010" or ISBN == "9.78142212482e+12"	a93c09e33b0611e98ce8f40f24344a08
qid2171	SELECT 书名/Title WHERE 索书号/CallNo. == "BF637.U53C555=12010" or ISBN == "9.78142212482e+12"	a93c09e33b0611e98ce8f40f24344a08
qid2172	SELECT 书名/Title WHERE 索书号/CallNo. == "BF637.U53C555=12010" or ISBN == "9.78142212482e+12"	a93c09e33b0611e98ce8f40f24344a08
qid2173	SELECT 总学时 WHERE 课程名称 == "自动控制理论"	abb2d8683b0611e9ba9ff40f24344a08
qid2174	SELECT 总学时 WHERE 课程名称 == "自动控制理论"	abb2d8683b0611e9ba9ff40f24344a08
qid2175	SELECT 总学时 WHERE 课程名称 == "自动控制理论"	abb2d8683b0611e9ba9ff40f24344a08
qid2176	SELECT 单位名称 WHERE 省份 == "广东"	f63647a1453d11e99e95f40f24344a08
qid2177	SELECT 单位名称 WHERE 省份 == "广东"	f63647a1453d11e99e95f40f24344a08
qid2178	SELECT 开工日期 , 已开工面积 WHERE 项目名称 == "紫雅苑二期"	f59c8805453d11e9bb70f40f24344a08
qid2179	SELECT 开工日期 , 已开工面积 WHERE 项目名称 == "紫雅苑二期"	f59c8805453d11e9bb70f40f24344a08
qid2180	SELECT 县级行社 WHERE 学历要求 == "普通类本科及以上学历" and 用工数量 > "30"	a880998c3b0611e99040f40f24344a08
qid2181	SELECT 县级行社 WHERE 学历要求 == "普通类本科及以上学历" and 用工数量 > "30"	a880998c3b0611e99040f40f24344a08
qid2182	SELECT 县级行社 WHERE 学历要求 == "普通类本科及以上学历" and 用工数量 > "30"	a880998c3b0611e99040f40f24344a08
qid2183	SELECT 标称生产企业名称 WHERE 规格型号 == "180克/瓶" and 食品名称 == "香辣酱(油泼辣子)"	ed4e3d0a453d11e9a9f6f40f24344a08
qid2184	SELECT 标称生产企业名称 WHERE 规格型号 == "180克/瓶" and 食品名称 == "香辣酱(油泼辣子)"	ed4e3d0a453d11e9a9f6f40f24344a08
qid2185	SELECT 发车时间* WHERE 始发站* == "醴陵" and 终点站* == "浏阳"	a807eec53b0611e99fa2f40f24344a08
qid2186	SELECT 发车时间* WHERE 始发站* == "醴陵" and 终点站* == "浏阳"	a807eec53b0611e99fa2f40f24344a08
qid2187	SELECT 发车时间* WHERE 始发站* == "醴陵" and 终点站* == "浏阳"	a807eec53b0611e99fa2f40f24344a08
qid2188	SELECT 出版日期 , 出版者 WHERE 书名 == "追迹三代"	a885c27d3b0611e9a419f40f24344a08
qid2189	SELECT 出版日期 , 出版者 WHERE 书名 == "追迹三代"	a885c27d3b0611e9a419f40f24344a08
qid2190	SELECT 出版日期 , 出版者 WHERE 书名 == "追迹三代"	a885c27d3b0611e9a419f40f24344a08
qid2191	SELECT 奖补金额（万元） WHERE 所在区 == "南山区" and 企业名称 == "深圳市可可卓科科技有限公司"	a8c023f53b0611e98e93f40f24344a08
qid2192	SELECT 奖补金额（万元） WHERE 所在区 == "南山区" and 企业名称 == "深圳市可可卓科科技有限公司"	a8c023f53b0611e98e93f40f24344a08
qid2193	SELECT 奖补金额（万元） WHERE 所在区 == "南山区" and 企业名称 == "深圳市可可卓科科技有限公司"	a8c023f53b0611e98e93f40f24344a08
qid2194	SELECT 企业名称 WHERE 所在省 == "江苏省"	f540af0c453d11e98e15f40f24344a08
qid2195	SELECT 企业名称 WHERE 所在省 == "江苏省"	f540af0c453d11e98e15f40f24344a08
qid2196	SELECT 企业名称 WHERE 所在省 == "江苏省"	f540af0c453d11e98e15f40f24344a08
qid2197	SELECT 集数 WHERE 产地 == "中国香港" and 剧名 == "酒店风云" and 类别 == "电视剧"	ab7cd7753b0611e9beb8f40f24344a08
qid2198	SELECT 集数 WHERE 产地 == "中国香港" and 剧名 == "酒店风云" and 类别 == "电视剧"	ab7cd7753b0611e9beb8f40f24344a08
qid2199	SELECT 集数 WHERE 产地 == "中国香港" and 剧名 == "酒店风云" and 类别 == "电视剧"	ab7cd7753b0611e9beb8f40f24344a08
qid2200	SELECT ISBN WHERE 书名 == "近代中国的知识分子与文明"	ab6c40613b0611e9bce6f40f24344a08
qid2201	SELECT ISBN WHERE 书名 == "近代中国的知识分子与文明"	ab6c40613b0611e9bce6f40f24344a08
qid2202	SELECT ISBN WHERE 书名 == "近代中国的知识分子与文明"	ab6c40613b0611e9bce6f40f24344a08
qid2203	SELECT 首席专家 WHERE 课题名称 == "习近平社会主义生态文明观研究" or 课题名称 == "习近平新时代中国特色社会主义党建思想体系整体建构研究"	ab75ef0c3b0611e9aa7bf40f24344a08
qid2204	SELECT 首席专家 WHERE 课题名称 == "习近平社会主义生态文明观研究" or 课题名称 == "习近平新时代中国特色社会主义党建思想体系整体建构研究"	ab75ef0c3b0611e9aa7bf40f24344a08
qid2205	SELECT 首席专家 WHERE 课题名称 == "习近平社会主义生态文明观研究" or 课题名称 == "习近平新时代中国特色社会主义党建思想体系整体建构研究"	ab75ef0c3b0611e9aa7bf40f24344a08
qid2206	SELECT 专业 WHERE 用人部门 == "警察体育与战术训练教研部"	ab53defa3b0611e9b50df40f24344a08
qid2207	SELECT 专业 WHERE 用人部门 == "警察体育与战术训练教研部"	ab53defa3b0611e9b50df40f24344a08
qid2208	SELECT 专业 WHERE 用人部门 == "警察体育与战术训练教研部"	ab53defa3b0611e9b50df40f24344a08
qid2209	SELECT 标称生产企业名称 WHERE 规格(包装规格） == "187.2g/盒" and 标称产品名称 == "富兰克牌西洋参含片"	ed0df600453d11e98318f40f24344a08
qid2210	SELECT 标称生产企业名称 WHERE 规格(包装规格） == "187.2g/盒" and 标称产品名称 == "富兰克牌西洋参含片"	ed0df600453d11e98318f40f24344a08
qid2211	SELECT 标称生产企业名称 WHERE 规格(包装规格） == "187.2g/盒" and 标称产品名称 == "富兰克牌西洋参含片"	ed0df600453d11e98318f40f24344a08
qid2212	SELECT 总学分 WHERE 开设单位 == "日文学院" and 专业名称 == "日语"	aae6e1753b0611e9a8a0f40f24344a08
qid2213	SELECT 总学分 WHERE 开设单位 == "日文学院" and 专业名称 == "日语"	aae6e1753b0611e9a8a0f40f24344a08
qid2214	SELECT 总学分 WHERE 开设单位 == "日文学院" and 专业名称 == "日语"	aae6e1753b0611e9a8a0f40f24344a08
qid2215	SELECT 岗位名称 WHERE 用人部门 == "国际体育组织学院"	a8ae13f03b0611e984c3f40f24344a08
qid2216	SELECT 岗位名称 WHERE 用人部门 == "国际体育组织学院"	a8ae13f03b0611e984c3f40f24344a08
qid2217	SELECT 岗位名称 WHERE 用人部门 == "国际体育组织学院"	a8ae13f03b0611e984c3f40f24344a08
qid2218	SELECT 课程名称 WHERE 授课对象 == "博士生"	a9b514233b0611e9bf56f40f24344a08
qid2219	SELECT 课程名称 WHERE 授课对象 == "博士生"	a9b514233b0611e9bf56f40f24344a08
qid2220	SELECT 课程名称 WHERE 授课对象 == "博士生"	a9b514233b0611e9bf56f40f24344a08
qid2221	SELECT 集数 WHERE 引进单位 == "海口广播电视台" and 剧名 == "梦幻岛"	f006e18a453d11e9b8bff40f24344a08
qid2222	SELECT 集数 WHERE 引进单位 == "海口广播电视台" and 剧名 == "梦幻岛"	f006e18a453d11e9b8bff40f24344a08
qid2223	SELECT 作者 , 出版单位 WHERE 著作名称 == "绘画艺术空间论"	aaf5835c3b0611e9a4b5f40f24344a08
qid2224	SELECT 作者 , 出版单位 WHERE 著作名称 == "绘画艺术空间论"	aaf5835c3b0611e9a4b5f40f24344a08
qid2225	SELECT 作者 , 出版单位 WHERE 著作名称 == "绘画艺术空间论"	aaf5835c3b0611e9a4b5f40f24344a08
qid2226	SELECT 招聘数 WHERE 科室 == "放射科" and 岗位需求（正高） == "主任医师"	f038dd99453d11e98375f40f24344a08
qid2227	SELECT 招聘数 WHERE 科室 == "放射科" and 岗位需求（正高） == "主任医师"	f038dd99453d11e98375f40f24344a08
qid2228	SELECT 招聘数 WHERE 科室 == "放射科" and 岗位需求（正高） == "主任医师"	f038dd99453d11e98375f40f24344a08
qid2229	SELECT 负责人 WHERE 项目名称 == "中国公民人文素质现状与对策研究" or 项目名称 == "马克思主义理论创新与社会主义历史命运"	abb4cb513b0611e9b56bf40f24344a08
qid2230	SELECT 负责人 WHERE 项目名称 == "中国公民人文素质现状与对策研究" or 项目名称 == "马克思主义理论创新与社会主义历史命运"	abb4cb513b0611e9b56bf40f24344a08
qid2231	SELECT 负责人 WHERE 项目名称 == "中国公民人文素质现状与对策研究" or 项目名称 == "马克思主义理论创新与社会主义历史命运"	abb4cb513b0611e9b56bf40f24344a08
qid2232	SELECT 图书编号 WHERE 书名 == "实用英语口语" and 作者 == "鲁瑛编著"	abd6aac23b0611e98ab2f40f24344a08
qid2233	SELECT 图书编号 WHERE 书名 == "实用英语口语" and 作者 == "鲁瑛编著"	abd6aac23b0611e98ab2f40f24344a08
qid2234	SELECT 图书编号 WHERE 书名 == "实用英语口语" and 作者 == "鲁瑛编著"	abd6aac23b0611e98ab2f40f24344a08
qid2235	SELECT 线路路名 WHERE 平峰期发车间隔 == "不高于10分钟" and 高峰期发车间隔 == "低于5分钟"	aa2d04213b0611e9b9f2f40f24344a08
qid2236	SELECT 线路路名 WHERE 平峰期发车间隔 == "不高于10分钟" and 高峰期发车间隔 == "低于5分钟"	aa2d04213b0611e9b9f2f40f24344a08
qid2237	SELECT 线路路名 WHERE 平峰期发车间隔 == "不高于10分钟" and 高峰期发车间隔 == "低于5分钟"	aa2d04213b0611e9b9f2f40f24344a08
qid2238	SELECT 著作名称 , 申请人 WHERE 推荐单位 == "中国传媒大学"	f2a559c7453d11e98104f40f24344a08
qid2239	SELECT 著作名称 , 申请人 WHERE 推荐单位 == "中国传媒大学"	f2a559c7453d11e98104f40f24344a08
qid2240	SELECT 著作名称 , 申请人 WHERE 推荐单位 == "中国传媒大学"	f2a559c7453d11e98104f40f24344a08
qid2241	SELECT 学历 WHERE 单位名称 == "闻喜二中" and 岗位名称 == "物理教师岗位"	ef6a5aeb453d11e9af32f40f24344a08
qid2242	SELECT 学历 WHERE 单位名称 == "闻喜二中" and 岗位名称 == "物理教师岗位"	ef6a5aeb453d11e9af32f40f24344a08
qid2243	SELECT 学历 WHERE 单位名称 == "闻喜二中" and 岗位名称 == "物理教师岗位"	ef6a5aeb453d11e9af32f40f24344a08
qid2244	SELECT 出现次数 WHERE 词语 == "在" and 词类名称 == "介词"	aa78b1de3b0611e9b5d5f40f24344a08
qid2245	SELECT 出现次数 WHERE 词语 == "在" and 词类名称 == "介词"	aa78b1de3b0611e9b5d5f40f24344a08
qid2246	SELECT 出现次数 WHERE 词语 == "在" and 词类名称 == "介词"	aa78b1de3b0611e9b5d5f40f24344a08
qid2247	SELECT 食品名称 WHERE 被抽样单位名称 == "逊克县缘客隆超市" and 被抽样单位所在省份 == "黑龙江"	ab4279943b0611e9b1dcf40f24344a08
qid2248	SELECT 食品名称 WHERE 被抽样单位名称 == "逊克县缘客隆超市" and 被抽样单位所在省份 == "黑龙江"	ab4279943b0611e9b1dcf40f24344a08
qid2249	SELECT 食品名称 WHERE 被抽样单位名称 == "逊克县缘客隆超市" and 被抽样单位所在省份 == "黑龙江"	ab4279943b0611e9b1dcf40f24344a08
qid2250	SELECT 出版日期 WHERE 书名 == "赢在行动学习"	a904150c3b0611e98a24f40f24344a08
qid2251	SELECT 出版日期 WHERE 书名 == "赢在行动学习"	a904150c3b0611e98a24f40f24344a08
qid2252	SELECT 出版日期 WHERE 书名 == "赢在行动学习"	a904150c3b0611e98a24f40f24344a08
qid2253	SELECT 设备名称 WHERE 许可证编号 == "02-B391-143176" or 设备型号 == "Venue11Pro714051"	ab41b0023b0611e9837bf40f24344a08
qid2254	SELECT 设备名称 WHERE 许可证编号 == "02-B391-143176" or 设备型号 == "Venue11Pro714051"	ab41b0023b0611e9837bf40f24344a08
qid2255	SELECT 设备名称 WHERE 许可证编号 == "02-B391-143176" or 设备型号 == "Venue11Pro714051"	ab41b0023b0611e9837bf40f24344a08
qid2256	SELECT 读者对象 WHERE 书名 == "拓扑指数的应用"	a9dd432b3b0611e9b3d0f40f24344a08
qid2257	SELECT 读者对象 WHERE 书名 == "拓扑指数的应用"	a9dd432b3b0611e9b3d0f40f24344a08
qid2258	SELECT 读者对象 WHERE 书名 == "拓扑指数的应用"	a9dd432b3b0611e9b3d0f40f24344a08
qid2259	SELECT 产品名称 WHERE 研制单位 == "北京天一集成科技有限公司"	f23e7168453d11e9a04ff40f24344a08
qid2260	SELECT 产品名称 WHERE 研制单位 == "北京天一集成科技有限公司"	f23e7168453d11e9a04ff40f24344a08
qid2261	SELECT 产品名称 WHERE 研制单位 == "北京天一集成科技有限公司"	f23e7168453d11e9a04ff40f24344a08
qid2262	SELECT 分类 WHERE 规格型号 == "160克/袋" or 生产日期/批号 == "42784"	ef0b6097453d11e9b30ff40f24344a08
qid2263	SELECT 分类 WHERE 规格型号 == "160克/袋" or 生产日期/批号 == "42784"	ef0b6097453d11e9b30ff40f24344a08
qid2264	SELECT 专业 , 学历要求 WHERE 岗位名称 == "科研岗位01"	aa9713193b0611e9bf8ff40f24344a08
qid2265	SELECT 专业 , 学历要求 WHERE 岗位名称 == "科研岗位01"	aa9713193b0611e9bf8ff40f24344a08
qid2266	SELECT 专业 , 学历要求 WHERE 岗位名称 == "科研岗位01"	aa9713193b0611e9bf8ff40f24344a08
qid2267	SELECT 制作单位 WHERE 集数 == "40" and 剧名 == "大秦帝国之崛起"	f269e3f0453d11e9b048f40f24344a08
qid2268	SELECT 制作单位 WHERE 集数 == "40" and 剧名 == "大秦帝国之崛起"	f269e3f0453d11e9b048f40f24344a08
qid2269	SELECT 制作单位 WHERE 集数 == "40" and 剧名 == "大秦帝国之崛起"	f269e3f0453d11e9b048f40f24344a08
qid2270	SELECT 联系电话 WHERE 单位名称 == "财源大酒店" and 地址 == "青屏大街"	a8a332d13b0611e986f8f40f24344a08
qid2271	SELECT 联系电话 WHERE 单位名称 == "财源大酒店" and 地址 == "青屏大街"	a8a332d13b0611e986f8f40f24344a08
qid2272	SELECT 第一责任者 WHERE 题名 == "佛家静坐方法论"	ef449c6b453d11e9b88ef40f24344a08
qid2273	SELECT 第一责任者 WHERE 题名 == "佛家静坐方法论"	ef449c6b453d11e9b88ef40f24344a08
qid2274	SELECT 第一责任者 WHERE 题名 == "佛家静坐方法论"	ef449c6b453d11e9b88ef40f24344a08
qid2275	SELECT 食品名称 WHERE 标识生产企业名称 == "湖北吉利食品有限公司" or 标识生产企业地址 == "浙江省嘉兴市秀洲区油车港正阳东路169号"	ed7b874a453d11e9a94ff40f24344a08
qid2276	SELECT 食品名称 WHERE 标识生产企业名称 == "湖北吉利食品有限公司" or 标识生产企业地址 == "浙江省嘉兴市秀洲区油车港正阳东路169号"	ed7b874a453d11e9a94ff40f24344a08
qid2277	SELECT 食品名称 WHERE 标识生产企业名称 == "湖北吉利食品有限公司" or 标识生产企业地址 == "浙江省嘉兴市秀洲区油车港正阳东路169号"	ed7b874a453d11e9a94ff40f24344a08
qid2278	SELECT 机构名称 WHERE 分配额度（枚） > "15000"	ab432c173b0611e9a627f40f24344a08
qid2279	SELECT 机构名称 WHERE 分配额度（枚） > "15000"	ab432c173b0611e9a627f40f24344a08
qid2280	SELECT 机构名称 WHERE 分配额度（枚） > "15000"	ab432c173b0611e9a627f40f24344a08
qid2281	SELECT SUM ( 定价 ) WHERE 书名 == "让人流口水的美食/好奇心小百科" or 书名 == "身边的科学常识/好奇心小百科"	a9c862ae3b0611e98fa7f40f24344a08
qid2282	SELECT SUM ( 定价 ) WHERE 书名 == "让人流口水的美食/好奇心小百科" or 书名 == "身边的科学常识/好奇心小百科"	a9c862ae3b0611e98fa7f40f24344a08
qid2283	SELECT SUM ( 定价 ) WHERE 书名 == "让人流口水的美食/好奇心小百科" or 书名 == "身边的科学常识/好奇心小百科"	a9c862ae3b0611e98fa7f40f24344a08
qid2284	SELECT 药品名称 WHERE 生产单位 == "广东众生药业股份有限公司" and 检验结果 == "合格"	f1503bd7453d11e99c91f40f24344a08
qid2285	SELECT 药品名称 WHERE 生产单位 == "广东众生药业股份有限公司" and 检验结果 == "合格"	f1503bd7453d11e99c91f40f24344a08
qid2286	SELECT 药品名称 WHERE 生产单位 == "广东众生药业股份有限公司" and 检验结果 == "合格"	f1503bd7453d11e99c91f40f24344a08
qid2287	SELECT 书号（ISBN） WHERE 书名 == "毛泽东阅读史"	a8d059353b0611e999eff40f24344a08
qid2288	SELECT 书号（ISBN） WHERE 书名 == "毛泽东阅读史"	a8d059353b0611e999eff40f24344a08
qid2289	SELECT 书号（ISBN） WHERE 书名 == "毛泽东阅读史"	a8d059353b0611e999eff40f24344a08
qid2290	SELECT COUNT ( 项目名称 ) WHERE 市级财政补助资金（万元） > "20" and 县（区）财政补助资金（万元） > "20"	f62208a8453d11e9b12ef40f24344a08
qid2291	SELECT COUNT ( 项目名称 ) WHERE 市级财政补助资金（万元） > "20" and 县（区）财政补助资金（万元） > "20"	f62208a8453d11e9b12ef40f24344a08
qid2292	SELECT COUNT ( 项目名称 ) WHERE 市级财政补助资金（万元） > "20" and 县（区）财政补助资金（万元） > "20"	f62208a8453d11e9b12ef40f24344a08
qid2293	SELECT 定价 WHERE 主题名 == "企业科普研究" and 第一责任者 == "何丽著"	aa73bc913b0611e9a252f40f24344a08
qid2294	SELECT 定价 WHERE 主题名 == "企业科普研究" and 第一责任者 == "何丽著"	aa73bc913b0611e9a252f40f24344a08
qid2295	SELECT 定价 WHERE 主题名 == "企业科普研究" and 第一责任者 == "何丽著"	aa73bc913b0611e9a252f40f24344a08
qid2296	SELECT 作者 WHERE 选题名称 == "我们家未来十年"	f725152e453d11e992b2f40f24344a08
qid2297	SELECT 作者 WHERE 选题名称 == "我们家未来十年"	f725152e453d11e992b2f40f24344a08
qid2298	SELECT 作者 WHERE 选题名称 == "我们家未来十年"	f725152e453d11e992b2f40f24344a08
qid2299	SELECT 用工部门 WHERE 岗位名称 == "学生助理" and 招聘人数 > "10"	a8bdfaae3b0611e9ac87f40f24344a08
qid2300	SELECT 用工部门 WHERE 岗位名称 == "学生助理" and 招聘人数 > "10"	a8bdfaae3b0611e9ac87f40f24344a08
qid2301	SELECT 用工部门 WHERE 岗位名称 == "学生助理" and 招聘人数 > "10"	a8bdfaae3b0611e9ac87f40f24344a08
qid2302	SELECT 拟聘人数 WHERE 招聘学校 == "九台区第一中学" and 学科（专业） == "语文"	a987b41e3b0611e9b318f40f24344a08
qid2303	SELECT 拟聘人数 WHERE 招聘学校 == "九台区第一中学" and 学科（专业） == "语文"	a987b41e3b0611e9b318f40f24344a08
qid2304	SELECT 拟聘人数 WHERE 招聘学校 == "九台区第一中学" and 学科（专业） == "语文"	a987b41e3b0611e9b318f40f24344a08
qid2305	SELECT SUM ( 招聘人数 ) WHERE 招聘单位 == "市中心医院"	ed4959ab453d11e9a2b4f40f24344a08
qid2306	SELECT SUM ( 招聘人数 ) WHERE 招聘单位 == "市中心医院"	ed4959ab453d11e9a2b4f40f24344a08
qid2307	SELECT SUM ( 招聘人数 ) WHERE 招聘单位 == "市中心医院"	ed4959ab453d11e9a2b4f40f24344a08
qid2308	SELECT 定价 WHERE 书名 == "小学生多功能英语词典（彩图版）" or 书号 == "9.7878068254e+12"	efd3f48c453d11e991dcf40f24344a08
qid2309	SELECT 定价 WHERE 书名 == "小学生多功能英语词典（彩图版）" or 书号 == "9.7878068254e+12"	efd3f48c453d11e991dcf40f24344a08
qid2310	SELECT 定价 WHERE 书名 == "小学生多功能英语词典（彩图版）" or 书号 == "9.7878068254e+12"	efd3f48c453d11e991dcf40f24344a08
qid2311	SELECT 网站标识码 WHERE 网站名称 == "西藏水利网"	a81752a83b0611e9a442f40f24344a08
qid2312	SELECT 网站标识码 WHERE 网站名称 == "西藏水利网"	a81752a83b0611e9a442f40f24344a08
qid2313	SELECT 网站标识码 WHERE 网站名称 == "西藏水利网"	a81752a83b0611e9a442f40f24344a08
qid2314	SELECT 页数 WHERE 题名 == "利他到觉悟"	aba602f33b0611e98117f40f24344a08
qid2315	SELECT 页数 WHERE 题名 == "利他到觉悟"	aba602f33b0611e98117f40f24344a08
qid2316	SELECT 页数 WHERE 题名 == "利他到觉悟"	aba602f33b0611e98117f40f24344a08
qid2317	SELECT 涨跌幅(%)Change(%) WHERE 开盘Open < "2000" or 收盘Close < "2000"	a991b95c3b0611e9911cf40f24344a08
qid2318	SELECT 涨跌幅(%)Change(%) WHERE 开盘Open < "2000" or 收盘Close < "2000"	a991b95c3b0611e9911cf40f24344a08
qid2319	SELECT 涨跌幅(%)Change(%) WHERE 开盘Open < "2000" or 收盘Close < "2000"	a991b95c3b0611e9911cf40f24344a08
qid2320	SELECT 医院名称 WHERE 医院类型 == "对外综合" or 医院等级 == "一级甲等"	ab7277973b0611e9ad5ef40f24344a08
qid2321	SELECT 医院名称 WHERE 医院类型 == "对外综合" or 医院等级 == "一级甲等"	ab7277973b0611e9ad5ef40f24344a08
qid2322	SELECT 医院名称 WHERE 医院类型 == "对外综合" or 医院等级 == "一级甲等"	ab7277973b0611e9ad5ef40f24344a08
qid2323	SELECT 定价 WHERE 书名 == "前街后街" or 书名 == "最后的冬天"	f61b765c453d11e983cef40f24344a08
qid2324	SELECT 定价 WHERE 书名 == "前街后街" or 书名 == "最后的冬天"	f61b765c453d11e983cef40f24344a08
qid2325	SELECT 定价 WHERE 书名 == "前街后街" or 书名 == "最后的冬天"	f61b765c453d11e983cef40f24344a08
qid2326	SELECT SUM ( 学分 ) WHERE 课程名称 == "拉丁舞" or 课程名称 == "插画入门"	f40c8b42453d11e98c66f40f24344a08
qid2327	SELECT SUM ( 学分 ) WHERE 课程名称 == "拉丁舞" or 课程名称 == "插画入门"	f40c8b42453d11e98c66f40f24344a08
qid2328	SELECT SUM ( 学分 ) WHERE 课程名称 == "拉丁舞" or 课程名称 == "插画入门"	f40c8b42453d11e98c66f40f24344a08
qid2329	SELECT 作者 WHERE 书名 == "古乐之美" or 书名 == "吃货的生物学修养"	a81425ba3b0611e99a4ef40f24344a08
qid2330	SELECT 作者 WHERE 书名 == "古乐之美" or 书名 == "吃货的生物学修养"	a81425ba3b0611e99a4ef40f24344a08
qid2331	SELECT 作者 WHERE 书名 == "古乐之美" or 书名 == "吃货的生物学修养"	a81425ba3b0611e99a4ef40f24344a08
qid2332	SELECT 页码 WHERE 书名 == "把人生活成奇迹" or 书名 == "朗西埃"	aa0325193b0611e983c2f40f24344a08
qid2333	SELECT 页码 WHERE 书名 == "把人生活成奇迹" or 书名 == "朗西埃"	aa0325193b0611e983c2f40f24344a08
qid2334	SELECT 页码 WHERE 书名 == "把人生活成奇迹" or 书名 == "朗西埃"	aa0325193b0611e983c2f40f24344a08
qid2335	SELECT 参考书 WHERE 科目名称 == "高等代数"	f34ecbab453d11e98a5df40f24344a08
qid2336	SELECT 参考书 WHERE 科目名称 == "高等代数"	f34ecbab453d11e98a5df40f24344a08
qid2337	SELECT 参考书 WHERE 科目名称 == "高等代数"	f34ecbab453d11e98a5df40f24344a08
qid2338	SELECT 校区 , 实到人数 WHERE 缺勤率 > "0.01"	ed5964c7453d11e9add5f40f24344a08
qid2339	SELECT 校区 , 实到人数 WHERE 缺勤率 > "0.01"	ed5964c7453d11e9add5f40f24344a08
qid2340	SELECT 校区 , 实到人数 WHERE 缺勤率 > "0.01"	ed5964c7453d11e9add5f40f24344a08
qid2341	SELECT 出版社 WHERE 题名 == "百年孤独" or 题名 == "茶花女"	f0aff985453d11e9a14cf40f24344a08
qid2342	SELECT 出版社 WHERE 题名 == "百年孤独" or 题名 == "茶花女"	f0aff985453d11e9a14cf40f24344a08
qid2343	SELECT 出版社 WHERE 题名 == "百年孤独" or 题名 == "茶花女"	f0aff985453d11e9a14cf40f24344a08
qid2344	SELECT 出版日期 WHERE isbn == "978-7-5463-3478-3"	aa7ee43d3b0611e98808f40f24344a08
qid2345	SELECT 出版日期 WHERE isbn == "978-7-5463-3478-3"	aa7ee43d3b0611e98808f40f24344a08
qid2346	SELECT 出版日期 WHERE isbn == "978-7-5463-3478-3"	aa7ee43d3b0611e98808f40f24344a08
qid2347	SELECT 书名 WHERE ISBN == "9.78751304084e+12" or ISBN == "9.78751303746e+12"	a8c104f53b0611e98382f40f24344a08
qid2348	SELECT 书名 WHERE ISBN == "9.78751304084e+12" or ISBN == "9.78751303746e+12"	a8c104f53b0611e98382f40f24344a08
qid2349	SELECT 书名 WHERE ISBN == "9.78751304084e+12" or ISBN == "9.78751303746e+12"	a8c104f53b0611e98382f40f24344a08
qid2350	SELECT 岗位 WHERE 年龄 == "40周岁以下" or 年龄 == "30周岁以下"	a9302f3d3b0611e9ae5cf40f24344a08
qid2351	SELECT 岗位 WHERE 年龄 == "40周岁以下" or 年龄 == "30周岁以下"	a9302f3d3b0611e9ae5cf40f24344a08
qid2352	SELECT 岗位 WHERE 年龄 == "40周岁以下" or 年龄 == "30周岁以下"	a9302f3d3b0611e9ae5cf40f24344a08
qid2353	SELECT 主持人 WHERE 项目名称 == "以模块化方式培养综合性人才的药剂学教学改革" or 项目名称 == "基于多媒体的沉浸式英语口语课堂教学策略研究"	a87afd3a3b0611e99555f40f24344a08
qid2354	SELECT 主持人 WHERE 项目名称 == "以模块化方式培养综合性人才的药剂学教学改革" or 项目名称 == "基于多媒体的沉浸式英语口语课堂教学策略研究"	a87afd3a3b0611e99555f40f24344a08
qid2355	SELECT 主持人 WHERE 项目名称 == "以模块化方式培养综合性人才的药剂学教学改革" or 项目名称 == "基于多媒体的沉浸式英语口语课堂教学策略研究"	a87afd3a3b0611e99555f40f24344a08
qid2356	SELECT 企业名称 WHERE 所在地 == "郑州" and 产品名称 == "漂白布"	edd2ac02453d11e99008f40f24344a08
qid2357	SELECT 企业名称 WHERE 所在地 == "郑州" and 产品名称 == "漂白布"	edd2ac02453d11e99008f40f24344a08
qid2358	SELECT 企业名称 WHERE 所在地 == "郑州" and 产品名称 == "漂白布"	edd2ac02453d11e99008f40f24344a08
qid2359	SELECT 学位 WHERE 应聘单位 == "吉林省气象探测保障中心" and 应聘职位 == "技术保障"	a7e26c8c3b0611e9a244f40f24344a08
qid2360	SELECT 学位 WHERE 应聘单位 == "吉林省气象探测保障中心" and 应聘职位 == "技术保障"	a7e26c8c3b0611e9a244f40f24344a08
qid2361	SELECT 学位 WHERE 应聘单位 == "吉林省气象探测保障中心" and 应聘职位 == "技术保障"	a7e26c8c3b0611e9a244f40f24344a08
qid2362	SELECT ISBN WHERE 书名 == "公司的概念" or 书名 == "巨变时代的管理"	ab9694473b0611e984b5f40f24344a08
qid2363	SELECT ISBN WHERE 书名 == "公司的概念" or 书名 == "巨变时代的管理"	ab9694473b0611e984b5f40f24344a08
qid2364	SELECT ISBN WHERE 书名 == "公司的概念" or 书名 == "巨变时代的管理"	ab9694473b0611e984b5f40f24344a08
qid2365	SELECT 招聘岗位 WHERE 岗位代码 == "140109001"	f1fac5d9453d11e9a044f40f24344a08
qid2366	SELECT 招聘岗位 WHERE 岗位代码 == "140109001"	f1fac5d9453d11e9a044f40f24344a08
qid2367	SELECT 招聘岗位 WHERE 岗位代码 == "140109001"	f1fac5d9453d11e9a044f40f24344a08
qid2368	SELECT 招聘人数 WHERE 公司名称 == "赛坦科技"	f4fa93d1453d11e9ae09f40f24344a08
qid2369	SELECT 招聘人数 WHERE 公司名称 == "赛坦科技"	f4fa93d1453d11e9ae09f40f24344a08
qid2370	SELECT 招聘人数 WHERE 公司名称 == "赛坦科技"	f4fa93d1453d11e9ae09f40f24344a08
qid2371	SELECT 课程名称 WHERE 类别 == "语言与文学"	aae4f1973b0611e99c72f40f24344a08
qid2372	SELECT 课程名称 WHERE 类别 == "语言与文学"	aae4f1973b0611e99c72f40f24344a08
qid2373	SELECT 课程名称 WHERE 类别 == "语言与文学"	aae4f1973b0611e99c72f40f24344a08
qid2374	SELECT 内容简介 WHERE 作者 == "葛婷编著" and 书名 == "别让压力毁了你"	a82b68423b0611e99654f40f24344a08
qid2375	SELECT 内容简介 WHERE 作者 == "葛婷编著" and 书名 == "别让压力毁了你"	a82b68423b0611e99654f40f24344a08
qid2376	SELECT 内容简介 WHERE 作者 == "葛婷编著" and 书名 == "别让压力毁了你"	a82b68423b0611e99654f40f24344a08
qid2377	SELECT COUNT ( 建筑名称 ) WHERE 行政村（社区） == "界桥社区" or 自然村（街区） == "竹基村"	f4e37ed7453d11e98a1ff40f24344a08
qid2378	SELECT COUNT ( 建筑名称 ) WHERE 行政村（社区） == "界桥社区" or 自然村（街区） == "竹基村"	f4e37ed7453d11e98a1ff40f24344a08
qid2379	SELECT COUNT ( 建筑名称 ) WHERE 行政村（社区） == "界桥社区" or 自然村（街区） == "竹基村"	f4e37ed7453d11e98a1ff40f24344a08
qid2380	SELECT 生产单位 WHERE 部数 > "8" or 分钟数 > "6000"	abafe2de3b0611e981dbf40f24344a08
qid2381	SELECT 生产单位 WHERE 部数 > "8" or 分钟数 > "6000"	abafe2de3b0611e981dbf40f24344a08
qid2382	SELECT 出版日期 WHERE 书名 == "金融内战" and 出版者 == "金城出版社"	a904150c3b0611e98a24f40f24344a08
qid2383	SELECT 出版日期 WHERE 书名 == "金融内战" and 出版者 == "金城出版社"	a904150c3b0611e98a24f40f24344a08
qid2384	SELECT 出版日期 WHERE 书名 == "金融内战" and 出版者 == "金城出版社"	a904150c3b0611e98a24f40f24344a08
qid2385	SELECT 作者 WHERE 书名 == "听力障碍儿童心理与教育" or 书名 == "文房图赞"	a9b7985c3b0611e994a6f40f24344a08
qid2386	SELECT 作者 WHERE 书名 == "听力障碍儿童心理与教育" or 书名 == "文房图赞"	a9b7985c3b0611e994a6f40f24344a08
qid2387	SELECT 作者 WHERE 书名 == "听力障碍儿童心理与教育" or 书名 == "文房图赞"	a9b7985c3b0611e994a6f40f24344a08
qid2388	SELECT 抽样编号 WHERE 被抽样单位所在省份 == "宁夏" and 被抽样单位名称 == "固原长城淀粉有限公司"	ed03eb38453d11e9a003f40f24344a08
qid2389	SELECT 抽样编号 WHERE 被抽样单位所在省份 == "宁夏" and 被抽样单位名称 == "固原长城淀粉有限公司"	ed03eb38453d11e9a003f40f24344a08
qid2390	SELECT 读者对象 WHERE 书名 == "网络社区"	a98679513b0611e997b9f40f24344a08
qid2391	SELECT 读者对象 WHERE 书名 == "网络社区"	a98679513b0611e997b9f40f24344a08
qid2392	SELECT 读者对象 WHERE 书名 == "网络社区"	a98679513b0611e997b9f40f24344a08
qid2393	SELECT 图书编号 WHERE 书目名称 == "斯大林" or 书目名称 == "加里宁传"	a8356e823b0611e9a0cdf40f24344a08
qid2394	SELECT 图书编号 WHERE 书目名称 == "斯大林" or 书目名称 == "加里宁传"	a8356e823b0611e9a0cdf40f24344a08
qid2395	SELECT 图书编号 WHERE 书目名称 == "斯大林" or 书目名称 == "加里宁传"	a8356e823b0611e9a0cdf40f24344a08
qid2396	SELECT 每包册数 WHERE 书名 == "影视精品导读"	a80f97473b0611e99f35f40f24344a08
qid2397	SELECT 每包册数 WHERE 书名 == "影视精品导读"	a80f97473b0611e99f35f40f24344a08
qid2398	SELECT 每包册数 WHERE 书名 == "影视精品导读"	a80f97473b0611e99f35f40f24344a08
qid2399	SELECT 书号 WHERE 教材名称 == "汽车美容"	ab8b42f03b0611e9aae5f40f24344a08
qid2400	SELECT 书号 WHERE 教材名称 == "汽车美容"	ab8b42f03b0611e9aae5f40f24344a08
qid2401	SELECT 书号 WHERE 教材名称 == "汽车美容"	ab8b42f03b0611e9aae5f40f24344a08
qid2402	SELECT 生产日期（批号） WHERE 规格型号 == "NSB-80H220V800W" and 产品详细名称 == "取暖器" and 企业名称 == "慈溪佳美电器厂"	f1c0aa30453d11e99db4f40f24344a08
qid2403	SELECT 生产日期（批号） WHERE 规格型号 == "NSB-80H220V800W" and 产品详细名称 == "取暖器" and 企业名称 == "慈溪佳美电器厂"	f1c0aa30453d11e99db4f40f24344a08
qid2404	SELECT 生产日期（批号） WHERE 规格型号 == "NSB-80H220V800W" and 产品详细名称 == "取暖器" and 企业名称 == "慈溪佳美电器厂"	f1c0aa30453d11e99db4f40f24344a08
qid2405	SELECT 单价 WHERE 书名 == "品牌农业" and 作者 == "娄向鹏"	aa5cc4e33b0611e9b0caf40f24344a08
qid2406	SELECT 单价 WHERE 书名 == "品牌农业" and 作者 == "娄向鹏"	aa5cc4e33b0611e9b0caf40f24344a08
qid2407	SELECT 单价 WHERE 书名 == "品牌农业" and 作者 == "娄向鹏"	aa5cc4e33b0611e9b0caf40f24344a08
qid2408	SELECT 企业名称 , 奖励金额 WHERE 入围类别 == "实力20强"	f1250147453d11e9895cf40f24344a08
qid2409	SELECT 企业名称 , 奖励金额 WHERE 入围类别 == "实力20强"	f1250147453d11e9895cf40f24344a08
qid2410	SELECT 企业名称 , 奖励金额 WHERE 入围类别 == "实力20强"	f1250147453d11e9895cf40f24344a08
qid2411	SELECT 书名 WHERE ISBN == "978-7-5682-4044-4" or ISBN == "978-7-5682-3282-1"	a9648a543b0611e9b5a1f40f24344a08
qid2412	SELECT 书名 WHERE ISBN == "978-7-5682-4044-4" or ISBN == "978-7-5682-3282-1"	a9648a543b0611e9b5a1f40f24344a08
qid2413	SELECT 书名 WHERE ISBN == "978-7-5682-4044-4" or ISBN == "978-7-5682-3282-1"	a9648a543b0611e9b5a1f40f24344a08
qid2414	SELECT 教材名称 WHERE 书号 == "978-7-04-019258-2"	eebda34a453d11e9b8b7f40f24344a08
qid2415	SELECT 教材名称 WHERE 书号 == "978-7-04-019258-2"	eebda34a453d11e9b8b7f40f24344a08
qid2416	SELECT 教材名称 WHERE 书号 == "978-7-04-019258-2"	eebda34a453d11e9b8b7f40f24344a08
qid2417	SELECT 价格 WHERE 书名 == "诡盗团" or 书名 == "大国长剑"	aba756de3b0611e98992f40f24344a08
qid2418	SELECT 价格 WHERE 书名 == "诡盗团" or 书名 == "大国长剑"	aba756de3b0611e98992f40f24344a08
qid2419	SELECT 价格 WHERE 书名 == "诡盗团" or 书名 == "大国长剑"	aba756de3b0611e98992f40f24344a08
qid2420	SELECT 食品名称 WHERE 标识生产企业名称 == "上海永安乳品有限公司" and 生产日期/批号 == "2018-9-26"	a9652cc03b0611e9966af40f24344a08
qid2421	SELECT 食品名称 WHERE 标识生产企业名称 == "上海永安乳品有限公司" and 生产日期/批号 == "2018-9-26"	a9652cc03b0611e9966af40f24344a08
qid2422	SELECT 食品名称 WHERE 标识生产企业名称 == "上海永安乳品有限公司" and 生产日期/批号 == "2018-9-26"	a9652cc03b0611e9966af40f24344a08
qid2423	SELECT 书名 WHERE 书号 == "9787551133272"	f61b765c453d11e983cef40f24344a08
qid2424	SELECT 书名 WHERE 书号 == "9787551133272"	f61b765c453d11e983cef40f24344a08
qid2425	SELECT 书名 WHERE 书号 == "9787551133272"	f61b765c453d11e983cef40f24344a08
qid2426	SELECT 数量 WHERE 资产名称 == "水浴恒温振荡器" or 型号 == "SHA-B"	aafb70633b0611e997b6f40f24344a08
qid2427	SELECT 数量 WHERE 资产名称 == "水浴恒温振荡器" or 型号 == "SHA-B"	aafb70633b0611e997b6f40f24344a08
qid2428	SELECT 数量 WHERE 资产名称 == "水浴恒温振荡器" or 型号 == "SHA-B"	aafb70633b0611e997b6f40f24344a08
qid2429	SELECT 作者 WHERE 书名 == "超越原生家庭（原书第4版）"	aa784a973b0611e99e9df40f24344a08
qid2430	SELECT 作者 WHERE 书名 == "超越原生家庭（原书第4版）"	aa784a973b0611e99e9df40f24344a08
qid2431	SELECT 作者 WHERE 书名 == "超越原生家庭（原书第4版）"	aa784a973b0611e99e9df40f24344a08
qid2432	SELECT 申请人 WHERE 矿区面积（平方公里） == "1.8152" and 矿山名称 == "毕节市七星关区顺发粘土矿"	a834f2173b0611e994a0f40f24344a08
qid2433	SELECT 申请人 WHERE 矿区面积（平方公里） == "1.8152" and 矿山名称 == "毕节市七星关区顺发粘土矿"	a834f2173b0611e994a0f40f24344a08
qid2434	SELECT 申请人 WHERE 矿区面积（平方公里） == "1.8152" and 矿山名称 == "毕节市七星关区顺发粘土矿"	a834f2173b0611e994a0f40f24344a08
qid2435	SELECT 作者 WHERE 书名 == "西汉龙纹镜" or 书名 == "古文字学"	a95e66543b0611e98395f40f24344a08
qid2436	SELECT 作者 WHERE 书名 == "西汉龙纹镜" or 书名 == "古文字学"	a95e66543b0611e98395f40f24344a08
qid2437	SELECT 作者 WHERE 书名 == "西汉龙纹镜" or 书名 == "古文字学"	a95e66543b0611e98395f40f24344a08
qid2438	SELECT 人数 WHERE 课程名称 == "计算机与现代医学"	a9c3019c3b0611e9a77ef40f24344a08
qid2439	SELECT 人数 WHERE 课程名称 == "计算机与现代医学"	a9c3019c3b0611e9a77ef40f24344a08
qid2440	SELECT 人数 WHERE 课程名称 == "计算机与现代医学"	a9c3019c3b0611e9a77ef40f24344a08
qid2441	SELECT 承检机构 WHERE 企业名称 == "今麦郎饮品股份有限公司" and 产品名称 == "乌龙蜜茶(调味茶饮料)"	ef2ebbae453d11e9b19ef40f24344a08
qid2442	SELECT 承检机构 WHERE 企业名称 == "今麦郎饮品股份有限公司" and 产品名称 == "乌龙蜜茶(调味茶饮料)"	ef2ebbae453d11e9b19ef40f24344a08
qid2443	SELECT 承检机构 WHERE 企业名称 == "今麦郎饮品股份有限公司" and 产品名称 == "乌龙蜜茶(调味茶饮料)"	ef2ebbae453d11e9b19ef40f24344a08
qid2444	SELECT SUM ( 录用人数 ) WHERE 招考单位 == "广州市公安局白云区分局" and 招考职位 == "基层派出所二级警员"	a9597bd13b0611e9bfdef40f24344a08
qid2445	SELECT SUM ( 录用人数 ) WHERE 招考单位 == "广州市公安局白云区分局" and 招考职位 == "基层派出所二级警员"	a9597bd13b0611e9bfdef40f24344a08
qid2446	SELECT SUM ( 录用人数 ) WHERE 招考单位 == "广州市公安局白云区分局" and 招考职位 == "基层派出所二级警员"	a9597bd13b0611e9bfdef40f24344a08
qid2447	SELECT 学历 WHERE 招聘单位 == "铁路学校" and 招聘岗位 == "小学音乐"	edc62e63453d11e9b041f40f24344a08
qid2448	SELECT 学历 WHERE 招聘单位 == "铁路学校" and 招聘岗位 == "小学音乐"	edc62e63453d11e9b041f40f24344a08
qid2449	SELECT 学历 WHERE 招聘单位 == "铁路学校" and 招聘岗位 == "小学音乐"	edc62e63453d11e9b041f40f24344a08
qid2450	SELECT 页码 WHERE 正书名 == "世界文学史"	ab2c2fc23b0611e99a3af40f24344a08
qid2451	SELECT 页码 WHERE 正书名 == "世界文学史"	ab2c2fc23b0611e99a3af40f24344a08
qid2452	SELECT 页码 WHERE 正书名 == "世界文学史"	ab2c2fc23b0611e99a3af40f24344a08
qid2453	SELECT 企业名称 WHERE 地区（部门） == "北京"	f44a515c453d11e9a15ef40f24344a08
qid2454	SELECT 企业名称 WHERE 地区（部门） == "北京"	f44a515c453d11e9a15ef40f24344a08
qid2455	SELECT 编者 WHERE 教材名称及版次 == "《经济与商务》" or 教材名称及版次 == "《金融英语教程》"	efd82cd4453d11e982eef40f24344a08
qid2456	SELECT 编者 WHERE 教材名称及版次 == "《经济与商务》" or 教材名称及版次 == "《金融英语教程》"	efd82cd4453d11e982eef40f24344a08
qid2457	SELECT 编者 WHERE 教材名称及版次 == "《经济与商务》" or 教材名称及版次 == "《金融英语教程》"	efd82cd4453d11e982eef40f24344a08
qid2458	SELECT 字数（千） WHERE 书名 == "测量学"	a98679513b0611e997b9f40f24344a08
qid2459	SELECT 字数（千） WHERE 书名 == "测量学"	a98679513b0611e997b9f40f24344a08
qid2460	SELECT 字数（千） WHERE 书名 == "测量学"	a98679513b0611e997b9f40f24344a08
qid2461	SELECT 计划招聘数 WHERE 用人单位 == "质量技术监督检测院" and 岗位 == "理化检验员"	f61e44ca453d11e99684f40f24344a08
qid2462	SELECT 计划招聘数 WHERE 用人单位 == "质量技术监督检测院" and 岗位 == "理化检验员"	f61e44ca453d11e99684f40f24344a08
qid2463	SELECT 编著者 WHERE 选题名称 == "说说国防和军队建设新成就" and 出版单位 == "长征出版社"	f63a40b3453d11e9be17f40f24344a08
qid2464	SELECT 编著者 WHERE 选题名称 == "说说国防和军队建设新成就" and 出版单位 == "长征出版社"	f63a40b3453d11e9be17f40f24344a08
qid2465	SELECT 书名 WHERE 出版地 == "北京"	aa54bc733b0611e9a067f40f24344a08
qid2466	SELECT 书名 WHERE 出版地 == "北京"	aa54bc733b0611e9a067f40f24344a08
qid2467	SELECT 书名 WHERE 出版地 == "北京"	aa54bc733b0611e9a067f40f24344a08
qid2468	SELECT 类别 WHERE 著作名称 == "《制造系统工程》" or 著作名称 == "《液压与气压传动》"	f5884ce1453d11e9b3dbf40f24344a08
qid2469	SELECT 类别 WHERE 著作名称 == "《制造系统工程》" or 著作名称 == "《液压与气压传动》"	f5884ce1453d11e9b3dbf40f24344a08
qid2470	SELECT 类别 WHERE 著作名称 == "《制造系统工程》" or 著作名称 == "《液压与气压传动》"	f5884ce1453d11e9b3dbf40f24344a08
qid2471	SELECT 书名 , 作者 WHERE 单价 < "20"	a83d80d73b0611e9a6a1f40f24344a08
qid2472	SELECT 书名 , 作者 WHERE 单价 < "20"	a83d80d73b0611e9a6a1f40f24344a08
qid2473	SELECT 书名 , 作者 WHERE 单价 < "20"	a83d80d73b0611e9a6a1f40f24344a08
qid2474	SELECT 面积（平方米） WHERE 单位 == "周口天发油脂有限公司" and 位置 == "周淮公路南侧、大庆路东侧、文昌大道北侧"	aae060873b0611e9b327f40f24344a08
qid2475	SELECT 面积（平方米） WHERE 单位 == "周口天发油脂有限公司" and 位置 == "周淮公路南侧、大庆路东侧、文昌大道北侧"	aae060873b0611e9b327f40f24344a08
qid2476	SELECT 面积（平方米） WHERE 单位 == "周口天发油脂有限公司" and 位置 == "周淮公路南侧、大庆路东侧、文昌大道北侧"	aae060873b0611e9b327f40f24344a08
qid2477	SELECT 开课网络 WHERE 课程名称 == "可再生能源与低碳社会" or 课程类别名称 == "人文艺术类(任选)"	a8fb1f233b0611e9807cf40f24344a08
qid2478	SELECT 开课网络 WHERE 课程名称 == "可再生能源与低碳社会" or 课程类别名称 == "人文艺术类(任选)"	a8fb1f233b0611e9807cf40f24344a08
qid2479	SELECT 教室 WHERE 课程名 == "流体力学"	edd1551e453d11e980bbf40f24344a08
qid2480	SELECT 教室 WHERE 课程名 == "流体力学"	edd1551e453d11e980bbf40f24344a08
qid2481	SELECT 教室 WHERE 课程名 == "流体力学"	edd1551e453d11e980bbf40f24344a08
qid2482	SELECT 计划时间 WHERE 展会主办单位 == "湖北省政府" and 2015年展会名称 == "第九届中国中部贸易投资博览会"	a8793ec73b0611e988a5f40f24344a08
qid2483	SELECT 计划时间 WHERE 展会主办单位 == "湖北省政府" and 2015年展会名称 == "第九届中国中部贸易投资博览会"	a8793ec73b0611e988a5f40f24344a08
qid2484	SELECT 招聘人数 WHERE 单位名称 == "上海清水日用制品有限公司" and 岗位名称 == "仓库管理员"	abab46733b0611e9a862f40f24344a08
qid2485	SELECT 招聘人数 WHERE 单位名称 == "上海清水日用制品有限公司" and 岗位名称 == "仓库管理员"	abab46733b0611e9a862f40f24344a08
qid2486	SELECT 招聘人数 WHERE 单位名称 == "上海清水日用制品有限公司" and 岗位名称 == "仓库管理员"	abab46733b0611e9a862f40f24344a08
qid2487	SELECT 考点代码 WHERE 考点 == "北京航空航天大学" or 考点 == "新发宾馆3楼会议室"	aa1a47a33b0611e9acc5f40f24344a08
qid2488	SELECT 考点代码 WHERE 考点 == "北京航空航天大学" or 考点 == "新发宾馆3楼会议室"	aa1a47a33b0611e9acc5f40f24344a08
qid2489	SELECT 考点代码 WHERE 考点 == "北京航空航天大学" or 考点 == "新发宾馆3楼会议室"	aa1a47a33b0611e9acc5f40f24344a08
qid2490	SELECT 出版社 WHERE 书名 == "成语大词典"	a9db10c73b0611e9a5eff40f24344a08
qid2491	SELECT 出版社 WHERE 书名 == "成语大词典"	a9db10c73b0611e9a5eff40f24344a08
qid2492	SELECT 出版社 WHERE 书名 == "成语大词典"	a9db10c73b0611e9a5eff40f24344a08
qid2493	SELECT 第一责任者 WHERE 出版社 == "华夏出版社" and 名称 == "活生生的保尔·柯察金"	a7e00e913b0611e99363f40f24344a08
qid2494	SELECT 第一责任者 WHERE 出版社 == "华夏出版社" and 名称 == "活生生的保尔·柯察金"	a7e00e913b0611e99363f40f24344a08
qid2495	SELECT 第一责任者 WHERE 出版社 == "华夏出版社" and 名称 == "活生生的保尔·柯察金"	a7e00e913b0611e99363f40f24344a08
qid2496	SELECT ISBN/ISSN WHERE 标题 == "蝇蛆生态养殖技术" or 标题 == "老人与海"	ed7555fd453d11e99e61f40f24344a08
qid2497	SELECT ISBN/ISSN WHERE 标题 == "蝇蛆生态养殖技术" or 标题 == "老人与海"	ed7555fd453d11e99e61f40f24344a08
qid2498	SELECT ISBN/ISSN WHERE 标题 == "蝇蛆生态养殖技术" or 标题 == "老人与海"	ed7555fd453d11e99e61f40f24344a08
qid2499	SELECT 线路路名 WHERE 线路长度（公里） > "20"	aa2d04213b0611e9b9f2f40f24344a08
qid2500	SELECT 线路路名 WHERE 线路长度（公里） > "20"	aa2d04213b0611e9b9f2f40f24344a08
qid2501	SELECT 线路路名 WHERE 线路长度（公里） > "20"	aa2d04213b0611e9b9f2f40f24344a08
qid2502	SELECT 企业名称 WHERE 专业要求 == "广告学、新闻或媒体传播相关专业" and 补助标准（＞1000元/人） == "1200元/人"	aba67c973b0611e9b257f40f24344a08
qid2503	SELECT 企业名称 WHERE 专业要求 == "广告学、新闻或媒体传播相关专业" and 补助标准（＞1000元/人） == "1200元/人"	aba67c973b0611e9b257f40f24344a08
qid2504	SELECT 企业名称 WHERE 专业要求 == "广告学、新闻或媒体传播相关专业" and 补助标准（＞1000元/人） == "1200元/人"	aba67c973b0611e9b257f40f24344a08
qid2505	SELECT 会议（活动）名称 WHERE 地点 == "霖顺一号楼会议室" and 召集部门 == "党政办"	f2f66082453d11e98f68f40f24344a08
qid2506	SELECT 会议（活动）名称 WHERE 地点 == "霖顺一号楼会议室" and 召集部门 == "党政办"	f2f66082453d11e98f68f40f24344a08
qid2507	SELECT 会议（活动）名称 WHERE 地点 == "霖顺一号楼会议室" and 召集部门 == "党政办"	f2f66082453d11e98f68f40f24344a08
qid2508	SELECT 部门名称 WHERE 职位名称 == "音乐教师" or 招考人数 == "1"	a9508b593b0611e98b51f40f24344a08
qid2509	SELECT 部门名称 WHERE 职位名称 == "音乐教师" or 招考人数 == "1"	a9508b593b0611e98b51f40f24344a08
qid2510	SELECT 部门名称 WHERE 职位名称 == "音乐教师" or 招考人数 == "1"	a9508b593b0611e98b51f40f24344a08
qid2511	SELECT 存放地 WHERE 原值（元） > "10000" and 名称 == "微型电子计算机"	a80f919e3b0611e9b750f40f24344a08
qid2512	SELECT 存放地 WHERE 原值（元） > "10000" and 名称 == "微型电子计算机"	a80f919e3b0611e9b750f40f24344a08
qid2513	SELECT 存放地 WHERE 原值（元） > "10000" and 名称 == "微型电子计算机"	a80f919e3b0611e9b750f40f24344a08
qid2514	SELECT 录取人数 WHERE 专业 == "逻辑学" or 专业 == "伦理学"	f69daf75453d11e9abe0f40f24344a08
qid2515	SELECT 录取人数 WHERE 专业 == "逻辑学" or 专业 == "伦理学"	f69daf75453d11e9abe0f40f24344a08
qid2516	SELECT 录取人数 WHERE 专业 == "逻辑学" or 专业 == "伦理学"	f69daf75453d11e9abe0f40f24344a08
qid2517	SELECT 企业名称 WHERE 规格型号 == "NSB-80A220V800W" and 产品详细名称 == "室内加热器"	f1c0aa30453d11e99db4f40f24344a08
qid2518	SELECT 企业名称 WHERE 规格型号 == "NSB-80A220V800W" and 产品详细名称 == "室内加热器"	f1c0aa30453d11e99db4f40f24344a08
qid2519	SELECT 企业名称 WHERE 规格型号 == "NSB-80A220V800W" and 产品详细名称 == "室内加热器"	f1c0aa30453d11e99db4f40f24344a08
qid2520	SELECT 项目名称 WHERE 需求方 == "九亭镇"	edbab3cc453d11e9bc21f40f24344a08
qid2521	SELECT 项目名称 WHERE 需求方 == "九亭镇"	edbab3cc453d11e9bc21f40f24344a08
qid2522	SELECT 上映日期 WHERE 片名 == "找到你"	a8d968023b0611e9a290f40f24344a08
qid2523	SELECT 上映日期 WHERE 片名 == "找到你"	a8d968023b0611e9a290f40f24344a08
qid2524	SELECT 上映日期 WHERE 片名 == "找到你"	a8d968023b0611e9a290f40f24344a08
qid2525	SELECT ISBN WHERE 书名 == "从零开始学五线谱" or 书名 == "从零开始学口风琴"	a7e0e4fd3b0611e9971ef40f24344a08
qid2526	SELECT ISBN WHERE 书名 == "从零开始学五线谱" or 书名 == "从零开始学口风琴"	a7e0e4fd3b0611e9971ef40f24344a08
qid2527	SELECT ISBN WHERE 书名 == "从零开始学五线谱" or 书名 == "从零开始学口风琴"	a7e0e4fd3b0611e9971ef40f24344a08
qid2528	SELECT 发证机关 WHERE 剧名 == "赵氏孤儿案"	f47d456b453d11e9aa8ef40f24344a08
qid2529	SELECT 发证机关 WHERE 剧名 == "赵氏孤儿案"	f47d456b453d11e9aa8ef40f24344a08
qid2530	SELECT 正题名 WHERE 读者对象 == "本书适用于大众读者" or 页码 == "369页"	a8fac7fd3b0611e99cdcf40f24344a08
qid2531	SELECT 正题名 WHERE 读者对象 == "本书适用于大众读者" or 页码 == "369页"	a8fac7fd3b0611e99cdcf40f24344a08
qid2532	SELECT 作者 WHERE 书名 == "马衡讲金石学"	f000ce1c453d11e9b8ebf40f24344a08
qid2533	SELECT 作者 WHERE 书名 == "马衡讲金石学"	f000ce1c453d11e9b8ebf40f24344a08
qid2534	SELECT 作者 WHERE 书名 == "马衡讲金石学"	f000ce1c453d11e9b8ebf40f24344a08
qid2535	SELECT 书名 , 作者 WHERE 出版者 == "金城出版社"	aaf666593b0611e99aabf40f24344a08
qid2536	SELECT 书名 , 作者 WHERE 出版者 == "金城出版社"	aaf666593b0611e99aabf40f24344a08
qid2537	SELECT 书名 , 作者 WHERE 出版者 == "金城出版社"	aaf666593b0611e99aabf40f24344a08
qid2538	SELECT 抽查结果 WHERE 承检机构 == "河南省产品质量监督检验院" and 产品名称 == "蒸压加气混凝土砌块"	ee923e97453d11e98bf4f40f24344a08
qid2539	SELECT 抽查结果 WHERE 承检机构 == "河南省产品质量监督检验院" and 产品名称 == "蒸压加气混凝土砌块"	ee923e97453d11e98bf4f40f24344a08
qid2540	SELECT 抽查结果 WHERE 承检机构 == "河南省产品质量监督检验院" and 产品名称 == "蒸压加气混凝土砌块"	ee923e97453d11e98bf4f40f24344a08
qid2541	SELECT 招聘人数 WHERE 支行名称 == "黄土坎支行" and 招聘岗位 == "信贷"	f4e784cc453d11e9bf64f40f24344a08
qid2542	SELECT 招聘人数 WHERE 支行名称 == "黄土坎支行" and 招聘岗位 == "信贷"	f4e784cc453d11e9bf64f40f24344a08
qid2543	SELECT 招聘人数 WHERE 支行名称 == "黄土坎支行" and 招聘岗位 == "信贷"	f4e784cc453d11e9bf64f40f24344a08
qid2544	SELECT 拟安排岗位 WHERE 单位层级 == "县级" and 需求数 == "1"	a91a20c23b0611e99639f40f24344a08
qid2545	SELECT 拟安排岗位 WHERE 单位层级 == "县级" and 需求数 == "1"	a91a20c23b0611e99639f40f24344a08
qid2546	SELECT 拟安排岗位 WHERE 单位层级 == "县级" and 需求数 == "1"	a91a20c23b0611e99639f40f24344a08
qid2547	SELECT AVG ( 车辆 ) WHERE 学校名称 == "新浜小学" or 学校名称 == "九亭小学"	f134dc30453d11e992aaf40f24344a08
qid2548	SELECT AVG ( 车辆 ) WHERE 学校名称 == "新浜小学" or 学校名称 == "九亭小学"	f134dc30453d11e992aaf40f24344a08
qid2549	SELECT AVG ( 车辆 ) WHERE 学校名称 == "新浜小学" or 学校名称 == "九亭小学"	f134dc30453d11e992aaf40f24344a08
qid2550	SELECT 机构名称 WHERE 分配额度（枚） == "3000"	ab432c173b0611e9a627f40f24344a08
qid2551	SELECT 机构名称 WHERE 分配额度（枚） == "3000"	ab432c173b0611e9a627f40f24344a08
qid2552	SELECT 出版时间（年月） WHERE 书名 == "大学生心理健康教育" or 书名 == "高校思想政治理论课教学论"	f5eadb26453d11e99b3df40f24344a08
qid2553	SELECT 出版时间（年月） WHERE 书名 == "大学生心理健康教育" or 书名 == "高校思想政治理论课教学论"	f5eadb26453d11e99b3df40f24344a08
qid2554	SELECT 出版时间（年月） WHERE 书名 == "大学生心理健康教育" or 书名 == "高校思想政治理论课教学论"	f5eadb26453d11e99b3df40f24344a08
qid2555	SELECT 科室 WHERE 学历 == "硕士"	a987e8633b0611e9b67ef40f24344a08
qid2556	SELECT 科室 WHERE 学历 == "硕士"	a987e8633b0611e9b67ef40f24344a08
qid2557	SELECT 科室 WHERE 学历 == "硕士"	a987e8633b0611e9b67ef40f24344a08
qid2558	SELECT 饭店名称 WHERE 星级 == "四星"	a8b868b33b0611e9af10f40f24344a08
qid2559	SELECT 饭店名称 WHERE 星级 == "四星"	a8b868b33b0611e9af10f40f24344a08
qid2560	SELECT 饭店名称 WHERE 星级 == "四星"	a8b868b33b0611e9af10f40f24344a08
qid2561	SELECT 入库日期 WHERE 规格型号 == "2*400g" and 物资名称 == "HeroBaby1奶粉"	f54a1005453d11e9a80bf40f24344a08
qid2562	SELECT 入库日期 WHERE 规格型号 == "2*400g" and 物资名称 == "HeroBaby1奶粉"	f54a1005453d11e9a80bf40f24344a08
qid2563	SELECT 入库日期 WHERE 规格型号 == "2*400g" and 物资名称 == "HeroBaby1奶粉"	f54a1005453d11e9a80bf40f24344a08
qid2564	SELECT 2018年刊例价/天 WHERE 规格 == "340*155" and 广告位名称 == "AIO-焦点图-河南"	a99bfa0c3b0611e9aff8f40f24344a08
qid2565	SELECT 2018年刊例价/天 WHERE 规格 == "340*155" and 广告位名称 == "AIO-焦点图-河南"	a99bfa0c3b0611e9aff8f40f24344a08
qid2566	SELECT 作者 WHERE ISBN == "978-7-111-59809-1"	a91fc5053b0611e98454f40f24344a08
qid2567	SELECT 作者 WHERE ISBN == "978-7-111-59809-1"	a91fc5053b0611e98454f40f24344a08
qid2568	SELECT 作者 WHERE ISBN == "978-7-111-59809-1"	a91fc5053b0611e98454f40f24344a08
qid2569	SELECT 规格型号 WHERE 生产日期/批号 == "2016-06-10" and 产品名称 == "电水壶"	a9b14b823b0611e9a0dcf40f24344a08
qid2570	SELECT 规格型号 WHERE 生产日期/批号 == "2016-06-10" and 产品名称 == "电水壶"	a9b14b823b0611e9a0dcf40f24344a08
qid2571	SELECT 规格型号 WHERE 生产日期/批号 == "2016-06-10" and 产品名称 == "电水壶"	a9b14b823b0611e9a0dcf40f24344a08
qid2572	SELECT 著作责任者 WHERE 项目分类 == "小说" and 项目名称 == "平原客"	ab0ad0b83b0611e9b464f40f24344a08
qid2573	SELECT 著作责任者 WHERE 项目分类 == "小说" and 项目名称 == "平原客"	ab0ad0b83b0611e9b464f40f24344a08
qid2574	SELECT 剧名 WHERE 制作单位 == "芒果影视文化（湖南）有限公司" and 集数 > "20"	f71aecde453d11e99729f40f24344a08
qid2575	SELECT 剧名 WHERE 制作单位 == "芒果影视文化（湖南）有限公司" and 集数 > "20"	f71aecde453d11e99729f40f24344a08
qid2576	SELECT 剧名 WHERE 制作单位 == "芒果影视文化（湖南）有限公司" and 集数 > "20"	f71aecde453d11e99729f40f24344a08
qid2577	SELECT 专业要求 WHERE 教研室/科室 == "管理学院" and 岗位类型 == "教师"	aacb31543b0611e996c7f40f24344a08
qid2578	SELECT 专业要求 WHERE 教研室/科室 == "管理学院" and 岗位类型 == "教师"	aacb31543b0611e996c7f40f24344a08
qid2579	SELECT 专业要求 WHERE 教研室/科室 == "管理学院" and 岗位类型 == "教师"	aacb31543b0611e996c7f40f24344a08
qid2580	SELECT 产品名称 WHERE 生产日期和批号 == "2016-05-31" and 企业名称 == "台州鼎尚卫浴有限公司"	aafb7d8c3b0611e98b0df40f24344a08
qid2581	SELECT 产品名称 WHERE 生产日期和批号 == "2016-05-31" and 企业名称 == "台州鼎尚卫浴有限公司"	aafb7d8c3b0611e98b0df40f24344a08
qid2582	SELECT 产品名称 WHERE 生产日期和批号 == "2016-05-31" and 企业名称 == "台州鼎尚卫浴有限公司"	aafb7d8c3b0611e98b0df40f24344a08
qid2583	SELECT 价格（￥） WHERE 规格型号 == "50T" and 产品名称 == "离心柱型动物组织基因组DNA提取试剂盒"	ef637a38453d11e9bf0df40f24344a08
qid2584	SELECT 价格（￥） WHERE 规格型号 == "50T" and 产品名称 == "离心柱型动物组织基因组DNA提取试剂盒"	ef637a38453d11e9bf0df40f24344a08
qid2585	SELECT 价格（￥） WHERE 规格型号 == "50T" and 产品名称 == "离心柱型动物组织基因组DNA提取试剂盒"	ef637a38453d11e9bf0df40f24344a08
qid2586	SELECT 企业名称 WHERE 产品名称 == "长效防冻液"	aa520b383b0611e9a0aaf40f24344a08
qid2587	SELECT 企业名称 WHERE 产品名称 == "长效防冻液"	aa520b383b0611e9a0aaf40f24344a08
qid2588	SELECT 企业名称 WHERE 产品名称 == "长效防冻液"	aa520b383b0611e9a0aaf40f24344a08
qid2589	SELECT 预期成果 WHERE 项目名称 == "“三个代表”重要思想与我国社会主义制度自我完善和发展研究"	abb4cb513b0611e9b56bf40f24344a08
qid2590	SELECT 预期成果 WHERE 项目名称 == "“三个代表”重要思想与我国社会主义制度自我完善和发展研究"	abb4cb513b0611e9b56bf40f24344a08
qid2591	SELECT 预期成果 WHERE 项目名称 == "“三个代表”重要思想与我国社会主义制度自我完善和发展研究"	abb4cb513b0611e9b56bf40f24344a08
qid2592	SELECT 发证日期 WHERE 剧名 == "燃情密码"	f47d456b453d11e9aa8ef40f24344a08
qid2593	SELECT 发证日期 WHERE 剧名 == "燃情密码"	f47d456b453d11e9aa8ef40f24344a08
qid2594	SELECT 发证日期 WHERE 剧名 == "燃情密码"	f47d456b453d11e9aa8ef40f24344a08
qid2595	SELECT 项目名称 , 项目负责人 WHERE 单位名称 == "首都医科大学附属北京安贞医院"	edf529ba453d11e98b45f40f24344a08
qid2596	SELECT 项目名称 , 项目负责人 WHERE 单位名称 == "首都医科大学附属北京安贞医院"	edf529ba453d11e98b45f40f24344a08
qid2597	SELECT 项目名称 , 项目负责人 WHERE 单位名称 == "首都医科大学附属北京安贞医院"	edf529ba453d11e98b45f40f24344a08
qid2598	SELECT 岗位名称 WHERE 职称要求 == "不限" and 执业资格证要求 == "不限"	f1d36828453d11e990c2f40f24344a08
qid2599	SELECT 岗位名称 WHERE 职称要求 == "不限" and 执业资格证要求 == "不限"	f1d36828453d11e990c2f40f24344a08
qid2600	SELECT 岗位名称 WHERE 职称要求 == "不限" and 执业资格证要求 == "不限"	f1d36828453d11e990c2f40f24344a08
qid2601	SELECT 学位 WHERE 单位 == "乐东管理局" and 岗位 == "计算机岗"	ed28d61e453d11e998dcf40f24344a08
qid2602	SELECT 学位 WHERE 单位 == "乐东管理局" and 岗位 == "计算机岗"	ed28d61e453d11e998dcf40f24344a08
qid2603	SELECT 学位 WHERE 单位 == "乐东管理局" and 岗位 == "计算机岗"	ed28d61e453d11e998dcf40f24344a08
qid2604	SELECT 定价（元） WHERE 书名 == "幸福排列组合" or 书名 == "你要相信，去爱就不会一无所有"	aba8c64a3b0611e9bccdf40f24344a08
qid2605	SELECT 定价（元） WHERE 书名 == "幸福排列组合" or 书名 == "你要相信，去爱就不会一无所有"	aba8c64a3b0611e9bccdf40f24344a08
qid2606	SELECT 定价（元） WHERE 书名 == "幸福排列组合" or 书名 == "你要相信，去爱就不会一无所有"	aba8c64a3b0611e9bccdf40f24344a08
qid2607	SELECT 食品名称 WHERE 被抽样单位名称 == "上海嘉定安亭大润发商贸有限公司"	a9a4b6e13b0611e9b900f40f24344a08
qid2608	SELECT 食品名称 WHERE 被抽样单位名称 == "上海嘉定安亭大润发商贸有限公司"	a9a4b6e13b0611e9b900f40f24344a08
qid2609	SELECT 食品名称 WHERE 被抽样单位名称 == "上海嘉定安亭大润发商贸有限公司"	a9a4b6e13b0611e9b900f40f24344a08
qid2610	SELECT 学历要求 WHERE 单位 == "场站社区"	f50677a6453d11e99218f40f24344a08
qid2611	SELECT 学历要求 WHERE 单位 == "场站社区"	f50677a6453d11e99218f40f24344a08
qid2612	SELECT 学历要求 WHERE 单位 == "场站社区"	f50677a6453d11e99218f40f24344a08
qid2613	SELECT 估定价 WHERE 作者 == "维权帮著" and 书名 == "受益一生的法律常识"	aa59f3543b0611e986f1f40f24344a08
qid2614	SELECT 估定价 WHERE 作者 == "维权帮著" and 书名 == "受益一生的法律常识"	aa59f3543b0611e986f1f40f24344a08
qid2615	SELECT 估定价 WHERE 作者 == "维权帮著" and 书名 == "受益一生的法律常识"	aa59f3543b0611e986f1f40f24344a08
qid2616	SELECT 作者 WHERE 出版社 == "上海人民出版社" and 书名 == "治史三书"	f66e7c57453d11e98c88f40f24344a08
qid2617	SELECT 作者 WHERE 出版社 == "上海人民出版社" and 书名 == "治史三书"	f66e7c57453d11e98c88f40f24344a08
qid2618	SELECT 作者 WHERE 出版社 == "上海人民出版社" and 书名 == "治史三书"	f66e7c57453d11e98c88f40f24344a08
qid2619	SELECT 商品名称 WHERE 被抽检人所在平台 == "京东"	f419baf5453d11e98a54f40f24344a08
qid2620	SELECT 商品名称 WHERE 被抽检人所在平台 == "京东"	f419baf5453d11e98a54f40f24344a08
qid2621	SELECT 时间 WHERE 活动内容 == "馒头创意大课堂"	a8062bcc3b0611e9a6eff40f24344a08
qid2622	SELECT 时间 WHERE 活动内容 == "馒头创意大课堂"	a8062bcc3b0611e9a6eff40f24344a08
qid2623	SELECT 时间 WHERE 活动内容 == "馒头创意大课堂"	a8062bcc3b0611e9a6eff40f24344a08
qid2624	SELECT 加工利用单位 WHERE 批准口岸 == "宁波" and 废物编号 == "7404000010.0"	f311c040453d11e9b67ff40f24344a08
qid2625	SELECT 加工利用单位 WHERE 批准口岸 == "宁波" and 废物编号 == "7404000010.0"	f311c040453d11e9b67ff40f24344a08
qid2626	SELECT 加工利用单位 WHERE 批准口岸 == "宁波" and 废物编号 == "7404000010.0"	f311c040453d11e9b67ff40f24344a08
qid2627	SELECT COUNT ( 企业名称 ) WHERE 企业所在地 == "江苏省" or 产品名称 == "LED苹果系列球泡灯（自镇流LED灯）"	a9a8e5e63b0611e99ed6f40f24344a08
qid2628	SELECT COUNT ( 企业名称 ) WHERE 企业所在地 == "江苏省" or 产品名称 == "LED苹果系列球泡灯（自镇流LED灯）"	a9a8e5e63b0611e99ed6f40f24344a08
qid2629	SELECT COUNT ( 企业名称 ) WHERE 企业所在地 == "江苏省" or 产品名称 == "LED苹果系列球泡灯（自镇流LED灯）"	a9a8e5e63b0611e99ed6f40f24344a08
qid2630	SELECT COUNT ( 产品名称 ) WHERE 生产企业名称 == "常熟市南方厨房设备有限责任公司" or 生产企业地址 == "苏州市常熟市博物馆尚湖镇王庄路120号2幢"	a8936f803b0611e9b2a6f40f24344a08
qid2631	SELECT COUNT ( 产品名称 ) WHERE 生产企业名称 == "常熟市南方厨房设备有限责任公司" or 生产企业地址 == "苏州市常熟市博物馆尚湖镇王庄路120号2幢"	a8936f803b0611e9b2a6f40f24344a08
qid2632	SELECT COUNT ( 产品名称 ) WHERE 生产企业名称 == "常熟市南方厨房设备有限责任公司" or 生产企业地址 == "苏州市常熟市博物馆尚湖镇王庄路120号2幢"	a8936f803b0611e9b2a6f40f24344a08
qid2633	SELECT 学院 WHERE 人数 == "1" and 要求 == "硕士及以上"	ab9c5e633b0611e9bb41f40f24344a08
qid2634	SELECT 学院 WHERE 人数 == "1" and 要求 == "硕士及以上"	ab9c5e633b0611e9bb41f40f24344a08
qid2635	SELECT 性别 WHERE 部门名称 == "海林市高级中学" and 职位名称 == "生物教师"	a9508b593b0611e98b51f40f24344a08
qid2636	SELECT 性别 WHERE 部门名称 == "海林市高级中学" and 职位名称 == "生物教师"	a9508b593b0611e98b51f40f24344a08
qid2637	SELECT 性别 WHERE 部门名称 == "海林市高级中学" and 职位名称 == "生物教师"	a9508b593b0611e98b51f40f24344a08
qid2638	SELECT 游戏名称 WHERE 研发公司 == "广州网易互动娱乐有限公司"	aa9082c03b0611e9aa0af40f24344a08
qid2639	SELECT 游戏名称 WHERE 研发公司 == "广州网易互动娱乐有限公司"	aa9082c03b0611e9aa0af40f24344a08
qid2640	SELECT 游戏名称 WHERE 研发公司 == "广州网易互动娱乐有限公司"	aa9082c03b0611e9aa0af40f24344a08
qid2641	SELECT 开课院系 WHERE 课程名 == "电子技术" or 课程名 == "电镀工艺学"	ef5f0cb5453d11e9bc98f40f24344a08
qid2642	SELECT 开课院系 WHERE 课程名 == "电子技术" or 课程名 == "电镀工艺学"	ef5f0cb5453d11e9bc98f40f24344a08
qid2643	SELECT 开课院系 WHERE 课程名 == "电子技术" or 课程名 == "电镀工艺学"	ef5f0cb5453d11e9bc98f40f24344a08
qid2644	SELECT 培训总金额（元） WHERE 培训时间 == "2017.7.7-2017.7.15" and 培训机构 == "成都工业学院"	f02a9b05453d11e9820cf40f24344a08
qid2645	SELECT 不合格项目 WHERE 抽查时间 == "2017年专项" and 产品名称 == "LED球泡灯"	aafb7d8c3b0611e98b0df40f24344a08
qid2646	SELECT 不合格项目 WHERE 抽查时间 == "2017年专项" and 产品名称 == "LED球泡灯"	aafb7d8c3b0611e98b0df40f24344a08
qid2647	SELECT 拟招聘人数 WHERE 单位 == "保亭管理局" and 岗位 == "计算机岗"	ed28d61e453d11e998dcf40f24344a08
qid2648	SELECT 拟招聘人数 WHERE 单位 == "保亭管理局" and 岗位 == "计算机岗"	ed28d61e453d11e998dcf40f24344a08
qid2649	SELECT 规格型号 WHERE 品牌 == "鲁川" and 材料名称 == "回收泵叶轮"	f58b3b11453d11e9b072f40f24344a08
qid2650	SELECT 规格型号 WHERE 品牌 == "鲁川" and 材料名称 == "回收泵叶轮"	f58b3b11453d11e9b072f40f24344a08
qid2651	SELECT 书号（ISBN） WHERE 书名 == "农民学习宝典" or 书名 == "农民维权宝典"	a95e4e303b0611e98a82f40f24344a08
qid2652	SELECT 书号（ISBN） WHERE 书名 == "农民学习宝典" or 书名 == "农民维权宝典"	a95e4e303b0611e98a82f40f24344a08
qid2653	SELECT 书号（ISBN） WHERE 书名 == "农民学习宝典" or 书名 == "农民维权宝典"	a95e4e303b0611e98a82f40f24344a08
qid2654	SELECT 作者 WHERE 书名 == "现象学导论" or 书名 == "易经助你走天下"	a9a0e92b3b0611e9be21f40f24344a08
qid2655	SELECT 作者 WHERE 书名 == "现象学导论" or 书名 == "易经助你走天下"	a9a0e92b3b0611e9be21f40f24344a08
qid2656	SELECT 作者 WHERE 书名 == "现象学导论" or 书名 == "易经助你走天下"	a9a0e92b3b0611e9be21f40f24344a08
qid2657	SELECT 名称 WHERE 类别 == "古遗址" and 时代 == "青铜时代"	eefd12a3453d11e9a724f40f24344a08
qid2658	SELECT 名称 WHERE 类别 == "古遗址" and 时代 == "青铜时代"	eefd12a3453d11e9a724f40f24344a08
qid2659	SELECT 名称 WHERE 类别 == "古遗址" and 时代 == "青铜时代"	eefd12a3453d11e9a724f40f24344a08
qid2660	SELECT COUNT ( 文书种类 ) WHERE 终审结果 == "同意" or 受理日期 == "2012-6-26"	abb29a073b0611e999d2f40f24344a08
qid2661	SELECT COUNT ( 文书种类 ) WHERE 终审结果 == "同意" or 受理日期 == "2012-6-26"	abb29a073b0611e999d2f40f24344a08
qid2662	SELECT COUNT ( 文书种类 ) WHERE 终审结果 == "同意" or 受理日期 == "2012-6-26"	abb29a073b0611e999d2f40f24344a08
qid2663	SELECT 竞赛项目 WHERE 获奖人数 > "1" and 获奖等第 == "一等奖"	f2d7f523453d11e99467f40f24344a08
qid2664	SELECT 竞赛项目 WHERE 获奖人数 > "1" and 获奖等第 == "一等奖"	f2d7f523453d11e99467f40f24344a08
qid2665	SELECT 竞赛项目 WHERE 获奖人数 > "1" and 获奖等第 == "一等奖"	f2d7f523453d11e99467f40f24344a08
qid2666	SELECT 抽样编号 WHERE 被抽样单位所在省份 == "宁夏" and 被抽样单位名称 == "固原玉明淀粉有限公司"	ed8502c2453d11e9a338f40f24344a08
qid2667	SELECT 抽样编号 WHERE 被抽样单位所在省份 == "宁夏" and 被抽样单位名称 == "固原玉明淀粉有限公司"	ed8502c2453d11e9a338f40f24344a08
qid2668	SELECT 抽样编号 WHERE 被抽样单位所在省份 == "宁夏" and 被抽样单位名称 == "固原玉明淀粉有限公司"	ed8502c2453d11e9a338f40f24344a08
qid2669	SELECT 馆藏索书号 WHERE 题名 == "改革开放以来党的建设" or 题名 == "两种改革开放观"	ab46ee8c3b0611e9a0dbf40f24344a08
qid2670	SELECT 馆藏索书号 WHERE 题名 == "改革开放以来党的建设" or 题名 == "两种改革开放观"	ab46ee8c3b0611e9a0dbf40f24344a08
qid2671	SELECT 馆藏索书号 WHERE 题名 == "改革开放以来党的建设" or 题名 == "两种改革开放观"	ab46ee8c3b0611e9a0dbf40f24344a08
qid2672	SELECT 出版日期 WHERE 正题名 == "老子说人生"	f4024038453d11e99f1af40f24344a08
qid2673	SELECT 出版日期 WHERE 正题名 == "老子说人生"	f4024038453d11e99f1af40f24344a08
qid2674	SELECT 出版日期 WHERE 正题名 == "老子说人生"	f4024038453d11e99f1af40f24344a08
qid2675	SELECT 企业名称 WHERE 抽查结果 == "合格" and 承检机构 == "国家电子计算机外部设备质量监督检验中心"	f2c8c1b0453d11e9ac63f40f24344a08
qid2676	SELECT 企业名称 WHERE 抽查结果 == "合格" and 承检机构 == "国家电子计算机外部设备质量监督检验中心"	f2c8c1b0453d11e9ac63f40f24344a08
qid2677	SELECT 企业名称 WHERE 抽查结果 == "合格" and 承检机构 == "国家电子计算机外部设备质量监督检验中心"	f2c8c1b0453d11e9ac63f40f24344a08
qid2678	SELECT 招聘人数 WHERE 岗位 == "文秘岗"	f63bbdd4453d11e9a4b3f40f24344a08
qid2679	SELECT 招聘人数 WHERE 岗位 == "文秘岗"	f63bbdd4453d11e9a4b3f40f24344a08
qid2680	SELECT 招聘人数 WHERE 岗位 == "文秘岗"	f63bbdd4453d11e9a4b3f40f24344a08
qid2681	SELECT 定价 WHERE 书名 == "解读花旗银行" and 作者 == "郑先炳著"	f398419c453d11e9a4d7f40f24344a08
qid2682	SELECT 定价 WHERE 书名 == "解读花旗银行" and 作者 == "郑先炳著"	f398419c453d11e9a4d7f40f24344a08
qid2683	SELECT 定价 WHERE 书名 == "解读花旗银行" and 作者 == "郑先炳著"	f398419c453d11e9a4d7f40f24344a08
qid2684	SELECT 产品型号 WHERE 市场价格 > "20000" or 协议供货价格 > "10000"	a9abed543b0611e9ab57f40f24344a08
qid2685	SELECT 产品型号 WHERE 市场价格 > "20000" or 协议供货价格 > "10000"	a9abed543b0611e9ab57f40f24344a08
qid2686	SELECT 产品型号 WHERE 市场价格 > "20000" or 协议供货价格 > "10000"	a9abed543b0611e9ab57f40f24344a08
qid2687	SELECT 出版日期 WHERE 书名 == "证券投资实务" or 书名 == "IT技术与校园文化的融合研究:对外经济贸易大学IT文化节的实践与发展"	aa1847ee3b0611e9ab9ef40f24344a08
qid2688	SELECT 出版日期 WHERE 书名 == "证券投资实务" or 书名 == "IT技术与校园文化的融合研究:对外经济贸易大学IT文化节的实践与发展"	aa1847ee3b0611e9ab9ef40f24344a08
qid2689	SELECT 出版日期 WHERE 书名 == "证券投资实务" or 书名 == "IT技术与校园文化的融合研究:对外经济贸易大学IT文化节的实践与发展"	aa1847ee3b0611e9ab9ef40f24344a08
qid2690	SELECT 题名 WHERE 出版社 == "人民文学出版社"	a98b097d3b0611e9a7e3f40f24344a08
qid2691	SELECT 题名 WHERE 出版社 == "人民文学出版社"	a98b097d3b0611e9a7e3f40f24344a08
qid2692	SELECT 题名 WHERE 出版社 == "人民文学出版社"	a98b097d3b0611e9a7e3f40f24344a08
qid2693	SELECT 出版日期 WHERE 书名 == "悟空，乖！" and 作者 == "向华"	ed4f1807453d11e9b763f40f24344a08
qid2694	SELECT 出版日期 WHERE 书名 == "悟空，乖！" and 作者 == "向华"	ed4f1807453d11e9b763f40f24344a08
qid2695	SELECT 任课教师 WHERE 课程名称 == "投资学" or 课程名称 == "物流管理"	aac9fcd13b0611e9af4ef40f24344a08
qid2696	SELECT 任课教师 WHERE 课程名称 == "投资学" or 课程名称 == "物流管理"	aac9fcd13b0611e9af4ef40f24344a08
qid2697	SELECT 任课教师 WHERE 课程名称 == "投资学" or 课程名称 == "物流管理"	aac9fcd13b0611e9af4ef40f24344a08
qid2698	SELECT 单位名称 WHERE 奖项 == "一等奖"	a92ccc0f3b0611e9a905f40f24344a08
qid2699	SELECT 单位名称 WHERE 奖项 == "一等奖"	a92ccc0f3b0611e9a905f40f24344a08
qid2700	SELECT 单位名称 WHERE 奖项 == "一等奖"	a92ccc0f3b0611e9a905f40f24344a08
qid2701	SELECT COUNT ( 标称生产企业 ) WHERE 样品名称 == "商务电池" or 标称商标 == "恒毅电子(包装)"	a9f4e71e3b0611e9bd8ff40f24344a08
qid2702	SELECT COUNT ( 标称生产企业 ) WHERE 样品名称 == "商务电池" or 标称商标 == "恒毅电子(包装)"	a9f4e71e3b0611e9bd8ff40f24344a08
qid2703	SELECT COUNT ( 标称生产企业 ) WHERE 样品名称 == "商务电池" or 标称商标 == "恒毅电子(包装)"	a9f4e71e3b0611e9bd8ff40f24344a08
qid2704	SELECT COUNT ( 企业名称 ) WHERE 产品名称 == "台扇" and 抽查结果 == "合格"	ab9fd6f33b0611e9ba5cf40f24344a08
qid2705	SELECT COUNT ( 企业名称 ) WHERE 产品名称 == "台扇" and 抽查结果 == "合格"	ab9fd6f33b0611e9ba5cf40f24344a08
qid2706	SELECT COUNT ( 企业名称 ) WHERE 产品名称 == "台扇" and 抽查结果 == "合格"	ab9fd6f33b0611e9ba5cf40f24344a08
qid2707	SELECT 集数 WHERE 剧名 == "富贵再三逼人" and 类别 == "电影"	eeeb6873453d11e992edf40f24344a08
qid2708	SELECT 集数 WHERE 剧名 == "富贵再三逼人" and 类别 == "电影"	eeeb6873453d11e992edf40f24344a08
qid2709	SELECT 集数 WHERE 剧名 == "富贵再三逼人" and 类别 == "电影"	eeeb6873453d11e992edf40f24344a08
qid2710	SELECT 出版单位 WHERE 书名 == "毛泽东之魂" and 作者 == "陈晋"	a948a6703b0611e9a901f40f24344a08
qid2711	SELECT 出版单位 WHERE 书名 == "毛泽东之魂" and 作者 == "陈晋"	a948a6703b0611e9a901f40f24344a08
qid2712	SELECT 出版单位 WHERE 书名 == "毛泽东之魂" and 作者 == "陈晋"	a948a6703b0611e9a901f40f24344a08
qid2713	SELECT 专业名称 , 专业代码 WHERE 学院名称 == "经济学院"	eded67a3453d11e99a1ff40f24344a08
qid2714	SELECT 专业名称 , 专业代码 WHERE 学院名称 == "经济学院"	eded67a3453d11e99a1ff40f24344a08
qid2715	SELECT 专业名称 , 专业代码 WHERE 学院名称 == "经济学院"	eded67a3453d11e99a1ff40f24344a08
qid2716	SELECT 项目名称 WHERE 所在区县 == "海淀" and 企业名称 == "北京城建弘城物业管理有限责任公司"	ab7a883d3b0611e9a7aff40f24344a08
qid2717	SELECT 项目名称 WHERE 所在区县 == "海淀" and 企业名称 == "北京城建弘城物业管理有限责任公司"	ab7a883d3b0611e9a7aff40f24344a08
qid2718	SELECT 项目名称 WHERE 所在区县 == "海淀" and 企业名称 == "北京城建弘城物业管理有限责任公司"	ab7a883d3b0611e9a7aff40f24344a08
qid2719	SELECT 作者 WHERE 书名 == "短线掘金"	a8331c9c3b0611e9b04ff40f24344a08
qid2720	SELECT 作者 WHERE 书名 == "短线掘金"	a8331c9c3b0611e9b04ff40f24344a08
qid2721	SELECT 作者 WHERE 书名 == "短线掘金"	a8331c9c3b0611e9b04ff40f24344a08
qid2722	SELECT 日期 WHERE 标称生产企业 == "四川有友食品开发有限公司" and 食品名称 == "香菇豆干（香辣味）"	ee2f38fa453d11e9bd51f40f24344a08
qid2723	SELECT 日期 WHERE 标称生产企业 == "四川有友食品开发有限公司" and 食品名称 == "香菇豆干（香辣味）"	ee2f38fa453d11e9bd51f40f24344a08
qid2724	SELECT 日期 WHERE 标称生产企业 == "四川有友食品开发有限公司" and 食品名称 == "香菇豆干（香辣味）"	ee2f38fa453d11e9bd51f40f24344a08
qid2725	SELECT COUNT ( 项目名称 ) WHERE 开工年份 == "2016" and 建成年份 == "2017"	f59e7561453d11e9acf9f40f24344a08
qid2726	SELECT COUNT ( 项目名称 ) WHERE 开工年份 == "2016" and 建成年份 == "2017"	f59e7561453d11e9acf9f40f24344a08
qid2727	SELECT COUNT ( 项目名称 ) WHERE 开工年份 == "2016" and 建成年份 == "2017"	f59e7561453d11e9acf9f40f24344a08
qid2728	SELECT 发现问题 WHERE 受审核部门 == "工程技术部" or 受审核部门 == "人力资源部"	ab370c003b0611e9bfcff40f24344a08
qid2729	SELECT 发现问题 WHERE 受审核部门 == "工程技术部" or 受审核部门 == "人力资源部"	ab370c003b0611e9bfcff40f24344a08
qid2730	SELECT 发现问题 WHERE 受审核部门 == "工程技术部" or 受审核部门 == "人力资源部"	ab370c003b0611e9bfcff40f24344a08
qid2731	SELECT 专业要求 WHERE 职位代码 == "DG1808"	ef7de378453d11e98032f40f24344a08
qid2732	SELECT 专业要求 WHERE 职位代码 == "DG1808"	ef7de378453d11e98032f40f24344a08
qid2733	SELECT 专业要求 WHERE 职位代码 == "DG1808"	ef7de378453d11e98032f40f24344a08
qid2734	SELECT 动物名称 WHERE 实验室名称 == "药理学实验室"	f6d634a3453d11e9858df40f24344a08
qid2735	SELECT 动物名称 WHERE 实验室名称 == "药理学实验室"	f6d634a3453d11e9858df40f24344a08
qid2736	SELECT 动物名称 WHERE 实验室名称 == "药理学实验室"	f6d634a3453d11e9858df40f24344a08
qid2737	SELECT 申请人 WHERE 项目名称 == "心电监护仪"	f47ffd33453d11e9afb3f40f24344a08
qid2738	SELECT 申请人 WHERE 项目名称 == "心电监护仪"	f47ffd33453d11e9afb3f40f24344a08
qid2739	SELECT 成果名称 WHERE 单位 == "计算机学院" and 等级 == "二等奖"	ede64885453d11e992edf40f24344a08
qid2740	SELECT 成果名称 WHERE 单位 == "计算机学院" and 等级 == "二等奖"	ede64885453d11e992edf40f24344a08
qid2741	SELECT 成果名称 WHERE 单位 == "计算机学院" and 等级 == "二等奖"	ede64885453d11e992edf40f24344a08
qid2742	SELECT 集数 WHERE 剧名 == "阳光情人梦" and 产地 == "韩国"	f3f00621453d11e98637f40f24344a08
qid2743	SELECT 集数 WHERE 剧名 == "阳光情人梦" and 产地 == "韩国"	f3f00621453d11e98637f40f24344a08
qid2744	SELECT 集数 WHERE 剧名 == "阳光情人梦" and 产地 == "韩国"	f3f00621453d11e98637f40f24344a08
qid2745	SELECT 作者 WHERE 刊播媒体及日期 == "新华日报2007.3.24" and 篇名 == "《挖不出新闻的新闻》"	a885e5e13b0611e9a2c0f40f24344a08
qid2746	SELECT 作者 WHERE 刊播媒体及日期 == "新华日报2007.3.24" and 篇名 == "《挖不出新闻的新闻》"	a885e5e13b0611e9a2c0f40f24344a08
qid2747	SELECT 作者 WHERE 刊播媒体及日期 == "新华日报2007.3.24" and 篇名 == "《挖不出新闻的新闻》"	a885e5e13b0611e9a2c0f40f24344a08
qid2748	SELECT 学时数 WHERE 课程名称 == "医学统计学"	aa189be63b0611e9b4adf40f24344a08
qid2749	SELECT 学时数 WHERE 课程名称 == "医学统计学"	aa189be63b0611e9b4adf40f24344a08
qid2750	SELECT 学时数 WHERE 课程名称 == "医学统计学"	aa189be63b0611e9b4adf40f24344a08
qid2751	SELECT 出版社 WHERE 书名 == "染缬集"	ab3fcbfd3b0611e9bbe7f40f24344a08
qid2752	SELECT 出版社 WHERE 书名 == "染缬集"	ab3fcbfd3b0611e9bbe7f40f24344a08
qid2753	SELECT 出版社 WHERE 书名 == "染缬集"	ab3fcbfd3b0611e9bbe7f40f24344a08
qid2754	SELECT 作品名称 WHERE 年级 == "高一" and 学科 == "计算机科学(CS)"	eed98f57453d11e992f6f40f24344a08
qid2755	SELECT 作品名称 WHERE 年级 == "高一" and 学科 == "计算机科学(CS)"	eed98f57453d11e992f6f40f24344a08
qid2756	SELECT 作品名称 WHERE 年级 == "高一" and 学科 == "计算机科学(CS)"	eed98f57453d11e992f6f40f24344a08
qid2757	SELECT 定价 WHERE 书名 == "雪地里的单车"	a8f9cef83b0611e9beeaf40f24344a08
qid2758	SELECT 定价 WHERE 书名 == "雪地里的单车"	a8f9cef83b0611e9beeaf40f24344a08
qid2759	SELECT 定价 WHERE 书名 == "雪地里的单车"	a8f9cef83b0611e9beeaf40f24344a08
qid2760	SELECT 建设项目 , 用地地点 WHERE 用地面积 > "3000"	abb1144f3b0611e986b3f40f24344a08
qid2761	SELECT 建设项目 , 用地地点 WHERE 用地面积 > "3000"	abb1144f3b0611e986b3f40f24344a08
qid2762	SELECT 建设项目 , 用地地点 WHERE 用地面积 > "3000"	abb1144f3b0611e986b3f40f24344a08
qid2763	SELECT ISBN WHERE 书名 == "信息描述实验教程" or 书名 == "涉外礼仪知识"	a87113d73b0611e9beb5f40f24344a08
qid2764	SELECT ISBN WHERE 书名 == "信息描述实验教程" or 书名 == "涉外礼仪知识"	a87113d73b0611e9beb5f40f24344a08
qid2765	SELECT ISBN WHERE 书名 == "信息描述实验教程" or 书名 == "涉外礼仪知识"	a87113d73b0611e9beb5f40f24344a08
qid2766	SELECT 招聘人数 WHERE 职位名称 == "财政金融领域研究"	a9b2ead13b0611e9ba09f40f24344a08
qid2767	SELECT 招聘人数 WHERE 职位名称 == "财政金融领域研究"	a9b2ead13b0611e9ba09f40f24344a08
qid2768	SELECT 中文原著作者或主编 WHERE 中文原著名称 == "道家的人文精神"	a9a01bd13b0611e98f84f40f24344a08
qid2769	SELECT 中文原著作者或主编 WHERE 中文原著名称 == "道家的人文精神"	a9a01bd13b0611e98f84f40f24344a08
qid2770	SELECT 中文原著作者或主编 WHERE 中文原著名称 == "道家的人文精神"	a9a01bd13b0611e98f84f40f24344a08
qid2771	SELECT 企业名称 WHERE 产品名称 == "餐具洗涤剂"	f20adce8453d11e9b411f40f24344a08
qid2772	SELECT 企业名称 WHERE 产品名称 == "餐具洗涤剂"	f20adce8453d11e9b411f40f24344a08
qid2773	SELECT 企业名称 WHERE 产品名称 == "餐具洗涤剂"	f20adce8453d11e9b411f40f24344a08
qid2774	SELECT 学历 WHERE 招聘单位 == "来安县张山镇卫生院" and 招聘岗位 == "专业技术"	f2ea43f8453d11e9812ef40f24344a08
qid2775	SELECT 学历 WHERE 招聘单位 == "来安县张山镇卫生院" and 招聘岗位 == "专业技术"	f2ea43f8453d11e9812ef40f24344a08
qid2776	SELECT 学历 WHERE 招聘单位 == "来安县张山镇卫生院" and 招聘岗位 == "专业技术"	f2ea43f8453d11e9812ef40f24344a08
qid2777	SELECT 企业名称 WHERE 产品名称 == "液晶电视机"	f540af0c453d11e98e15f40f24344a08
qid2778	SELECT 企业名称 WHERE 产品名称 == "液晶电视机"	f540af0c453d11e98e15f40f24344a08
qid2779	SELECT 企业名称 WHERE 产品名称 == "液晶电视机"	f540af0c453d11e98e15f40f24344a08
qid2780	SELECT 项目承担单位 , 项目名称 WHERE 所属市州 == "长沙市"	f313df91453d11e98122f40f24344a08
qid2781	SELECT 项目承担单位 , 项目名称 WHERE 所属市州 == "长沙市"	f313df91453d11e98122f40f24344a08
qid2782	SELECT 项目承担单位 , 项目名称 WHERE 所属市州 == "长沙市"	f313df91453d11e98122f40f24344a08
qid2783	SELECT COUNT ( 书名 ) WHERE 分类 == "成功励志"	aaf415eb3b0611e99aaef40f24344a08
qid2784	SELECT COUNT ( 书名 ) WHERE 分类 == "成功励志"	aaf415eb3b0611e99aaef40f24344a08
qid2785	SELECT COUNT ( 书名 ) WHERE 分类 == "成功励志"	aaf415eb3b0611e99aaef40f24344a08
qid2786	SELECT 申报单位 WHERE 项目名称 == "中关村笔记" or 项目名称 == "皖北大地"	a82730233b0611e9a8c5f40f24344a08
qid2787	SELECT 申报单位 WHERE 项目名称 == "中关村笔记" or 项目名称 == "皖北大地"	a82730233b0611e9a8c5f40f24344a08
qid2788	SELECT 申报单位 WHERE 项目名称 == "中关村笔记" or 项目名称 == "皖北大地"	a82730233b0611e9a8c5f40f24344a08
qid2789	SELECT ISBN/ISSN WHERE 题名 == "郁达夫自传" or 题名 == "冯玉祥自述"	a93d15fa3b0611e9813af40f24344a08
qid2790	SELECT ISBN/ISSN WHERE 题名 == "郁达夫自传" or 题名 == "冯玉祥自述"	a93d15fa3b0611e9813af40f24344a08
qid2791	SELECT ISBN/ISSN WHERE 题名 == "郁达夫自传" or 题名 == "冯玉祥自述"	a93d15fa3b0611e9813af40f24344a08
qid2792	SELECT 出版单位 WHERE 书名 == "居里夫人自传"	aa98115c3b0611e9acb1f40f24344a08
qid2793	SELECT 出版单位 WHERE 书名 == "居里夫人自传"	aa98115c3b0611e9acb1f40f24344a08
qid2794	SELECT 出版单位 WHERE 书名 == "居里夫人自传"	aa98115c3b0611e9acb1f40f24344a08
qid2795	SELECT 单位地址 , 经营范围 WHERE 单位名称 == "日照市残联爱心大药房"	abf229023b0611e99d1cf40f24344a08
qid2796	SELECT 单位地址 , 经营范围 WHERE 单位名称 == "日照市残联爱心大药房"	abf229023b0611e99d1cf40f24344a08
qid2797	SELECT 单位地址 , 经营范围 WHERE 单位名称 == "日照市残联爱心大药房"	abf229023b0611e99d1cf40f24344a08
qid2798	SELECT 性别 WHERE 系（科、室） == "胃肠外科" or 系（科、室） == "消化内科"	a8f4f7ab3b0611e9ab2ff40f24344a08
qid2799	SELECT 性别 WHERE 系（科、室） == "胃肠外科" or 系（科、室） == "消化内科"	a8f4f7ab3b0611e9ab2ff40f24344a08
qid2800	SELECT 性别 WHERE 系（科、室） == "胃肠外科" or 系（科、室） == "消化内科"	a8f4f7ab3b0611e9ab2ff40f24344a08
qid2801	SELECT 学历要求 WHERE 用人部门 == "污染防治科" and 招聘岗位 == "污染防治管理岗位"	a8afc74a3b0611e99996f40f24344a08
qid2802	SELECT 学历要求 WHERE 用人部门 == "污染防治科" and 招聘岗位 == "污染防治管理岗位"	a8afc74a3b0611e99996f40f24344a08
qid2803	SELECT 学历要求 WHERE 用人部门 == "污染防治科" and 招聘岗位 == "污染防治管理岗位"	a8afc74a3b0611e99996f40f24344a08
qid2804	SELECT 学历 WHERE 岗位名称 == "内科医师"	f4d14f7a453d11e99532f40f24344a08
qid2805	SELECT 学历 WHERE 岗位名称 == "内科医师"	f4d14f7a453d11e99532f40f24344a08
qid2806	SELECT 学历 WHERE 岗位名称 == "内科医师"	f4d14f7a453d11e99532f40f24344a08
qid2807	SELECT 生产日期/批号 WHERE 规格型号 == "散装" and 食品名称 == "香菇"	f0b57c19453d11e997dff40f24344a08
qid2808	SELECT 生产日期/批号 WHERE 规格型号 == "散装" and 食品名称 == "香菇"	f0b57c19453d11e997dff40f24344a08
qid2809	SELECT 生产日期/批号 WHERE 规格型号 == "散装" and 食品名称 == "香菇"	f0b57c19453d11e997dff40f24344a08
qid2810	SELECT 2018年学位（人） WHERE 学校名称 == "深圳市第三高级中学"	abf033913b0611e9abaef40f24344a08
qid2811	SELECT 2018年学位（人） WHERE 学校名称 == "深圳市第三高级中学"	abf033913b0611e9abaef40f24344a08
qid2812	SELECT 2018年学位（人） WHERE 学校名称 == "深圳市第三高级中学"	abf033913b0611e9abaef40f24344a08
qid2813	SELECT 标称生产企业地址 WHERE 规格型号 == "420ml/瓶" and 食品名称 == "厨邦纯米醋"	aabcd0303b0611e9b1caf40f24344a08
qid2814	SELECT 标称生产企业地址 WHERE 规格型号 == "420ml/瓶" and 食品名称 == "厨邦纯米醋"	aabcd0303b0611e9b1caf40f24344a08
qid2815	SELECT 标称生产企业地址 WHERE 规格型号 == "420ml/瓶" and 食品名称 == "厨邦纯米醋"	aabcd0303b0611e9b1caf40f24344a08
qid2816	SELECT 总学分 WHERE 课程名称 == "普通物理学" or 课程名称 == "金属工艺学"	ab899e3a3b0611e98266f40f24344a08
qid2817	SELECT 总学分 WHERE 课程名称 == "普通物理学" or 课程名称 == "金属工艺学"	ab899e3a3b0611e98266f40f24344a08
qid2818	SELECT 总学分 WHERE 课程名称 == "普通物理学" or 课程名称 == "金属工艺学"	ab899e3a3b0611e98266f40f24344a08
qid2819	SELECT 地址 WHERE 商家名称 == "建信车行"	a8ed47473b0611e9a623f40f24344a08
qid2820	SELECT 地址 WHERE 商家名称 == "建信车行"	a8ed47473b0611e9a623f40f24344a08
qid2821	SELECT 地址 WHERE 商家名称 == "建信车行"	a8ed47473b0611e9a623f40f24344a08
qid2822	SELECT 产品型号(车辆型号) WHERE 商标 == "福田牌" and 产品名称 == "商务车"	f451c5f5453d11e98f86f40f24344a08
qid2823	SELECT 产品型号(车辆型号) WHERE 商标 == "福田牌" and 产品名称 == "商务车"	f451c5f5453d11e98f86f40f24344a08
qid2824	SELECT 产品型号(车辆型号) WHERE 商标 == "福田牌" and 产品名称 == "商务车"	f451c5f5453d11e98f86f40f24344a08
qid2825	SELECT 作者 , 书名 WHERE 估定价 > "50"	a81232f03b0611e99f09f40f24344a08
qid2826	SELECT 作者 , 书名 WHERE 估定价 > "50"	a81232f03b0611e99f09f40f24344a08
qid2827	SELECT 作者 , 书名 WHERE 估定价 > "50"	a81232f03b0611e99f09f40f24344a08
qid2828	SELECT 题名 WHERE 出版者 == "花山文艺出版社" or 出版者 == "江苏凤凰文艺出版社"	f14c17cc453d11e98dbaf40f24344a08
qid2829	SELECT 题名 WHERE 出版者 == "花山文艺出版社" or 出版者 == "江苏凤凰文艺出版社"	f14c17cc453d11e98dbaf40f24344a08
qid2830	SELECT 题名 WHERE 出版者 == "花山文艺出版社" or 出版者 == "江苏凤凰文艺出版社"	f14c17cc453d11e98dbaf40f24344a08
qid2831	SELECT 适应区域 WHERE 品种名称 == "德宏象草" or 品种名称 == "奇台红豆草"	f344f828453d11e98b64f40f24344a08
qid2832	SELECT 适应区域 WHERE 品种名称 == "德宏象草" or 品种名称 == "奇台红豆草"	f344f828453d11e98b64f40f24344a08
qid2833	SELECT 适应区域 WHERE 品种名称 == "德宏象草" or 品种名称 == "奇台红豆草"	f344f828453d11e98b64f40f24344a08
qid2834	SELECT 出版社 WHERE 授权书名 == "西岭雪探秘红楼梦"	ab2b65193b0611e9a38ef40f24344a08
qid2835	SELECT 出版社 WHERE 授权书名 == "西岭雪探秘红楼梦"	ab2b65193b0611e9a38ef40f24344a08
qid2836	SELECT 总录取人数 WHERE 专业名称 == "海洋油气工程" and 类型 == "学术"	a9bb55143b0611e9aaeaf40f24344a08
qid2837	SELECT 总录取人数 WHERE 专业名称 == "海洋油气工程" and 类型 == "学术"	a9bb55143b0611e9aaeaf40f24344a08
qid2838	SELECT 电话 WHERE 辖区 == "宝安区" and 所在单位名称 == "沙井预防保健所"	a9e7b7803b0611e9b0ebf40f24344a08
qid2839	SELECT 电话 WHERE 辖区 == "宝安区" and 所在单位名称 == "沙井预防保健所"	a9e7b7803b0611e9b0ebf40f24344a08
qid2840	SELECT 电话 WHERE 辖区 == "宝安区" and 所在单位名称 == "沙井预防保健所"	a9e7b7803b0611e9b0ebf40f24344a08
qid2841	SELECT 抽样数量 WHERE 进出口 == "进口" and 商品描述 == "电饭锅"	abd8f86b3b0611e994c9f40f24344a08
qid2842	SELECT 抽样数量 WHERE 进出口 == "进口" and 商品描述 == "电饭锅"	abd8f86b3b0611e994c9f40f24344a08
qid2843	SELECT 专业名称 WHERE 考试时间 == "2018年01月16日" and 院校名称 == "吉林建筑大学"	a9622de83b0611e987bbf40f24344a08
qid2844	SELECT 专业名称 WHERE 考试时间 == "2018年01月16日" and 院校名称 == "吉林建筑大学"	a9622de83b0611e987bbf40f24344a08
qid2845	SELECT 专业名称 WHERE 考试时间 == "2018年01月16日" and 院校名称 == "吉林建筑大学"	a9622de83b0611e987bbf40f24344a08
qid2846	SELECT 学分 WHERE 课程名称 == "法律伦理学" or 课程名称 == "生命伦理学"	ab36c40a3b0611e9a803f40f24344a08
qid2847	SELECT 学分 WHERE 课程名称 == "法律伦理学" or 课程名称 == "生命伦理学"	ab36c40a3b0611e9a803f40f24344a08
qid2848	SELECT 学分 WHERE 课程名称 == "法律伦理学" or 课程名称 == "生命伦理学"	ab36c40a3b0611e9a803f40f24344a08
qid2849	SELECT 作者 WHERE 书目名称 == "时间简史"	f2f6d961453d11e9873af40f24344a08
qid2850	SELECT 作者 WHERE 书目名称 == "时间简史"	f2f6d961453d11e9873af40f24344a08
qid2851	SELECT 作者 WHERE 书目名称 == "时间简史"	f2f6d961453d11e9873af40f24344a08
qid2852	SELECT 出版时间 WHERE 作者 == "黄成兰" and 书名 == "10000条成语词典（双色）"	f5234f66453d11e99a38f40f24344a08
qid2853	SELECT 出版时间 WHERE 作者 == "黄成兰" and 书名 == "10000条成语词典（双色）"	f5234f66453d11e99a38f40f24344a08
qid2854	SELECT 出版时间 WHERE 作者 == "黄成兰" and 书名 == "10000条成语词典（双色）"	f5234f66453d11e99a38f40f24344a08
qid2855	SELECT 检品名称 WHERE 检验结果 == "合格" and 检验单位 == "张掖市食品药品检验检测中心"	a87c690c3b0611e9bf99f40f24344a08
qid2856	SELECT 检品名称 WHERE 检验结果 == "合格" and 检验单位 == "张掖市食品药品检验检测中心"	a87c690c3b0611e9bf99f40f24344a08
qid2857	SELECT 检品名称 WHERE 检验结果 == "合格" and 检验单位 == "张掖市食品药品检验检测中心"	a87c690c3b0611e9bf99f40f24344a08
qid2858	SELECT 读者对象 WHERE 书名 == "小肝癌的多学科治疗"	aaea0ae83b0611e9b8c0f40f24344a08
qid2859	SELECT 读者对象 WHERE 书名 == "小肝癌的多学科治疗"	aaea0ae83b0611e9b8c0f40f24344a08
qid2860	SELECT 读者对象 WHERE 书名 == "小肝癌的多学科治疗"	aaea0ae83b0611e9b8c0f40f24344a08
qid2861	SELECT 抽查结果 WHERE 企业名称 == "上海瀚唯科技有限公司" and 企业所在地 == "上海市" and 产品名称 == "LED面型灯"	a858ac113b0611e98400f40f24344a08
qid2862	SELECT 抽查结果 WHERE 企业名称 == "上海瀚唯科技有限公司" and 企业所在地 == "上海市" and 产品名称 == "LED面型灯"	a858ac113b0611e98400f40f24344a08
qid2863	SELECT 抽查结果 WHERE 企业名称 == "上海瀚唯科技有限公司" and 企业所在地 == "上海市" and 产品名称 == "LED面型灯"	a858ac113b0611e98400f40f24344a08
qid2864	SELECT 作者 WHERE 书名 == "拾年"	abeb19003b0611e98c46f40f24344a08
qid2865	SELECT 作者 WHERE 书名 == "拾年"	abeb19003b0611e98c46f40f24344a08
qid2866	SELECT 作者 WHERE 书名 == "拾年"	abeb19003b0611e98c46f40f24344a08
qid2867	SELECT 项目名称 WHERE 科室 == "骨科" and 所在单位 == "广州军区广州总医院"	aaeba0cc3b0611e9bf38f40f24344a08
qid2868	SELECT 项目名称 WHERE 科室 == "骨科" and 所在单位 == "广州军区广州总医院"	aaeba0cc3b0611e9bf38f40f24344a08
qid2869	SELECT 项目名称 WHERE 科室 == "骨科" and 所在单位 == "广州军区广州总医院"	aaeba0cc3b0611e9bf38f40f24344a08
qid2870	SELECT 专业名称 WHERE 院部名称 == "教育学部"	a905f3eb3b0611e9896bf40f24344a08
qid2871	SELECT 专业名称 WHERE 院部名称 == "教育学部"	a905f3eb3b0611e9896bf40f24344a08
qid2872	SELECT 专业名称 WHERE 院部名称 == "教育学部"	a905f3eb3b0611e9896bf40f24344a08
qid2873	SELECT 奖项 WHERE 节目名称 == "《yestertoday》" and 学校 == "天津市第四十五中学"	f047e068453d11e99818f40f24344a08
qid2874	SELECT 奖项 WHERE 节目名称 == "《yestertoday》" and 学校 == "天津市第四十五中学"	f047e068453d11e99818f40f24344a08
qid2875	SELECT 奖项 WHERE 节目名称 == "《yestertoday》" and 学校 == "天津市第四十五中学"	f047e068453d11e99818f40f24344a08
qid2876	SELECT 产品名称 WHERE 所在地 == "河北省" and 企业名称 == "河北恒德陶瓷有限公司"	f42a70b0453d11e98b57f40f24344a08
qid2877	SELECT 产品名称 WHERE 所在地 == "河北省" and 企业名称 == "河北恒德陶瓷有限公司"	f42a70b0453d11e98b57f40f24344a08
qid2878	SELECT 征文题目 WHERE 省份 == "广东"	f51a0d28453d11e986e5f40f24344a08
qid2879	SELECT 征文题目 WHERE 省份 == "广东"	f51a0d28453d11e986e5f40f24344a08
qid2880	SELECT 答辩时间 WHERE 所在学院 == "艺术学院" and 专业名称 == "环境设计"	f01d0e1c453d11e98cd7f40f24344a08
qid2881	SELECT 答辩时间 WHERE 所在学院 == "艺术学院" and 专业名称 == "环境设计"	f01d0e1c453d11e98cd7f40f24344a08
qid2882	SELECT 答辩时间 WHERE 所在学院 == "艺术学院" and 专业名称 == "环境设计"	f01d0e1c453d11e98cd7f40f24344a08
qid2883	SELECT 抽查结果 WHERE 规格型号 == "500ml/瓶" and 产品名称 == "统一冰红茶(柠檬味红茶饮料)"	ef2ebbae453d11e9b19ef40f24344a08
qid2884	SELECT 抽查结果 WHERE 规格型号 == "500ml/瓶" and 产品名称 == "统一冰红茶(柠檬味红茶饮料)"	ef2ebbae453d11e9b19ef40f24344a08
qid2885	SELECT 抽查结果 WHERE 规格型号 == "500ml/瓶" and 产品名称 == "统一冰红茶(柠檬味红茶饮料)"	ef2ebbae453d11e9b19ef40f24344a08
qid2886	SELECT 使用场地 WHERE 品牌 == "进丰灯饰" and 灯具名称 == "吊灯"	ef55adfd453d11e9ba56f40f24344a08
qid2887	SELECT 使用场地 WHERE 品牌 == "进丰灯饰" and 灯具名称 == "吊灯"	ef55adfd453d11e9ba56f40f24344a08
qid2888	SELECT 使用场地 WHERE 品牌 == "进丰灯饰" and 灯具名称 == "吊灯"	ef55adfd453d11e9ba56f40f24344a08
qid2889	SELECT 集数 WHERE 引进单位 == "中国国际电视总公司" and 剧名 == "哈克·费恩历险记"	aa6e7e6e3b0611e993fbf40f24344a08
qid2890	SELECT 集数 WHERE 引进单位 == "中国国际电视总公司" and 剧名 == "哈克·费恩历险记"	aa6e7e6e3b0611e993fbf40f24344a08
qid2891	SELECT 集数 WHERE 引进单位 == "中国国际电视总公司" and 剧名 == "哈克·费恩历险记"	aa6e7e6e3b0611e993fbf40f24344a08
qid2892	SELECT 展会时间 WHERE 展会名称 == "国际医药原料印尼展览会"	f2f79b66453d11e9bd85f40f24344a08
qid2893	SELECT 展会时间 WHERE 展会名称 == "国际医药原料印尼展览会"	f2f79b66453d11e9bd85f40f24344a08
qid2894	SELECT 展会时间 WHERE 展会名称 == "国际医药原料印尼展览会"	f2f79b66453d11e9bd85f40f24344a08
qid2895	SELECT 学历要求 WHERE 招聘单位 == "汕尾市技工学校" and 岗位名称 == "教师"	ee290cfa453d11e9a6f2f40f24344a08
qid2896	SELECT 学历要求 WHERE 招聘单位 == "汕尾市技工学校" and 岗位名称 == "教师"	ee290cfa453d11e9a6f2f40f24344a08
qid2897	SELECT 学历要求 WHERE 招聘单位 == "汕尾市技工学校" and 岗位名称 == "教师"	ee290cfa453d11e9a6f2f40f24344a08
qid2898	SELECT 课程名 WHERE 考场 == "B402"	f6106b1e453d11e9aad1f40f24344a08
qid2899	SELECT 课程名 WHERE 考场 == "B402"	f6106b1e453d11e9aad1f40f24344a08
qid2900	SELECT 课程名 WHERE 考场 == "B402"	f6106b1e453d11e9aad1f40f24344a08
qid2901	SELECT COUNT ( 水源地名称 ) WHERE 所在地 == "宝鸡市陈仓区"	aa2d6ff03b0611e9a373f40f24344a08
qid2902	SELECT COUNT ( 水源地名称 ) WHERE 所在地 == "宝鸡市陈仓区"	aa2d6ff03b0611e9a373f40f24344a08
qid2903	SELECT COUNT ( 水源地名称 ) WHERE 所在地 == "宝鸡市陈仓区"	aa2d6ff03b0611e9a373f40f24344a08
qid2904	SELECT 书名 , 著者 WHERE 出版地 == "北京" and 出版社 == "人民文学出版社"	edabdc75453d11e9b4d3f40f24344a08
qid2905	SELECT 书名 , 著者 WHERE 出版地 == "北京" and 出版社 == "人民文学出版社"	edabdc75453d11e9b4d3f40f24344a08
qid2906	SELECT 书名 , 著者 WHERE 出版地 == "北京" and 出版社 == "人民文学出版社"	edabdc75453d11e9b4d3f40f24344a08
qid2907	SELECT 申报单位 , 申报单位推荐的生产单位 WHERE 申报产品 == "沙窝萝卜"	a9a3a5513b0611e9a56ef40f24344a08
qid2908	SELECT 申报单位 , 申报单位推荐的生产单位 WHERE 申报产品 == "沙窝萝卜"	a9a3a5513b0611e9a56ef40f24344a08
qid2909	SELECT 申报单位 , 申报单位推荐的生产单位 WHERE 申报产品 == "沙窝萝卜"	a9a3a5513b0611e9a56ef40f24344a08
qid2910	SELECT 性别要求 WHERE 岗位名称 == "规划建设工作人员" or 岗位名称 == "市政园林工作人员"	ef52b5e8453d11e9ab65f40f24344a08
qid2911	SELECT 性别要求 WHERE 岗位名称 == "规划建设工作人员" or 岗位名称 == "市政园林工作人员"	ef52b5e8453d11e9ab65f40f24344a08
qid2912	SELECT 性别要求 WHERE 岗位名称 == "规划建设工作人员" or 岗位名称 == "市政园林工作人员"	ef52b5e8453d11e9ab65f40f24344a08
qid2913	SELECT 学制 WHERE 专业名称 == "市场营销" or 专业名称 == "物流管理"	f219c191453d11e99e24f40f24344a08
qid2914	SELECT 学制 WHERE 专业名称 == "市场营销" or 专业名称 == "物流管理"	f219c191453d11e99e24f40f24344a08
qid2915	SELECT 学制 WHERE 专业名称 == "市场营销" or 专业名称 == "物流管理"	f219c191453d11e99e24f40f24344a08
qid2916	SELECT 承检机构 WHERE 产品名称 == "液晶显示器" and 规格型号 == "VS16463"	f08ebb2b453d11e99795f40f24344a08
qid2917	SELECT 承检机构 WHERE 产品名称 == "液晶显示器" and 规格型号 == "VS16463"	f08ebb2b453d11e99795f40f24344a08
qid2918	SELECT 承检机构 WHERE 产品名称 == "液晶显示器" and 规格型号 == "VS16463"	f08ebb2b453d11e99795f40f24344a08
qid2919	SELECT 专业要求 WHERE 单位 == "奉化区中医医院" and 需求岗位 == "财务科"	a8463af03b0611e98f4cf40f24344a08
qid2920	SELECT 专业要求 WHERE 单位 == "奉化区中医医院" and 需求岗位 == "财务科"	a8463af03b0611e98f4cf40f24344a08
qid2921	SELECT 专业要求 WHERE 单位 == "奉化区中医医院" and 需求岗位 == "财务科"	a8463af03b0611e98f4cf40f24344a08
qid2922	SELECT 指导老师 WHERE 作品名称 == "学在田园、乐由心生" or 作品名称 == "发现我们身边的思品课"	f6129eb8453d11e99513f40f24344a08
qid2923	SELECT 指导老师 WHERE 作品名称 == "学在田园、乐由心生" or 作品名称 == "发现我们身边的思品课"	f6129eb8453d11e99513f40f24344a08
qid2924	SELECT 指导老师 WHERE 作品名称 == "学在田园、乐由心生" or 作品名称 == "发现我们身边的思品课"	f6129eb8453d11e99513f40f24344a08
qid2925	SELECT COUNT ( 考试科目 ) WHERE 考核方式 == "开卷"	f0433cb5453d11e9bc46f40f24344a08
qid2926	SELECT COUNT ( 考试科目 ) WHERE 考核方式 == "开卷"	f0433cb5453d11e9bc46f40f24344a08
qid2927	SELECT COUNT ( 考试科目 ) WHERE 考核方式 == "开卷"	f0433cb5453d11e9bc46f40f24344a08
qid2928	SELECT 项目名称 WHERE 许可内容 == "餐馆" and 许可类别 == "普通"	abcabfb53b0611e98d85f40f24344a08
qid2929	SELECT 项目名称 WHERE 许可内容 == "餐馆" and 许可类别 == "普通"	abcabfb53b0611e98d85f40f24344a08
qid2930	SELECT 项目名称 WHERE 许可内容 == "餐馆" and 许可类别 == "普通"	abcabfb53b0611e98d85f40f24344a08
qid2931	SELECT 被抽样单位名称 WHERE 被抽样单位所在省份 == "上海"	aac1dbf33b0611e9984af40f24344a08
qid2932	SELECT 被抽样单位名称 WHERE 被抽样单位所在省份 == "上海"	aac1dbf33b0611e9984af40f24344a08
qid2933	SELECT 被抽样单位名称 WHERE 被抽样单位所在省份 == "上海"	aac1dbf33b0611e9984af40f24344a08
qid2934	SELECT 作者 WHERE 版面 == "头版" and 稿件名称 == "用奋斗开创幸福未来"	aa468ae33b0611e9a592f40f24344a08
qid2935	SELECT 作者 WHERE 版面 == "头版" and 稿件名称 == "用奋斗开创幸福未来"	aa468ae33b0611e9a592f40f24344a08
qid2936	SELECT 作者 WHERE 版面 == "头版" and 稿件名称 == "用奋斗开创幸福未来"	aa468ae33b0611e9a592f40f24344a08
qid2937	SELECT 学费（元/生） WHERE 开设单位 == "商学院" and 专业名称 == "市场营销"	aae6e1753b0611e9a8a0f40f24344a08
qid2938	SELECT 学费（元/生） WHERE 开设单位 == "商学院" and 专业名称 == "市场营销"	aae6e1753b0611e9a8a0f40f24344a08
qid2939	SELECT 学费（元/生） WHERE 开设单位 == "商学院" and 专业名称 == "市场营销"	aae6e1753b0611e9a8a0f40f24344a08
qid2940	SELECT 作者 WHERE 书名 == "刺客之死" or 书名 == "麒麟阁"	a9e2b8ca3b0611e9a062f40f24344a08
qid2941	SELECT 作者 WHERE 书名 == "刺客之死" or 书名 == "麒麟阁"	a9e2b8ca3b0611e9a062f40f24344a08
qid2942	SELECT 作者 WHERE 书名 == "刺客之死" or 书名 == "麒麟阁"	a9e2b8ca3b0611e9a062f40f24344a08
qid2943	SELECT 书号（ISBN) WHERE 教材名称 == "线性代数" or 教材名称 == "中级有机化学"	ef1dbdb8453d11e9961df40f24344a08
qid2944	SELECT 书号（ISBN) WHERE 教材名称 == "线性代数" or 教材名称 == "中级有机化学"	ef1dbdb8453d11e9961df40f24344a08
qid2945	SELECT 书号（ISBN) WHERE 教材名称 == "线性代数" or 教材名称 == "中级有机化学"	ef1dbdb8453d11e9961df40f24344a08
qid2946	SELECT 开展人数 WHERE 医疗机构名称 == "怀来同济医院" and 医疗技术名称 == "血液透析治疗技术"	f15ceba6453d11e9b0d6f40f24344a08
qid2947	SELECT 开展人数 WHERE 医疗机构名称 == "怀来同济医院" and 医疗技术名称 == "血液透析治疗技术"	f15ceba6453d11e9b0d6f40f24344a08
qid2948	SELECT 开展人数 WHERE 医疗机构名称 == "怀来同济医院" and 医疗技术名称 == "血液透析治疗技术"	f15ceba6453d11e9b0d6f40f24344a08
qid2949	SELECT 地址 WHERE 名称 == "葡京分行"	f45411eb453d11e9be2bf40f24344a08
qid2950	SELECT 地址 WHERE 名称 == "葡京分行"	f45411eb453d11e9be2bf40f24344a08
qid2951	SELECT 地址 WHERE 名称 == "葡京分行"	f45411eb453d11e9be2bf40f24344a08
qid2952	SELECT 中介服务项目收费依据及标准 WHERE 中介服务项目类别 == "自主类" or 中介服务项目服务时限 == "双方协商约定"	a8c0e15e3b0611e9bb85f40f24344a08
qid2953	SELECT 中介服务项目收费依据及标准 WHERE 中介服务项目类别 == "自主类" or 中介服务项目服务时限 == "双方协商约定"	a8c0e15e3b0611e9bb85f40f24344a08
qid2954	SELECT 中介服务项目收费依据及标准 WHERE 中介服务项目类别 == "自主类" or 中介服务项目服务时限 == "双方协商约定"	a8c0e15e3b0611e9bb85f40f24344a08
qid2955	SELECT SUM ( 分值 ) WHERE 考核内容 == "稳定粮食播种面积" or 考核内容 == "稳定提高粮食产量"	a85a80b53b0611e9934cf40f24344a08
qid2956	SELECT SUM ( 分值 ) WHERE 考核内容 == "稳定粮食播种面积" or 考核内容 == "稳定提高粮食产量"	a85a80b53b0611e9934cf40f24344a08
qid2957	SELECT SUM ( 分值 ) WHERE 考核内容 == "稳定粮食播种面积" or 考核内容 == "稳定提高粮食产量"	a85a80b53b0611e9934cf40f24344a08
qid2958	SELECT 项目名称 WHERE 建设内容及规模 == "2015年棚户区改造配套基础设施建设，其中用于采煤沉陷区棚户区改造2651万元。" or 下达计划文号 == "黑发改投资[2015]228号"	a8cb77383b0611e9abbaf40f24344a08
qid2959	SELECT 项目名称 WHERE 建设内容及规模 == "2015年棚户区改造配套基础设施建设，其中用于采煤沉陷区棚户区改造2651万元。" or 下达计划文号 == "黑发改投资[2015]228号"	a8cb77383b0611e9abbaf40f24344a08
qid2960	SELECT 项目名称 WHERE 建设内容及规模 == "2015年棚户区改造配套基础设施建设，其中用于采煤沉陷区棚户区改造2651万元。" or 下达计划文号 == "黑发改投资[2015]228号"	a8cb77383b0611e9abbaf40f24344a08
qid2961	SELECT 生产日期或批号 WHERE 商标 == "木林森" and 产品名称 == "LED路灯"	ab4729613b0611e9a5aff40f24344a08
qid2962	SELECT 生产日期或批号 WHERE 商标 == "木林森" and 产品名称 == "LED路灯"	ab4729613b0611e9a5aff40f24344a08
qid2963	SELECT 生产日期或批号 WHERE 商标 == "木林森" and 产品名称 == "LED路灯"	ab4729613b0611e9a5aff40f24344a08
qid2964	SELECT 放映时间 WHERE 单位 == "张江镇江丰剧场" and 地址 == "益江路335号"	eee0bba1453d11e9a912f40f24344a08
qid2965	SELECT 放映时间 WHERE 单位 == "张江镇江丰剧场" and 地址 == "益江路335号"	eee0bba1453d11e9a912f40f24344a08
qid2966	SELECT 放映时间 WHERE 单位 == "张江镇江丰剧场" and 地址 == "益江路335号"	eee0bba1453d11e9a912f40f24344a08
qid2967	SELECT 名称 WHERE 底价 == "2500.00元"	eda780a3453d11e9817df40f24344a08
qid2968	SELECT 名称 WHERE 底价 == "2500.00元"	eda780a3453d11e9817df40f24344a08
qid2969	SELECT 名　称 WHERE 地　址 == "武隆县" and 级　别 == "世界自然遗产"	a8458f9c3b0611e9beabf40f24344a08
qid2970	SELECT 名　称 WHERE 地　址 == "武隆县" and 级　别 == "世界自然遗产"	a8458f9c3b0611e9beabf40f24344a08
qid2971	SELECT 名　称 WHERE 地　址 == "武隆县" and 级　别 == "世界自然遗产"	a8458f9c3b0611e9beabf40f24344a08
qid2972	SELECT 产品名称 WHERE 企业名称 == "郑州飞马机电有限公司" or 企业名称 == "河南千里机械有限公司"	f0cf63f0453d11e9a0d5f40f24344a08
qid2973	SELECT 产品名称 WHERE 企业名称 == "郑州飞马机电有限公司" or 企业名称 == "河南千里机械有限公司"	f0cf63f0453d11e9a0d5f40f24344a08
qid2974	SELECT 产品名称 WHERE 企业名称 == "郑州飞马机电有限公司" or 企业名称 == "河南千里机械有限公司"	f0cf63f0453d11e9a0d5f40f24344a08
qid2975	SELECT 设备型号 WHERE 生产企业 == "AISINAWCO.,LTD." or 设备名称 == "WCDMA无线数据终端"	ab41b0023b0611e9837bf40f24344a08
qid2976	SELECT 设备型号 WHERE 生产企业 == "AISINAWCO.,LTD." or 设备名称 == "WCDMA无线数据终端"	ab41b0023b0611e9837bf40f24344a08
qid2977	SELECT 设备型号 WHERE 生产企业 == "AISINAWCO.,LTD." or 设备名称 == "WCDMA无线数据终端"	ab41b0023b0611e9837bf40f24344a08
qid2978	SELECT 论文题目 WHERE 学院 == "公共管理学院" and 作者 == "许子妍"	ee6d214a453d11e99867f40f24344a08
qid2979	SELECT 论文题目 WHERE 学院 == "公共管理学院" and 作者 == "许子妍"	ee6d214a453d11e99867f40f24344a08
qid2980	SELECT 论文题目 WHERE 学院 == "公共管理学院" and 作者 == "许子妍"	ee6d214a453d11e99867f40f24344a08
qid2981	SELECT 展区 WHERE 公司名称 == "梅里亚动物保健有限公司"	ee7360fd453d11e9a8a8f40f24344a08
qid2982	SELECT 展区 WHERE 公司名称 == "梅里亚动物保健有限公司"	ee7360fd453d11e9a8a8f40f24344a08
qid2983	SELECT 展区 WHERE 公司名称 == "梅里亚动物保健有限公司"	ee7360fd453d11e9a8a8f40f24344a08
qid2984	SELECT 试验示范站（基地） , 负责人 WHERE 依托单位 == "林学院"	a8aff1173b0611e9bbb1f40f24344a08
qid2985	SELECT 试验示范站（基地） , 负责人 WHERE 依托单位 == "林学院"	a8aff1173b0611e9bbb1f40f24344a08
qid2986	SELECT 试验示范站（基地） , 负责人 WHERE 依托单位 == "林学院"	a8aff1173b0611e9bbb1f40f24344a08
qid2987	SELECT 生产日期/批号 WHERE 规格型号 == "定量：16.5g/㎡2层" and 产品名称 == "餐巾纸"	aa756ce33b0611e9bc8bf40f24344a08
qid2988	SELECT 生产日期/批号 WHERE 规格型号 == "定量：16.5g/㎡2层" and 产品名称 == "餐巾纸"	aa756ce33b0611e9bc8bf40f24344a08
qid2989	SELECT 企业名称 WHERE 规格型号 == "6228MC3" and 产品名称 == "深沟球轴承"	f132d714453d11e98e09f40f24344a08
qid2990	SELECT 企业名称 WHERE 规格型号 == "6228MC3" and 产品名称 == "深沟球轴承"	f132d714453d11e98e09f40f24344a08
qid2991	SELECT 企业名称 WHERE 规格型号 == "6228MC3" and 产品名称 == "深沟球轴承"	f132d714453d11e98e09f40f24344a08
qid2992	SELECT 需购数量 WHERE 实验室名称 == "人体形态学实验室" and 物品名称 == "整尸体"	f027a9cf453d11e98891f40f24344a08
qid2993	SELECT 需购数量 WHERE 实验室名称 == "人体形态学实验室" and 物品名称 == "整尸体"	f027a9cf453d11e98891f40f24344a08
qid2994	SELECT 版别名称 WHERE 作者 == "郭湛著" and 书名 == "面向实践的反思"	a9a0e92b3b0611e9be21f40f24344a08
qid2995	SELECT 版别名称 WHERE 作者 == "郭湛著" and 书名 == "面向实践的反思"	a9a0e92b3b0611e9be21f40f24344a08
qid2996	SELECT 专业要求 , 学历学位要求 WHERE 岗位名称 == "文秘人员"	a9ff6f403b0611e99712f40f24344a08
qid2997	SELECT 专业要求 , 学历学位要求 WHERE 岗位名称 == "文秘人员"	a9ff6f403b0611e99712f40f24344a08
qid2998	SELECT 专业要求 , 学历学位要求 WHERE 岗位名称 == "文秘人员"	a9ff6f403b0611e99712f40f24344a08
qid2999	SELECT 学习活动内容 WHERE 学习活动形式 == "集中学习" and 负责部门 == "校党委"	a96104403b0611e9adeff40f24344a08
qid3000	SELECT 学习活动内容 WHERE 学习活动形式 == "集中学习" and 负责部门 == "校党委"	a96104403b0611e9adeff40f24344a08
qid3001	SELECT 学习活动内容 WHERE 学习活动形式 == "集中学习" and 负责部门 == "校党委"	a96104403b0611e9adeff40f24344a08
qid3002	SELECT 定价 WHERE 书名 == "建筑力学"	ab6a49d73b0611e98f77f40f24344a08
qid3003	SELECT 定价 WHERE 书名 == "建筑力学"	ab6a49d73b0611e98f77f40f24344a08
qid3004	SELECT 定价 WHERE 书名 == "建筑力学"	ab6a49d73b0611e98f77f40f24344a08
qid3005	SELECT 著者 WHERE 书名 == "世界原本"	ab5ac86e3b0611e98633f40f24344a08
qid3006	SELECT 著者 WHERE 书名 == "世界原本"	ab5ac86e3b0611e98633f40f24344a08
qid3007	SELECT 著者 WHERE 书名 == "世界原本"	ab5ac86e3b0611e98633f40f24344a08
qid3008	SELECT 拟招聘岗位 WHERE 招聘名额 > "1" or 学历 == "本科及以上"	f5289302453d11e98a09f40f24344a08
qid3009	SELECT 拟招聘岗位 WHERE 招聘名额 > "1" or 学历 == "本科及以上"	f5289302453d11e98a09f40f24344a08
qid3010	SELECT 拟招聘岗位 WHERE 招聘名额 > "1" or 学历 == "本科及以上"	f5289302453d11e98a09f40f24344a08
qid3011	SELECT 标称生产企业名称 WHERE 生产日期/批号 == "42795" and 食品名称 == "辣椒面"	f3e1dbf3453d11e9b1d6f40f24344a08
qid3012	SELECT 标称生产企业名称 WHERE 生产日期/批号 == "42795" and 食品名称 == "辣椒面"	f3e1dbf3453d11e9b1d6f40f24344a08
qid3013	SELECT 标称生产企业名称 WHERE 生产日期/批号 == "42795" and 食品名称 == "辣椒面"	f3e1dbf3453d11e9b1d6f40f24344a08
qid3014	SELECT 题名 , 责任者 WHERE 出版社 == "北京师范大学出版社"	a98b097d3b0611e9a7e3f40f24344a08
qid3015	SELECT 题名 , 责任者 WHERE 出版社 == "北京师范大学出版社"	a98b097d3b0611e9a7e3f40f24344a08
qid3016	SELECT 题名 , 责任者 WHERE 出版社 == "北京师范大学出版社"	a98b097d3b0611e9a7e3f40f24344a08
qid3017	SELECT 俱乐部 WHERE 审核情况 == "通过" and 已获等级 == "AAA"	ee6850e8453d11e9ad86f40f24344a08
qid3018	SELECT 俱乐部 WHERE 审核情况 == "通过" and 已获等级 == "AAA"	ee6850e8453d11e9ad86f40f24344a08
qid3019	SELECT 俱乐部 WHERE 审核情况 == "通过" and 已获等级 == "AAA"	ee6850e8453d11e9ad86f40f24344a08
qid3020	SELECT 抽查结果 WHERE 企业名称 == "天津市东方制桶厂" and 产品名称 == "包装容器闭口钢桶"	eefea25c453d11e99547f40f24344a08
qid3021	SELECT 抽查结果 WHERE 企业名称 == "天津市东方制桶厂" and 产品名称 == "包装容器闭口钢桶"	eefea25c453d11e99547f40f24344a08
qid3022	SELECT 抽查结果 WHERE 企业名称 == "天津市东方制桶厂" and 产品名称 == "包装容器闭口钢桶"	eefea25c453d11e99547f40f24344a08
qid3023	SELECT 份数 WHERE 报刊名称 == "经济日报" and 刊期 == "日报"	a9e93bb33b0611e9b3faf40f24344a08
qid3024	SELECT 份数 WHERE 报刊名称 == "经济日报" and 刊期 == "日报"	a9e93bb33b0611e9b3faf40f24344a08
qid3025	SELECT 份数 WHERE 报刊名称 == "经济日报" and 刊期 == "日报"	a9e93bb33b0611e9b3faf40f24344a08
qid3026	SELECT 学时 WHERE 课程名称 == "军事技能训练"	ee91efcc453d11e9a743f40f24344a08
qid3027	SELECT 学时 WHERE 课程名称 == "军事技能训练"	ee91efcc453d11e9a743f40f24344a08
qid3028	SELECT 学时 WHERE 课程名称 == "军事技能训练"	ee91efcc453d11e9a743f40f24344a08
qid3029	SELECT 企业名称 WHERE 抽查结果 == "合格" and 产品名称 == "电磁灶"	f00da845453d11e98374f40f24344a08
qid3030	SELECT 企业名称 WHERE 抽查结果 == "合格" and 产品名称 == "电磁灶"	f00da845453d11e98374f40f24344a08
qid3031	SELECT 企业名称 WHERE 抽查结果 == "合格" and 产品名称 == "电磁灶"	f00da845453d11e98374f40f24344a08
qid3032	SELECT 产品名称 WHERE 所在地 == "天津市" and 企业名称 == "天津一诺塑料制品有限公司"	eefea25c453d11e99547f40f24344a08
qid3033	SELECT 产品名称 WHERE 所在地 == "天津市" and 企业名称 == "天津一诺塑料制品有限公司"	eefea25c453d11e99547f40f24344a08
qid3034	SELECT 产品名称 WHERE 所在地 == "天津市" and 企业名称 == "天津一诺塑料制品有限公司"	eefea25c453d11e99547f40f24344a08
qid3035	SELECT 数量 WHERE 设备使用部室 == "办公室" and 设备(配件)名称 == "投影机"	ab74d4a13b0611e9a708f40f24344a08
qid3036	SELECT 数量 WHERE 设备使用部室 == "办公室" and 设备(配件)名称 == "投影机"	ab74d4a13b0611e9a708f40f24344a08
qid3037	SELECT ISBN WHERE 题名 == "经济学的谎言"	f4c55bae453d11e98128f40f24344a08
qid3038	SELECT ISBN WHERE 题名 == "经济学的谎言"	f4c55bae453d11e98128f40f24344a08
qid3039	SELECT ISBN WHERE 题名 == "经济学的谎言"	f4c55bae453d11e98128f40f24344a08
qid3040	SELECT COUNT ( 审批部门 ) WHERE 行政许可事项编码 == "000000000002189230-XK-010-0000" or 行政许可事项名称 == "出版物批发单位设立、变更审批"	abe8cb8c3b0611e9934ef40f24344a08
qid3041	SELECT COUNT ( 审批部门 ) WHERE 行政许可事项编码 == "000000000002189230-XK-010-0000" or 行政许可事项名称 == "出版物批发单位设立、变更审批"	abe8cb8c3b0611e9934ef40f24344a08
qid3042	SELECT COUNT ( 审批部门 ) WHERE 行政许可事项编码 == "000000000002189230-XK-010-0000" or 行政许可事项名称 == "出版物批发单位设立、变更审批"	abe8cb8c3b0611e9934ef40f24344a08
qid3043	SELECT ISBN WHERE 题名 == "爱我海洋"	a7ea07753b0611e9be9bf40f24344a08
qid3044	SELECT ISBN WHERE 题名 == "爱我海洋"	a7ea07753b0611e9be9bf40f24344a08
qid3045	SELECT ISBN WHERE 题名 == "爱我海洋"	a7ea07753b0611e9be9bf40f24344a08
qid3046	SELECT 货物名称 WHERE 用途 == "食用" and 签发日期 == "2018-08-24"	a7af9cba3b0611e9ac76f40f24344a08
qid3047	SELECT 货物名称 WHERE 用途 == "食用" and 签发日期 == "2018-08-24"	a7af9cba3b0611e9ac76f40f24344a08
qid3048	SELECT 货物名称 WHERE 用途 == "食用" and 签发日期 == "2018-08-24"	a7af9cba3b0611e9ac76f40f24344a08
qid3049	SELECT 实施地点 WHERE 项目实施时间 == "2017年" and 项目学校 == "清水中学"	a9361aa13b0611e98ec8f40f24344a08
qid3050	SELECT 实施地点 WHERE 项目实施时间 == "2017年" and 项目学校 == "清水中学"	a9361aa13b0611e98ec8f40f24344a08
qid3051	SELECT 实施地点 WHERE 项目实施时间 == "2017年" and 项目学校 == "清水中学"	a9361aa13b0611e98ec8f40f24344a08
qid3052	SELECT 作者 , 出版者 WHERE 书名 == "让理财成为一种习惯"	aa5271073b0611e984c5f40f24344a08
qid3053	SELECT 作者 , 出版者 WHERE 书名 == "让理财成为一种习惯"	aa5271073b0611e984c5f40f24344a08
qid3054	SELECT 作者 , 出版者 WHERE 书名 == "让理财成为一种习惯"	aa5271073b0611e984c5f40f24344a08
qid3055	SELECT 引进单位 WHERE 类别 == "电影" and 剧名 == "绑架老板"	f42243eb453d11e9acb1f40f24344a08
qid3056	SELECT 引进单位 WHERE 类别 == "电影" and 剧名 == "绑架老板"	f42243eb453d11e9acb1f40f24344a08
qid3057	SELECT 引进单位 WHERE 类别 == "电影" and 剧名 == "绑架老板"	f42243eb453d11e9acb1f40f24344a08
qid3058	SELECT 不合格项目 WHERE 样品名称 == "甘草榄" and 检验结果 == "1.53g/kg"	f6494102453d11e9a13bf40f24344a08
qid3059	SELECT 建设内容及规模 WHERE 项目所在地 == "1、凤凰县" and 线路名称 == "神秘苗乡"	ab4109873b0611e9b3e1f40f24344a08
qid3060	SELECT 建设内容及规模 WHERE 项目所在地 == "1、凤凰县" and 线路名称 == "神秘苗乡"	ab4109873b0611e9b3e1f40f24344a08
qid3061	SELECT 建设内容及规模 WHERE 项目所在地 == "1、凤凰县" and 线路名称 == "神秘苗乡"	ab4109873b0611e9b3e1f40f24344a08
qid3062	SELECT 学分 WHERE 课程名称 == "专业外语"	f5126d4a453d11e98d84f40f24344a08
qid3063	SELECT 学分 WHERE 课程名称 == "专业外语"	f5126d4a453d11e98d84f40f24344a08
qid3064	SELECT 学分 WHERE 课程名称 == "专业外语"	f5126d4a453d11e98d84f40f24344a08
qid3065	SELECT 学历 WHERE 用人部门 == "体育工程学院" and 岗位名称 == "教师"	a9dbf7733b0611e9a6c4f40f24344a08
qid3066	SELECT 学历 WHERE 用人部门 == "体育工程学院" and 岗位名称 == "教师"	a9dbf7733b0611e9a6c4f40f24344a08
qid3067	SELECT 学历 WHERE 用人部门 == "体育工程学院" and 岗位名称 == "教师"	a9dbf7733b0611e9a6c4f40f24344a08
qid3068	SELECT 项目经费 WHERE 项目名称 == "水稻新品种选育及种子生产关键技术研究"	efcae6e6453d11e9a4d7f40f24344a08
qid3069	SELECT 项目经费 WHERE 项目名称 == "水稻新品种选育及种子生产关键技术研究"	efcae6e6453d11e9a4d7f40f24344a08
qid3070	SELECT 项目经费 WHERE 项目名称 == "水稻新品种选育及种子生产关键技术研究"	efcae6e6453d11e9a4d7f40f24344a08
qid3071	SELECT 时间 WHERE 活动名称 == "鼓楼民国旅游文化收藏展" and 举办城市或地区 == "南京市"	aa7a73eb3b0611e9931cf40f24344a08
qid3072	SELECT 时间 WHERE 活动名称 == "鼓楼民国旅游文化收藏展" and 举办城市或地区 == "南京市"	aa7a73eb3b0611e9931cf40f24344a08
qid3073	SELECT 时间 WHERE 活动名称 == "鼓楼民国旅游文化收藏展" and 举办城市或地区 == "南京市"	aa7a73eb3b0611e9931cf40f24344a08
qid3074	SELECT 题名 WHERE 出版社 == "东南大学出版社" and 出版年 == "2013"	aa5507053b0611e9bda8f40f24344a08
qid3075	SELECT 题名 WHERE 出版社 == "东南大学出版社" and 出版年 == "2013"	aa5507053b0611e9bda8f40f24344a08
qid3076	SELECT 题名 WHERE 出版社 == "东南大学出版社" and 出版年 == "2013"	aa5507053b0611e9bda8f40f24344a08
qid3077	SELECT 出版者 WHERE 题名 == "你就是不懂忍耐" and 责任者 == "郑一编著"	f6a4c8ba453d11e994f9f40f24344a08
qid3078	SELECT 出版者 WHERE 题名 == "你就是不懂忍耐" and 责任者 == "郑一编著"	f6a4c8ba453d11e994f9f40f24344a08
qid3079	SELECT 出版者 WHERE 题名 == "你就是不懂忍耐" and 责任者 == "郑一编著"	f6a4c8ba453d11e994f9f40f24344a08
qid3080	SELECT 生产厂家 WHERE 规格型号/技术指标 == "BP-U60" and 仪器设备名称 == "原装电池"	f4535900453d11e9a078f40f24344a08
qid3081	SELECT 生产厂家 WHERE 规格型号/技术指标 == "BP-U60" and 仪器设备名称 == "原装电池"	f4535900453d11e9a078f40f24344a08
qid3082	SELECT 生产厂家 WHERE 规格型号/技术指标 == "BP-U60" and 仪器设备名称 == "原装电池"	f4535900453d11e9a078f40f24344a08
qid3083	SELECT 课程名称 WHERE 开课校区 == "大学城校区" and 限选人数 == "100"	f3487554453d11e9a4e6f40f24344a08
qid3084	SELECT 课程名称 WHERE 开课校区 == "大学城校区" and 限选人数 == "100"	f3487554453d11e9a4e6f40f24344a08
qid3085	SELECT 课程名称 WHERE 开课校区 == "大学城校区" and 限选人数 == "100"	f3487554453d11e9a4e6f40f24344a08
qid3086	SELECT 详细地址 WHERE 机构名称 == "城西兵团支行营业处"	ee14565c453d11e98edcf40f24344a08
qid3087	SELECT 详细地址 WHERE 机构名称 == "城西兵团支行营业处"	ee14565c453d11e98edcf40f24344a08
qid3088	SELECT 详细地址 WHERE 机构名称 == "城西兵团支行营业处"	ee14565c453d11e98edcf40f24344a08
qid3089	SELECT 抽样编号 WHERE 被抽样单位名称 == "眉县齐镇昌浩粮油店"	aaf7fd683b0611e981c5f40f24344a08
qid3090	SELECT 抽样编号 WHERE 被抽样单位名称 == "眉县齐镇昌浩粮油店"	aaf7fd683b0611e981c5f40f24344a08
qid3091	SELECT 单价/元 WHERE 书名 == "国际1级心算"	f6ade8c0453d11e98dd9f40f24344a08
qid3092	SELECT 单价/元 WHERE 书名 == "国际1级心算"	f6ade8c0453d11e98dd9f40f24344a08
qid3093	SELECT 单价/元 WHERE 书名 == "国际1级心算"	f6ade8c0453d11e98dd9f40f24344a08
qid3094	SELECT 书名 WHERE 估定价 > "50" or ISBN == "978-7-5682-4037-6"	ab3402cf3b0611e9aa59f40f24344a08
qid3095	SELECT 书名 WHERE 估定价 > "50" or ISBN == "978-7-5682-4037-6"	ab3402cf3b0611e9aa59f40f24344a08
qid3096	SELECT SUM ( 招聘人数 ) WHERE 岗位名称 == "科研岗位01" or 岗位名称 == "科研岗位02"	aa9713193b0611e9bf8ff40f24344a08
qid3097	SELECT SUM ( 招聘人数 ) WHERE 岗位名称 == "科研岗位01" or 岗位名称 == "科研岗位02"	aa9713193b0611e9bf8ff40f24344a08
qid3098	SELECT SUM ( 招聘人数 ) WHERE 岗位名称 == "科研岗位01" or 岗位名称 == "科研岗位02"	aa9713193b0611e9bf8ff40f24344a08
qid3099	SELECT 书名 , 主要作者（编者） WHERE 出版机构名称 == "地质出版社"	abe58cc23b0611e98f0cf40f24344a08
qid3100	SELECT 书名 , 主要作者（编者） WHERE 出版机构名称 == "地质出版社"	abe58cc23b0611e98f0cf40f24344a08
qid3101	SELECT 书名 , 主要作者（编者） WHERE 出版机构名称 == "地质出版社"	abe58cc23b0611e98f0cf40f24344a08
qid3102	SELECT 岗位 WHERE 部门 == "演出中心"	a807ea023b0611e9a53ff40f24344a08
qid3103	SELECT 岗位 WHERE 部门 == "演出中心"	a807ea023b0611e9a53ff40f24344a08
qid3104	SELECT 岗位 WHERE 部门 == "演出中心"	a807ea023b0611e9a53ff40f24344a08
qid3105	SELECT 商品描述 WHERE 抽样数量 == "每批6个（满足实验和留样需求）"	abd8f86b3b0611e994c9f40f24344a08
qid3106	SELECT 商品描述 WHERE 抽样数量 == "每批6个（满足实验和留样需求）"	abd8f86b3b0611e994c9f40f24344a08
qid3107	SELECT 动物名称 WHERE 实验室名称 == "现代生物学实验室"	f1b92435453d11e98226f40f24344a08
qid3108	SELECT 动物名称 WHERE 实验室名称 == "现代生物学实验室"	f1b92435453d11e98226f40f24344a08
qid3109	SELECT 动物名称 WHERE 实验室名称 == "现代生物学实验室"	f1b92435453d11e98226f40f24344a08
qid3110	SELECT 日期 WHERE 无锡镍价格 > "100000" and 伦敦镍价格 < "15000"	f399ffd1453d11e9aea6f40f24344a08
qid3111	SELECT 日期 WHERE 无锡镍价格 > "100000" and 伦敦镍价格 < "15000"	f399ffd1453d11e9aea6f40f24344a08
qid3112	SELECT 单位名称 WHERE 办理事项 == "减少经营范围"	f2e87851453d11e9afb6f40f24344a08
qid3113	SELECT 单位名称 WHERE 办理事项 == "减少经营范围"	f2e87851453d11e9afb6f40f24344a08
qid3114	SELECT 出版社 WHERE 责任者 == "罗根泽著" and 题名 == "孟子传论."	aadfe1943b0611e9b08df40f24344a08
qid3115	SELECT 出版社 WHERE 责任者 == "罗根泽著" and 题名 == "孟子传论."	aadfe1943b0611e9b08df40f24344a08
qid3116	SELECT 出版社 WHERE 责任者 == "罗根泽著" and 题名 == "孟子传论."	aadfe1943b0611e9b08df40f24344a08
qid3117	SELECT 学时 WHERE 开课院系 == "法学院" and 课程名 == "生活中的民商法"	f3e3cf2b453d11e998f9f40f24344a08
qid3118	SELECT 学时 WHERE 开课院系 == "法学院" and 课程名 == "生活中的民商法"	f3e3cf2b453d11e998f9f40f24344a08
qid3119	SELECT 学时 WHERE 开课院系 == "法学院" and 课程名 == "生活中的民商法"	f3e3cf2b453d11e998f9f40f24344a08
qid3120	SELECT 检验机构 WHERE 标称生产企业名称 == "甘肃红川酒业有限责任公司" and 食品名称 == "金红川12号"	f50ef1b8453d11e9b81ef40f24344a08
qid3121	SELECT 检验机构 WHERE 标称生产企业名称 == "甘肃红川酒业有限责任公司" and 食品名称 == "金红川12号"	f50ef1b8453d11e9b81ef40f24344a08
qid3122	SELECT 检验机构 WHERE 标称生产企业名称 == "甘肃红川酒业有限责任公司" and 食品名称 == "金红川12号"	f50ef1b8453d11e9b81ef40f24344a08
qid3123	SELECT 书名 WHERE 定价 > "50"	a80f97473b0611e99f35f40f24344a08
qid3124	SELECT 书名 WHERE 定价 > "50"	a80f97473b0611e99f35f40f24344a08
qid3125	SELECT 书名 WHERE 定价 > "50"	a80f97473b0611e99f35f40f24344a08
qid3126	SELECT 招聘专业（专业方向） WHERE 单位 == "数理学院" and 岗位名称 == "教师"	f3e829e6453d11e98801f40f24344a08
qid3127	SELECT 招聘专业（专业方向） WHERE 单位 == "数理学院" and 岗位名称 == "教师"	f3e829e6453d11e98801f40f24344a08
qid3128	SELECT 招聘专业（专业方向） WHERE 单位 == "数理学院" and 岗位名称 == "教师"	f3e829e6453d11e98801f40f24344a08
qid3129	SELECT 承检机构 WHERE 企业名称 == "唐山爱信化工有限公司" and 产品名称 == "汽车用制动器衬片"	f685b285453d11e98593f40f24344a08
qid3130	SELECT 承检机构 WHERE 企业名称 == "唐山爱信化工有限公司" and 产品名称 == "汽车用制动器衬片"	f685b285453d11e98593f40f24344a08
qid3131	SELECT 承检机构 WHERE 企业名称 == "唐山爱信化工有限公司" and 产品名称 == "汽车用制动器衬片"	f685b285453d11e98593f40f24344a08
qid3132	SELECT 标称生产企业名称 WHERE 规格型号 == "400g/袋" and 食品名称 == "黄氏薯片（川香麻辣味）"	aa1283783b0611e9b5c6f40f24344a08
qid3133	SELECT 标称生产企业名称 WHERE 规格型号 == "400g/袋" and 食品名称 == "黄氏薯片（川香麻辣味）"	aa1283783b0611e9b5c6f40f24344a08
qid3134	SELECT 标称生产企业名称 WHERE 规格型号 == "400g/袋" and 食品名称 == "黄氏薯片（川香麻辣味）"	aa1283783b0611e9b5c6f40f24344a08
qid3135	SELECT 产品名称 WHERE 进境口岸 == "上海"	aaabf65e3b0611e9a3b3f40f24344a08
qid3136	SELECT 产品名称 WHERE 进境口岸 == "上海"	aaabf65e3b0611e9a3b3f40f24344a08
qid3137	SELECT 产品名称 WHERE 进境口岸 == "上海"	aaabf65e3b0611e9a3b3f40f24344a08
qid3138	SELECT 产业规模 WHERE 建设地点 == "枫树岭镇下姜村" and 项目名称 == "富城农特产品智慧农业项目"	ab8f870c3b0611e99e97f40f24344a08
qid3139	SELECT 产业规模 WHERE 建设地点 == "枫树岭镇下姜村" and 项目名称 == "富城农特产品智慧农业项目"	ab8f870c3b0611e99e97f40f24344a08
qid3140	SELECT 产业规模 WHERE 建设地点 == "枫树岭镇下姜村" and 项目名称 == "富城农特产品智慧农业项目"	ab8f870c3b0611e99e97f40f24344a08
qid3141	SELECT 承检机构 WHERE 抽查结果 == "合格"	a88cecab3b0611e994ebf40f24344a08
qid3142	SELECT 承检机构 WHERE 抽查结果 == "合格"	a88cecab3b0611e994ebf40f24344a08
qid3143	SELECT 承检机构 WHERE 抽查结果 == "合格"	a88cecab3b0611e994ebf40f24344a08
qid3144	SELECT 项目名称 , 负责人 WHERE 拨款额（万元） > "2" and 工作单位 == "清华大学"	abc8e7543b0611e98ad8f40f24344a08
qid3145	SELECT 项目名称 , 负责人 WHERE 拨款额（万元） > "2" and 工作单位 == "清华大学"	abc8e7543b0611e98ad8f40f24344a08
qid3146	SELECT 项目名称 , 负责人 WHERE 拨款额（万元） > "2" and 工作单位 == "清华大学"	abc8e7543b0611e98ad8f40f24344a08
qid3147	SELECT 地点 WHERE 项目名称 == "第17届亚运会武术比赛"	ee1502e6453d11e989d3f40f24344a08
qid3148	SELECT 地点 WHERE 项目名称 == "第17届亚运会武术比赛"	ee1502e6453d11e989d3f40f24344a08
qid3149	SELECT 地点 WHERE 项目名称 == "第17届亚运会武术比赛"	ee1502e6453d11e989d3f40f24344a08
qid3150	SELECT COUNT ( 样品名称 ) WHERE 受检单位名称 == "深圳市川崎运动用品有限公司" or 标称商标 == "LAPORA"	a97795543b0611e9ba27f40f24344a08
qid3151	SELECT COUNT ( 样品名称 ) WHERE 受检单位名称 == "深圳市川崎运动用品有限公司" or 标称商标 == "LAPORA"	a97795543b0611e9ba27f40f24344a08
qid3152	SELECT COUNT ( 样品名称 ) WHERE 受检单位名称 == "深圳市川崎运动用品有限公司" or 标称商标 == "LAPORA"	a97795543b0611e9ba27f40f24344a08
qid3153	SELECT 医院名称 WHERE 等级 == "一甲"	a9c5d44c3b0611e9bf76f40f24344a08
qid3154	SELECT 医院名称 WHERE 等级 == "一甲"	a9c5d44c3b0611e9bf76f40f24344a08
qid3155	SELECT 医院名称 WHERE 等级 == "一甲"	a9c5d44c3b0611e9bf76f40f24344a08
qid3156	SELECT 名称 WHERE 客房数(间) == "233.0" or 床位数(张) == "255.0"	f3a3d0fa453d11e9b7f5f40f24344a08
qid3157	SELECT 名称 WHERE 客房数(间) == "233.0" or 床位数(张) == "255.0"	f3a3d0fa453d11e9b7f5f40f24344a08
qid3158	SELECT 名称 WHERE 客房数(间) == "233.0" or 床位数(张) == "255.0"	f3a3d0fa453d11e9b7f5f40f24344a08
qid3159	SELECT 拟招人数 WHERE 用人部门 == "IT快车" and 招聘岗位 == "店员"	ab2cc3cf3b0611e98812f40f24344a08
qid3160	SELECT 拟招人数 WHERE 用人部门 == "IT快车" and 招聘岗位 == "店员"	ab2cc3cf3b0611e98812f40f24344a08
qid3161	SELECT 拟招人数 WHERE 用人部门 == "IT快车" and 招聘岗位 == "店员"	ab2cc3cf3b0611e98812f40f24344a08
qid3162	SELECT 学历 , 专业 WHERE 岗位名称 == "麻醉"	edc67cc0453d11e9aaf7f40f24344a08
qid3163	SELECT 学历 , 专业 WHERE 岗位名称 == "麻醉"	edc67cc0453d11e9aaf7f40f24344a08
qid3164	SELECT 学历 , 专业 WHERE 岗位名称 == "麻醉"	edc67cc0453d11e9aaf7f40f24344a08
qid3165	SELECT 学历学位 WHERE 招聘单位 == "驻马店市中心医院" and 招聘岗位 == "急诊科医师"	ab2406263b0611e99282f40f24344a08
qid3166	SELECT 学历学位 WHERE 招聘单位 == "驻马店市中心医院" and 招聘岗位 == "急诊科医师"	ab2406263b0611e99282f40f24344a08
qid3167	SELECT 学历学位 WHERE 招聘单位 == "驻马店市中心医院" and 招聘岗位 == "急诊科医师"	ab2406263b0611e99282f40f24344a08
qid3168	SELECT 商户营业地址 , 商户咨询电话 WHERE 门店名称 == "玉琉璃SPA美容休闲会馆"	ee57d359453d11e98fb2f40f24344a08
qid3169	SELECT 商户营业地址 , 商户咨询电话 WHERE 门店名称 == "玉琉璃SPA美容休闲会馆"	ee57d359453d11e98fb2f40f24344a08
qid3170	SELECT 商户营业地址 , 商户咨询电话 WHERE 门店名称 == "玉琉璃SPA美容休闲会馆"	ee57d359453d11e98fb2f40f24344a08
qid3171	SELECT 抽查结果 WHERE 企业名称 == "汉王制造有限公司" and 产品名称 == "汉王电纸书"	f6401487453d11e99070f40f24344a08
qid3172	SELECT 抽查结果 WHERE 企业名称 == "汉王制造有限公司" and 产品名称 == "汉王电纸书"	f6401487453d11e99070f40f24344a08
qid3173	SELECT 抽查结果 WHERE 企业名称 == "汉王制造有限公司" and 产品名称 == "汉王电纸书"	f6401487453d11e99070f40f24344a08
qid3174	SELECT 违法原因 WHERE 处理部门 == "上海市食品药品监督管理局" and 广告中标示的药品生产企业名称 == "吉林敖东药业集团延吉股份有限公司"	f60aabf5453d11e9a92cf40f24344a08
qid3175	SELECT 违法原因 WHERE 处理部门 == "上海市食品药品监督管理局" and 广告中标示的药品生产企业名称 == "吉林敖东药业集团延吉股份有限公司"	f60aabf5453d11e9a92cf40f24344a08
qid3176	SELECT 违法原因 WHERE 处理部门 == "上海市食品药品监督管理局" and 广告中标示的药品生产企业名称 == "吉林敖东药业集团延吉股份有限公司"	f60aabf5453d11e9a92cf40f24344a08
qid3177	SELECT 拟招人数 WHERE 招聘单位 == "北京市第二医院" and 职位名称 == "超声医师"	a8e47ee13b0611e9b2ccf40f24344a08
qid3178	SELECT 拟招人数 WHERE 招聘单位 == "北京市第二医院" and 职位名称 == "超声医师"	a8e47ee13b0611e9b2ccf40f24344a08
qid3179	SELECT 拟招人数 WHERE 招聘单位 == "北京市第二医院" and 职位名称 == "超声医师"	a8e47ee13b0611e9b2ccf40f24344a08
qid3180	SELECT 出版社 WHERE 著者 == "张洁著" and 书名 == "南瓜小人"	a998ef5e3b0611e9b48ef40f24344a08
qid3181	SELECT 出版社 WHERE 著者 == "张洁著" and 书名 == "南瓜小人"	a998ef5e3b0611e9b48ef40f24344a08
qid3182	SELECT 出版社 WHERE 著者 == "张洁著" and 书名 == "南瓜小人"	a998ef5e3b0611e9b48ef40f24344a08
qid3183	SELECT 企业名称 WHERE 产品名称 == "三相异步电动机" and 规格型号 == "IE2-160L-4"	aa2aadd93b0611e9bdedf40f24344a08
qid3184	SELECT 企业名称 WHERE 产品名称 == "三相异步电动机" and 规格型号 == "IE2-160L-4"	aa2aadd93b0611e9bdedf40f24344a08
qid3185	SELECT 企业名称 WHERE 产品名称 == "三相异步电动机" and 规格型号 == "IE2-160L-4"	aa2aadd93b0611e9bdedf40f24344a08
qid3186	SELECT 入驻部门 WHERE 事项数量 < "5" or 人员 < "10"	ab1c50ab3b0611e9bc5df40f24344a08
qid3187	SELECT 入驻部门 WHERE 事项数量 < "5" or 人员 < "10"	ab1c50ab3b0611e9bc5df40f24344a08
qid3188	SELECT 入驻部门 WHERE 事项数量 < "5" or 人员 < "10"	ab1c50ab3b0611e9bc5df40f24344a08
qid3189	SELECT 活动内容 , 日期 WHERE 地点 == "国际会展中心M厅"	a9fb33b53b0611e99e07f40f24344a08
qid3190	SELECT 活动内容 , 日期 WHERE 地点 == "国际会展中心M厅"	a9fb33b53b0611e99e07f40f24344a08
qid3191	SELECT 活动内容 , 日期 WHERE 地点 == "国际会展中心M厅"	a9fb33b53b0611e99e07f40f24344a08
qid3192	SELECT COUNT ( 职位名称 ) WHERE 薪酬(万/年薪) > "40" or 招聘人数 > "2"	f11b638f453d11e997def40f24344a08
qid3193	SELECT COUNT ( 职位名称 ) WHERE 薪酬(万/年薪) > "40" or 招聘人数 > "2"	f11b638f453d11e997def40f24344a08
qid3194	SELECT COUNT ( 职位名称 ) WHERE 薪酬(万/年薪) > "40" or 招聘人数 > "2"	f11b638f453d11e997def40f24344a08
qid3195	SELECT 课题名称 WHERE 主持人所在单位 == "武汉大学" and 项目类别 == "一般课题"	f52e52b3453d11e9835af40f24344a08
qid3196	SELECT 课题名称 WHERE 主持人所在单位 == "武汉大学" and 项目类别 == "一般课题"	f52e52b3453d11e9835af40f24344a08
qid3197	SELECT 课题名称 WHERE 主持人所在单位 == "武汉大学" and 项目类别 == "一般课题"	f52e52b3453d11e9835af40f24344a08
qid3198	SELECT 开发商 WHERE 项目地址 == "成华区邛崃山路" and 项目名称 == "龙之梦鹏瑞利新城"	eea872c5453d11e9a634f40f24344a08
qid3199	SELECT 开发商 WHERE 项目地址 == "成华区邛崃山路" and 项目名称 == "龙之梦鹏瑞利新城"	eea872c5453d11e9a634f40f24344a08
qid3200	SELECT 开发商 WHERE 项目地址 == "成华区邛崃山路" and 项目名称 == "龙之梦鹏瑞利新城"	eea872c5453d11e9a634f40f24344a08
qid3201	SELECT 页数 WHERE ISBN == "978-7-5657-0172-6"	a80f97473b0611e99f35f40f24344a08
qid3202	SELECT 页数 WHERE ISBN == "978-7-5657-0172-6"	a80f97473b0611e99f35f40f24344a08
qid3203	SELECT 页数 WHERE ISBN == "978-7-5657-0172-6"	a80f97473b0611e99f35f40f24344a08
qid3204	SELECT 对应高职专业代码 WHERE 招生专业 == "音乐学（音乐教育方向）" or 学校 == "沈阳音乐学院"	f1e79745453d11e9acb9f40f24344a08
qid3205	SELECT 对应高职专业代码 WHERE 招生专业 == "音乐学（音乐教育方向）" or 学校 == "沈阳音乐学院"	f1e79745453d11e9acb9f40f24344a08
qid3206	SELECT 对应高职专业代码 WHERE 招生专业 == "音乐学（音乐教育方向）" or 学校 == "沈阳音乐学院"	f1e79745453d11e9acb9f40f24344a08
qid3207	SELECT 医保支付标准 WHERE 规格 == "80mg" and 药品名称 == "阿利沙坦酯"	a7e258473b0611e98979f40f24344a08
qid3208	SELECT 医保支付标准 WHERE 规格 == "80mg" and 药品名称 == "阿利沙坦酯"	a7e258473b0611e98979f40f24344a08
qid3209	SELECT 医保支付标准 WHERE 规格 == "80mg" and 药品名称 == "阿利沙坦酯"	a7e258473b0611e98979f40f24344a08
qid3210	SELECT 出版社 WHERE 书名 == "少有人走的路" or 书名 == "好的孤独"	aaa5eae63b0611e98d30f40f24344a08
qid3211	SELECT 出版社 WHERE 书名 == "少有人走的路" or 书名 == "好的孤独"	aaa5eae63b0611e98d30f40f24344a08
qid3212	SELECT 出版社 WHERE 书名 == "少有人走的路" or 书名 == "好的孤独"	aaa5eae63b0611e98d30f40f24344a08
qid3213	SELECT 题名 WHERE ISBN == "7-80024-341-9"	ef3f8591453d11e9b716f40f24344a08
qid3214	SELECT 题名 WHERE ISBN == "7-80024-341-9"	ef3f8591453d11e9b716f40f24344a08
qid3215	SELECT 题名 WHERE ISBN == "7-80024-341-9"	ef3f8591453d11e9b716f40f24344a08
qid3216	SELECT 立项学期 WHERE 课程名称 == "智能信息处理"	f6dc5dab453d11e9b98ef40f24344a08
qid3217	SELECT 立项学期 WHERE 课程名称 == "智能信息处理"	f6dc5dab453d11e9b98ef40f24344a08
qid3218	SELECT 立项学期 WHERE 课程名称 == "智能信息处理"	f6dc5dab453d11e9b98ef40f24344a08
qid3219	SELECT 作者 WHERE 书名 == "爱国四章" or 书名 == "农民的鼎革"	a8d059353b0611e999eff40f24344a08
qid3220	SELECT 作者 WHERE 书名 == "爱国四章" or 书名 == "农民的鼎革"	a8d059353b0611e999eff40f24344a08
qid3221	SELECT 作者 WHERE 书名 == "爱国四章" or 书名 == "农民的鼎革"	a8d059353b0611e999eff40f24344a08
qid3222	SELECT 课程名 WHERE 考场 == "B401"	aa6d0de83b0611e9af35f40f24344a08
qid3223	SELECT 课程名 WHERE 考场 == "B401"	aa6d0de83b0611e9af35f40f24344a08
qid3224	SELECT 项目名称 WHERE 所属省份 == "甘肃省" and 总投资（万元） > "100000"	a7d739a13b0611e9925af40f24344a08
qid3225	SELECT 项目名称 WHERE 所属省份 == "甘肃省" and 总投资（万元） > "100000"	a7d739a13b0611e9925af40f24344a08
qid3226	SELECT 项目名称 WHERE 所属省份 == "甘肃省" and 总投资（万元） > "100000"	a7d739a13b0611e9925af40f24344a08
qid3227	SELECT 缴费方式 , 保障期限 WHERE 产品名称 == "红福宝"	f615bdbd453d11e9a178f40f24344a08
qid3228	SELECT 缴费方式 , 保障期限 WHERE 产品名称 == "红福宝"	f615bdbd453d11e9a178f40f24344a08
qid3229	SELECT 缴费方式 , 保障期限 WHERE 产品名称 == "红福宝"	f615bdbd453d11e9a178f40f24344a08
qid3230	SELECT 单位名称 WHERE 项目名称 == "阳光•精致•舒适生活"	f636b78a453d11e9882df40f24344a08
qid3231	SELECT 单位名称 WHERE 项目名称 == "阳光•精致•舒适生活"	f636b78a453d11e9882df40f24344a08
qid3232	SELECT 单位名称 WHERE 项目名称 == "阳光•精致•舒适生活"	f636b78a453d11e9882df40f24344a08
qid3233	SELECT 出版日期 , 作者 WHERE 书名 == "安徽省岩石地层"	f5edebf5453d11e9ac6ef40f24344a08
qid3234	SELECT 出版日期 , 作者 WHERE 书名 == "安徽省岩石地层"	f5edebf5453d11e9ac6ef40f24344a08
qid3235	SELECT 出版日期 , 作者 WHERE 书名 == "安徽省岩石地层"	f5edebf5453d11e9ac6ef40f24344a08
qid3236	SELECT 专业要求 WHERE 招聘职位 == "财务"	f4242de3453d11e9ac1ef40f24344a08
qid3237	SELECT 专业要求 WHERE 招聘职位 == "财务"	f4242de3453d11e9ac1ef40f24344a08
qid3238	SELECT 专业要求 WHERE 招聘职位 == "财务"	f4242de3453d11e9ac1ef40f24344a08
qid3239	SELECT COUNT ( 项目名称 ) WHERE 总经费 > "1000" and 专项经费 > "1000"	a7b1ce873b0611e9aa37f40f24344a08
qid3240	SELECT COUNT ( 项目名称 ) WHERE 总经费 > "1000" and 专项经费 > "1000"	a7b1ce873b0611e9aa37f40f24344a08
qid3241	SELECT COUNT ( 项目名称 ) WHERE 总经费 > "1000" and 专项经费 > "1000"	a7b1ce873b0611e9aa37f40f24344a08
qid3242	SELECT 抽查结果 WHERE 承检机构 == "国家日用金属制品质量监督检验中心（沈阳）" and 产品名称 == "樱花嵌入式燃气灶"	f23c7a82453d11e98f5bf40f24344a08
qid3243	SELECT 抽查结果 WHERE 承检机构 == "国家日用金属制品质量监督检验中心（沈阳）" and 产品名称 == "樱花嵌入式燃气灶"	f23c7a82453d11e98f5bf40f24344a08
qid3244	SELECT 抽查结果 WHERE 承检机构 == "国家日用金属制品质量监督检验中心（沈阳）" and 产品名称 == "樱花嵌入式燃气灶"	f23c7a82453d11e98f5bf40f24344a08
qid3245	SELECT 办公时间 WHERE 户政受理窗口名称 == "罗湖公安分局人口管理科" or 户政受理窗口名称 == "南山公安分局人口管理科"	a7dbad703b0611e9ad70f40f24344a08
qid3246	SELECT 办公时间 WHERE 户政受理窗口名称 == "罗湖公安分局人口管理科" or 户政受理窗口名称 == "南山公安分局人口管理科"	a7dbad703b0611e9ad70f40f24344a08
qid3247	SELECT 办公时间 WHERE 户政受理窗口名称 == "罗湖公安分局人口管理科" or 户政受理窗口名称 == "南山公安分局人口管理科"	a7dbad703b0611e9ad70f40f24344a08
qid3248	SELECT 企业名称 WHERE 生产日期/批号 == "2013-09" and 产品名称 == "室内加热器（电热式取暖器）"	eebd0107453d11e987d1f40f24344a08
qid3249	SELECT 企业名称 WHERE 生产日期/批号 == "2013-09" and 产品名称 == "室内加热器（电热式取暖器）"	eebd0107453d11e987d1f40f24344a08
qid3250	SELECT 企业名称 WHERE 生产日期/批号 == "2013-09" and 产品名称 == "室内加热器（电热式取暖器）"	eebd0107453d11e987d1f40f24344a08
qid3251	SELECT 数量 WHERE 商品名称 == "干燥器"	f727800c453d11e98844f40f24344a08
qid3252	SELECT 数量 WHERE 商品名称 == "干燥器"	f727800c453d11e98844f40f24344a08
qid3253	SELECT 数量 WHERE 商品名称 == "干燥器"	f727800c453d11e98844f40f24344a08
qid3254	SELECT 内容提要 WHERE 书名 == "英语口语教学研究与实践"	a9cf464f3b0611e9a19ff40f24344a08
qid3255	SELECT 内容提要 WHERE 书名 == "英语口语教学研究与实践"	a9cf464f3b0611e9a19ff40f24344a08
qid3256	SELECT 内容提要 WHERE 书名 == "英语口语教学研究与实践"	a9cf464f3b0611e9a19ff40f24344a08
qid3257	SELECT 企业名称 WHERE 区域 == "盐田区" and 行业 == "轻工"	aa46e0f33b0611e9a8d9f40f24344a08
qid3258	SELECT 企业名称 WHERE 区域 == "盐田区" and 行业 == "轻工"	aa46e0f33b0611e9a8d9f40f24344a08
qid3259	SELECT 企业名称 WHERE 区域 == "盐田区" and 行业 == "轻工"	aa46e0f33b0611e9a8d9f40f24344a08
qid3260	SELECT 变更项变更前内容 , 变更项变更后内容 WHERE 变更具体描述 == "数据项字段长度扩充为18位"	aa2d42473b0611e982ebf40f24344a08
qid3261	SELECT 变更项变更前内容 , 变更项变更后内容 WHERE 变更具体描述 == "数据项字段长度扩充为18位"	aa2d42473b0611e982ebf40f24344a08
qid3262	SELECT 变更项变更前内容 , 变更项变更后内容 WHERE 变更具体描述 == "数据项字段长度扩充为18位"	aa2d42473b0611e982ebf40f24344a08
qid3263	SELECT COUNT ( 医院名称 ) WHERE 医院等级 == "三级甲等"	aa577cc73b0611e994def40f24344a08
qid3264	SELECT COUNT ( 医院名称 ) WHERE 医院等级 == "三级甲等"	aa577cc73b0611e994def40f24344a08
qid3265	SELECT COUNT ( 医院名称 ) WHERE 医院等级 == "三级甲等"	aa577cc73b0611e994def40f24344a08
qid3266	SELECT 奖项 WHERE 设计制作者 == "金国荣" and 作品名称 == "《西湖风韵－茶具》"	f3dee1b0453d11e9ac1ff40f24344a08
qid3267	SELECT 奖项 WHERE 设计制作者 == "金国荣" and 作品名称 == "《西湖风韵－茶具》"	f3dee1b0453d11e9ac1ff40f24344a08
qid3268	SELECT 出版社 WHERE 书名 == "原始瓷器研究"	f0021075453d11e9a0b3f40f24344a08
qid3269	SELECT 出版社 WHERE 书名 == "原始瓷器研究"	f0021075453d11e9a0b3f40f24344a08
qid3270	SELECT 出版社 WHERE 书名 == "原始瓷器研究"	f0021075453d11e9a0b3f40f24344a08
qid3271	SELECT COUNT ( 中文刊名 ) WHERE 期刊名 == "FUNGALDIVERSITY" or ISSN == "0166-0616"	aad6c1a33b0611e99b65f40f24344a08
qid3272	SELECT COUNT ( 中文刊名 ) WHERE 期刊名 == "FUNGALDIVERSITY" or ISSN == "0166-0616"	aad6c1a33b0611e99b65f40f24344a08
qid3273	SELECT COUNT ( 中文刊名 ) WHERE 期刊名 == "FUNGALDIVERSITY" or ISSN == "0166-0616"	aad6c1a33b0611e99b65f40f24344a08
qid3274	SELECT 招聘岗位 WHERE 所需专业 == "护理专业（助产方向）"	ab2406263b0611e99282f40f24344a08
qid3275	SELECT 招聘岗位 WHERE 所需专业 == "护理专业（助产方向）"	ab2406263b0611e99282f40f24344a08
qid3276	SELECT 招聘岗位 WHERE 所需专业 == "护理专业（助产方向）"	ab2406263b0611e99282f40f24344a08
qid3277	SELECT 品种 WHERE 品牌 == "联想"	a85378333b0611e9955cf40f24344a08
qid3278	SELECT 品种 WHERE 品牌 == "联想"	a85378333b0611e9955cf40f24344a08
qid3279	SELECT 品种 WHERE 品牌 == "联想"	a85378333b0611e9955cf40f24344a08
qid3280	SELECT 数量 WHERE 品牌 == "PEPE" and 商品名称 == "裤子"	a87933ba3b0611e99e2ef40f24344a08
qid3281	SELECT 数量 WHERE 品牌 == "PEPE" and 商品名称 == "裤子"	a87933ba3b0611e99e2ef40f24344a08
qid3282	SELECT 数量 WHERE 品牌 == "PEPE" and 商品名称 == "裤子"	a87933ba3b0611e99e2ef40f24344a08
qid3283	SELECT 书名 WHERE 索取号 == "B022/20-2"	ef6ae6b8453d11e999adf40f24344a08
qid3284	SELECT 书名 WHERE 索取号 == "B022/20-2"	ef6ae6b8453d11e999adf40f24344a08
qid3285	SELECT 书名 WHERE 索取号 == "B022/20-2"	ef6ae6b8453d11e999adf40f24344a08
qid3286	SELECT 成果名称 , 单位 WHERE 等级 == "一等奖"	ede64885453d11e992edf40f24344a08
qid3287	SELECT 成果名称 , 单位 WHERE 等级 == "一等奖"	ede64885453d11e992edf40f24344a08
qid3288	SELECT 成果名称 , 单位 WHERE 等级 == "一等奖"	ede64885453d11e992edf40f24344a08
qid3289	SELECT 页码 WHERE 书名 == "中国文化的根本精神" or 书名 == "吃货的生物学修养"	a81425ba3b0611e99a4ef40f24344a08
qid3290	SELECT 页码 WHERE 书名 == "中国文化的根本精神" or 书名 == "吃货的生物学修养"	a81425ba3b0611e99a4ef40f24344a08
qid3291	SELECT 页码 WHERE 书名 == "中国文化的根本精神" or 书名 == "吃货的生物学修养"	a81425ba3b0611e99a4ef40f24344a08
qid3292	SELECT 优秀率 WHERE 院系 == "护理系"	ab00fc113b0611e9b631f40f24344a08
qid3293	SELECT 优秀率 WHERE 院系 == "护理系"	ab00fc113b0611e9b631f40f24344a08
qid3294	SELECT 优秀率 WHERE 院系 == "护理系"	ab00fc113b0611e9b631f40f24344a08
qid3295	SELECT 出版社 WHERE 书名 == "先秦南洞庭：南洞庭湖古遗址发掘报告集"	f6fd21ca453d11e9abcef40f24344a08
qid3296	SELECT 出版社 WHERE 书名 == "先秦南洞庭：南洞庭湖古遗址发掘报告集"	f6fd21ca453d11e9abcef40f24344a08
qid3297	SELECT 出版社 WHERE 书名 == "先秦南洞庭：南洞庭湖古遗址发掘报告集"	f6fd21ca453d11e9abcef40f24344a08
qid3298	SELECT COUNT ( 企业名称 ) WHERE 申请内容 == "消防设施工程设计与施工资质壹级" or 申请事项 == "延续"	aa4aa98a3b0611e985aaf40f24344a08
qid3299	SELECT COUNT ( 企业名称 ) WHERE 申请内容 == "消防设施工程设计与施工资质壹级" or 申请事项 == "延续"	aa4aa98a3b0611e985aaf40f24344a08
qid3300	SELECT COUNT ( 企业名称 ) WHERE 申请内容 == "消防设施工程设计与施工资质壹级" or 申请事项 == "延续"	aa4aa98a3b0611e985aaf40f24344a08
qid3301	SELECT 招考人数 WHERE 职位简介 == "行业信息化发展规划、建设管理" or 考试类别 == "省级以上（含副省级）综合管理类"	abcac5873b0611e9b1b9f40f24344a08
qid3302	SELECT 招考人数 WHERE 职位简介 == "行业信息化发展规划、建设管理" or 考试类别 == "省级以上（含副省级）综合管理类"	abcac5873b0611e9b1b9f40f24344a08
qid3303	SELECT 招考人数 WHERE 职位简介 == "行业信息化发展规划、建设管理" or 考试类别 == "省级以上（含副省级）综合管理类"	abcac5873b0611e9b1b9f40f24344a08
qid3304	SELECT 招聘计划 WHERE 招聘岗位 == "高中生物教师" or 招聘岗位 == "高中化学教师"	a920e2403b0611e99e82f40f24344a08
qid3305	SELECT 招聘计划 WHERE 招聘岗位 == "高中生物教师" or 招聘岗位 == "高中化学教师"	a920e2403b0611e99e82f40f24344a08
qid3306	SELECT 招聘计划 WHERE 招聘岗位 == "高中生物教师" or 招聘岗位 == "高中化学教师"	a920e2403b0611e99e82f40f24344a08
qid3307	SELECT COUNT ( 企业名称 ) WHERE 生产线数量 > "1" or 站点地址 == "龙岗区龙港镇龙西村"	ab8abc683b0611e99d0af40f24344a08
qid3308	SELECT COUNT ( 企业名称 ) WHERE 生产线数量 > "1" or 站点地址 == "龙岗区龙港镇龙西村"	ab8abc683b0611e99d0af40f24344a08
qid3309	SELECT COUNT ( 企业名称 ) WHERE 生产线数量 > "1" or 站点地址 == "龙岗区龙港镇龙西村"	ab8abc683b0611e99d0af40f24344a08
qid3310	SELECT COUNT ( 研制单位 ) WHERE 产品名称 == "多功能密码应用互联网终端"	f23e7168453d11e9a04ff40f24344a08
qid3311	SELECT COUNT ( 研制单位 ) WHERE 产品名称 == "多功能密码应用互联网终端"	f23e7168453d11e9a04ff40f24344a08
qid3312	SELECT COUNT ( 研制单位 ) WHERE 产品名称 == "多功能密码应用互联网终端"	f23e7168453d11e9a04ff40f24344a08
qid3313	SELECT 企业名称 WHERE 型号 == "ZS1115" and 产品名称 == "柴油机"	a7c5ae263b0611e98ebaf40f24344a08
qid3314	SELECT 企业名称 WHERE 型号 == "ZS1115" and 产品名称 == "柴油机"	a7c5ae263b0611e98ebaf40f24344a08
qid3315	SELECT 企业名称 WHERE 型号 == "ZS1115" and 产品名称 == "柴油机"	a7c5ae263b0611e98ebaf40f24344a08
qid3316	SELECT 等级 WHERE 班级名称 == "2015级中医学班"	ed3470c7453d11e99fdff40f24344a08
qid3317	SELECT 等级 WHERE 班级名称 == "2015级中医学班"	ed3470c7453d11e99fdff40f24344a08
qid3318	SELECT 等级 WHERE 班级名称 == "2015级中医学班"	ed3470c7453d11e99fdff40f24344a08
qid3319	SELECT 推荐单位 WHERE 作品名称 == "《微光》"	aa4673263b0611e98dd8f40f24344a08
qid3320	SELECT 推荐单位 WHERE 作品名称 == "《微光》"	aa4673263b0611e98dd8f40f24344a08
qid3321	SELECT 推荐单位 WHERE 作品名称 == "《微光》"	aa4673263b0611e98dd8f40f24344a08
qid3322	SELECT 内容介绍 WHERE 正题名 == "毛泽东手迹寻踪"	aa9760873b0611e98e9df40f24344a08
qid3323	SELECT 内容介绍 WHERE 正题名 == "毛泽东手迹寻踪"	aa9760873b0611e98e9df40f24344a08
qid3324	SELECT 内容介绍 WHERE 正题名 == "毛泽东手迹寻踪"	aa9760873b0611e98e9df40f24344a08
qid3325	SELECT 出版日期 WHERE 书名 == "变形词" and 版别 == "百花文艺出版社"	a9b4b72b3b0611e99cb3f40f24344a08
qid3326	SELECT 出版日期 WHERE 书名 == "变形词" and 版别 == "百花文艺出版社"	a9b4b72b3b0611e99cb3f40f24344a08
qid3327	SELECT 出版日期 WHERE 书名 == "变形词" and 版别 == "百花文艺出版社"	a9b4b72b3b0611e99cb3f40f24344a08
qid3328	SELECT 出版社 WHERE 书名 == "辽宁碑志"	ed8f4105453d11e9b994f40f24344a08
qid3329	SELECT 出版社 WHERE 书名 == "辽宁碑志"	ed8f4105453d11e9b994f40f24344a08
qid3330	SELECT 出版社 WHERE 书名 == "辽宁碑志"	ed8f4105453d11e9b994f40f24344a08
qid3331	SELECT 题名 WHERE 馆藏地 == "书库" and 出版年 == "2004.0"	f6f73fe6453d11e9a4c9f40f24344a08
qid3332	SELECT 题名 WHERE 馆藏地 == "书库" and 出版年 == "2004.0"	f6f73fe6453d11e9a4c9f40f24344a08
qid3333	SELECT 题名 WHERE 馆藏地 == "书库" and 出版年 == "2004.0"	f6f73fe6453d11e9a4c9f40f24344a08
qid3334	SELECT 学历 WHERE 执业资格 == "高级中学及以上种类教师资格" or 最低服务年限 == "5年"	a9508b593b0611e98b51f40f24344a08
qid3335	SELECT 学历 WHERE 执业资格 == "高级中学及以上种类教师资格" or 最低服务年限 == "5年"	a9508b593b0611e98b51f40f24344a08
qid3336	SELECT 学历 WHERE 执业资格 == "高级中学及以上种类教师资格" or 最低服务年限 == "5年"	a9508b593b0611e98b51f40f24344a08
qid3337	SELECT 网站标识码 WHERE 网站名称 == "中国黑龙江财政"	eebc17dc453d11e9873bf40f24344a08
qid3338	SELECT 网站标识码 WHERE 网站名称 == "中国黑龙江财政"	eebc17dc453d11e9873bf40f24344a08
qid3339	SELECT 网站标识码 WHERE 网站名称 == "中国黑龙江财政"	eebc17dc453d11e9873bf40f24344a08
qid3340	SELECT 招聘人数 WHERE 招聘科室 == "临床科室" and 工作岗位 == "技士"	f3c716c0453d11e98037f40f24344a08
qid3341	SELECT 招聘人数 WHERE 招聘科室 == "临床科室" and 工作岗位 == "技士"	f3c716c0453d11e98037f40f24344a08
qid3342	SELECT 招聘人数 WHERE 招聘科室 == "临床科室" and 工作岗位 == "技士"	f3c716c0453d11e98037f40f24344a08
qid3343	SELECT 标称生产企业名称 WHERE 食品名称 == "淀粉" or 食品名称 == "水晶粉丝"	f49c44a8453d11e9b092f40f24344a08
qid3344	SELECT 标称生产企业名称 WHERE 食品名称 == "淀粉" or 食品名称 == "水晶粉丝"	f49c44a8453d11e9b092f40f24344a08
qid3345	SELECT 标称生产企业名称 WHERE 食品名称 == "淀粉" or 食品名称 == "水晶粉丝"	f49c44a8453d11e9b092f40f24344a08
qid3346	SELECT 分类 WHERE 书名 == "说服心理学"	abbd0df83b0611e9a87ff40f24344a08
qid3347	SELECT 分类 WHERE 书名 == "说服心理学"	abbd0df83b0611e9a87ff40f24344a08
qid3348	SELECT 分类 WHERE 书名 == "说服心理学"	abbd0df83b0611e9a87ff40f24344a08
qid3349	SELECT 责任者 WHERE 正题名 == "回看毛泽东" or 正题名 == "奋斗"	aad765dc3b0611e994c0f40f24344a08
qid3350	SELECT 责任者 WHERE 正题名 == "回看毛泽东" or 正题名 == "奋斗"	aad765dc3b0611e994c0f40f24344a08
qid3351	SELECT 责任者 WHERE 正题名 == "回看毛泽东" or 正题名 == "奋斗"	aad765dc3b0611e994c0f40f24344a08
qid3352	SELECT 书号 WHERE 书名 == "鲁凯族的文化与艺术"	abae65c03b0611e993c1f40f24344a08
qid3353	SELECT 书号 WHERE 书名 == "鲁凯族的文化与艺术"	abae65c03b0611e993c1f40f24344a08
qid3354	SELECT 书号 WHERE 书名 == "鲁凯族的文化与艺术"	abae65c03b0611e993c1f40f24344a08
qid3355	SELECT 书名 , ID WHERE 业务分类 == "哲学"	ab3402cf3b0611e9aa59f40f24344a08
qid3356	SELECT 书名 , ID WHERE 业务分类 == "哲学"	ab3402cf3b0611e9aa59f40f24344a08
qid3357	SELECT 书名 , ID WHERE 业务分类 == "哲学"	ab3402cf3b0611e9aa59f40f24344a08
qid3358	SELECT 食品名称 WHERE 标称生产企业地址 == "黑龙江省尚志市" and 标称生产企业名称 == "黑龙江绿松食品有限公司"	ab4279943b0611e9b1dcf40f24344a08
qid3359	SELECT 食品名称 WHERE 标称生产企业地址 == "黑龙江省尚志市" and 标称生产企业名称 == "黑龙江绿松食品有限公司"	ab4279943b0611e9b1dcf40f24344a08
qid3360	SELECT 食品名称 WHERE 标称生产企业地址 == "黑龙江省尚志市" and 标称生产企业名称 == "黑龙江绿松食品有限公司"	ab4279943b0611e9b1dcf40f24344a08
qid3361	SELECT 题名 WHERE 出版社 == "内蒙古文化出版社" and 出版时间 == "2013"	f1212fc7453d11e995ebf40f24344a08
qid3362	SELECT 题名 WHERE 出版社 == "内蒙古文化出版社" and 出版时间 == "2013"	f1212fc7453d11e995ebf40f24344a08
qid3363	SELECT 时间 WHERE 活动 == "新闻发布会"	aa51a65e3b0611e9b322f40f24344a08
qid3364	SELECT 时间 WHERE 活动 == "新闻发布会"	aa51a65e3b0611e9b322f40f24344a08
qid3365	SELECT 时间 WHERE 活动 == "新闻发布会"	aa51a65e3b0611e9b322f40f24344a08
qid3366	SELECT 定价 , 出版日期 WHERE 书名 == "诗情际会"	a92fb8683b0611e9aa8df40f24344a08
qid3367	SELECT 定价 , 出版日期 WHERE 书名 == "诗情际会"	a92fb8683b0611e9aa8df40f24344a08
qid3368	SELECT 定价 , 出版日期 WHERE 书名 == "诗情际会"	a92fb8683b0611e9aa8df40f24344a08
qid3369	SELECT 考试类别 WHERE 基层工作最低年限 == "无限制" or 是否组织专业考试 == "是"	a830431c3b0611e9b2dff40f24344a08
qid3370	SELECT 考试类别 WHERE 基层工作最低年限 == "无限制" or 是否组织专业考试 == "是"	a830431c3b0611e9b2dff40f24344a08
qid3371	SELECT 考试类别 WHERE 基层工作最低年限 == "无限制" or 是否组织专业考试 == "是"	a830431c3b0611e9b2dff40f24344a08
qid3372	SELECT 业务分类 WHERE ISBN == "978-7-117-25194-5" or ISBN13 == "9787030555434"	a8e73bd93b0611e99af4f40f24344a08
qid3373	SELECT 业务分类 WHERE ISBN == "978-7-117-25194-5" or ISBN13 == "9787030555434"	a8e73bd93b0611e99af4f40f24344a08
qid3374	SELECT 业务分类 WHERE ISBN == "978-7-117-25194-5" or ISBN13 == "9787030555434"	a8e73bd93b0611e99af4f40f24344a08
qid3375	SELECT 项目地址 WHERE 用地单位 == "广州市交通委员会" and 建设项目 == "公交站场(交通设施用地)"	abaf27a63b0611e98607f40f24344a08
qid3376	SELECT 项目地址 WHERE 用地单位 == "广州市交通委员会" and 建设项目 == "公交站场(交通设施用地)"	abaf27a63b0611e98607f40f24344a08
qid3377	SELECT 项目地址 WHERE 用地单位 == "广州市交通委员会" and 建设项目 == "公交站场(交通设施用地)"	abaf27a63b0611e98607f40f24344a08
qid3378	SELECT 现场确认运行点（个） , 补贴金额（万元） WHERE 项目建设单位名称 == "银川佳通轮胎有限公司"	f0a879e6453d11e9b266f40f24344a08
qid3379	SELECT 现场确认运行点（个） , 补贴金额（万元） WHERE 项目建设单位名称 == "银川佳通轮胎有限公司"	f0a879e6453d11e9b266f40f24344a08
qid3380	SELECT 现场确认运行点（个） , 补贴金额（万元） WHERE 项目建设单位名称 == "银川佳通轮胎有限公司"	f0a879e6453d11e9b266f40f24344a08
qid3381	SELECT 单户单位规模要求 WHERE 产业名称 == "马铃薯"	a8eb55c53b0611e9aaa0f40f24344a08
qid3382	SELECT 单户单位规模要求 WHERE 产业名称 == "马铃薯"	a8eb55c53b0611e9aaa0f40f24344a08
qid3383	SELECT 抽查方式 WHERE 抽查对象 == "县级以上一般公路" and 抽查周期 == "每月"	aa23752b3b0611e99db9f40f24344a08
qid3384	SELECT 抽查方式 WHERE 抽查对象 == "县级以上一般公路" and 抽查周期 == "每月"	aa23752b3b0611e99db9f40f24344a08
qid3385	SELECT 书名 WHERE 定价 > "60"	a8ed2e8c3b0611e9b494f40f24344a08
qid3386	SELECT 书名 WHERE 定价 > "60"	a8ed2e8c3b0611e9b494f40f24344a08
qid3387	SELECT 企业名称 WHERE 规格型号 == "T-117" and 产品名称 == "沙发"	f4bac6d9453d11e9a692f40f24344a08
qid3388	SELECT 企业名称 WHERE 规格型号 == "T-117" and 产品名称 == "沙发"	f4bac6d9453d11e9a692f40f24344a08
qid3389	SELECT 企业名称 WHERE 规格型号 == "T-117" and 产品名称 == "沙发"	f4bac6d9453d11e9a692f40f24344a08
qid3390	SELECT 标识生产企业地址 WHERE 标识生产企业名称 == "上海永安乳品有限公司"	f5bad74f453d11e99311f40f24344a08
qid3391	SELECT 标识生产企业地址 WHERE 标识生产企业名称 == "上海永安乳品有限公司"	f5bad74f453d11e99311f40f24344a08
qid3392	SELECT 标识生产企业地址 WHERE 标识生产企业名称 == "上海永安乳品有限公司"	f5bad74f453d11e99311f40f24344a08
qid3393	SELECT 项目名称 WHERE 项目类别 == "杰出青年科学基金项目"	abb967333b0611e9a8a9f40f24344a08
qid3394	SELECT 规格 WHERE 名称 == "强化铁剂"	aac005353b0611e9ae96f40f24344a08
qid3395	SELECT 规格 WHERE 名称 == "强化铁剂"	aac005353b0611e9ae96f40f24344a08
qid3396	SELECT 工作地点 WHERE 岗位 == "文秘岗"	f63bbdd4453d11e9a4b3f40f24344a08
qid3397	SELECT 工作地点 WHERE 岗位 == "文秘岗"	f63bbdd4453d11e9a4b3f40f24344a08
qid3398	SELECT 工作地点 WHERE 岗位 == "文秘岗"	f63bbdd4453d11e9a4b3f40f24344a08
qid3399	SELECT 生产日期或批号 WHERE 型号 == "诺基亚(BL-4C)" or 规格 == "3.7V、1200mAh"	a9f4e71e3b0611e9bd8ff40f24344a08
qid3400	SELECT 生产日期或批号 WHERE 型号 == "诺基亚(BL-4C)" or 规格 == "3.7V、1200mAh"	a9f4e71e3b0611e9bd8ff40f24344a08
qid3401	SELECT 生产日期或批号 WHERE 型号 == "诺基亚(BL-4C)" or 规格 == "3.7V、1200mAh"	a9f4e71e3b0611e9bd8ff40f24344a08
qid3402	SELECT 付费截止日期 WHERE 备注 == "由交易所付费"	a8583fa13b0611e996c9f40f24344a08
qid3403	SELECT 抽查结果 WHERE 承检机构 == "杭州市质量技术监督检测院" and 产品名称 == "休闲裤"	f036b68a453d11e99623f40f24344a08
qid3404	SELECT 抽查结果 WHERE 承检机构 == "杭州市质量技术监督检测院" and 产品名称 == "休闲裤"	f036b68a453d11e99623f40f24344a08
qid3405	SELECT 抽查结果 WHERE 承检机构 == "杭州市质量技术监督检测院" and 产品名称 == "休闲裤"	f036b68a453d11e99623f40f24344a08
qid3406	SELECT 星期五（11月30日） WHERE 餐点 == "水果"	f4f0636e453d11e994c4f40f24344a08
qid3407	SELECT 星期五（11月30日） WHERE 餐点 == "水果"	f4f0636e453d11e994c4f40f24344a08
qid3408	SELECT 星期五（11月30日） WHERE 餐点 == "水果"	f4f0636e453d11e994c4f40f24344a08
qid3409	SELECT 专业 WHERE 学分 < "3" or 备注 == "限定选修课课程组9学分（每位学生必修）"	f4bc98f3453d11e9a4a9f40f24344a08
qid3410	SELECT 专业 WHERE 学分 < "3" or 备注 == "限定选修课课程组9学分（每位学生必修）"	f4bc98f3453d11e9a4a9f40f24344a08
qid3411	SELECT 专业 WHERE 学分 < "3" or 备注 == "限定选修课课程组9学分（每位学生必修）"	f4bc98f3453d11e9a4a9f40f24344a08
qid3412	SELECT 索书号 WHERE 书名 == "保险术语" or 书名 == "法医学辞典 "	a9201a993b0611e980c9f40f24344a08
qid3413	SELECT 索书号 WHERE 书名 == "保险术语" or 书名 == "法医学辞典 "	a9201a993b0611e980c9f40f24344a08
qid3414	SELECT 索书号 WHERE 书名 == "保险术语" or 书名 == "法医学辞典 "	a9201a993b0611e980c9f40f24344a08
qid3415	SELECT 招聘部门 , 岗位名称 WHERE 专业名称 == "法学类" and 学历 == "研究生及以上学历"	aace11453b0611e9a5e3f40f24344a08
qid3416	SELECT 招聘部门 , 岗位名称 WHERE 专业名称 == "法学类" and 学历 == "研究生及以上学历"	aace11453b0611e9a5e3f40f24344a08
qid3417	SELECT 招聘部门 , 岗位名称 WHERE 专业名称 == "法学类" and 学历 == "研究生及以上学历"	aace11453b0611e9a5e3f40f24344a08
qid3418	SELECT 物品名称 WHERE 科室 == "手术室北院" and 布料要求 == "棉质"	a89b95f33b0611e99140f40f24344a08
qid3419	SELECT 物品名称 WHERE 科室 == "手术室北院" and 布料要求 == "棉质"	a89b95f33b0611e99140f40f24344a08
qid3420	SELECT 物品名称 WHERE 科室 == "手术室北院" and 布料要求 == "棉质"	a89b95f33b0611e99140f40f24344a08
qid3421	SELECT COUNT ( 岗位名称 ) WHERE 专业 == "计算机类" or 学历 == "本科及以上"	aab62e613b0611e9a3ddf40f24344a08
qid3422	SELECT COUNT ( 岗位名称 ) WHERE 专业 == "计算机类" or 学历 == "本科及以上"	aab62e613b0611e9a3ddf40f24344a08
qid3423	SELECT 网址 WHERE 名称 == "阿里巴巴"	ab9761c03b0611e998bff40f24344a08
qid3424	SELECT 书名 WHERE 分类 == "经管理财" and 出版者 == "北京大学出版社"	a8331c9c3b0611e9b04ff40f24344a08
qid3425	SELECT 书名 WHERE 分类 == "经管理财" and 出版者 == "北京大学出版社"	a8331c9c3b0611e9b04ff40f24344a08
qid3426	SELECT 书名 WHERE 分类 == "经管理财" and 出版者 == "北京大学出版社"	a8331c9c3b0611e9b04ff40f24344a08
qid3427	SELECT COUNT ( 单位名称 ) WHERE 数据状态说明 == "2审核中" and 状态数量（条） > "1000"	aa285d3a3b0611e9ae4df40f24344a08
qid3428	SELECT COUNT ( 单位名称 ) WHERE 数据状态说明 == "2审核中" and 状态数量（条） > "1000"	aa285d3a3b0611e9ae4df40f24344a08
qid3429	SELECT COUNT ( 单位名称 ) WHERE 数据状态说明 == "2审核中" and 状态数量（条） > "1000"	aa285d3a3b0611e9ae4df40f24344a08
qid3430	SELECT 教材名称 WHERE 编著者 == "何树华" and 出版社 == "化学工业出版社"	f5209b35453d11e9b085f40f24344a08
qid3431	SELECT 教材名称 WHERE 编著者 == "何树华" and 出版社 == "化学工业出版社"	f5209b35453d11e9b085f40f24344a08
qid3432	SELECT 教材名称 WHERE 编著者 == "何树华" and 出版社 == "化学工业出版社"	f5209b35453d11e9b085f40f24344a08
qid3433	SELECT 开课情况 WHERE 课程名称 == "中西文化比较"	aae4f1973b0611e99c72f40f24344a08
qid3434	SELECT 开课情况 WHERE 课程名称 == "中西文化比较"	aae4f1973b0611e99c72f40f24344a08
qid3435	SELECT 开课情况 WHERE 课程名称 == "中西文化比较"	aae4f1973b0611e99c72f40f24344a08
qid3436	SELECT COUNT ( 场馆名称 ) WHERE 座位数（个） > "5000" or 收入合计（万元） > "500"	ab6265403b0611e9b937f40f24344a08
qid3437	SELECT COUNT ( 场馆名称 ) WHERE 座位数（个） > "5000" or 收入合计（万元） > "500"	ab6265403b0611e9b937f40f24344a08
qid3438	SELECT 价格 WHERE 作者 == "安丽霞著" and 书名 == "现代性的忧郁"	aa1aa4193b0611e9a25af40f24344a08
qid3439	SELECT 价格 WHERE 作者 == "安丽霞著" and 书名 == "现代性的忧郁"	aa1aa4193b0611e9a25af40f24344a08
qid3440	SELECT 价格 WHERE 作者 == "安丽霞著" and 书名 == "现代性的忧郁"	aa1aa4193b0611e9a25af40f24344a08
qid3441	SELECT 书名 , 出版社 WHERE 定价 > "30"	f0bb3d6b453d11e98f48f40f24344a08
qid3442	SELECT 书名 , 出版社 WHERE 定价 > "30"	f0bb3d6b453d11e98f48f40f24344a08
qid3443	SELECT 书名 , 出版社 WHERE 定价 > "30"	f0bb3d6b453d11e98f48f40f24344a08
qid3444	SELECT 品牌 WHERE 生产国别 == "意大利"	a87933ba3b0611e99e2ef40f24344a08
qid3445	SELECT 品牌 WHERE 生产国别 == "意大利"	a87933ba3b0611e99e2ef40f24344a08
qid3446	SELECT 商户地址 WHERE 城市 == "南宁" and 商户名称 == "南宁市青秀南城百货有限公司"	a7c3b9993b0611e9867ff40f24344a08
qid3447	SELECT 商户地址 WHERE 城市 == "南宁" and 商户名称 == "南宁市青秀南城百货有限公司"	a7c3b9993b0611e9867ff40f24344a08
qid3448	SELECT 商户地址 WHERE 城市 == "南宁" and 商户名称 == "南宁市青秀南城百货有限公司"	a7c3b9993b0611e9867ff40f24344a08
qid3449	SELECT 网点名称 WHERE 发行方式 == "柜台兑换" and 兑换数量（枚） > "6000"	ab0c2bd13b0611e98832f40f24344a08
qid3450	SELECT 网点名称 WHERE 发行方式 == "柜台兑换" and 兑换数量（枚） > "6000"	ab0c2bd13b0611e98832f40f24344a08
qid3451	SELECT 网点名称 WHERE 发行方式 == "柜台兑换" and 兑换数量（枚） > "6000"	ab0c2bd13b0611e98832f40f24344a08
qid3452	SELECT COUNT ( 影片名称 ) WHERE 海报名称 == "战火中的青春" or 连环画名称 == "冰山上的来客" or 电影传奇名称 == "瞧这两口子"	a86da7513b0611e98f7df40f24344a08
qid3453	SELECT COUNT ( 影片名称 ) WHERE 海报名称 == "战火中的青春" or 连环画名称 == "冰山上的来客" or 电影传奇名称 == "瞧这两口子"	a86da7513b0611e98f7df40f24344a08
qid3454	SELECT COUNT ( 影片名称 ) WHERE 海报名称 == "战火中的青春" or 连环画名称 == "冰山上的来客" or 电影传奇名称 == "瞧这两口子"	a86da7513b0611e98f7df40f24344a08
qid3455	SELECT 特色说明 WHERE 村落名称 == "龙眼村"	a8be8f633b0611e987fdf40f24344a08
qid3456	SELECT 特色说明 WHERE 村落名称 == "龙眼村"	a8be8f633b0611e987fdf40f24344a08
qid3457	SELECT 实施依据 WHERE 项目名称 == "年度生产经营计划及年度工作总结"	a80932f33b0611e98d48f40f24344a08
qid3458	SELECT 实施依据 WHERE 项目名称 == "年度生产经营计划及年度工作总结"	a80932f33b0611e98d48f40f24344a08
qid3459	SELECT 实施依据 WHERE 项目名称 == "年度生产经营计划及年度工作总结"	a80932f33b0611e98d48f40f24344a08
qid3460	SELECT 证券名称 WHERE 公司中文名称 == "辽宁曙光汽车集团股份有限公司"	f196fe11453d11e982a4f40f24344a08
qid3461	SELECT 证券名称 WHERE 公司中文名称 == "辽宁曙光汽车集团股份有限公司"	f196fe11453d11e982a4f40f24344a08
qid3462	SELECT 课程名称 WHERE 类别 == "历史与文化" and 学分 == "2"	aae4f1973b0611e99c72f40f24344a08
qid3463	SELECT 课程名称 WHERE 类别 == "历史与文化" and 学分 == "2"	aae4f1973b0611e99c72f40f24344a08
qid3464	SELECT 课程名称 WHERE 类别 == "历史与文化" and 学分 == "2"	aae4f1973b0611e99c72f40f24344a08
qid3465	SELECT 书名 , 书代号 WHERE 单价 > "50"	ef4a0f8a453d11e99d46f40f24344a08
qid3466	SELECT 书名 , 书代号 WHERE 单价 > "50"	ef4a0f8a453d11e99d46f40f24344a08
qid3467	SELECT 书名 , 书代号 WHERE 单价 > "50"	ef4a0f8a453d11e99d46f40f24344a08
qid3468	SELECT 编号 WHERE 品牌 == "联想" and 品种 == "主机" and 备注 == "正常"	ee1b1000453d11e9b09df40f24344a08
qid3469	SELECT 编号 WHERE 品牌 == "联想" and 品种 == "主机" and 备注 == "正常"	ee1b1000453d11e9b09df40f24344a08
qid3470	SELECT 编号 WHERE 品牌 == "联想" and 品种 == "主机" and 备注 == "正常"	ee1b1000453d11e9b09df40f24344a08
qid3471	SELECT 授予学分 WHERE 序号 == "Y1501002" or 序号 == "Y1501018"	aa52c5853b0611e99fbaf40f24344a08
qid3472	SELECT 授予学分 WHERE 序号 == "Y1501002" or 序号 == "Y1501018"	aa52c5853b0611e99fbaf40f24344a08
qid3473	SELECT 授予学分 WHERE 序号 == "Y1501002" or 序号 == "Y1501018"	aa52c5853b0611e99fbaf40f24344a08
qid3474	SELECT SUM ( 死亡人数 ) WHERE 事故名称 == "四川广汉金雁花炮有限责任公司连山分厂“5.14”事故" or 事故名称 == "重庆奉节县重庆市松元烟花爆竹有限公司“5.21”事故"	f2519e45453d11e9b571f40f24344a08
qid3475	SELECT SUM ( 死亡人数 ) WHERE 事故名称 == "四川广汉金雁花炮有限责任公司连山分厂“5.14”事故" or 事故名称 == "重庆奉节县重庆市松元烟花爆竹有限公司“5.21”事故"	f2519e45453d11e9b571f40f24344a08
qid3476	SELECT SUM ( 死亡人数 ) WHERE 事故名称 == "四川广汉金雁花炮有限责任公司连山分厂“5.14”事故" or 事故名称 == "重庆奉节县重庆市松元烟花爆竹有限公司“5.21”事故"	f2519e45453d11e9b571f40f24344a08
qid3477	SELECT 作者 WHERE isbn == "978-7-5640-7612-2" or isbn == "978-7-5468-1176-5"	aa7ee43d3b0611e98808f40f24344a08
qid3478	SELECT 作者 WHERE isbn == "978-7-5640-7612-2" or isbn == "978-7-5468-1176-5"	aa7ee43d3b0611e98808f40f24344a08
qid3479	SELECT 作者 WHERE isbn == "978-7-5640-7612-2" or isbn == "978-7-5468-1176-5"	aa7ee43d3b0611e98808f40f24344a08
qid3480	SELECT 出版社 WHERE 书名 == "江南胜迹"	f2981aba453d11e9bf47f40f24344a08
qid3481	SELECT 出版社 WHERE 书名 == "江南胜迹"	f2981aba453d11e9bf47f40f24344a08
qid3482	SELECT 出版社 WHERE 书名 == "江南胜迹"	f2981aba453d11e9bf47f40f24344a08
qid3483	SELECT 始建时间 WHERE 保护区名称 == "云峰山"	f62cd90c453d11e99e59f40f24344a08
qid3484	SELECT 始建时间 WHERE 保护区名称 == "云峰山"	f62cd90c453d11e99e59f40f24344a08
qid3485	SELECT 出版社 WHERE 主编 == "[英]西尔维·拉福雷" and 教材名称 == "现代品牌管理"	ef6573c2453d11e999f6f40f24344a08
qid3486	SELECT 出版社 WHERE 主编 == "[英]西尔维·拉福雷" and 教材名称 == "现代品牌管理"	ef6573c2453d11e999f6f40f24344a08
qid3487	SELECT 出版社 WHERE 主编 == "[英]西尔维·拉福雷" and 教材名称 == "现代品牌管理"	ef6573c2453d11e999f6f40f24344a08
qid3488	SELECT 名称 WHERE 类别 == "近现代重要史迹及代表性建筑" and 所在地 == "中华街道文安社区"	f34e0621453d11e992bff40f24344a08
qid3489	SELECT 名称 WHERE 类别 == "近现代重要史迹及代表性建筑" and 所在地 == "中华街道文安社区"	f34e0621453d11e992bff40f24344a08
qid3490	SELECT 名称 WHERE 类别 == "近现代重要史迹及代表性建筑" and 所在地 == "中华街道文安社区"	f34e0621453d11e992bff40f24344a08
qid3491	SELECT 出版社 WHERE 书名 == "中国古塔及其审美文化特征" or 书名 == "中国大学英语内容依托式教学模式研究"	a90dca7a3b0611e9b94af40f24344a08
qid3492	SELECT 出版社 WHERE 书名 == "中国古塔及其审美文化特征" or 书名 == "中国大学英语内容依托式教学模式研究"	a90dca7a3b0611e9b94af40f24344a08
qid3493	SELECT 出版社 WHERE 书名 == "中国古塔及其审美文化特征" or 书名 == "中国大学英语内容依托式教学模式研究"	a90dca7a3b0611e9b94af40f24344a08
qid3494	SELECT 考生编号 WHERE 录取专业 == "材料学" and 录取通知书发放方式 == "自取"	ef7382a1453d11e9827cf40f24344a08
qid3495	SELECT 考生编号 WHERE 录取专业 == "材料学" and 录取通知书发放方式 == "自取"	ef7382a1453d11e9827cf40f24344a08
qid3496	SELECT 考生编号 WHERE 录取专业 == "材料学" and 录取通知书发放方式 == "自取"	ef7382a1453d11e9827cf40f24344a08
qid3497	SELECT 结项证书号 WHERE 项目名称 == "邓子恢文稿的收集整理与研究" or 项目名称 == "证据、司法真相与社会公平正义"	f5bd4b8c453d11e987b8f40f24344a08
qid3498	SELECT 结项证书号 WHERE 项目名称 == "邓子恢文稿的收集整理与研究" or 项目名称 == "证据、司法真相与社会公平正义"	f5bd4b8c453d11e987b8f40f24344a08
qid3499	SELECT 结项证书号 WHERE 项目名称 == "邓子恢文稿的收集整理与研究" or 项目名称 == "证据、司法真相与社会公平正义"	f5bd4b8c453d11e987b8f40f24344a08
qid3500	SELECT 出版者 WHERE 作者 == "宇琦编著" and 书名 == "哈佛财商课:哈佛财富精英是怎样炼成的"	a901e9263b0611e9853ff40f24344a08
qid3501	SELECT 出版者 WHERE 作者 == "宇琦编著" and 书名 == "哈佛财商课:哈佛财富精英是怎样炼成的"	a901e9263b0611e9853ff40f24344a08
qid3502	SELECT 出版者 WHERE 作者 == "宇琦编著" and 书名 == "哈佛财商课:哈佛财富精英是怎样炼成的"	a901e9263b0611e9853ff40f24344a08
qid3503	SELECT 专业 WHERE 招聘单位 == "葵涌办事处" and 职位 == "工程管理员"	a95cd55c3b0611e9b60ef40f24344a08
qid3504	SELECT 专业 WHERE 招聘单位 == "葵涌办事处" and 职位 == "工程管理员"	a95cd55c3b0611e9b60ef40f24344a08
qid3505	SELECT 专业 WHERE 招聘单位 == "葵涌办事处" and 职位 == "工程管理员"	a95cd55c3b0611e9b60ef40f24344a08
qid3506	SELECT 产品名称 WHERE 生产商 == "恒源气体" and 规格 == "40L"	f578570c453d11e9a110f40f24344a08
qid3507	SELECT 产品名称 WHERE 生产商 == "恒源气体" and 规格 == "40L"	f578570c453d11e9a110f40f24344a08
qid3508	SELECT 产品名称 WHERE 生产商 == "恒源气体" and 规格 == "40L"	f578570c453d11e9a110f40f24344a08
qid3509	SELECT 专业要求 WHERE 招录机关 == "淄博市审计局" and 招录职位名称 == "审计职位"	a895488f3b0611e981edf40f24344a08
qid3510	SELECT 专业要求 WHERE 招录机关 == "淄博市审计局" and 招录职位名称 == "审计职位"	a895488f3b0611e981edf40f24344a08
qid3511	SELECT 专业要求 WHERE 招录机关 == "淄博市审计局" and 招录职位名称 == "审计职位"	a895488f3b0611e981edf40f24344a08
qid3512	SELECT 办公地址 , 公司网站 WHERE 公司名称 == "东吴基金管理有限公司"	efcc9c66453d11e9a11cf40f24344a08
qid3513	SELECT 办公地址 , 公司网站 WHERE 公司名称 == "东吴基金管理有限公司"	efcc9c66453d11e9a11cf40f24344a08
qid3514	SELECT 办公地址 , 公司网站 WHERE 公司名称 == "东吴基金管理有限公司"	efcc9c66453d11e9a11cf40f24344a08
qid3515	SELECT COUNT ( 企业名称 ) WHERE 产品名称 == "普通硅酸盐水泥"	f2660051453d11e982fdf40f24344a08
qid3516	SELECT COUNT ( 企业名称 ) WHERE 产品名称 == "普通硅酸盐水泥"	f2660051453d11e982fdf40f24344a08
qid3517	SELECT COUNT ( 企业名称 ) WHERE 产品名称 == "普通硅酸盐水泥"	f2660051453d11e982fdf40f24344a08
qid3518	SELECT COUNT ( 企业名称 ) WHERE 产品名称 == "柴油机油" or 规格型号 == "AP/SL5W-304L/桶"	f4c9420a453d11e98018f40f24344a08
qid3519	SELECT COUNT ( 企业名称 ) WHERE 产品名称 == "柴油机油" or 规格型号 == "AP/SL5W-304L/桶"	f4c9420a453d11e98018f40f24344a08
qid3520	SELECT COUNT ( 企业名称 ) WHERE 产品名称 == "柴油机油" or 规格型号 == "AP/SL5W-304L/桶"	f4c9420a453d11e98018f40f24344a08
qid3521	SELECT 箱价 WHERE 品名 == "可爱多甜筒香芋牛奶口味冰淇淋多支装" and 规格 == "408g"	aa44830c3b0611e98556f40f24344a08
qid3522	SELECT 箱价 WHERE 品名 == "可爱多甜筒香芋牛奶口味冰淇淋多支装" and 规格 == "408g"	aa44830c3b0611e98556f40f24344a08
qid3523	SELECT 箱价 WHERE 品名 == "可爱多甜筒香芋牛奶口味冰淇淋多支装" and 规格 == "408g"	aa44830c3b0611e98556f40f24344a08
qid3524	SELECT 申报产品 WHERE 申报单位 == "河北省玉田县农牧局"	a9a3a5513b0611e9a56ef40f24344a08
qid3525	SELECT 申报产品 WHERE 申报单位 == "河北省玉田县农牧局"	a9a3a5513b0611e9a56ef40f24344a08
qid3526	SELECT 申报产品 WHERE 申报单位 == "河北省玉田县农牧局"	a9a3a5513b0611e9a56ef40f24344a08
qid3527	SELECT 生产企业名称 WHERE 抽查时间 == "2015年" and 企业所在地 == "北京市"	aa624de13b0611e9abc3f40f24344a08
qid3528	SELECT 生产企业名称 WHERE 抽查时间 == "2015年" and 企业所在地 == "北京市"	aa624de13b0611e9abc3f40f24344a08
qid3529	SELECT 生产企业名称 WHERE 抽查时间 == "2015年" and 企业所在地 == "北京市"	aa624de13b0611e9abc3f40f24344a08
qid3530	SELECT 定价 WHERE ISBN == "9.78751305068e+12"	aae6798c3b0611e9bbd4f40f24344a08
qid3531	SELECT 定价 WHERE ISBN == "9.78751305068e+12"	aae6798c3b0611e9bbd4f40f24344a08
qid3532	SELECT 定价 WHERE ISBN == "9.78751305068e+12"	aae6798c3b0611e9bbd4f40f24344a08
qid3533	SELECT 学分 WHERE 开课学期 == "第一学期（秋季）" and 课程名称 == "马克思主义法理学"	f322a270453d11e99ac4f40f24344a08
qid3534	SELECT 学分 WHERE 开课学期 == "第一学期（秋季）" and 课程名称 == "马克思主义法理学"	f322a270453d11e99ac4f40f24344a08
qid3535	SELECT 学分 WHERE 开课学期 == "第一学期（秋季）" and 课程名称 == "马克思主义法理学"	f322a270453d11e99ac4f40f24344a08
qid3536	SELECT 企业名称 WHERE 规格型号 == "QB-7H" and 产品名称 == "平板电脑"	f1545e5c453d11e98176f40f24344a08
qid3537	SELECT 企业名称 WHERE 规格型号 == "QB-7H" and 产品名称 == "平板电脑"	f1545e5c453d11e98176f40f24344a08
qid3538	SELECT 企业名称 WHERE 规格型号 == "QB-7H" and 产品名称 == "平板电脑"	f1545e5c453d11e98176f40f24344a08
qid3539	SELECT 线下额度（枚） WHERE 机构名称 == "大通县支行营业室" and 线上额度（枚） > "100"	ef94dbd1453d11e9a092f40f24344a08
qid3540	SELECT 线下额度（枚） WHERE 机构名称 == "大通县支行营业室" and 线上额度（枚） > "100"	ef94dbd1453d11e9a092f40f24344a08
qid3541	SELECT 线下额度（枚） WHERE 机构名称 == "大通县支行营业室" and 线上额度（枚） > "100"	ef94dbd1453d11e9a092f40f24344a08
qid3542	SELECT 教练车数 WHERE 驾校名称 == "南航驾校"	ab2ab8873b0611e98e59f40f24344a08
qid3543	SELECT 教练车数 WHERE 驾校名称 == "南航驾校"	ab2ab8873b0611e98e59f40f24344a08
qid3544	SELECT 教练车数 WHERE 驾校名称 == "南航驾校"	ab2ab8873b0611e98e59f40f24344a08
qid3545	SELECT 标识生产企业地址 WHERE 标识生产企业名称 == "上海金像食品有限公司"	f36c7291453d11e9a918f40f24344a08
qid3546	SELECT 标识生产企业地址 WHERE 标识生产企业名称 == "上海金像食品有限公司"	f36c7291453d11e9a918f40f24344a08
qid3547	SELECT 标识生产企业地址 WHERE 标识生产企业名称 == "上海金像食品有限公司"	f36c7291453d11e9a918f40f24344a08
qid3548	SELECT 周次 WHERE 课程名 == "青春发育学" or 课程名 == "卫生法学"	ab3fa62e3b0611e99385f40f24344a08
qid3549	SELECT 周次 WHERE 课程名 == "青春发育学" or 课程名 == "卫生法学"	ab3fa62e3b0611e99385f40f24344a08
qid3550	SELECT 周次 WHERE 课程名 == "青春发育学" or 课程名 == "卫生法学"	ab3fa62e3b0611e99385f40f24344a08
qid3551	SELECT 食品名称 WHERE 标称生产企业地址 == "湖北省武汉市武昌区徐东二路2号" and 标称生产企业名称 == "武汉中油康尼科技有限公司"	f1f534d1453d11e9a16bf40f24344a08
qid3552	SELECT 食品名称 WHERE 标称生产企业地址 == "湖北省武汉市武昌区徐东二路2号" and 标称生产企业名称 == "武汉中油康尼科技有限公司"	f1f534d1453d11e9a16bf40f24344a08
qid3553	SELECT 食品名称 WHERE 标称生产企业地址 == "湖北省武汉市武昌区徐东二路2号" and 标称生产企业名称 == "武汉中油康尼科技有限公司"	f1f534d1453d11e9a16bf40f24344a08
qid3554	SELECT 项目名称 WHERE 评审结果 == "特等奖" and 所属学科 == "管理学"	a8a025e13b0611e9a53df40f24344a08
qid3555	SELECT 项目名称 WHERE 评审结果 == "特等奖" and 所属学科 == "管理学"	a8a025e13b0611e9a53df40f24344a08
qid3556	SELECT 项目名称 WHERE 评审结果 == "特等奖" and 所属学科 == "管理学"	a8a025e13b0611e9a53df40f24344a08
qid3557	SELECT 办公地址 , 公司电话 WHERE 公司中文名称 == "上海电力股份有限公司"	a93e30f03b0611e9975af40f24344a08
qid3558	SELECT 办公地址 , 公司电话 WHERE 公司中文名称 == "上海电力股份有限公司"	a93e30f03b0611e9975af40f24344a08
qid3559	SELECT 办公地址 , 公司电话 WHERE 公司中文名称 == "上海电力股份有限公司"	a93e30f03b0611e9975af40f24344a08
qid3560	SELECT 承办单位 WHERE 项目名称 == "中国数字阅读大会"	a7ea5ac73b0611e9af14f40f24344a08
qid3561	SELECT 承办单位 WHERE 项目名称 == "中国数字阅读大会"	a7ea5ac73b0611e9af14f40f24344a08
qid3562	SELECT 学位 WHERE 招聘岗位 == "心理教师" or 招聘岗位 == "医学营养教师"	aba93f113b0611e9b59cf40f24344a08
qid3563	SELECT 学位 WHERE 招聘岗位 == "心理教师" or 招聘岗位 == "医学营养教师"	aba93f113b0611e9b59cf40f24344a08
qid3564	SELECT 学位 WHERE 招聘岗位 == "心理教师" or 招聘岗位 == "医学营养教师"	aba93f113b0611e9b59cf40f24344a08
qid3565	SELECT 企业名称 , 承检机构 WHERE 产品名称 == "蓝星不冻液"	ab1844d93b0611e9ab0bf40f24344a08
qid3566	SELECT 企业名称 , 承检机构 WHERE 产品名称 == "蓝星不冻液"	ab1844d93b0611e9ab0bf40f24344a08
qid3567	SELECT 企业名称 , 承检机构 WHERE 产品名称 == "蓝星不冻液"	ab1844d93b0611e9ab0bf40f24344a08
qid3568	SELECT 生产日期/批号 WHERE 规格型号 == "240克/盒" and 样品名称 == "核桃DHA配方奶米粉"	a9e3b3ba3b0611e99026f40f24344a08
qid3569	SELECT 生产日期/批号 WHERE 规格型号 == "240克/盒" and 样品名称 == "核桃DHA配方奶米粉"	a9e3b3ba3b0611e99026f40f24344a08
qid3570	SELECT 生产日期/批号 WHERE 规格型号 == "240克/盒" and 样品名称 == "核桃DHA配方奶米粉"	a9e3b3ba3b0611e99026f40f24344a08
qid3571	SELECT ISBN WHERE 书名 == "保险学理论研究" or 书名 == "能源金融理论与实践"	a83d80d73b0611e9a6a1f40f24344a08
qid3572	SELECT ISBN WHERE 书名 == "保险学理论研究" or 书名 == "能源金融理论与实践"	a83d80d73b0611e9a6a1f40f24344a08
qid3573	SELECT ISBN WHERE 书名 == "保险学理论研究" or 书名 == "能源金融理论与实践"	a83d80d73b0611e9a6a1f40f24344a08
qid3574	SELECT 单位名称 WHERE 岗位类别 == "管理"	a9ae2fd73b0611e991f4f40f24344a08
qid3575	SELECT 单位名称 WHERE 岗位类别 == "管理"	a9ae2fd73b0611e991f4f40f24344a08
qid3576	SELECT 单位名称 WHERE 岗位类别 == "管理"	a9ae2fd73b0611e991f4f40f24344a08
qid3577	SELECT 整改意见（整改时间截至2011年9月底） WHERE 场馆名称 == "天津市动物园" or 场馆名称 == "大连森林动物园"	aa02cf5c3b0611e9bf66f40f24344a08
qid3578	SELECT 整改意见（整改时间截至2011年9月底） WHERE 场馆名称 == "天津市动物园" or 场馆名称 == "大连森林动物园"	aa02cf5c3b0611e9bf66f40f24344a08
qid3579	SELECT 整改意见（整改时间截至2011年9月底） WHERE 场馆名称 == "天津市动物园" or 场馆名称 == "大连森林动物园"	aa02cf5c3b0611e9bf66f40f24344a08
qid3580	SELECT 设备名称 WHERE 使用/管理单位 == "材料学院" and 设备价值（元） == "350000"	aaa3428c3b0611e98081f40f24344a08
qid3581	SELECT 设备名称 WHERE 使用/管理单位 == "材料学院" and 设备价值（元） == "350000"	aaa3428c3b0611e98081f40f24344a08
qid3582	SELECT 设备名称 WHERE 使用/管理单位 == "材料学院" and 设备价值（元） == "350000"	aaa3428c3b0611e98081f40f24344a08
qid3583	SELECT CCC认证费用 WHERE 标准 == "GB15084-2006" and 项目 == "汽车后视镜"	ab52964c3b0611e9a43cf40f24344a08
qid3584	SELECT CCC认证费用 WHERE 标准 == "GB15084-2006" and 项目 == "汽车后视镜"	ab52964c3b0611e9a43cf40f24344a08
qid3585	SELECT CCC认证费用 WHERE 标准 == "GB15084-2006" and 项目 == "汽车后视镜"	ab52964c3b0611e9a43cf40f24344a08
qid3586	SELECT 内容简介 WHERE 书名 == "倒霉国逃生记"	a885c27d3b0611e9a419f40f24344a08
qid3587	SELECT 内容简介 WHERE 书名 == "倒霉国逃生记"	a885c27d3b0611e9a419f40f24344a08
qid3588	SELECT 内容简介 WHERE 书名 == "倒霉国逃生记"	a885c27d3b0611e9a419f40f24344a08
qid3589	SELECT 塑化剂 WHERE 品名 == "鲜橙多" or 品名 == "蜜桃多"	f18e2f23453d11e999aff40f24344a08
qid3590	SELECT 塑化剂 WHERE 品名 == "鲜橙多" or 品名 == "蜜桃多"	f18e2f23453d11e999aff40f24344a08
qid3591	SELECT 塑化剂 WHERE 品名 == "鲜橙多" or 品名 == "蜜桃多"	f18e2f23453d11e999aff40f24344a08
qid3592	SELECT 实施单位 WHERE 预算执行时间 == "2016.01.01-2016.12.31" and 项目名称 == "门户网站内容更新保障和专题专栏建设服务"	f25db4ee453d11e988a4f40f24344a08
qid3593	SELECT 实施单位 WHERE 预算执行时间 == "2016.01.01-2016.12.31" and 项目名称 == "门户网站内容更新保障和专题专栏建设服务"	f25db4ee453d11e988a4f40f24344a08
qid3594	SELECT 实施单位 WHERE 预算执行时间 == "2016.01.01-2016.12.31" and 项目名称 == "门户网站内容更新保障和专题专栏建设服务"	f25db4ee453d11e988a4f40f24344a08
qid3595	SELECT 题名 WHERE 作者 == "李永丰撰稿"	ee20d2eb453d11e9ad87f40f24344a08
qid3596	SELECT 题名 WHERE 作者 == "李永丰撰稿"	ee20d2eb453d11e9ad87f40f24344a08
qid3597	SELECT 题名 WHERE 作者 == "李永丰撰稿"	ee20d2eb453d11e9ad87f40f24344a08
qid3598	SELECT 专业要求 WHERE 岗位名称 == "三资管理人员" or 岗位名称 == "规划建设工程师"	ef52b5e8453d11e9ab65f40f24344a08
qid3599	SELECT 专业要求 WHERE 岗位名称 == "三资管理人员" or 岗位名称 == "规划建设工程师"	ef52b5e8453d11e9ab65f40f24344a08
qid3600	SELECT 专业要求 WHERE 岗位名称 == "三资管理人员" or 岗位名称 == "规划建设工程师"	ef52b5e8453d11e9ab65f40f24344a08
qid3601	SELECT 抽样单编号 WHERE 被抽样单位名称 == "微山县夏镇小橙都古法冒菜馆" and 被抽样单位所在省份 == "山东省"	f364f1c0453d11e98129f40f24344a08
qid3602	SELECT 抽样单编号 WHERE 被抽样单位名称 == "微山县夏镇小橙都古法冒菜馆" and 被抽样单位所在省份 == "山东省"	f364f1c0453d11e98129f40f24344a08
qid3603	SELECT 抽样单编号 WHERE 被抽样单位名称 == "微山县夏镇小橙都古法冒菜馆" and 被抽样单位所在省份 == "山东省"	f364f1c0453d11e98129f40f24344a08
qid3604	SELECT 出版者 WHERE 责任者 == "池舒涵著" and 题名 == "纳兰性德"	a963e32e3b0611e9a642f40f24344a08
qid3605	SELECT 出版者 WHERE 责任者 == "池舒涵著" and 题名 == "纳兰性德"	a963e32e3b0611e9a642f40f24344a08
qid3606	SELECT 出版者 WHERE 责任者 == "池舒涵著" and 题名 == "纳兰性德"	a963e32e3b0611e9a642f40f24344a08
qid3607	SELECT 专利名称 WHERE 单位 == "化学化工学院" and 专利类型 == "发明"	abd961873b0611e99fa2f40f24344a08
qid3608	SELECT 专利名称 WHERE 单位 == "化学化工学院" and 专利类型 == "发明"	abd961873b0611e99fa2f40f24344a08
qid3609	SELECT 专利名称 WHERE 单位 == "化学化工学院" and 专利类型 == "发明"	abd961873b0611e99fa2f40f24344a08
qid3610	SELECT 课时 WHERE 章节 == "第四章" and 内容 == "4-1术语及定义"	ef1e14e8453d11e9af1ef40f24344a08
qid3611	SELECT 课时 WHERE 章节 == "第四章" and 内容 == "4-1术语及定义"	ef1e14e8453d11e9af1ef40f24344a08
qid3612	SELECT 岗位名称 WHERE 学历 == "本科及以上" and 学位 == "学士及以上"	a7de78333b0611e9a5fbf40f24344a08
qid3613	SELECT 岗位名称 WHERE 学历 == "本科及以上" and 学位 == "学士及以上"	a7de78333b0611e9a5fbf40f24344a08
qid3614	SELECT 岗位名称 WHERE 学历 == "本科及以上" and 学位 == "学士及以上"	a7de78333b0611e9a5fbf40f24344a08
qid3615	SELECT 学制 WHERE 招生专业（课程）名称 == "土木工程"	f07a4f1c453d11e9ba7df40f24344a08
qid3616	SELECT 学制 WHERE 招生专业（课程）名称 == "土木工程"	f07a4f1c453d11e9ba7df40f24344a08
qid3617	SELECT 学制 WHERE 招生专业（课程）名称 == "土木工程"	f07a4f1c453d11e9ba7df40f24344a08
qid3618	SELECT 招聘岗位 WHERE 学历要求 == "博士" and 招聘人数 == "2.0"	abf387023b0611e9b696f40f24344a08
qid3619	SELECT 招聘岗位 WHERE 学历要求 == "博士" and 招聘人数 == "2.0"	abf387023b0611e9b696f40f24344a08
qid3620	SELECT 受检单位 WHERE 样品名称 == "餐具清洁剂" and 检验结论 == "合格"	aac6cbb33b0611e9af1cf40f24344a08
qid3621	SELECT 受检单位 WHERE 样品名称 == "餐具清洁剂" and 检验结论 == "合格"	aac6cbb33b0611e9af1cf40f24344a08
qid3622	SELECT 受检单位 WHERE 样品名称 == "餐具清洁剂" and 检验结论 == "合格"	aac6cbb33b0611e9af1cf40f24344a08
qid3623	SELECT 参赛号 WHERE 节目名称 == "《天路》" or 节目名称 == "《宝贝不要哭》"	f047e068453d11e99818f40f24344a08
qid3624	SELECT 参赛号 WHERE 节目名称 == "《天路》" or 节目名称 == "《宝贝不要哭》"	f047e068453d11e99818f40f24344a08
qid3625	SELECT 参赛号 WHERE 节目名称 == "《天路》" or 节目名称 == "《宝贝不要哭》"	f047e068453d11e99818f40f24344a08
qid3626	SELECT 套数 WHERE 项目名称 == "南方钢厂(二期)项目"	efe11428453d11e9a864f40f24344a08
qid3627	SELECT 套数 WHERE 项目名称 == "南方钢厂(二期)项目"	efe11428453d11e9a864f40f24344a08
qid3628	SELECT 出版时间 WHERE 出版社 == "百花洲文艺出版社" and 书名 == "钱文忠青少年国学"	ab78a42e3b0611e98b57f40f24344a08
qid3629	SELECT 出版时间 WHERE 出版社 == "百花洲文艺出版社" and 书名 == "钱文忠青少年国学"	ab78a42e3b0611e98b57f40f24344a08
qid3630	SELECT 出版时间 WHERE 出版社 == "百花洲文艺出版社" and 书名 == "钱文忠青少年国学"	ab78a42e3b0611e98b57f40f24344a08
qid3631	SELECT 生产日期/批号 WHERE 规格型号 == "250g/瓶" and 食品名称 == "槐花蜂王浆"	ed734c8a453d11e9acd0f40f24344a08
qid3632	SELECT 生产日期/批号 WHERE 规格型号 == "250g/瓶" and 食品名称 == "槐花蜂王浆"	ed734c8a453d11e9acd0f40f24344a08
qid3633	SELECT 生产日期/批号 WHERE 规格型号 == "250g/瓶" and 食品名称 == "槐花蜂王浆"	ed734c8a453d11e9acd0f40f24344a08
qid3634	SELECT 样品名称 , 生产企业名称 WHERE 检验结果 == "合格"	ab4d149e3b0611e98a58f40f24344a08
qid3635	SELECT 样品名称 , 生产企业名称 WHERE 检验结果 == "合格"	ab4d149e3b0611e98a58f40f24344a08
qid3636	SELECT 样品名称 , 生产企业名称 WHERE 检验结果 == "合格"	ab4d149e3b0611e98a58f40f24344a08
qid3637	SELECT 承检机构 WHERE 生产企业名称(标称) == "佛山市风行家电有限公司" and 产品名称 == "风行牌吊扇"	a8958dc73b0611e99f24f40f24344a08
qid3638	SELECT 承检机构 WHERE 生产企业名称(标称) == "佛山市风行家电有限公司" and 产品名称 == "风行牌吊扇"	a8958dc73b0611e99f24f40f24344a08
qid3639	SELECT 承检机构 WHERE 生产企业名称(标称) == "佛山市风行家电有限公司" and 产品名称 == "风行牌吊扇"	a8958dc73b0611e99f24f40f24344a08
qid3640	SELECT 经营场所 WHERE 企业名称 == "东莞横沥马艺模具厂"	aa4be43a3b0611e9b2d0f40f24344a08
qid3641	SELECT 经营场所 WHERE 企业名称 == "东莞横沥马艺模具厂"	aa4be43a3b0611e9b2d0f40f24344a08
qid3642	SELECT 经营场所 WHERE 企业名称 == "东莞横沥马艺模具厂"	aa4be43a3b0611e9b2d0f40f24344a08
qid3643	SELECT 地址 WHERE 企业名称 == "上海九州通医药有限公司"	f0fbad99453d11e99454f40f24344a08
qid3644	SELECT 地址 WHERE 企业名称 == "上海九州通医药有限公司"	f0fbad99453d11e99454f40f24344a08
qid3645	SELECT 地址 WHERE 企业名称 == "上海九州通医药有限公司"	f0fbad99453d11e99454f40f24344a08
qid3646	SELECT 职位名称 WHERE 专业 == "计算机（软件）、通信（信息）工程" or 学历 == "本科及以上"	abcac5873b0611e9b1b9f40f24344a08
qid3647	SELECT 职位名称 WHERE 专业 == "计算机（软件）、通信（信息）工程" or 学历 == "本科及以上"	abcac5873b0611e9b1b9f40f24344a08
qid3648	SELECT 职位名称 WHERE 专业 == "计算机（软件）、通信（信息）工程" or 学历 == "本科及以上"	abcac5873b0611e9b1b9f40f24344a08
qid3649	SELECT 单位名称 WHERE 负责人 == "杜升学"	f512a7ee453d11e9a828f40f24344a08
qid3650	SELECT 标题 WHERE 出版社 == "人民卫生出版社"	ed7555fd453d11e99e61f40f24344a08
qid3651	SELECT 标题 WHERE 出版社 == "人民卫生出版社"	ed7555fd453d11e99e61f40f24344a08
qid3652	SELECT 标题 WHERE 出版社 == "人民卫生出版社"	ed7555fd453d11e99e61f40f24344a08
qid3653	SELECT 学历 WHERE 用人部门 == "艺术学院" and 岗位名称 == "教师"	ab77e1803b0611e9893bf40f24344a08
qid3654	SELECT 学历 WHERE 用人部门 == "艺术学院" and 岗位名称 == "教师"	ab77e1803b0611e9893bf40f24344a08
qid3655	SELECT 学历 WHERE 用人部门 == "艺术学院" and 岗位名称 == "教师"	ab77e1803b0611e9893bf40f24344a08
qid3656	SELECT 出版时间 WHERE 书名 == "北极熊报告" or 书名 == "爱哭的猫头鹰"	a9c862ae3b0611e98fa7f40f24344a08
qid3657	SELECT 出版时间 WHERE 书名 == "北极熊报告" or 书名 == "爱哭的猫头鹰"	a9c862ae3b0611e98fa7f40f24344a08
qid3658	SELECT 出版时间 WHERE 书名 == "北极熊报告" or 书名 == "爱哭的猫头鹰"	a9c862ae3b0611e98fa7f40f24344a08
qid3659	SELECT 学历要求 WHERE 招聘单位 == "北京市第二医院" and 职位名称 == "超声医师"	a8e47ee13b0611e9b2ccf40f24344a08
qid3660	SELECT 学历要求 WHERE 招聘单位 == "北京市第二医院" and 职位名称 == "超声医师"	a8e47ee13b0611e9b2ccf40f24344a08
qid3661	SELECT 学历要求 WHERE 招聘单位 == "北京市第二医院" and 职位名称 == "超声医师"	a8e47ee13b0611e9b2ccf40f24344a08
qid3662	SELECT 时间安排 WHERE 活动主题 == "参观爱国主义教育基地"	a86d624c3b0611e99c9ef40f24344a08
qid3663	SELECT 时间安排 WHERE 活动主题 == "参观爱国主义教育基地"	a86d624c3b0611e99c9ef40f24344a08
qid3664	SELECT 竞赛级别（国际级/国家级/省级） WHERE 举办单位 == "教育部" and 学科竞赛名称 == "“互联网+”大学生创新创业大赛"	f6dca92e453d11e997a2f40f24344a08
qid3665	SELECT 竞赛级别（国际级/国家级/省级） WHERE 举办单位 == "教育部" and 学科竞赛名称 == "“互联网+”大学生创新创业大赛"	f6dca92e453d11e997a2f40f24344a08
qid3666	SELECT 竞赛级别（国际级/国家级/省级） WHERE 举办单位 == "教育部" and 学科竞赛名称 == "“互联网+”大学生创新创业大赛"	f6dca92e453d11e997a2f40f24344a08
qid3667	SELECT 岗位名称 WHERE 招聘人数 == "2"	a7dc63b33b0611e9a1bcf40f24344a08
qid3668	SELECT 岗位名称 WHERE 招聘人数 == "2"	a7dc63b33b0611e9a1bcf40f24344a08
qid3669	SELECT 作者 WHERE 书名 == "新文化运动与世界文明" or 书名 == "援藏青春赞歌"	a95e4e303b0611e98a82f40f24344a08
qid3670	SELECT 作者 WHERE 书名 == "新文化运动与世界文明" or 书名 == "援藏青春赞歌"	a95e4e303b0611e98a82f40f24344a08
qid3671	SELECT 作者 WHERE 书名 == "新文化运动与世界文明" or 书名 == "援藏青春赞歌"	a95e4e303b0611e98a82f40f24344a08
qid3672	SELECT 书号（ISBN） WHERE 教材名称 == "全新法语语法"	ab65ca8c3b0611e986e1f40f24344a08
qid3673	SELECT 书号（ISBN） WHERE 教材名称 == "全新法语语法"	ab65ca8c3b0611e986e1f40f24344a08
qid3674	SELECT 书号（ISBN） WHERE 教材名称 == "全新法语语法"	ab65ca8c3b0611e986e1f40f24344a08
qid3675	SELECT 检查结果 WHERE 承检机构 == "河南省机动车零部件质量监督检验中心" and 产品名称 == "减振器"	aab1bff53b0611e9b0a3f40f24344a08
qid3676	SELECT 检查结果 WHERE 承检机构 == "河南省机动车零部件质量监督检验中心" and 产品名称 == "减振器"	aab1bff53b0611e9b0a3f40f24344a08
qid3677	SELECT 检查结果 WHERE 承检机构 == "河南省机动车零部件质量监督检验中心" and 产品名称 == "减振器"	aab1bff53b0611e9b0a3f40f24344a08
qid3678	SELECT 价格 WHERE 规格 == "24片" and 药品名称 == "氨酚伪麻美芬片II/氨麻苯美片"	ab41f3023b0611e98599f40f24344a08
qid3679	SELECT 价格 WHERE 规格 == "24片" and 药品名称 == "氨酚伪麻美芬片II/氨麻苯美片"	ab41f3023b0611e98599f40f24344a08
qid3680	SELECT 产品名称 WHERE 缴费期限 == "一次性"	eebeb368453d11e98042f40f24344a08
qid3681	SELECT 产品名称 WHERE 缴费期限 == "一次性"	eebeb368453d11e98042f40f24344a08
qid3682	SELECT 产品名称 WHERE 缴费期限 == "一次性"	eebeb368453d11e98042f40f24344a08
qid3683	SELECT 学时 WHERE 课程名称 == "计算机与现代医学" or 课程名称 == "餐饮文化与饮食健康"	a9c3019c3b0611e9a77ef40f24344a08
qid3684	SELECT 学时 WHERE 课程名称 == "计算机与现代医学" or 课程名称 == "餐饮文化与饮食健康"	a9c3019c3b0611e9a77ef40f24344a08
qid3685	SELECT 学时 WHERE 课程名称 == "计算机与现代医学" or 课程名称 == "餐饮文化与饮食健康"	a9c3019c3b0611e9a77ef40f24344a08
qid3686	SELECT 所在区县 WHERE 企业名称 == "北京宝盈信达物业服务有限公司" and 项目名称 == "密西花园"	f4fab0e1453d11e99675f40f24344a08
qid3687	SELECT 所在区县 WHERE 企业名称 == "北京宝盈信达物业服务有限公司" and 项目名称 == "密西花园"	f4fab0e1453d11e99675f40f24344a08
qid3688	SELECT 所在区县 WHERE 企业名称 == "北京宝盈信达物业服务有限公司" and 项目名称 == "密西花园"	f4fab0e1453d11e99675f40f24344a08
qid3689	SELECT 考试日期 , 考试教室 WHERE 课程名称 == "税法"	f08402d4453d11e9b9e7f40f24344a08
qid3690	SELECT 考试日期 , 考试教室 WHERE 课程名称 == "税法"	f08402d4453d11e9b9e7f40f24344a08
qid3691	SELECT 考试日期 , 考试教室 WHERE 课程名称 == "税法"	f08402d4453d11e9b9e7f40f24344a08
qid3692	SELECT 抽查结果 WHERE 企业名称 == "上海英雄金笔厂有限公司" and 产品名称 == "笔（水性圆珠笔）"	eddb989e453d11e999f5f40f24344a08
qid3693	SELECT 抽查结果 WHERE 企业名称 == "上海英雄金笔厂有限公司" and 产品名称 == "笔（水性圆珠笔）"	eddb989e453d11e999f5f40f24344a08
qid3694	SELECT 抽查结果 WHERE 企业名称 == "上海英雄金笔厂有限公司" and 产品名称 == "笔（水性圆珠笔）"	eddb989e453d11e999f5f40f24344a08
qid3695	SELECT 题名 WHERE 出版社 == "中共党史出版社"	ab46ee8c3b0611e9a0dbf40f24344a08
qid3696	SELECT 题名 WHERE 出版社 == "中共党史出版社"	ab46ee8c3b0611e9a0dbf40f24344a08
qid3697	SELECT 题名 WHERE 出版社 == "中共党史出版社"	ab46ee8c3b0611e9a0dbf40f24344a08
qid3698	SELECT 专业 WHERE 部门 == "金属有机国家重点实验室" and 课题组 == "黄正组" and 岗位 == "研究助理"	aa8540f33b0611e9b786f40f24344a08
qid3699	SELECT 专业 WHERE 部门 == "金属有机国家重点实验室" and 课题组 == "黄正组" and 岗位 == "研究助理"	aa8540f33b0611e9b786f40f24344a08
qid3700	SELECT 专业 WHERE 部门 == "金属有机国家重点实验室" and 课题组 == "黄正组" and 岗位 == "研究助理"	aa8540f33b0611e9b786f40f24344a08
qid3701	SELECT 交办单位 WHERE 案件号 == "金工商广字（2013）第07号" or 交办日期 == "2013.3.11"	aabc5eca3b0611e9b0e4f40f24344a08
qid3702	SELECT 交办单位 WHERE 案件号 == "金工商广字（2013）第07号" or 交办日期 == "2013.3.11"	aabc5eca3b0611e9b0e4f40f24344a08
qid3703	SELECT 交办单位 WHERE 案件号 == "金工商广字（2013）第07号" or 交办日期 == "2013.3.11"	aabc5eca3b0611e9b0e4f40f24344a08
qid3704	SELECT 标称生产企业名称 WHERE 规格型号 == "10kg/袋" and 食品名称 == "宁昊长香米"	a93817943b0611e9ae3ef40f24344a08
qid3705	SELECT 标称生产企业名称 WHERE 规格型号 == "10kg/袋" and 食品名称 == "宁昊长香米"	a93817943b0611e9ae3ef40f24344a08
qid3706	SELECT 标称生产企业名称 WHERE 规格型号 == "10kg/袋" and 食品名称 == "宁昊长香米"	a93817943b0611e9ae3ef40f24344a08
qid3707	SELECT 作者 WHERE 著作名称 == "聚合物无机萘复合材料"	a916cdbd3b0611e98a17f40f24344a08
qid3708	SELECT 作者 WHERE 著作名称 == "聚合物无机萘复合材料"	a916cdbd3b0611e98a17f40f24344a08
qid3709	SELECT 作者 WHERE 著作名称 == "聚合物无机萘复合材料"	a916cdbd3b0611e98a17f40f24344a08
qid3710	SELECT COUNT ( 書名 ) WHERE 出版年代 == "1945.0"	a830dcbd3b0611e98d26f40f24344a08
qid3711	SELECT COUNT ( 書名 ) WHERE 出版年代 == "1945.0"	a830dcbd3b0611e98d26f40f24344a08
qid3712	SELECT COUNT ( 書名 ) WHERE 出版年代 == "1945.0"	a830dcbd3b0611e98d26f40f24344a08
qid3713	SELECT 投诉受理电子邮件地址 WHERE 航空公司 == "春秋航空股份有限公司"	a7d37f543b0611e98a9bf40f24344a08
qid3714	SELECT 投诉受理电子邮件地址 WHERE 航空公司 == "春秋航空股份有限公司"	a7d37f543b0611e98a9bf40f24344a08
qid3715	SELECT 投诉受理电子邮件地址 WHERE 航空公司 == "春秋航空股份有限公司"	a7d37f543b0611e98a9bf40f24344a08
qid3716	SELECT 办理依据 WHERE 实施机构 == "市妇联办公室（组宣部）" and 事项名称 == "寻找最美家庭"	a9001e7a3b0611e9994ef40f24344a08
qid3717	SELECT 办理依据 WHERE 实施机构 == "市妇联办公室（组宣部）" and 事项名称 == "寻找最美家庭"	a9001e7a3b0611e9994ef40f24344a08
qid3718	SELECT 办理依据 WHERE 实施机构 == "市妇联办公室（组宣部）" and 事项名称 == "寻找最美家庭"	a9001e7a3b0611e9994ef40f24344a08
qid3719	SELECT 单位名称 WHERE 奖项 == "二等奖"	a8d2a2753b0611e992c4f40f24344a08
qid3720	SELECT 单位名称 WHERE 奖项 == "二等奖"	a8d2a2753b0611e992c4f40f24344a08
qid3721	SELECT 价格 WHERE 书名 == "食色男女" and 作者 == "戴军著"	f5e7bedc453d11e9b1f0f40f24344a08
qid3722	SELECT 价格 WHERE 书名 == "食色男女" and 作者 == "戴军著"	f5e7bedc453d11e9b1f0f40f24344a08
qid3723	SELECT 价格 WHERE 书名 == "食色男女" and 作者 == "戴军著"	f5e7bedc453d11e9b1f0f40f24344a08
qid3724	SELECT 被抽查单位 WHERE 抽查结果 == "合格"	f40a6c66453d11e9b1eef40f24344a08
qid3725	SELECT 被抽查单位 WHERE 抽查结果 == "合格"	f40a6c66453d11e9b1eef40f24344a08
qid3726	SELECT 发行量(000) WHERE 国家 == "日本" and 名称 == "东京体育报"	f60ac2d7453d11e9ad9bf40f24344a08
qid3727	SELECT 发行量(000) WHERE 国家 == "日本" and 名称 == "东京体育报"	f60ac2d7453d11e9ad9bf40f24344a08
qid3728	SELECT 发行量(000) WHERE 国家 == "日本" and 名称 == "东京体育报"	f60ac2d7453d11e9ad9bf40f24344a08
qid3729	SELECT 血透设备数量（台） WHERE 医疗机构名称 == "深圳市中医院"	f690bb40453d11e98654f40f24344a08
qid3730	SELECT 血透设备数量（台） WHERE 医疗机构名称 == "深圳市中医院"	f690bb40453d11e98654f40f24344a08
qid3731	SELECT 血透设备数量（台） WHERE 医疗机构名称 == "深圳市中医院"	f690bb40453d11e98654f40f24344a08
qid3732	SELECT 产品名称 WHERE 规格型号 == "AS22-5.5-90" or 生产日期（批号） == "2011-07-22"	a82ffa383b0611e9ab29f40f24344a08
qid3733	SELECT 产品名称 WHERE 规格型号 == "AS22-5.5-90" or 生产日期（批号） == "2011-07-22"	a82ffa383b0611e9ab29f40f24344a08
qid3734	SELECT 产品名称 WHERE 规格型号 == "AS22-5.5-90" or 生产日期（批号） == "2011-07-22"	a82ffa383b0611e9ab29f40f24344a08
qid3735	SELECT 产品名称 , 生产企业 WHERE 承检机构 == "潍坊市质检所" and 抽查结果 == "不合格"	f59ad32e453d11e98712f40f24344a08
qid3736	SELECT 产品名称 , 生产企业 WHERE 承检机构 == "潍坊市质检所" and 抽查结果 == "不合格"	f59ad32e453d11e98712f40f24344a08
qid3737	SELECT 产品名称 , 生产企业 WHERE 承检机构 == "潍坊市质检所" and 抽查结果 == "不合格"	f59ad32e453d11e98712f40f24344a08
qid3738	SELECT COUNT ( 参考书 ) WHERE 科目名称 == "高等代数" or 出版社 == "高等教育出版社第三版"	abe9e7e13b0611e9a90df40f24344a08
qid3739	SELECT COUNT ( 参考书 ) WHERE 科目名称 == "高等代数" or 出版社 == "高等教育出版社第三版"	abe9e7e13b0611e9a90df40f24344a08
qid3740	SELECT COUNT ( 参考书 ) WHERE 科目名称 == "高等代数" or 出版社 == "高等教育出版社第三版"	abe9e7e13b0611e9a90df40f24344a08
qid3741	SELECT 引进单位 WHERE 剧名 == "爱情的呼唤" and 类别 == "电影"	aaac24d93b0611e9af27f40f24344a08
qid3742	SELECT 引进单位 WHERE 剧名 == "爱情的呼唤" and 类别 == "电影"	aaac24d93b0611e9af27f40f24344a08
qid3743	SELECT 引进单位 WHERE 剧名 == "爱情的呼唤" and 类别 == "电影"	aaac24d93b0611e9af27f40f24344a08
qid3744	SELECT 收费类别 WHERE 单位名称 == "解放军五三三医院"	abdf3da63b0611e99f41f40f24344a08
qid3745	SELECT 收费类别 WHERE 单位名称 == "解放军五三三医院"	abdf3da63b0611e99f41f40f24344a08
qid3746	SELECT 标称生产企业名称 WHERE 规格型号 == "300g/袋" and 食品名称 == "豆皮"	ab0c66073b0611e9a067f40f24344a08
qid3747	SELECT 标称生产企业名称 WHERE 规格型号 == "300g/袋" and 食品名称 == "豆皮"	ab0c66073b0611e9a067f40f24344a08
qid3748	SELECT 标称生产企业名称 WHERE 规格型号 == "300g/袋" and 食品名称 == "豆皮"	ab0c66073b0611e9a067f40f24344a08
qid3749	SELECT 学费（人民币：元） WHERE 招生专业（课程）名称 == "护理学" and 专业（课程）类别 == "理工类"	f07a4f1c453d11e9ba7df40f24344a08
qid3750	SELECT 学费（人民币：元） WHERE 招生专业（课程）名称 == "护理学" and 专业（课程）类别 == "理工类"	f07a4f1c453d11e9ba7df40f24344a08
qid3751	SELECT 学费（人民币：元） WHERE 招生专业（课程）名称 == "护理学" and 专业（课程）类别 == "理工类"	f07a4f1c453d11e9ba7df40f24344a08
qid3752	SELECT 内容 WHERE 交办限定回交时间 == "2013.3.15" or 交办日期 == "2013.1.29"	aabc5eca3b0611e9b0e4f40f24344a08
qid3753	SELECT 内容 WHERE 交办限定回交时间 == "2013.3.15" or 交办日期 == "2013.1.29"	aabc5eca3b0611e9b0e4f40f24344a08
qid3754	SELECT 内容 WHERE 交办限定回交时间 == "2013.3.15" or 交办日期 == "2013.1.29"	aabc5eca3b0611e9b0e4f40f24344a08
qid3755	SELECT 出版日期 WHERE 作者 == "王军著" and 书名 == "炒股第一步"	aaf666593b0611e99aabf40f24344a08
qid3756	SELECT 出版日期 WHERE 作者 == "王军著" and 书名 == "炒股第一步"	aaf666593b0611e99aabf40f24344a08
qid3757	SELECT 出版日期 WHERE 作者 == "王军著" and 书名 == "炒股第一步"	aaf666593b0611e99aabf40f24344a08
qid3758	SELECT 领队 WHERE 团队名称 == "SumerHot" or 团队名称 == "党建在工商"	aa71e13a3b0611e9a91af40f24344a08
qid3759	SELECT 领队 WHERE 团队名称 == "SumerHot" or 团队名称 == "党建在工商"	aa71e13a3b0611e9a91af40f24344a08
qid3760	SELECT 领队 WHERE 团队名称 == "SumerHot" or 团队名称 == "党建在工商"	aa71e13a3b0611e9a91af40f24344a08
qid3761	SELECT 企业名称 WHERE 电商平台 == "天猫" and 产品名称 == "电磁炉"	a8b8afa33b0611e9a1e9f40f24344a08
qid3762	SELECT 企业名称 WHERE 电商平台 == "天猫" and 产品名称 == "电磁炉"	a8b8afa33b0611e9a1e9f40f24344a08
qid3763	SELECT 企业名称 WHERE 电商平台 == "天猫" and 产品名称 == "电磁炉"	a8b8afa33b0611e9a1e9f40f24344a08
qid3764	SELECT 招聘人数 WHERE 职位名称 == "党务文秘"	abe568fa3b0611e98ef0f40f24344a08
qid3765	SELECT 招聘人数 WHERE 职位名称 == "党务文秘"	abe568fa3b0611e98ef0f40f24344a08
qid3766	SELECT 招聘人数 WHERE 职位名称 == "党务文秘"	abe568fa3b0611e98ef0f40f24344a08
qid3767	SELECT 承接机构 WHERE 项目名称 == "“守护青春”志愿服务项目"	aa8ca5913b0611e9b798f40f24344a08
qid3768	SELECT 承接机构 WHERE 项目名称 == "“守护青春”志愿服务项目"	aa8ca5913b0611e9b798f40f24344a08
qid3769	SELECT 承接机构 WHERE 项目名称 == "“守护青春”志愿服务项目"	aa8ca5913b0611e9b798f40f24344a08
qid3770	SELECT 电话 , 地址 WHERE 单位 == "桂林街派出所"	f55ad30a453d11e98aa8f40f24344a08
qid3771	SELECT 电话 , 地址 WHERE 单位 == "桂林街派出所"	f55ad30a453d11e98aa8f40f24344a08
qid3772	SELECT 电话 , 地址 WHERE 单位 == "桂林街派出所"	f55ad30a453d11e98aa8f40f24344a08
qid3773	SELECT 作者 WHERE 题名 == "读书是件好玩的事"	f1af118a453d11e9af76f40f24344a08
qid3774	SELECT 作者 WHERE 题名 == "读书是件好玩的事"	f1af118a453d11e9af76f40f24344a08
qid3775	SELECT 作者 WHERE 题名 == "读书是件好玩的事"	f1af118a453d11e9af76f40f24344a08
qid3776	SELECT 责任者 WHERE 题名 == "美国手记:"	a8e0e6353b0611e9a67ff40f24344a08
qid3777	SELECT 责任者 WHERE 题名 == "美国手记:"	a8e0e6353b0611e9a67ff40f24344a08
qid3778	SELECT 责任者 WHERE 题名 == "美国手记:"	a8e0e6353b0611e9a67ff40f24344a08
qid3779	SELECT 编号 WHERE 申报题目 == "医学生视野中的“白求恩精神”调查与分析" or 申报题目 == "学生党员党性锻炼长效机制的研究与实践"	ef45907d453d11e9b847f40f24344a08
qid3780	SELECT 编号 WHERE 申报题目 == "医学生视野中的“白求恩精神”调查与分析" or 申报题目 == "学生党员党性锻炼长效机制的研究与实践"	ef45907d453d11e9b847f40f24344a08
qid3781	SELECT 编号 WHERE 申报题目 == "医学生视野中的“白求恩精神”调查与分析" or 申报题目 == "学生党员党性锻炼长效机制的研究与实践"	ef45907d453d11e9b847f40f24344a08
qid3782	SELECT 科目名称 WHERE 出版社名 == "高等教育出版社"	aa7024303b0611e9acb2f40f24344a08
qid3783	SELECT 科目名称 WHERE 出版社名 == "高等教育出版社"	aa7024303b0611e9acb2f40f24344a08
qid3784	SELECT 科目名称 WHERE 出版社名 == "高等教育出版社"	aa7024303b0611e9acb2f40f24344a08
qid3785	SELECT 抽样日期 WHERE 药品名称 == "咳特灵胶囊" or 药品名称 == "众生丸"	f1503bd7453d11e99c91f40f24344a08
qid3786	SELECT 抽样日期 WHERE 药品名称 == "咳特灵胶囊" or 药品名称 == "众生丸"	f1503bd7453d11e99c91f40f24344a08
qid3787	SELECT 抽样日期 WHERE 药品名称 == "咳特灵胶囊" or 药品名称 == "众生丸"	f1503bd7453d11e99c91f40f24344a08
qid3788	SELECT 出版社 WHERE 名称 == "飞行学校"	aa6eeb193b0611e98d6bf40f24344a08
qid3789	SELECT 出版社 WHERE 名称 == "飞行学校"	aa6eeb193b0611e98d6bf40f24344a08
qid3790	SELECT 项目名称 WHERE 立项经费 == "12" and 所属单位 == "法学院"	ef184cab453d11e9b0a5f40f24344a08
qid3791	SELECT 项目名称 WHERE 立项经费 == "12" and 所属单位 == "法学院"	ef184cab453d11e9b0a5f40f24344a08
qid3792	SELECT 项目名称 WHERE 立项经费 == "12" and 所属单位 == "法学院"	ef184cab453d11e9b0a5f40f24344a08
qid3793	SELECT 月薪（元/月） WHERE 单位名称 == "上海众兴国际旅行社有限公司" and 岗位名称 == "导游（见习）"	a8fa60f03b0611e9b705f40f24344a08
qid3794	SELECT 月薪（元/月） WHERE 单位名称 == "上海众兴国际旅行社有限公司" and 岗位名称 == "导游（见习）"	a8fa60f03b0611e9b705f40f24344a08
qid3795	SELECT 月薪（元/月） WHERE 单位名称 == "上海众兴国际旅行社有限公司" and 岗位名称 == "导游（见习）"	a8fa60f03b0611e9b705f40f24344a08
qid3796	SELECT 专业 WHERE 招聘单位名称 == "吉水县公证处" and 岗位名称 == "公证员助理"	ab08b4d43b0611e9ba7ff40f24344a08
qid3797	SELECT 专业 WHERE 招聘单位名称 == "吉水县公证处" and 岗位名称 == "公证员助理"	ab08b4d43b0611e9ba7ff40f24344a08
qid3798	SELECT 专业 WHERE 招聘单位名称 == "吉水县公证处" and 岗位名称 == "公证员助理"	ab08b4d43b0611e9ba7ff40f24344a08
qid3799	SELECT 应聘职位 , 具体用人单位 WHERE 学位 == "硕士" and 专业 == "大气科学"	a868b5613b0611e9a5e8f40f24344a08
qid3800	SELECT 应聘职位 , 具体用人单位 WHERE 学位 == "硕士" and 专业 == "大气科学"	a868b5613b0611e9a5e8f40f24344a08
qid3801	SELECT 应聘职位 , 具体用人单位 WHERE 学位 == "硕士" and 专业 == "大气科学"	a868b5613b0611e9a5e8f40f24344a08
qid3802	SELECT 检验结论 WHERE 样品名称 == "玫瑰香干" or 样品名称 == "精品茶干"	edab6ecf453d11e9a01df40f24344a08
qid3803	SELECT 检验结论 WHERE 样品名称 == "玫瑰香干" or 样品名称 == "精品茶干"	edab6ecf453d11e9a01df40f24344a08
qid3804	SELECT 检验结论 WHERE 样品名称 == "玫瑰香干" or 样品名称 == "精品茶干"	edab6ecf453d11e9a01df40f24344a08
qid3805	SELECT 项目内容 , 金额 WHERE 项目单位 == "北京市农业局"	aa804cab3b0611e9b277f40f24344a08
qid3806	SELECT 项目内容 , 金额 WHERE 项目单位 == "北京市农业局"	aa804cab3b0611e9b277f40f24344a08
qid3807	SELECT 定价 WHERE 书名 == "百年永定爱育辉煌" or 书名 == "大学生主体性发展"	aae6798c3b0611e9bbd4f40f24344a08
qid3808	SELECT 定价 WHERE 书名 == "百年永定爱育辉煌" or 书名 == "大学生主体性发展"	aae6798c3b0611e9bbd4f40f24344a08
qid3809	SELECT 定价 WHERE 书名 == "百年永定爱育辉煌" or 书名 == "大学生主体性发展"	aae6798c3b0611e9bbd4f40f24344a08
qid3810	SELECT 期刊名 WHERE 投稿难易度 == "很难（命中率约20%）" or 审稿时长 == "较慢,6-12周"	aad6c1a33b0611e99b65f40f24344a08
qid3811	SELECT 期刊名 WHERE 投稿难易度 == "很难（命中率约20%）" or 审稿时长 == "较慢,6-12周"	aad6c1a33b0611e99b65f40f24344a08
qid3812	SELECT 期刊名 WHERE 投稿难易度 == "很难（命中率约20%）" or 审稿时长 == "较慢,6-12周"	aad6c1a33b0611e99b65f40f24344a08
qid3813	SELECT 生产企业名称(标称) WHERE 产品名称 == "饼干袋"	ed3e63ba453d11e9b869f40f24344a08
qid3814	SELECT 生产企业名称(标称) WHERE 产品名称 == "饼干袋"	ed3e63ba453d11e9b869f40f24344a08
qid3815	SELECT 生产企业名称(标称) WHERE 产品名称 == "饼干袋"	ed3e63ba453d11e9b869f40f24344a08
qid3816	SELECT 教材名称 WHERE ISBN == "978-7-301-12261-7" or ISBN == "978-7-5628-2783-2"	aa76a5cf3b0611e9b05bf40f24344a08
qid3817	SELECT 教材名称 WHERE ISBN == "978-7-301-12261-7" or ISBN == "978-7-5628-2783-2"	aa76a5cf3b0611e9b05bf40f24344a08
qid3818	SELECT 教材名称 WHERE ISBN == "978-7-301-12261-7" or ISBN == "978-7-5628-2783-2"	aa76a5cf3b0611e9b05bf40f24344a08
qid3819	SELECT 被抽检单位名称 WHERE 食品名称 == "卤牛肉"	a87d01a13b0611e98534f40f24344a08
qid3820	SELECT 被抽检单位名称 WHERE 食品名称 == "卤牛肉"	a87d01a13b0611e98534f40f24344a08
qid3821	SELECT 书名 WHERE 装帧 == "平装" and 估定价 > "35"	aa2e9e213b0611e9ba5bf40f24344a08
qid3822	SELECT 书名 WHERE 装帧 == "平装" and 估定价 > "35"	aa2e9e213b0611e9ba5bf40f24344a08
qid3823	SELECT 书名 WHERE 装帧 == "平装" and 估定价 > "35"	aa2e9e213b0611e9ba5bf40f24344a08
qid3824	SELECT 总学分 WHERE 课程名称 == "物理学拓展" or 课程名称 == "复分析"	ab6c2c3a3b0611e9871cf40f24344a08
qid3825	SELECT 总学分 WHERE 课程名称 == "物理学拓展" or 课程名称 == "复分析"	ab6c2c3a3b0611e9871cf40f24344a08
qid3826	SELECT 总学分 WHERE 课程名称 == "物理学拓展" or 课程名称 == "复分析"	ab6c2c3a3b0611e9871cf40f24344a08
qid3827	SELECT 项目名称 , 负责人 WHERE 工作单位 == "新疆社会科学院" and 拨款额（万元） > "1"	effd453a453d11e99af3f40f24344a08
qid3828	SELECT 项目名称 , 负责人 WHERE 工作单位 == "新疆社会科学院" and 拨款额（万元） > "1"	effd453a453d11e99af3f40f24344a08
qid3829	SELECT 项目名称 , 负责人 WHERE 工作单位 == "新疆社会科学院" and 拨款额（万元） > "1"	effd453a453d11e99af3f40f24344a08
qid3830	SELECT 经济舱最高限价 WHERE 出发 == "百色" and 到达 == "深圳"	a97294303b0611e992a5f40f24344a08
qid3831	SELECT 经济舱最高限价 WHERE 出发 == "百色" and 到达 == "深圳"	a97294303b0611e992a5f40f24344a08
qid3832	SELECT 经济舱最高限价 WHERE 出发 == "百色" and 到达 == "深圳"	a97294303b0611e992a5f40f24344a08
qid3833	SELECT 地址 WHERE 市 == "天津市" and 所属区 == "河西区" and 考点名称 == "天津财经大学"	aa778f403b0611e9a036f40f24344a08
qid3834	SELECT 地址 WHERE 市 == "天津市" and 所属区 == "河西区" and 考点名称 == "天津财经大学"	aa778f403b0611e9a036f40f24344a08
qid3835	SELECT 地址 WHERE 市 == "天津市" and 所属区 == "河西区" and 考点名称 == "天津财经大学"	aa778f403b0611e9a036f40f24344a08
qid3836	SELECT 规格型号 WHERE 产品名称 == "电磁灶" and 抽查结果 == "合格"	f00da845453d11e98374f40f24344a08
qid3837	SELECT 规格型号 WHERE 产品名称 == "电磁灶" and 抽查结果 == "合格"	f00da845453d11e98374f40f24344a08
qid3838	SELECT 规格型号 WHERE 产品名称 == "电磁灶" and 抽查结果 == "合格"	f00da845453d11e98374f40f24344a08
qid3839	SELECT 开始日期 WHERE 会议类型 == "省级会议" and 会议名称 == "中原经济区旅游创新与发展论坛"	a93a8a383b0611e984e6f40f24344a08
qid3840	SELECT 开始日期 WHERE 会议类型 == "省级会议" and 会议名称 == "中原经济区旅游创新与发展论坛"	a93a8a383b0611e984e6f40f24344a08
qid3841	SELECT 开始日期 WHERE 会议类型 == "省级会议" and 会议名称 == "中原经济区旅游创新与发展论坛"	a93a8a383b0611e984e6f40f24344a08
qid3842	SELECT 书号 WHERE 书名 == "德国的科学" or 书名 == "复杂性之美"	a9d7d23d3b0611e9b471f40f24344a08
qid3843	SELECT 书号 WHERE 书名 == "德国的科学" or 书名 == "复杂性之美"	a9d7d23d3b0611e9b471f40f24344a08
qid3844	SELECT 书号 WHERE 书名 == "德国的科学" or 书名 == "复杂性之美"	a9d7d23d3b0611e9b471f40f24344a08
qid3845	SELECT 定价 WHERE 作者 == "郑先炳著" and 书名 == "解读花旗银行"	ee840f91453d11e98a30f40f24344a08
qid3846	SELECT 定价 WHERE 作者 == "郑先炳著" and 书名 == "解读花旗银行"	ee840f91453d11e98a30f40f24344a08
qid3847	SELECT 定价 WHERE 作者 == "郑先炳著" and 书名 == "解读花旗银行"	ee840f91453d11e98a30f40f24344a08
qid3848	SELECT 运营单位名称 WHERE 创业基地名称 == "湖南大学国家大学科技园"	ee2ea642453d11e9a71ef40f24344a08
qid3849	SELECT 运营单位名称 WHERE 创业基地名称 == "湖南大学国家大学科技园"	ee2ea642453d11e9a71ef40f24344a08
qid3850	SELECT 部数 WHERE 基地 == "深圳市动画制作中心"	f429ea0a453d11e9b3a6f40f24344a08
qid3851	SELECT 部数 WHERE 基地 == "深圳市动画制作中心"	f429ea0a453d11e9b3a6f40f24344a08
qid3852	SELECT 部数 WHERE 基地 == "深圳市动画制作中心"	f429ea0a453d11e9b3a6f40f24344a08
qid3853	SELECT 车辆型号 , 车辆牌号 WHERE 所属区县 == "松江" and 学校名称 == "新浜小学"	f134dc30453d11e992aaf40f24344a08
qid3854	SELECT 车辆型号 , 车辆牌号 WHERE 所属区县 == "松江" and 学校名称 == "新浜小学"	f134dc30453d11e992aaf40f24344a08
qid3855	SELECT 车辆型号 , 车辆牌号 WHERE 所属区县 == "松江" and 学校名称 == "新浜小学"	f134dc30453d11e992aaf40f24344a08
qid3856	SELECT 产品名称 , 证书编号 WHERE 鉴定机构 == "农业部农业机械试验鉴定总站"	a7c5ae263b0611e98ebaf40f24344a08
qid3857	SELECT 产品名称 , 证书编号 WHERE 鉴定机构 == "农业部农业机械试验鉴定总站"	a7c5ae263b0611e98ebaf40f24344a08
qid3858	SELECT 产品名称 , 证书编号 WHERE 鉴定机构 == "农业部农业机械试验鉴定总站"	a7c5ae263b0611e98ebaf40f24344a08
qid3859	SELECT 招聘人数 WHERE 招聘单位 == "鲁迅美术学院" and 岗位名称 == "设计史论专业筹备组专任教师一"	aac55fc23b0611e98bb6f40f24344a08
qid3860	SELECT 招聘人数 WHERE 招聘单位 == "鲁迅美术学院" and 岗位名称 == "设计史论专业筹备组专任教师一"	aac55fc23b0611e98bb6f40f24344a08
qid3861	SELECT 招聘人数 WHERE 招聘单位 == "鲁迅美术学院" and 岗位名称 == "设计史论专业筹备组专任教师一"	aac55fc23b0611e98bb6f40f24344a08
qid3862	SELECT 岗位名称 WHERE 工作职责 == "文档整理、网络维护" or 缺岗数 > "3"	f5f57c2b453d11e986b5f40f24344a08
qid3863	SELECT 岗位名称 WHERE 工作职责 == "文档整理、网络维护" or 缺岗数 > "3"	f5f57c2b453d11e986b5f40f24344a08
qid3864	SELECT 岗位名称 WHERE 工作职责 == "文档整理、网络维护" or 缺岗数 > "3"	f5f57c2b453d11e986b5f40f24344a08
qid3865	SELECT 定价 WHERE 书名 == "影视精品导读"	a80f97473b0611e99f35f40f24344a08
qid3866	SELECT 定价 WHERE 书名 == "影视精品导读"	a80f97473b0611e99f35f40f24344a08
qid3867	SELECT 定价 WHERE 书名 == "影视精品导读"	a80f97473b0611e99f35f40f24344a08
qid3868	SELECT 定价 WHERE 年级 == "七年级" and 教辅名称 == "欢乐寒假"	abac4db03b0611e99a64f40f24344a08
qid3869	SELECT 定价 WHERE 年级 == "七年级" and 教辅名称 == "欢乐寒假"	abac4db03b0611e99a64f40f24344a08
qid3870	SELECT 定价 WHERE 年级 == "七年级" and 教辅名称 == "欢乐寒假"	abac4db03b0611e99a64f40f24344a08
qid3871	SELECT 书号 WHERE 书名 == "这就是纽约"	f27972ae453d11e99485f40f24344a08
qid3872	SELECT 书号 WHERE 书名 == "这就是纽约"	f27972ae453d11e99485f40f24344a08
qid3873	SELECT 书号 WHERE 书名 == "这就是纽约"	f27972ae453d11e99485f40f24344a08
qid3874	SELECT 获奖者 WHERE 成果形式 == "论文" and 获奖等级 == "三等奖"	f5430dc5453d11e9bc94f40f24344a08
qid3875	SELECT 获奖者 WHERE 成果形式 == "论文" and 获奖等级 == "三等奖"	f5430dc5453d11e9bc94f40f24344a08
qid3876	SELECT 获奖者 WHERE 成果形式 == "论文" and 获奖等级 == "三等奖"	f5430dc5453d11e9bc94f40f24344a08
qid3877	SELECT 规格型号 WHERE 产品名称 == "染色布"	edd2ac02453d11e99008f40f24344a08
qid3878	SELECT 规格型号 WHERE 产品名称 == "染色布"	edd2ac02453d11e99008f40f24344a08
qid3879	SELECT 规格型号 WHERE 产品名称 == "染色布"	edd2ac02453d11e99008f40f24344a08
qid3880	SELECT 成果名称 , 主要完成人 WHERE 等级 == "特等奖"	ede64885453d11e992edf40f24344a08
qid3881	SELECT 成果名称 , 主要完成人 WHERE 等级 == "特等奖"	ede64885453d11e992edf40f24344a08
qid3882	SELECT 成果名称 , 主要完成人 WHERE 等级 == "特等奖"	ede64885453d11e992edf40f24344a08
qid3883	SELECT 作者 WHERE 出版社 == "上海外教" and 书名 == "变频器原理及应用"	ed6289c2453d11e99d33f40f24344a08
qid3884	SELECT 作者 WHERE 出版社 == "上海外教" and 书名 == "变频器原理及应用"	ed6289c2453d11e99d33f40f24344a08
qid3885	SELECT 作者 WHERE 出版社 == "上海外教" and 书名 == "变频器原理及应用"	ed6289c2453d11e99d33f40f24344a08
qid3886	SELECT 项目名称 WHERE 完成单位 == "江西中医药大学"	abc762943b0611e981e3f40f24344a08
qid3887	SELECT 项目名称 WHERE 完成单位 == "江西中医药大学"	abc762943b0611e981e3f40f24344a08
qid3888	SELECT 作者 WHERE 出版社 == "人民出版社" and 成果名称 == "创业发展论"	a980fb263b0611e9b3fdf40f24344a08
qid3889	SELECT 作者 WHERE 出版社 == "人民出版社" and 成果名称 == "创业发展论"	a980fb263b0611e9b3fdf40f24344a08
qid3890	SELECT 作者 WHERE 出版社 == "人民出版社" and 成果名称 == "创业发展论"	a980fb263b0611e9b3fdf40f24344a08
qid3891	SELECT 数量 WHERE 书名 == "广元石窟"	a8e811e83b0611e99f6df40f24344a08
qid3892	SELECT 数量 WHERE 书名 == "广元石窟"	a8e811e83b0611e99f6df40f24344a08
qid3893	SELECT 数量 WHERE 书名 == "广元石窟"	a8e811e83b0611e99f6df40f24344a08
qid3894	SELECT 作者 WHERE 作品 == "白夜行"	aa39fc333b0611e9943cf40f24344a08
qid3895	SELECT 作者 WHERE 作品 == "白夜行"	aa39fc333b0611e9943cf40f24344a08
qid3896	SELECT 作者 WHERE 作品 == "白夜行"	aa39fc333b0611e9943cf40f24344a08
qid3897	SELECT 通用名 WHERE 药品编码 == "122246"	a8f4d8803b0611e98766f40f24344a08
qid3898	SELECT 通用名 WHERE 药品编码 == "122246"	a8f4d8803b0611e98766f40f24344a08
qid3899	SELECT 通用名 WHERE 药品编码 == "122246"	a8f4d8803b0611e98766f40f24344a08
qid3900	SELECT 招聘计划 , 报名人数 WHERE 招聘岗位 == "麻醉医师"	aa85487d3b0611e9a737f40f24344a08
qid3901	SELECT 招聘计划 , 报名人数 WHERE 招聘岗位 == "麻醉医师"	aa85487d3b0611e9a737f40f24344a08
qid3902	SELECT 招聘计划 , 报名人数 WHERE 招聘岗位 == "麻醉医师"	aa85487d3b0611e9a737f40f24344a08
qid3903	SELECT 书名 WHERE 出版社 == "台大出版中心"	a8b9d9a63b0611e98bd1f40f24344a08
qid3904	SELECT 书名 WHERE 出版社 == "台大出版中心"	a8b9d9a63b0611e98bd1f40f24344a08
qid3905	SELECT 书名 WHERE 出版社 == "台大出版中心"	a8b9d9a63b0611e98bd1f40f24344a08
qid3906	SELECT 书名 WHERE 出版社 == "人教社" and 出版 == "初版"	ed472e14453d11e9aa84f40f24344a08
qid3907	SELECT 书名 WHERE 出版社 == "人教社" and 出版 == "初版"	ed472e14453d11e9aa84f40f24344a08
qid3908	SELECT 书名 WHERE 出版社 == "人教社" and 出版 == "初版"	ed472e14453d11e9aa84f40f24344a08
qid3909	SELECT 岗位代码 WHERE 招聘岗位 == "心内科医师"	ab2406263b0611e99282f40f24344a08
qid3910	SELECT 岗位代码 WHERE 招聘岗位 == "心内科医师"	ab2406263b0611e99282f40f24344a08
qid3911	SELECT 岗位代码 WHERE 招聘岗位 == "心内科医师"	ab2406263b0611e99282f40f24344a08
qid3912	SELECT 办理部门 WHERE 证照事项名称 == "国际货运代理企业备案"	f6caa723453d11e9a7bbf40f24344a08
qid3913	SELECT 办理部门 WHERE 证照事项名称 == "国际货运代理企业备案"	f6caa723453d11e9a7bbf40f24344a08
qid3914	SELECT 计算公式 WHERE 图形名称 == "正n边形" and 名称 == "圆心角（α）"	f636a48f453d11e9a22bf40f24344a08
qid3915	SELECT 计算公式 WHERE 图形名称 == "正n边形" and 名称 == "圆心角（α）"	f636a48f453d11e9a22bf40f24344a08
qid3916	SELECT 计算公式 WHERE 图形名称 == "正n边形" and 名称 == "圆心角（α）"	f636a48f453d11e9a22bf40f24344a08
qid3917	SELECT 定价 , 页数 WHERE 书名 == "雨的四季·海之幻"	a888c06e3b0611e9bb2df40f24344a08
qid3918	SELECT 定价 , 页数 WHERE 书名 == "雨的四季·海之幻"	a888c06e3b0611e9bb2df40f24344a08
qid3919	SELECT 定价 , 页数 WHERE 书名 == "雨的四季·海之幻"	a888c06e3b0611e9bb2df40f24344a08
qid3920	SELECT 读者对象 WHERE 题名 == "管理沟通"	a915277a3b0611e9afd4f40f24344a08
qid3921	SELECT 读者对象 WHERE 题名 == "管理沟通"	a915277a3b0611e9afd4f40f24344a08
qid3922	SELECT 读者对象 WHERE 题名 == "管理沟通"	a915277a3b0611e9afd4f40f24344a08
qid3923	SELECT 商户营业地址 WHERE 门店名称 == "拱北口岸中旅"	f56583e8453d11e99168f40f24344a08
qid3924	SELECT 商户营业地址 WHERE 门店名称 == "拱北口岸中旅"	f56583e8453d11e99168f40f24344a08
qid3925	SELECT 商户营业地址 WHERE 门店名称 == "拱北口岸中旅"	f56583e8453d11e99168f40f24344a08
qid3926	SELECT 规格型号 WHERE 企业名称 == "爱好（上海）商贸有限公司" and 产品名称 == "儿童旅游鞋"	a88cecab3b0611e994ebf40f24344a08
qid3927	SELECT 规格型号 WHERE 企业名称 == "爱好（上海）商贸有限公司" and 产品名称 == "儿童旅游鞋"	a88cecab3b0611e994ebf40f24344a08
qid3928	SELECT 规格型号 WHERE 企业名称 == "爱好（上海）商贸有限公司" and 产品名称 == "儿童旅游鞋"	a88cecab3b0611e994ebf40f24344a08
qid3929	SELECT 剧名 WHERE 集数 > "10"	ab7cd7753b0611e9beb8f40f24344a08
qid3930	SELECT 剧名 WHERE 集数 > "10"	ab7cd7753b0611e9beb8f40f24344a08
qid3931	SELECT 剧名 WHERE 集数 > "10"	ab7cd7753b0611e9beb8f40f24344a08
qid3932	SELECT 企业名称 , 检查结论 WHERE 资质等级 == "甲"	a81733873b0611e993e4f40f24344a08
qid3933	SELECT 企业名称 , 检查结论 WHERE 资质等级 == "甲"	a81733873b0611e993e4f40f24344a08
qid3934	SELECT 企业名称 , 检查结论 WHERE 资质等级 == "甲"	a81733873b0611e993e4f40f24344a08
qid3935	SELECT 采购内容 WHERE 数量 > "100"	ab2d6ef03b0611e9b97df40f24344a08
qid3936	SELECT 采购内容 WHERE 数量 > "100"	ab2d6ef03b0611e9b97df40f24344a08
qid3937	SELECT 招聘岗位名称 , 报考人数 WHERE 需求学历 == "研究生"	a87638d43b0611e997a4f40f24344a08
qid3938	SELECT 招聘岗位名称 , 报考人数 WHERE 需求学历 == "研究生"	a87638d43b0611e997a4f40f24344a08
qid3939	SELECT 招聘岗位名称 , 报考人数 WHERE 需求学历 == "研究生"	a87638d43b0611e997a4f40f24344a08
qid3940	SELECT 岗位名称 WHERE 单位名称（具体用人单位） == "胜利发电厂"	a88525573b0611e99a0ff40f24344a08
qid3941	SELECT 岗位名称 WHERE 单位名称（具体用人单位） == "胜利发电厂"	a88525573b0611e99a0ff40f24344a08
qid3942	SELECT 岗位名称 WHERE 单位名称（具体用人单位） == "胜利发电厂"	a88525573b0611e99a0ff40f24344a08
qid3943	SELECT 成果名称 WHERE 获奖等级 == "著作一等奖"	a9345f1e3b0611e98bfbf40f24344a08
qid3944	SELECT 成果名称 WHERE 获奖等级 == "著作一等奖"	a9345f1e3b0611e98bfbf40f24344a08
qid3945	SELECT 成果名称 WHERE 获奖等级 == "著作一等奖"	a9345f1e3b0611e98bfbf40f24344a08
qid3946	SELECT COUNT ( 场馆名称 ) WHERE 座位数（个） > "40000"	ed6715a1453d11e98830f40f24344a08
qid3947	SELECT COUNT ( 场馆名称 ) WHERE 座位数（个） > "40000"	ed6715a1453d11e98830f40f24344a08
qid3948	SELECT COUNT ( 场馆名称 ) WHERE 座位数（个） > "40000"	ed6715a1453d11e98830f40f24344a08
qid3949	SELECT 企业全称 WHERE 注册区县 == "静海区" or 申请类别 == "股改补助" or 补助金额 == "20万元"	f6e75ee6453d11e9b0edf40f24344a08
qid3950	SELECT 企业全称 WHERE 注册区县 == "静海区" or 申请类别 == "股改补助" or 补助金额 == "20万元"	f6e75ee6453d11e9b0edf40f24344a08
qid3951	SELECT 企业全称 WHERE 注册区县 == "静海区" or 申请类别 == "股改补助" or 补助金额 == "20万元"	f6e75ee6453d11e9b0edf40f24344a08
qid3952	SELECT 培训者人数 WHERE 培训课程 == "高级企业管理" and 培训时间 == "3周"	a95fd8573b0611e98ba2f40f24344a08
qid3953	SELECT 培训者人数 WHERE 培训课程 == "高级企业管理" and 培训时间 == "3周"	a95fd8573b0611e98ba2f40f24344a08
qid3954	SELECT 培训者人数 WHERE 培训课程 == "高级企业管理" and 培训时间 == "3周"	a95fd8573b0611e98ba2f40f24344a08
qid3955	SELECT 生产企业 WHERE 产品名称 == "柴油滤清器" and 抽查时间 == "2014年4季度" and 检验结论 == "符合本次监督检查要求"	f168e899453d11e99315f40f24344a08
qid3956	SELECT 生产企业 WHERE 产品名称 == "柴油滤清器" and 抽查时间 == "2014年4季度" and 检验结论 == "符合本次监督检查要求"	f168e899453d11e99315f40f24344a08
qid3957	SELECT 生产企业 WHERE 产品名称 == "柴油滤清器" and 抽查时间 == "2014年4季度" and 检验结论 == "符合本次监督检查要求"	f168e899453d11e99315f40f24344a08
qid3958	SELECT 学分 WHERE 课程名称 == "数值分析"	a84c72113b0611e9bfebf40f24344a08
qid3959	SELECT 学分 WHERE 课程名称 == "数值分析"	a84c72113b0611e9bfebf40f24344a08
qid3960	SELECT 学分 WHERE 课程名称 == "数值分析"	a84c72113b0611e9bfebf40f24344a08
qid3961	SELECT 项目单位名称 WHERE 总投资（万元） > "2" and 补助资金（万元） > "2"	f3228540453d11e98e6ef40f24344a08
qid3962	SELECT 项目单位名称 WHERE 总投资（万元） > "2" and 补助资金（万元） > "2"	f3228540453d11e98e6ef40f24344a08
qid3963	SELECT 项目单位名称 WHERE 总投资（万元） > "2" and 补助资金（万元） > "2"	f3228540453d11e98e6ef40f24344a08
qid3964	SELECT 电话（0591） , 地址 WHERE 主办网点名称 == "工商银行长乐支行"	ed4b5494453d11e9b3c5f40f24344a08
qid3965	SELECT 电话（0591） , 地址 WHERE 主办网点名称 == "工商银行长乐支行"	ed4b5494453d11e9b3c5f40f24344a08
qid3966	SELECT 电话（0591） , 地址 WHERE 主办网点名称 == "工商银行长乐支行"	ed4b5494453d11e9b3c5f40f24344a08
qid3967	SELECT 作者 WHERE 书名 == "情商养成" or 书名 == "重复的力量"	ab3402cf3b0611e9aa59f40f24344a08
qid3968	SELECT 作者 WHERE 书名 == "情商养成" or 书名 == "重复的力量"	ab3402cf3b0611e9aa59f40f24344a08
qid3969	SELECT 作者 WHERE 书名 == "情商养成" or 书名 == "重复的力量"	ab3402cf3b0611e9aa59f40f24344a08
qid3970	SELECT 出版社 WHERE 题名 == "现代政治" and 责任者 == "傅斯年著"	eeff5170453d11e9a8dcf40f24344a08
qid3971	SELECT 出版社 WHERE 题名 == "现代政治" and 责任者 == "傅斯年著"	eeff5170453d11e9a8dcf40f24344a08
qid3972	SELECT 出版社 WHERE 题名 == "现代政治" and 责任者 == "傅斯年著"	eeff5170453d11e9a8dcf40f24344a08
qid3973	SELECT 学历 WHERE 应聘单位 == "吉林省气象科学研究所" and 应聘职位 == "农业气象"	a7e26c8c3b0611e9a244f40f24344a08
qid3974	SELECT 学历 WHERE 应聘单位 == "吉林省气象科学研究所" and 应聘职位 == "农业气象"	a7e26c8c3b0611e9a244f40f24344a08
qid3975	SELECT 学历 WHERE 应聘单位 == "吉林省气象科学研究所" and 应聘职位 == "农业气象"	a7e26c8c3b0611e9a244f40f24344a08
qid3976	SELECT 招聘单位 WHERE 招聘岗位 == "项目管理" or 招聘岗位 == "测量员"	ee000d63453d11e98482f40f24344a08
qid3977	SELECT 招聘单位 WHERE 招聘岗位 == "项目管理" or 招聘岗位 == "测量员"	ee000d63453d11e98482f40f24344a08
qid3978	SELECT 招聘单位 WHERE 招聘岗位 == "项目管理" or 招聘岗位 == "测量员"	ee000d63453d11e98482f40f24344a08
qid3979	SELECT 内容 WHERE 项目 == "安全教育培训" or 评分标准 == "1、未保证安全生产投入的，扣2分；2、安全生产费用使用不全，每少1项，扣1分，扣完4分为止。"	a89521f83b0611e9a3b9f40f24344a08
qid3980	SELECT 内容 WHERE 项目 == "安全教育培训" or 评分标准 == "1、未保证安全生产投入的，扣2分；2、安全生产费用使用不全，每少1项，扣1分，扣完4分为止。"	a89521f83b0611e9a3b9f40f24344a08
qid3981	SELECT 内容 WHERE 项目 == "安全教育培训" or 评分标准 == "1、未保证安全生产投入的，扣2分；2、安全生产费用使用不全，每少1项，扣1分，扣完4分为止。"	a89521f83b0611e9a3b9f40f24344a08
qid3982	SELECT 数量 WHERE 出版社 == "天津古籍出版社" and 书名 == "近出西周金文集释"	ab03adcc3b0611e9abc9f40f24344a08
qid3983	SELECT 数量 WHERE 出版社 == "天津古籍出版社" and 书名 == "近出西周金文集释"	ab03adcc3b0611e9abc9f40f24344a08
qid3984	SELECT 作者 WHERE 书名 == "误闯海盗船" or 书名 == "卡诺小镇的新居民"	f6625d21453d11e98e40f40f24344a08
qid3985	SELECT 作者 WHERE 书名 == "误闯海盗船" or 书名 == "卡诺小镇的新居民"	f6625d21453d11e98e40f40f24344a08
qid3986	SELECT 作者 WHERE 书名 == "误闯海盗船" or 书名 == "卡诺小镇的新居民"	f6625d21453d11e98e40f40f24344a08
qid3987	SELECT ISBN WHERE 书名 == "建筑玻璃应用技术规程"	a95567053b0611e9a4cdf40f24344a08
qid3988	SELECT ISBN WHERE 书名 == "建筑玻璃应用技术规程"	a95567053b0611e9a4cdf40f24344a08
qid3989	SELECT ISBN WHERE 书名 == "建筑玻璃应用技术规程"	a95567053b0611e9a4cdf40f24344a08
qid3990	SELECT 专　业 WHERE 单位名称 == "区法院" and 职位名称 == "法院工作人员"	ef5d9ec2453d11e9b3daf40f24344a08
qid3991	SELECT 专　业 WHERE 单位名称 == "区法院" and 职位名称 == "法院工作人员"	ef5d9ec2453d11e9b3daf40f24344a08
qid3992	SELECT 品牌 WHERE 品种 == "显示器" or 品种 == "一体机"	f08851fd453d11e9a141f40f24344a08
qid3993	SELECT 品牌 WHERE 品种 == "显示器" or 品种 == "一体机"	f08851fd453d11e9a141f40f24344a08
qid3994	SELECT 品牌 WHERE 品种 == "显示器" or 品种 == "一体机"	f08851fd453d11e9a141f40f24344a08
qid3995	SELECT 发行量（册） , 出版时间 WHERE 书名 == "《明史演义》"	aa98115c3b0611e9acb1f40f24344a08
qid3996	SELECT 发行量（册） , 出版时间 WHERE 书名 == "《明史演义》"	aa98115c3b0611e9acb1f40f24344a08
qid3997	SELECT 发行量（册） , 出版时间 WHERE 书名 == "《明史演义》"	aa98115c3b0611e9acb1f40f24344a08
qid3998	SELECT 地址 WHERE 单位 == "辽宁光电电子股份有限公司"	a93c94543b0611e99e53f40f24344a08
qid3999	SELECT 地址 WHERE 单位 == "辽宁光电电子股份有限公司"	a93c94543b0611e99e53f40f24344a08
qid4000	SELECT 地址 WHERE 单位 == "辽宁光电电子股份有限公司"	a93c94543b0611e99e53f40f24344a08
qid4001	SELECT 作者 WHERE ISBN == "978-7-111-58308-0" or ISBN == "978-7-111-58123-9"	aaefedee3b0611e99608f40f24344a08
qid4002	SELECT 作者 WHERE ISBN == "978-7-111-58308-0" or ISBN == "978-7-111-58123-9"	aaefedee3b0611e99608f40f24344a08
qid4003	SELECT 作者 WHERE ISBN == "978-7-111-58308-0" or ISBN == "978-7-111-58123-9"	aaefedee3b0611e99608f40f24344a08
qid4004	SELECT 网店数量 WHERE 地区 == "成都" and 零售 == "红旗超市"	ab4679f33b0611e9bd92f40f24344a08
qid4005	SELECT 网店数量 WHERE 地区 == "成都" and 零售 == "红旗超市"	ab4679f33b0611e9bd92f40f24344a08
qid4006	SELECT 网店数量 WHERE 地区 == "成都" and 零售 == "红旗超市"	ab4679f33b0611e9bd92f40f24344a08
qid4007	SELECT 总投资（万元） WHERE 项目名称 == "东湖水世界项目"	a96bad823b0611e9b9c0f40f24344a08
qid4008	SELECT 总投资（万元） WHERE 项目名称 == "东湖水世界项目"	a96bad823b0611e9b9c0f40f24344a08
qid4009	SELECT 总投资（万元） WHERE 项目名称 == "东湖水世界项目"	a96bad823b0611e9b9c0f40f24344a08
qid4010	SELECT 岗位名称 WHERE 部门名称 == "国际部"	ab46cb023b0611e99ad4f40f24344a08
qid4011	SELECT 岗位名称 WHERE 部门名称 == "国际部"	ab46cb023b0611e99ad4f40f24344a08
qid4012	SELECT 岗位名称 WHERE 部门名称 == "国际部"	ab46cb023b0611e99ad4f40f24344a08
qid4013	SELECT 成果名称 WHERE 项目名称 == "图像时代古典文学的视觉再现" or 项目名称 == "艺术学原创性理论研究"	a959c4513b0611e9863bf40f24344a08
qid4014	SELECT 成果名称 WHERE 项目名称 == "图像时代古典文学的视觉再现" or 项目名称 == "艺术学原创性理论研究"	a959c4513b0611e9863bf40f24344a08
qid4015	SELECT 成果名称 WHERE 项目名称 == "图像时代古典文学的视觉再现" or 项目名称 == "艺术学原创性理论研究"	a959c4513b0611e9863bf40f24344a08
qid4016	SELECT 学历要求 WHERE 岗位名称 == "人事管理岗" or 岗位名称 == "科研管理岗"	aa7c23333b0611e99d6ff40f24344a08
qid4017	SELECT 学历要求 WHERE 岗位名称 == "人事管理岗" or 岗位名称 == "科研管理岗"	aa7c23333b0611e99d6ff40f24344a08
qid4018	SELECT 学历要求 WHERE 岗位名称 == "人事管理岗" or 岗位名称 == "科研管理岗"	aa7c23333b0611e99d6ff40f24344a08
qid4019	SELECT 设备型号 WHERE 使用单位名称 == "克拉玛依市金磊建材有限公司" and 设备类型 == "承压蒸汽锅炉"	ab39b2753b0611e9b60af40f24344a08
qid4020	SELECT 设备型号 WHERE 使用单位名称 == "克拉玛依市金磊建材有限公司" and 设备类型 == "承压蒸汽锅炉"	ab39b2753b0611e9b60af40f24344a08
qid4021	SELECT 设备型号 WHERE 使用单位名称 == "克拉玛依市金磊建材有限公司" and 设备类型 == "承压蒸汽锅炉"	ab39b2753b0611e9b60af40f24344a08
qid4022	SELECT 等级 WHERE 班级名称 == "2016级国际经济与贸易班" or 班级名称 == "2015级软件工程班"	ed3470c7453d11e99fdff40f24344a08
qid4023	SELECT 等级 WHERE 班级名称 == "2016级国际经济与贸易班" or 班级名称 == "2015级软件工程班"	ed3470c7453d11e99fdff40f24344a08
qid4024	SELECT 等级 WHERE 班级名称 == "2016级国际经济与贸易班" or 班级名称 == "2015级软件工程班"	ed3470c7453d11e99fdff40f24344a08
qid4025	SELECT 招聘岗位 WHERE 学历要求 == "本科" and 专业要求 == "工程测量"	ee000d63453d11e98482f40f24344a08
qid4026	SELECT 招聘岗位 WHERE 学历要求 == "本科" and 专业要求 == "工程测量"	ee000d63453d11e98482f40f24344a08
qid4027	SELECT 招聘岗位 WHERE 学历要求 == "本科" and 专业要求 == "工程测量"	ee000d63453d11e98482f40f24344a08
qid4028	SELECT 需求数量 WHERE 部门名称 == "新华新媒文化传播有限公司" and 岗位名称 == "新媒体中文采编"	a841ce8c3b0611e984faf40f24344a08
qid4029	SELECT 需求数量 WHERE 部门名称 == "新华新媒文化传播有限公司" and 岗位名称 == "新媒体中文采编"	a841ce8c3b0611e984faf40f24344a08
qid4030	SELECT 需求数量 WHERE 部门名称 == "新华新媒文化传播有限公司" and 岗位名称 == "新媒体中文采编"	a841ce8c3b0611e984faf40f24344a08
qid4031	SELECT 著作作者 WHERE 书名 == "大学生心理健康教育" or 书名 == "国家主导型发展模式研究"	f5eadb26453d11e99b3df40f24344a08
qid4032	SELECT 著作作者 WHERE 书名 == "大学生心理健康教育" or 书名 == "国家主导型发展模式研究"	f5eadb26453d11e99b3df40f24344a08
qid4033	SELECT 著作作者 WHERE 书名 == "大学生心理健康教育" or 书名 == "国家主导型发展模式研究"	f5eadb26453d11e99b3df40f24344a08
qid4034	SELECT 招聘人数 WHERE 用人部门 == "金融市场部"	ab4bac073b0611e98b05f40f24344a08
qid4035	SELECT 招聘人数 WHERE 用人部门 == "金融市场部"	ab4bac073b0611e98b05f40f24344a08
qid4036	SELECT 招聘人数 WHERE 用人部门 == "金融市场部"	ab4bac073b0611e98b05f40f24344a08
qid4037	SELECT 比赛地点 WHERE 赛事名称 == "2014年广州国际龙舟邀请赛"	a96474753b0611e9bda5f40f24344a08
qid4038	SELECT 比赛地点 WHERE 赛事名称 == "2014年广州国际龙舟邀请赛"	a96474753b0611e9bda5f40f24344a08
qid4039	SELECT 比赛地点 WHERE 赛事名称 == "2014年广州国际龙舟邀请赛"	a96474753b0611e9bda5f40f24344a08
qid4040	SELECT 学历要求 , 专业要求 WHERE 招录机关 == "平度市辖区乡镇" and 招录对象 == "面向长期在乡镇（街道）工作人员"	f2425c91453d11e9891df40f24344a08
qid4041	SELECT 学历要求 , 专业要求 WHERE 招录机关 == "平度市辖区乡镇" and 招录对象 == "面向长期在乡镇（街道）工作人员"	f2425c91453d11e9891df40f24344a08
qid4042	SELECT 学历要求 , 专业要求 WHERE 招录机关 == "平度市辖区乡镇" and 招录对象 == "面向长期在乡镇（街道）工作人员"	f2425c91453d11e9891df40f24344a08
qid4043	SELECT 项目名称 WHERE 财务分类 == "D" or 编码 == "310100044X"	f41b5866453d11e9af57f40f24344a08
qid4044	SELECT 项目名称 WHERE 财务分类 == "D" or 编码 == "310100044X"	f41b5866453d11e9af57f40f24344a08
qid4045	SELECT 项目名称 WHERE 财务分类 == "D" or 编码 == "310100044X"	f41b5866453d11e9af57f40f24344a08
qid4046	SELECT 学校 WHERE 组别 == "中学组" and 奖项 == "一等奖"	f3248285453d11e9a009f40f24344a08
qid4047	SELECT 学校 WHERE 组别 == "中学组" and 奖项 == "一等奖"	f3248285453d11e9a009f40f24344a08
qid4048	SELECT 学校 WHERE 组别 == "中学组" and 奖项 == "一等奖"	f3248285453d11e9a009f40f24344a08
qid4049	SELECT 企业名称 , 产品名称 WHERE 省份 == "广东" and 产品类别 == "杀虫剂"	a8580b853b0611e99e1ff40f24344a08
qid4050	SELECT 企业名称 , 产品名称 WHERE 省份 == "广东" and 产品类别 == "杀虫剂"	a8580b853b0611e99e1ff40f24344a08
qid4051	SELECT 企业名称 , 产品名称 WHERE 省份 == "广东" and 产品类别 == "杀虫剂"	a8580b853b0611e99e1ff40f24344a08
qid4052	SELECT COUNT ( 招聘岗位 ) WHERE 薪资待遇（年薪） == "50000-60000元/年"	ab4dc6dc3b0611e9aa57f40f24344a08
qid4053	SELECT COUNT ( 招聘岗位 ) WHERE 薪资待遇（年薪） == "50000-60000元/年"	ab4dc6dc3b0611e9aa57f40f24344a08
qid4054	SELECT COUNT ( 招聘岗位 ) WHERE 薪资待遇（年薪） == "50000-60000元/年"	ab4dc6dc3b0611e9aa57f40f24344a08
qid4055	SELECT 定价 WHERE 书号 == "9.78730805116e+12"	f3478680453d11e98935f40f24344a08
qid4056	SELECT 定价 WHERE 书号 == "9.78730805116e+12"	f3478680453d11e98935f40f24344a08
qid4057	SELECT 定价 WHERE 书号 == "9.78730805116e+12"	f3478680453d11e98935f40f24344a08
qid4058	SELECT 规格型号 WHERE 企业名称 == "台州鼎尚卫浴有限公司" and 产品名称 == "电子座便器（智能坐便器）"	aafb7d8c3b0611e98b0df40f24344a08
qid4059	SELECT 规格型号 WHERE 企业名称 == "台州鼎尚卫浴有限公司" and 产品名称 == "电子座便器（智能坐便器）"	aafb7d8c3b0611e98b0df40f24344a08
qid4060	SELECT 规格型号 WHERE 企业名称 == "台州鼎尚卫浴有限公司" and 产品名称 == "电子座便器（智能坐便器）"	aafb7d8c3b0611e98b0df40f24344a08
qid4061	SELECT 内容 WHERE 地点 == "实验室" and 星期 == "二"	f11c1dd9453d11e99e48f40f24344a08
qid4062	SELECT 内容 WHERE 地点 == "实验室" and 星期 == "二"	f11c1dd9453d11e99e48f40f24344a08
qid4063	SELECT 内容 WHERE 地点 == "实验室" and 星期 == "二"	f11c1dd9453d11e99e48f40f24344a08
qid4064	SELECT 作者 WHERE ISBN == "978-7-307-20641-0" or ISBN == "978-7-307-20547-5"	a90dca7a3b0611e9b94af40f24344a08
qid4065	SELECT 作者 WHERE ISBN == "978-7-307-20641-0" or ISBN == "978-7-307-20547-5"	a90dca7a3b0611e9b94af40f24344a08
qid4066	SELECT 作者 WHERE ISBN == "978-7-307-20641-0" or ISBN == "978-7-307-20547-5"	a90dca7a3b0611e9b94af40f24344a08
qid4067	SELECT 项目Content WHERE 地点Venue == "北京铁道大厦3层多功能厅"	ee0aa9f3453d11e9b17ef40f24344a08
qid4068	SELECT 项目Content WHERE 地点Venue == "北京铁道大厦3层多功能厅"	ee0aa9f3453d11e9b17ef40f24344a08
qid4069	SELECT 项目Content WHERE 地点Venue == "北京铁道大厦3层多功能厅"	ee0aa9f3453d11e9b17ef40f24344a08
qid4070	SELECT COUNT ( 生产企业 ) WHERE 药品通用名 == "复方枸橼酸铁铵糖浆"	a93eb9a83b0611e9a163f40f24344a08
qid4071	SELECT COUNT ( 生产企业 ) WHERE 药品通用名 == "复方枸橼酸铁铵糖浆"	a93eb9a83b0611e9a163f40f24344a08
qid4072	SELECT COUNT ( 生产企业 ) WHERE 药品通用名 == "复方枸橼酸铁铵糖浆"	a93eb9a83b0611e9a163f40f24344a08
qid4073	SELECT 产品等级 WHERE 企业名称 == "上海红富士家纺有限公司" and 产品名称 == "七孔枕"	f0bcb347453d11e99738f40f24344a08
qid4074	SELECT 产品等级 WHERE 企业名称 == "上海红富士家纺有限公司" and 产品名称 == "七孔枕"	f0bcb347453d11e99738f40f24344a08
qid4075	SELECT 产品等级 WHERE 企业名称 == "上海红富士家纺有限公司" and 产品名称 == "七孔枕"	f0bcb347453d11e99738f40f24344a08
qid4076	SELECT 出版社 WHERE 书名 == "中国通史" and 作者 == "吕思勉"	aa02c2d93b0611e9b573f40f24344a08
qid4077	SELECT 出版社 WHERE 书名 == "中国通史" and 作者 == "吕思勉"	aa02c2d93b0611e9b573f40f24344a08
qid4078	SELECT 出版社 WHERE 书名 == "中国通史" and 作者 == "吕思勉"	aa02c2d93b0611e9b573f40f24344a08
qid4079	SELECT 地址 WHERE 所属城区 == "南京" and 加油名称 == "江宁宝盛充值点"	f5f7057a453d11e985bdf40f24344a08
qid4080	SELECT 地址 WHERE 所属城区 == "南京" and 加油名称 == "江宁宝盛充值点"	f5f7057a453d11e985bdf40f24344a08
qid4081	SELECT 地址 WHERE 所属城区 == "南京" and 加油名称 == "江宁宝盛充值点"	f5f7057a453d11e985bdf40f24344a08
qid4082	SELECT 课程学时 WHERE 课程名称 == "焊接物理" or 课程名称 == "计算理论"	f2ffcd85453d11e98e53f40f24344a08
qid4083	SELECT 课程学时 WHERE 课程名称 == "焊接物理" or 课程名称 == "计算理论"	f2ffcd85453d11e98e53f40f24344a08
qid4084	SELECT 课程学时 WHERE 课程名称 == "焊接物理" or 课程名称 == "计算理论"	f2ffcd85453d11e98e53f40f24344a08
qid4085	SELECT 网址 WHERE 名称 == "龙门县文化馆"	ab5571473b0611e9ba9ff40f24344a08
qid4086	SELECT 网址 WHERE 名称 == "龙门县文化馆"	ab5571473b0611e9ba9ff40f24344a08
qid4087	SELECT 网址 WHERE 名称 == "龙门县文化馆"	ab5571473b0611e9ba9ff40f24344a08
qid4088	SELECT 学历 WHERE 招聘单位 == "鲁迅美术学院" and 岗位名称 == "文化传播与管理系专业教师"	aac55fc23b0611e98bb6f40f24344a08
qid4089	SELECT 学历 WHERE 招聘单位 == "鲁迅美术学院" and 岗位名称 == "文化传播与管理系专业教师"	aac55fc23b0611e98bb6f40f24344a08
qid4090	SELECT 学历 WHERE 招聘单位 == "鲁迅美术学院" and 岗位名称 == "文化传播与管理系专业教师"	aac55fc23b0611e98bb6f40f24344a08
qid4091	SELECT 店铺数量 WHERE 公司名称 == "华润万家有限公司" and 品牌名称 == "华润万家"	a9b617c03b0611e9b5c4f40f24344a08
qid4092	SELECT 店铺数量 WHERE 公司名称 == "华润万家有限公司" and 品牌名称 == "华润万家"	a9b617c03b0611e9b5c4f40f24344a08
qid4093	SELECT 店铺数量 WHERE 公司名称 == "华润万家有限公司" and 品牌名称 == "华润万家"	a9b617c03b0611e9b5c4f40f24344a08
qid4094	SELECT 营业时间 WHERE 门店名称 == "悠游堂海盗主题乐园北京祥云小镇店"	a99d0d703b0611e9866bf40f24344a08
qid4095	SELECT 营业时间 WHERE 门店名称 == "悠游堂海盗主题乐园北京祥云小镇店"	a99d0d703b0611e9866bf40f24344a08
qid4096	SELECT 营业时间 WHERE 门店名称 == "悠游堂海盗主题乐园北京祥云小镇店"	a99d0d703b0611e9866bf40f24344a08
qid4097	SELECT 学历 WHERE 招聘岗位 == "手足外科"	f1675cd1453d11e98592f40f24344a08
qid4098	SELECT 学历 WHERE 招聘岗位 == "手足外科"	f1675cd1453d11e98592f40f24344a08
qid4099	SELECT 学历 WHERE 招聘岗位 == "手足外科"	f1675cd1453d11e98592f40f24344a08
qid4100	SELECT 招聘人数 WHERE 单位名称 == "举视（上海）新能源科技有限公司" and 岗位名称 == "网店店铺运营专员"	a9b039e83b0611e9bfeff40f24344a08
qid4101	SELECT 招聘人数 WHERE 单位名称 == "举视（上海）新能源科技有限公司" and 岗位名称 == "网店店铺运营专员"	a9b039e83b0611e9bfeff40f24344a08
qid4102	SELECT 招聘人数 WHERE 单位名称 == "举视（上海）新能源科技有限公司" and 岗位名称 == "网店店铺运营专员"	a9b039e83b0611e9bfeff40f24344a08
qid4103	SELECT 岗位编号 WHERE 岗位 == "深土公司生产岗位"	ed38c6fa453d11e9b344f40f24344a08
qid4104	SELECT 岗位编号 WHERE 岗位 == "深土公司生产岗位"	ed38c6fa453d11e9b344f40f24344a08
qid4105	SELECT 岗位编号 WHERE 岗位 == "深土公司生产岗位"	ed38c6fa453d11e9b344f40f24344a08
qid4106	SELECT 专业条件 WHERE 报考岗位 == "影像诊断" or 报考岗位 == "康复治疗"	f23281c7453d11e9b58af40f24344a08
qid4107	SELECT 专业条件 WHERE 报考岗位 == "影像诊断" or 报考岗位 == "康复治疗"	f23281c7453d11e9b58af40f24344a08
qid4108	SELECT 专业条件 WHERE 报考岗位 == "影像诊断" or 报考岗位 == "康复治疗"	f23281c7453d11e9b58af40f24344a08
qid4109	SELECT 作者 WHERE 书名 == "党建热点面对面" or 书名 == "变革的十年"	eee6e297453d11e9a46bf40f24344a08
qid4110	SELECT 作者 WHERE 书名 == "党建热点面对面" or 书名 == "变革的十年"	eee6e297453d11e9a46bf40f24344a08
qid4111	SELECT 作者 WHERE 书名 == "党建热点面对面" or 书名 == "变革的十年"	eee6e297453d11e9a46bf40f24344a08
qid4112	SELECT 生产日期/批号 WHERE 规格型号 == "M60" and 产品名称 == "平板电脑"	f607dda3453d11e9a411f40f24344a08
qid4113	SELECT 生产日期/批号 WHERE 规格型号 == "M60" and 产品名称 == "平板电脑"	f607dda3453d11e9a411f40f24344a08
qid4114	SELECT 生产日期/批号 WHERE 规格型号 == "M60" and 产品名称 == "平板电脑"	f607dda3453d11e9a411f40f24344a08
qid4115	SELECT 许可证编号 WHERE 剧名 == "丘比特的圈套"	f56ece00453d11e9aedef40f24344a08
qid4116	SELECT 许可证编号 WHERE 剧名 == "丘比特的圈套"	f56ece00453d11e9aedef40f24344a08
qid4117	SELECT 许可证编号 WHERE 剧名 == "丘比特的圈套"	f56ece00453d11e9aedef40f24344a08
qid4118	SELECT 学历 WHERE 招聘单位 == "长沙市园林管理局所属事业单位" and 招聘岗位 == "文秘"	aa8edfeb3b0611e9b238f40f24344a08
qid4119	SELECT 学历 WHERE 招聘单位 == "长沙市园林管理局所属事业单位" and 招聘岗位 == "文秘"	aa8edfeb3b0611e9b238f40f24344a08
qid4120	SELECT 学历 WHERE 招聘单位 == "长沙市园林管理局所属事业单位" and 招聘岗位 == "文秘"	aa8edfeb3b0611e9b238f40f24344a08
qid4121	SELECT 出版年 WHERE 题名 == "邓小平与改革开放的起步" or 题名 == "回顾与前瞻:四川社科界纪念改革开放30周年论文撷英"	ef277b07453d11e984b6f40f24344a08
qid4122	SELECT 出版年 WHERE 题名 == "邓小平与改革开放的起步" or 题名 == "回顾与前瞻:四川社科界纪念改革开放30周年论文撷英"	ef277b07453d11e984b6f40f24344a08
qid4123	SELECT 出版年 WHERE 题名 == "邓小平与改革开放的起步" or 题名 == "回顾与前瞻:四川社科界纪念改革开放30周年论文撷英"	ef277b07453d11e984b6f40f24344a08
qid4124	SELECT 题名 WHERE ISBN == "978-7-5064-8993-5" or ISBN == "978-7-03-053785-0"	ab3d1ac53b0611e98c1cf40f24344a08
qid4125	SELECT 题名 WHERE ISBN == "978-7-5064-8993-5" or ISBN == "978-7-03-053785-0"	ab3d1ac53b0611e98c1cf40f24344a08
qid4126	SELECT 题名 WHERE ISBN == "978-7-5064-8993-5" or ISBN == "978-7-03-053785-0"	ab3d1ac53b0611e98c1cf40f24344a08
qid4127	SELECT 自然村 , 解决方案 WHERE 致贫原因 == "缺技术"	a7cbbb053b0611e9b121f40f24344a08
qid4128	SELECT 自然村 , 解决方案 WHERE 致贫原因 == "缺技术"	a7cbbb053b0611e9b121f40f24344a08
qid4129	SELECT 自然村 , 解决方案 WHERE 致贫原因 == "缺技术"	a7cbbb053b0611e9b121f40f24344a08
qid4130	SELECT COUNT ( 活动内容 ) WHERE 地点 == "国际会展中心M厅"	a8062bcc3b0611e9a6eff40f24344a08
qid4131	SELECT COUNT ( 活动内容 ) WHERE 地点 == "国际会展中心M厅"	a8062bcc3b0611e9a6eff40f24344a08
qid4132	SELECT COUNT ( 活动内容 ) WHERE 地点 == "国际会展中心M厅"	a8062bcc3b0611e9a6eff40f24344a08
qid4133	SELECT 出版社 WHERE 书号 == "9.78754385502e+12"	a7c215d73b0611e9929df40f24344a08
qid4134	SELECT 出版社 WHERE 书号 == "9.78754385502e+12"	a7c215d73b0611e9929df40f24344a08
qid4135	SELECT 出版社 WHERE 书号 == "9.78754385502e+12"	a7c215d73b0611e9929df40f24344a08
qid4136	SELECT 2018年中考报名人数 WHERE 学校 == "上饶县茶亭中学"	abe6084a3b0611e9b632f40f24344a08
qid4137	SELECT 2018年中考报名人数 WHERE 学校 == "上饶县茶亭中学"	abe6084a3b0611e9b632f40f24344a08
qid4138	SELECT 2018年中考报名人数 WHERE 学校 == "上饶县茶亭中学"	abe6084a3b0611e9b632f40f24344a08
qid4139	SELECT COUNT ( 定价 ) WHERE 书名 == "西夏咒" or 书名 == "龙伞"	a9ceb3ca3b0611e9a2a5f40f24344a08
qid4140	SELECT COUNT ( 定价 ) WHERE 书名 == "西夏咒" or 书名 == "龙伞"	a9ceb3ca3b0611e9a2a5f40f24344a08
qid4141	SELECT COUNT ( 定价 ) WHERE 书名 == "西夏咒" or 书名 == "龙伞"	a9ceb3ca3b0611e9a2a5f40f24344a08
qid4142	SELECT 医保类别 WHERE 项目名称 == "人工血管"	ef79bf33453d11e9ac2ff40f24344a08
qid4143	SELECT 医保类别 WHERE 项目名称 == "人工血管"	ef79bf33453d11e9ac2ff40f24344a08
qid4144	SELECT 课题名称 , 负责人 WHERE 项目类别 == "重点项目"	f4b1a030453d11e9b96af40f24344a08
qid4145	SELECT 课题名称 , 负责人 WHERE 项目类别 == "重点项目"	f4b1a030453d11e9b96af40f24344a08
qid4146	SELECT 课题名称 , 负责人 WHERE 项目类别 == "重点项目"	f4b1a030453d11e9b96af40f24344a08
qid4147	SELECT 项目名称 , 项目负责人 WHERE 在哪些实验室（名称）开展项目 == "计算机硬件实验室"	f38b3159453d11e99bf5f40f24344a08
qid4148	SELECT 项目名称 , 项目负责人 WHERE 在哪些实验室（名称）开展项目 == "计算机硬件实验室"	f38b3159453d11e99bf5f40f24344a08
qid4149	SELECT 项目名称 , 项目负责人 WHERE 在哪些实验室（名称）开展项目 == "计算机硬件实验室"	f38b3159453d11e99bf5f40f24344a08
qid4150	SELECT 课题名称 , 申请人 WHERE 学院 == "信息工程学院"	a9f052b53b0611e9b1daf40f24344a08
qid4151	SELECT 课题名称 , 申请人 WHERE 学院 == "信息工程学院"	a9f052b53b0611e9b1daf40f24344a08
qid4152	SELECT 课题名称 , 申请人 WHERE 学院 == "信息工程学院"	a9f052b53b0611e9b1daf40f24344a08
qid4153	SELECT 学分 WHERE 课程名称 == "军事理论"	ee91efcc453d11e9a743f40f24344a08
qid4154	SELECT 学分 WHERE 课程名称 == "军事理论"	ee91efcc453d11e9a743f40f24344a08
qid4155	SELECT 学分 WHERE 课程名称 == "军事理论"	ee91efcc453d11e9a743f40f24344a08
qid4156	SELECT 作者 WHERE 版别名称 == "中国纺织出版社" and 书名 == "做人要厚道做事要精明"	a9a0e92b3b0611e9be21f40f24344a08
qid4157	SELECT 作者 WHERE 版别名称 == "中国纺织出版社" and 书名 == "做人要厚道做事要精明"	a9a0e92b3b0611e9be21f40f24344a08
qid4158	SELECT 书名 WHERE 出版日期 == "2011" and 出版社 == "作家出版社"	a9f3ac823b0611e9aba9f40f24344a08
qid4159	SELECT 书名 WHERE 出版日期 == "2011" and 出版社 == "作家出版社"	a9f3ac823b0611e9aba9f40f24344a08
qid4160	SELECT 书名 WHERE 出版日期 == "2011" and 出版社 == "作家出版社"	a9f3ac823b0611e9aba9f40f24344a08
qid4161	SELECT 出版社 WHERE 书名 == "坐天下" and 第一责任者 == "张宏杰著"	a8f9cef83b0611e9beeaf40f24344a08
qid4162	SELECT 出版社 WHERE 书名 == "坐天下" and 第一责任者 == "张宏杰著"	a8f9cef83b0611e9beeaf40f24344a08
qid4163	SELECT 出版社 WHERE 书名 == "坐天下" and 第一责任者 == "张宏杰著"	a8f9cef83b0611e9beeaf40f24344a08
qid4164	SELECT 报考岗位 WHERE 专业条件 == "口腔医学"	f23281c7453d11e9b58af40f24344a08
qid4165	SELECT 报考岗位 WHERE 专业条件 == "口腔医学"	f23281c7453d11e9b58af40f24344a08
qid4166	SELECT 报考岗位 WHERE 专业条件 == "口腔医学"	f23281c7453d11e9b58af40f24344a08
qid4167	SELECT 户籍要求 WHERE 支行名称 == "小甸子支行" or 支行名称 == "黑沟支行"	f4e784cc453d11e9bf64f40f24344a08
qid4168	SELECT 户籍要求 WHERE 支行名称 == "小甸子支行" or 支行名称 == "黑沟支行"	f4e784cc453d11e9bf64f40f24344a08
qid4169	SELECT 户籍要求 WHERE 支行名称 == "小甸子支行" or 支行名称 == "黑沟支行"	f4e784cc453d11e9bf64f40f24344a08
qid4170	SELECT 招聘人数 WHERE 单位名称 == "首都图书馆" and 招聘职位 == "数据库建设"	ab3bd1ab3b0611e9809cf40f24344a08
qid4171	SELECT 招聘人数 WHERE 单位名称 == "首都图书馆" and 招聘职位 == "数据库建设"	ab3bd1ab3b0611e9809cf40f24344a08
qid4172	SELECT 招聘人数 WHERE 单位名称 == "首都图书馆" and 招聘职位 == "数据库建设"	ab3bd1ab3b0611e9809cf40f24344a08
qid4173	SELECT 计划出版时间 WHERE 项目名称 == "数学大典"	ed2e0440453d11e9ac9cf40f24344a08
qid4174	SELECT 计划出版时间 WHERE 项目名称 == "数学大典"	ed2e0440453d11e9ac9cf40f24344a08
qid4175	SELECT 计划出版时间 WHERE 项目名称 == "数学大典"	ed2e0440453d11e9ac9cf40f24344a08
qid4176	SELECT 企业名称 WHERE 所在地 == "天津市"	edff703d453d11e9a0c2f40f24344a08
qid4177	SELECT 企业名称 WHERE 所在地 == "天津市"	edff703d453d11e9a0c2f40f24344a08
qid4178	SELECT 企业名称 WHERE 所在地 == "天津市"	edff703d453d11e9a0c2f40f24344a08
qid4179	SELECT 第一责任者 WHERE 出版社 == "清华大学出版社" and 题名 == "老子注译"	a915277a3b0611e9afd4f40f24344a08
qid4180	SELECT 第一责任者 WHERE 出版社 == "清华大学出版社" and 题名 == "老子注译"	a915277a3b0611e9afd4f40f24344a08
qid4181	SELECT 第一责任者 WHERE 出版社 == "清华大学出版社" and 题名 == "老子注译"	a915277a3b0611e9afd4f40f24344a08
qid4182	SELECT COUNT ( 作品名 ) WHERE 申报单位 == "广州阿里巴巴文学信息技术有限公司" or 发表网站 == "阿里文学"	a88493873b0611e98f16f40f24344a08
qid4183	SELECT COUNT ( 作品名 ) WHERE 申报单位 == "广州阿里巴巴文学信息技术有限公司" or 发表网站 == "阿里文学"	a88493873b0611e98f16f40f24344a08
qid4184	SELECT COUNT ( 作品名 ) WHERE 申报单位 == "广州阿里巴巴文学信息技术有限公司" or 发表网站 == "阿里文学"	a88493873b0611e98f16f40f24344a08
qid4185	SELECT 成果名称 WHERE 获奖等次 == "一等奖"	abe895703b0611e9857af40f24344a08
qid4186	SELECT 成果名称 WHERE 获奖等次 == "一等奖"	abe895703b0611e9857af40f24344a08
qid4187	SELECT 成果名称 WHERE 获奖等次 == "一等奖"	abe895703b0611e9857af40f24344a08
qid4188	SELECT COUNT ( 项目名称 ) WHERE 所在单位 == "上海交通大学"	a7bb3e4f3b0611e9b90ff40f24344a08
qid4189	SELECT COUNT ( 项目名称 ) WHERE 所在单位 == "上海交通大学"	a7bb3e4f3b0611e9b90ff40f24344a08
qid4190	SELECT COUNT ( 项目名称 ) WHERE 所在单位 == "上海交通大学"	a7bb3e4f3b0611e9b90ff40f24344a08
qid4191	SELECT 专业 WHERE 岗位 == "气象预报"	ab4e82023b0611e99f0df40f24344a08
qid4192	SELECT 专业 WHERE 岗位 == "气象预报"	ab4e82023b0611e99f0df40f24344a08
qid4193	SELECT 专业 WHERE 岗位 == "气象预报"	ab4e82023b0611e99f0df40f24344a08
qid4194	SELECT 器械名称 WHERE 数量 < "10" or 使用科室 == "颅脑器械"	a7c0b4143b0611e9bfecf40f24344a08
qid4195	SELECT 器械名称 WHERE 数量 < "10" or 使用科室 == "颅脑器械"	a7c0b4143b0611e9bfecf40f24344a08
qid4196	SELECT 器械名称 WHERE 数量 < "10" or 使用科室 == "颅脑器械"	a7c0b4143b0611e9bfecf40f24344a08
qid4197	SELECT 起始期 WHERE 企业名称 == "中国建设银行股份有限公司黑龙江省分行"	ed47f8b3453d11e9af78f40f24344a08
qid4198	SELECT 起始期 WHERE 企业名称 == "中国建设银行股份有限公司黑龙江省分行"	ed47f8b3453d11e9af78f40f24344a08
qid4199	SELECT 起始期 WHERE 企业名称 == "中国建设银行股份有限公司黑龙江省分行"	ed47f8b3453d11e9af78f40f24344a08
qid4200	SELECT 作者 WHERE 成果名称 == "辽宁省农村留守儿童教育现状调查研究报告" or 成果名称 == "IT知识与英语语言教学的结合"	f4608d47453d11e9b282f40f24344a08
qid4201	SELECT 作者 WHERE 成果名称 == "辽宁省农村留守儿童教育现状调查研究报告" or 成果名称 == "IT知识与英语语言教学的结合"	f4608d47453d11e9b282f40f24344a08
qid4202	SELECT 作者 WHERE 成果名称 == "辽宁省农村留守儿童教育现状调查研究报告" or 成果名称 == "IT知识与英语语言教学的结合"	f4608d47453d11e9b282f40f24344a08
qid4203	SELECT 型号 WHERE 标称生产单位 == "广东绮瑞制衣实业有限公司" and 商品名称 == "棉麻休闲女套装"	f49063b8453d11e9840af40f24344a08
qid4204	SELECT 型号 WHERE 标称生产单位 == "广东绮瑞制衣实业有限公司" and 商品名称 == "棉麻休闲女套装"	f49063b8453d11e9840af40f24344a08
qid4205	SELECT 型号 WHERE 标称生产单位 == "广东绮瑞制衣实业有限公司" and 商品名称 == "棉麻休闲女套装"	f49063b8453d11e9840af40f24344a08
qid4206	SELECT 课程号 WHERE 课程名 == "人体生理学" or 课程名 == "教育学"	f3ff29ab453d11e9b43ef40f24344a08
qid4207	SELECT 课程号 WHERE 课程名 == "人体生理学" or 课程名 == "教育学"	f3ff29ab453d11e9b43ef40f24344a08
qid4208	SELECT 课程号 WHERE 课程名 == "人体生理学" or 课程名 == "教育学"	f3ff29ab453d11e9b43ef40f24344a08
qid4209	SELECT 企业名称 WHERE 抽查结果 == "合格" and 所在地 == "浙江省"	f4a3ebae453d11e9b0eff40f24344a08
qid4210	SELECT 企业名称 WHERE 抽查结果 == "合格" and 所在地 == "浙江省"	f4a3ebae453d11e9b0eff40f24344a08
qid4211	SELECT 企业名称 WHERE 抽查结果 == "合格" and 所在地 == "浙江省"	f4a3ebae453d11e9b0eff40f24344a08
qid4212	SELECT 地址 WHERE 市场名称 == "上钢菜市场" and 区域 == "浦东新区"	abb7d0053b0611e99cf7f40f24344a08
qid4213	SELECT 地址 WHERE 市场名称 == "上钢菜市场" and 区域 == "浦东新区"	abb7d0053b0611e99cf7f40f24344a08
qid4214	SELECT 地址 WHERE 市场名称 == "上钢菜市场" and 区域 == "浦东新区"	abb7d0053b0611e99cf7f40f24344a08
qid4215	SELECT 影片名称 WHERE 国家 == "中国大陆/香港" and 封装 == "3D"	ab5fd9a63b0611e98cdff40f24344a08
qid4216	SELECT 影片名称 WHERE 国家 == "中国大陆/香港" and 封装 == "3D"	ab5fd9a63b0611e98cdff40f24344a08
qid4217	SELECT 影片名称 WHERE 国家 == "中国大陆/香港" and 封装 == "3D"	ab5fd9a63b0611e98cdff40f24344a08
qid4218	SELECT 企业名称 WHERE 抽查结果 == "合格" and 产品名称 == "汽车安全带"	f3578468453d11e99868f40f24344a08
qid4219	SELECT 企业名称 WHERE 抽查结果 == "合格" and 产品名称 == "汽车安全带"	f3578468453d11e99868f40f24344a08
qid4220	SELECT 企业名称 WHERE 抽查结果 == "合格" and 产品名称 == "汽车安全带"	f3578468453d11e99868f40f24344a08
qid4221	SELECT 专业名称 , 省份 WHERE 录取数 > "10"	f608ca63453d11e9ad09f40f24344a08
qid4222	SELECT 专业名称 , 省份 WHERE 录取数 > "10"	f608ca63453d11e9ad09f40f24344a08
qid4223	SELECT 专业名称 , 省份 WHERE 录取数 > "10"	f608ca63453d11e9ad09f40f24344a08
qid4224	SELECT 专业要求 WHERE 单位名称 == "嘉兴市中级人民法院" and 计划数 == "1" and 职位 == "检察官助理"	a95d88a83b0611e9aeb5f40f24344a08
qid4225	SELECT 专业要求 WHERE 单位名称 == "嘉兴市中级人民法院" and 计划数 == "1" and 职位 == "检察官助理"	a95d88a83b0611e9aeb5f40f24344a08
qid4226	SELECT 专业要求 WHERE 单位名称 == "嘉兴市中级人民法院" and 计划数 == "1" and 职位 == "检察官助理"	a95d88a83b0611e9aeb5f40f24344a08
qid4227	SELECT 书名 WHERE ISBN == "978-7-03-053744-7" or ISBN == "978-7-03-053743-0"	aa784a973b0611e99e9df40f24344a08
qid4228	SELECT 书名 WHERE ISBN == "978-7-03-053744-7" or ISBN == "978-7-03-053743-0"	aa784a973b0611e99e9df40f24344a08
qid4229	SELECT 书名 WHERE ISBN == "978-7-03-053744-7" or ISBN == "978-7-03-053743-0"	aa784a973b0611e99e9df40f24344a08
qid4230	SELECT 标称生产企业地址 WHERE 标称生产企业名称 == "三全食品股份有限公司"	a84099b03b0611e9ae2bf40f24344a08
qid4231	SELECT 标称生产企业地址 WHERE 标称生产企业名称 == "三全食品股份有限公司"	a84099b03b0611e9ae2bf40f24344a08
qid4232	SELECT 标称生产企业地址 WHERE 标称生产企业名称 == "三全食品股份有限公司"	a84099b03b0611e9ae2bf40f24344a08
qid4233	SELECT 发行日期 WHERE 邮票名称 == "高逸图"	a885dc003b0611e98b51f40f24344a08
qid4234	SELECT 发行日期 WHERE 邮票名称 == "高逸图"	a885dc003b0611e98b51f40f24344a08
qid4235	SELECT 地址 WHERE 城市 == "北京" and 名称 == "爱康君安健疗齿科分院"	efa1d468453d11e98a85f40f24344a08
qid4236	SELECT 地址 WHERE 城市 == "北京" and 名称 == "爱康君安健疗齿科分院"	efa1d468453d11e98a85f40f24344a08
qid4237	SELECT 地址 WHERE 城市 == "北京" and 名称 == "爱康君安健疗齿科分院"	efa1d468453d11e98a85f40f24344a08
qid4238	SELECT 批准号 WHERE 成果名称 == "美国大都市区时代的县政府与县域经济" or 成果名称 == "二十世纪初期台湾少数民族文化共同特质研究"	aaa97f0a3b0611e9b0bcf40f24344a08
qid4239	SELECT 批准号 WHERE 成果名称 == "美国大都市区时代的县政府与县域经济" or 成果名称 == "二十世纪初期台湾少数民族文化共同特质研究"	aaa97f0a3b0611e9b0bcf40f24344a08
qid4240	SELECT 批准号 WHERE 成果名称 == "美国大都市区时代的县政府与县域经济" or 成果名称 == "二十世纪初期台湾少数民族文化共同特质研究"	aaa97f0a3b0611e9b0bcf40f24344a08
qid4241	SELECT 作者 WHERE 书名 == "《谁动了我的奶酪》"	aa331f683b0611e99fd9f40f24344a08
qid4242	SELECT 作者 WHERE 书名 == "《谁动了我的奶酪》"	aa331f683b0611e99fd9f40f24344a08
qid4243	SELECT 作者 WHERE 书名 == "《谁动了我的奶酪》"	aa331f683b0611e99fd9f40f24344a08
qid4244	SELECT 产品名称 WHERE 生产企业名称(标称) == "广州市超波王美发电器有限公司" and 生产日期或批号 == "2015.10"	a83cd7cf3b0611e994e6f40f24344a08
qid4245	SELECT 产品名称 WHERE 生产企业名称(标称) == "广州市超波王美发电器有限公司" and 生产日期或批号 == "2015.10"	a83cd7cf3b0611e994e6f40f24344a08
qid4246	SELECT 产品名称 WHERE 生产企业名称(标称) == "广州市超波王美发电器有限公司" and 生产日期或批号 == "2015.10"	a83cd7cf3b0611e994e6f40f24344a08
qid4247	SELECT 作者 WHERE 书号（ISBN） == "978-7-221-12528-6"	aba8c64a3b0611e9bccdf40f24344a08
qid4248	SELECT 作者 WHERE 书号（ISBN） == "978-7-221-12528-6"	aba8c64a3b0611e9bccdf40f24344a08
qid4249	SELECT 作者 WHERE 书号（ISBN） == "978-7-221-12528-6"	aba8c64a3b0611e9bccdf40f24344a08
qid4250	SELECT 书名 WHERE 出版社 == "浙江大学"	f703f45c453d11e998a3f40f24344a08
qid4251	SELECT 书名 WHERE 出版社 == "浙江大学"	f703f45c453d11e998a3f40f24344a08
qid4252	SELECT 书名 WHERE 出版社 == "浙江大学"	f703f45c453d11e998a3f40f24344a08
qid4253	SELECT 书名 , 内容提要(150字以内) WHERE 定价（元） > "30"	aa98115c3b0611e9acb1f40f24344a08
qid4254	SELECT 书名 , 内容提要(150字以内) WHERE 定价（元） > "30"	aa98115c3b0611e9acb1f40f24344a08
qid4255	SELECT 书名 , 内容提要(150字以内) WHERE 定价（元） > "30"	aa98115c3b0611e9acb1f40f24344a08
qid4256	SELECT 报考岗位 WHERE 单　位 == "萧山区中医院"	f54335e3453d11e982acf40f24344a08
qid4257	SELECT 报考岗位 WHERE 单　位 == "萧山区中医院"	f54335e3453d11e982acf40f24344a08
qid4258	SELECT 报考岗位 WHERE 单　位 == "萧山区中医院"	f54335e3453d11e982acf40f24344a08
qid4259	SELECT 定价 WHERE 书名 == "利益的诱惑" or 书名 == "领导力轮盘"	a97453573b0611e9a363f40f24344a08
qid4260	SELECT 定价 WHERE 书名 == "利益的诱惑" or 书名 == "领导力轮盘"	a97453573b0611e9a363f40f24344a08
qid4261	SELECT 定价 WHERE 书名 == "利益的诱惑" or 书名 == "领导力轮盘"	a97453573b0611e9a363f40f24344a08
qid4262	SELECT 出版机构名称 WHERE 书名 == "《会飞的恐龙系列丛书》" or 书名 == "《美丽地球新视角》"	abe58cc23b0611e98f0cf40f24344a08
qid4263	SELECT 出版机构名称 WHERE 书名 == "《会飞的恐龙系列丛书》" or 书名 == "《美丽地球新视角》"	abe58cc23b0611e98f0cf40f24344a08
qid4264	SELECT 出版机构名称 WHERE 书名 == "《会飞的恐龙系列丛书》" or 书名 == "《美丽地球新视角》"	abe58cc23b0611e98f0cf40f24344a08
qid4265	SELECT 书名 , ISBN WHERE 定价 > "50"	a92fb8683b0611e9aa8df40f24344a08
qid4266	SELECT 书名 , ISBN WHERE 定价 > "50"	a92fb8683b0611e9aa8df40f24344a08
qid4267	SELECT 书名 , ISBN WHERE 定价 > "50"	a92fb8683b0611e9aa8df40f24344a08
qid4268	SELECT 出版社 WHERE 书目名称 == "美丽月球" and 作者 == "张元东"	ef17bdc7453d11e99ae8f40f24344a08
qid4269	SELECT 出版社 WHERE 书目名称 == "美丽月球" and 作者 == "张元东"	ef17bdc7453d11e99ae8f40f24344a08
qid4270	SELECT 出版社 WHERE 书目名称 == "美丽月球" and 作者 == "张元东"	ef17bdc7453d11e99ae8f40f24344a08
qid4271	SELECT 车牌号码 WHERE 使用性质 == "货运" and 号牌种类 == "大型汽车"	f38ece00453d11e99ceef40f24344a08
qid4272	SELECT 车牌号码 WHERE 使用性质 == "货运" and 号牌种类 == "大型汽车"	f38ece00453d11e99ceef40f24344a08
qid4273	SELECT 车牌号码 WHERE 使用性质 == "货运" and 号牌种类 == "大型汽车"	f38ece00453d11e99ceef40f24344a08
qid4274	SELECT 书号（ISBN） WHERE 书名 == "实战营销全攻略" or 书名 == "务工就业培训指南"	aba8c64a3b0611e9bccdf40f24344a08
qid4275	SELECT 书号（ISBN） WHERE 书名 == "实战营销全攻略" or 书名 == "务工就业培训指南"	aba8c64a3b0611e9bccdf40f24344a08
qid4276	SELECT 书号（ISBN） WHERE 书名 == "实战营销全攻略" or 书名 == "务工就业培训指南"	aba8c64a3b0611e9bccdf40f24344a08
qid4277	SELECT 学校名称 WHERE 类别 == "高职" and 推荐单位 == "芜湖市"	aa95d2333b0611e980a6f40f24344a08
qid4278	SELECT 学校名称 WHERE 类别 == "高职" and 推荐单位 == "芜湖市"	aa95d2333b0611e980a6f40f24344a08
qid4279	SELECT 学校名称 WHERE 类别 == "高职" and 推荐单位 == "芜湖市"	aa95d2333b0611e980a6f40f24344a08
qid4280	SELECT 注册地址 WHERE 单位名称 == "长阳惠康医院"	f715fc73453d11e9b971f40f24344a08
qid4281	SELECT 注册地址 WHERE 单位名称 == "长阳惠康医院"	f715fc73453d11e9b971f40f24344a08
qid4282	SELECT 学分 WHERE 课程名称 == "大学英语Ⅳ（英文演讲）"	a8464f173b0611e9bdddf40f24344a08
qid4283	SELECT 学分 WHERE 课程名称 == "大学英语Ⅳ（英文演讲）"	a8464f173b0611e9bdddf40f24344a08
qid4284	SELECT 学分 WHERE 课程名称 == "大学英语Ⅳ（英文演讲）"	a8464f173b0611e9bdddf40f24344a08
qid4285	SELECT 专业要求 WHERE 科室 == "血液病研究所" and 岗位名称 == "科研人员"	ef72198a453d11e9850ef40f24344a08
qid4286	SELECT 专业要求 WHERE 科室 == "血液病研究所" and 岗位名称 == "科研人员"	ef72198a453d11e9850ef40f24344a08
qid4287	SELECT 专业要求 WHERE 科室 == "血液病研究所" and 岗位名称 == "科研人员"	ef72198a453d11e9850ef40f24344a08
qid4288	SELECT 集数 WHERE 剧名 == "八路军"	f409c9fd453d11e99f9ef40f24344a08
qid4289	SELECT 集数 WHERE 剧名 == "八路军"	f409c9fd453d11e99f9ef40f24344a08
qid4290	SELECT 集数 WHERE 剧名 == "八路军"	f409c9fd453d11e99f9ef40f24344a08
qid4291	SELECT 规格型号 WHERE 生产日期/批号 == "2015-10-30" and 产品名称 == "智能马桶盖（智能温水洗净便座）"	aa9866173b0611e99656f40f24344a08
qid4292	SELECT 规格型号 WHERE 生产日期/批号 == "2015-10-30" and 产品名称 == "智能马桶盖（智能温水洗净便座）"	aa9866173b0611e99656f40f24344a08
qid4293	SELECT 规格型号 WHERE 生产日期/批号 == "2015-10-30" and 产品名称 == "智能马桶盖（智能温水洗净便座）"	aa9866173b0611e99656f40f24344a08
qid4294	SELECT 生产单位 WHERE 产品名称 == "舒筋丸"	f6012900453d11e98561f40f24344a08
qid4295	SELECT 生产单位 WHERE 产品名称 == "舒筋丸"	f6012900453d11e98561f40f24344a08
qid4296	SELECT 生产单位 WHERE 产品名称 == "舒筋丸"	f6012900453d11e98561f40f24344a08
qid4297	SELECT 项目名称 WHERE 所在省市 == "上海" and 项目类别 == "重点项目"	f14295d1453d11e9a4eff40f24344a08
qid4298	SELECT 项目名称 WHERE 所在省市 == "上海" and 项目类别 == "重点项目"	f14295d1453d11e9a4eff40f24344a08
qid4299	SELECT 项目名称 WHERE 所在省市 == "上海" and 项目类别 == "重点项目"	f14295d1453d11e9a4eff40f24344a08
qid4300	SELECT 招聘岗位 , 招聘单位 WHERE 所需专业 == "医学影像学" and 学历学位 == "硕士研究生"	ab2406263b0611e99282f40f24344a08
qid4301	SELECT 招聘岗位 , 招聘单位 WHERE 所需专业 == "医学影像学" and 学历学位 == "硕士研究生"	ab2406263b0611e99282f40f24344a08
qid4302	SELECT 招聘岗位 , 招聘单位 WHERE 所需专业 == "医学影像学" and 学历学位 == "硕士研究生"	ab2406263b0611e99282f40f24344a08
qid4303	SELECT 考试内容 WHERE 岗位名称 == "血液科医师" or 岗位名称 == "普外科医师"	f68a6acf453d11e9a7a5f40f24344a08
qid4304	SELECT 考试内容 WHERE 岗位名称 == "血液科医师" or 岗位名称 == "普外科医师"	f68a6acf453d11e9a7a5f40f24344a08
qid4305	SELECT 考试内容 WHERE 岗位名称 == "血液科医师" or 岗位名称 == "普外科医师"	f68a6acf453d11e9a7a5f40f24344a08
qid4306	SELECT 招考人数 WHERE 部门名称 == "海林市高级中学" and 职位名称 == "生物教师"	f6e0875e453d11e984d3f40f24344a08
qid4307	SELECT 招考人数 WHERE 部门名称 == "海林市高级中学" and 职位名称 == "生物教师"	f6e0875e453d11e984d3f40f24344a08
qid4308	SELECT 招考人数 WHERE 部门名称 == "海林市高级中学" and 职位名称 == "生物教师"	f6e0875e453d11e984d3f40f24344a08
qid4309	SELECT 产品名称 WHERE 备注 == "胶印平装" and 印制单位 == "安徽新华印刷股份有限公司"	ef2fee5c453d11e9b3c4f40f24344a08
qid4310	SELECT 产品名称 WHERE 备注 == "胶印平装" and 印制单位 == "安徽新华印刷股份有限公司"	ef2fee5c453d11e9b3c4f40f24344a08
qid4311	SELECT 产品名称 WHERE 备注 == "胶印平装" and 印制单位 == "安徽新华印刷股份有限公司"	ef2fee5c453d11e9b3c4f40f24344a08
qid4312	SELECT 初评等级 WHERE 企业名称 == "深圳市安达运输有限公司" and 行业类型 == "出租汽车"	a9c2589e3b0611e99c3ff40f24344a08
qid4313	SELECT 初评等级 WHERE 企业名称 == "深圳市安达运输有限公司" and 行业类型 == "出租汽车"	a9c2589e3b0611e99c3ff40f24344a08
qid4314	SELECT 初评等级 WHERE 企业名称 == "深圳市安达运输有限公司" and 行业类型 == "出租汽车"	a9c2589e3b0611e99c3ff40f24344a08
qid4315	SELECT 项目名称 WHERE 项目类别 == "一般项目" and 所在省市 == "社科院"	f1f91bd7453d11e9992df40f24344a08
qid4316	SELECT 项目名称 WHERE 项目类别 == "一般项目" and 所在省市 == "社科院"	f1f91bd7453d11e9992df40f24344a08
qid4317	SELECT 项目名称 WHERE 项目类别 == "一般项目" and 所在省市 == "社科院"	f1f91bd7453d11e9992df40f24344a08
qid4318	SELECT 书名 WHERE 出版社 == "中国人民大学"	f4b8477a453d11e9901bf40f24344a08
qid4319	SELECT 书名 WHERE 出版社 == "中国人民大学"	f4b8477a453d11e9901bf40f24344a08
qid4320	SELECT 书名 WHERE 出版社 == "中国人民大学"	f4b8477a453d11e9901bf40f24344a08
qid4321	SELECT COUNT ( 知识产权名称 ) WHERE 资助金额(元) > "1000" and 专利类型 == "实用新型"	f0dabb54453d11e99378f40f24344a08
qid4322	SELECT COUNT ( 知识产权名称 ) WHERE 资助金额(元) > "1000" and 专利类型 == "实用新型"	f0dabb54453d11e99378f40f24344a08
qid4323	SELECT COUNT ( 知识产权名称 ) WHERE 资助金额(元) > "1000" and 专利类型 == "实用新型"	f0dabb54453d11e99378f40f24344a08
qid4324	SELECT 地址（不含省、市、行政区信息） WHERE 行政区 == "海淀区" and 门店名称 == "沃尔玛购物广场北京清河分店"	ee8016f5453d11e9ab6bf40f24344a08
qid4325	SELECT 地址（不含省、市、行政区信息） WHERE 行政区 == "海淀区" and 门店名称 == "沃尔玛购物广场北京清河分店"	ee8016f5453d11e9ab6bf40f24344a08
qid4326	SELECT 地址（不含省、市、行政区信息） WHERE 行政区 == "海淀区" and 门店名称 == "沃尔玛购物广场北京清河分店"	ee8016f5453d11e9ab6bf40f24344a08
qid4327	SELECT 内容简介 WHERE 书名 == "拒绝上瘾"	aa784a973b0611e99e9df40f24344a08
qid4328	SELECT 内容简介 WHERE 书名 == "拒绝上瘾"	aa784a973b0611e99e9df40f24344a08
qid4329	SELECT 内容简介 WHERE 书名 == "拒绝上瘾"	aa784a973b0611e99e9df40f24344a08
qid4330	SELECT 岗位名称 , 岗位简介 WHERE 招聘人数 == "2"	aa9713193b0611e9bf8ff40f24344a08
qid4331	SELECT 岗位名称 , 岗位简介 WHERE 招聘人数 == "2"	aa9713193b0611e9bf8ff40f24344a08
qid4332	SELECT 岗位名称 , 岗位简介 WHERE 招聘人数 == "2"	aa9713193b0611e9bf8ff40f24344a08
qid4333	SELECT 考试周时间 WHERE 课程名称 == "钢结构设计原理"	aaa4ea4c3b0611e9b3b9f40f24344a08
qid4334	SELECT 考试周时间 WHERE 课程名称 == "钢结构设计原理"	aaa4ea4c3b0611e9b3b9f40f24344a08
qid4335	SELECT 考试周时间 WHERE 课程名称 == "钢结构设计原理"	aaa4ea4c3b0611e9b3b9f40f24344a08
qid4336	SELECT 联系电话 WHERE 店名 == "西单君太店"	aad1e3303b0611e9b446f40f24344a08
qid4337	SELECT 联系电话 WHERE 店名 == "西单君太店"	aad1e3303b0611e9b446f40f24344a08
qid4338	SELECT 拟招聘人数 WHERE 单位 == "昌江管理局" and 岗位 == "计算机岗"	f2ca5ba6453d11e99538f40f24344a08
qid4339	SELECT 拟招聘人数 WHERE 单位 == "昌江管理局" and 岗位 == "计算机岗"	f2ca5ba6453d11e99538f40f24344a08
qid4340	SELECT 拟招聘人数 WHERE 单位 == "昌江管理局" and 岗位 == "计算机岗"	f2ca5ba6453d11e99538f40f24344a08
qid4341	SELECT 产品名称 WHERE 受检单位 == "沃尔玛（珠海）商业零售有限公司" and 检验结果 == "合格"	f6b449a1453d11e98c63f40f24344a08
qid4342	SELECT 产品名称 WHERE 受检单位 == "沃尔玛（珠海）商业零售有限公司" and 检验结果 == "合格"	f6b449a1453d11e98c63f40f24344a08
qid4343	SELECT 产品名称 WHERE 受检单位 == "沃尔玛（珠海）商业零售有限公司" and 检验结果 == "合格"	f6b449a1453d11e98c63f40f24344a08
qid4344	SELECT 第一批分配数量 WHERE 网点名称 == "中国农业银行双鸭山安邦支行"	f4a4ae68453d11e9be85f40f24344a08
qid4345	SELECT 第一批分配数量 WHERE 网点名称 == "中国农业银行双鸭山安邦支行"	f4a4ae68453d11e9be85f40f24344a08
qid4346	SELECT 第一批分配数量 WHERE 网点名称 == "中国农业银行双鸭山安邦支行"	f4a4ae68453d11e9be85f40f24344a08
qid4347	SELECT 单位 WHERE 学历要求 == "本科及以上" and 计划数 == "2.0"	f09ef905453d11e9902cf40f24344a08
qid4348	SELECT 单位 WHERE 学历要求 == "本科及以上" and 计划数 == "2.0"	f09ef905453d11e9902cf40f24344a08
qid4349	SELECT 单位 WHERE 学历要求 == "本科及以上" and 计划数 == "2.0"	f09ef905453d11e9902cf40f24344a08
qid4350	SELECT 地址电话 WHERE 活动商户 == "秦妈火锅"	ab21688a3b0611e99c56f40f24344a08
qid4351	SELECT 地址电话 WHERE 活动商户 == "秦妈火锅"	ab21688a3b0611e99c56f40f24344a08
qid4352	SELECT 集数 WHERE 剧名 == "年画"	f47d456b453d11e9aa8ef40f24344a08
qid4353	SELECT 集数 WHERE 剧名 == "年画"	f47d456b453d11e9aa8ef40f24344a08
qid4354	SELECT 集数 WHERE 剧名 == "年画"	f47d456b453d11e9aa8ef40f24344a08
qid4355	SELECT 办事地点 WHERE 受理单位 == "北京市朝阳区公安消防支队受理大厅"	f6f9a8c5453d11e99ccdf40f24344a08
qid4356	SELECT 办事地点 WHERE 受理单位 == "北京市朝阳区公安消防支队受理大厅"	f6f9a8c5453d11e99ccdf40f24344a08
qid4357	SELECT 起始期 WHERE 企业名称 == "中国建设银行股份有限公司山西省分行"	ed47f8b3453d11e9af78f40f24344a08
qid4358	SELECT 起始期 WHERE 企业名称 == "中国建设银行股份有限公司山西省分行"	ed47f8b3453d11e9af78f40f24344a08
qid4359	SELECT 起始期 WHERE 企业名称 == "中国建设银行股份有限公司山西省分行"	ed47f8b3453d11e9af78f40f24344a08
qid4360	SELECT 书名 WHERE 估定价 > "50" or ISBN == "978-7-111-58427-8"	aa4fbab03b0611e999fef40f24344a08
qid4361	SELECT 书名 WHERE 估定价 > "50" or ISBN == "978-7-111-58427-8"	aa4fbab03b0611e999fef40f24344a08
qid4362	SELECT 座位数（个） WHERE 所在省份 == "辽宁" and 场馆名称 == "铁西区体育场"	ab6265403b0611e9b937f40f24344a08
qid4363	SELECT 座位数（个） WHERE 所在省份 == "辽宁" and 场馆名称 == "铁西区体育场"	ab6265403b0611e9b937f40f24344a08
qid4364	SELECT 座位数（个） WHERE 所在省份 == "辽宁" and 场馆名称 == "铁西区体育场"	ab6265403b0611e9b937f40f24344a08
qid4365	SELECT 出版社简称 WHERE 作者 == "薛芳主编" and 书名 == "在痛苦世界中寻找"	a9cf464f3b0611e9a19ff40f24344a08
qid4366	SELECT 出版社简称 WHERE 作者 == "薛芳主编" and 书名 == "在痛苦世界中寻找"	a9cf464f3b0611e9a19ff40f24344a08
qid4367	SELECT 出版社简称 WHERE 作者 == "薛芳主编" and 书名 == "在痛苦世界中寻找"	a9cf464f3b0611e9a19ff40f24344a08
qid4368	SELECT 企业名称 WHERE 所在省 == "天津市"	ee923e97453d11e98bf4f40f24344a08
qid4369	SELECT 企业名称 WHERE 所在省 == "天津市"	ee923e97453d11e98bf4f40f24344a08
qid4370	SELECT 年龄 WHERE 单位 == "白沙管理局" and 拟招聘人数 == "1" and 岗位 == "计算机岗"	ed28d61e453d11e998dcf40f24344a08
qid4371	SELECT 年龄 WHERE 单位 == "白沙管理局" and 拟招聘人数 == "1" and 岗位 == "计算机岗"	ed28d61e453d11e998dcf40f24344a08
qid4372	SELECT 年龄 WHERE 单位 == "白沙管理局" and 拟招聘人数 == "1" and 岗位 == "计算机岗"	ed28d61e453d11e998dcf40f24344a08
qid4373	SELECT 电话 , 地址 WHERE 公司名称 == "大连尊荣通达汽车贸易有限公司"	aac74e353b0611e9a69bf40f24344a08
qid4374	SELECT 电话 , 地址 WHERE 公司名称 == "大连尊荣通达汽车贸易有限公司"	aac74e353b0611e9a69bf40f24344a08
qid4375	SELECT 电话 , 地址 WHERE 公司名称 == "大连尊荣通达汽车贸易有限公司"	aac74e353b0611e9a69bf40f24344a08
qid4376	SELECT 参展企业 WHERE 展位费补贴(万元） > "1" and 展位面积（平方米） > "10"	f37f6fdc453d11e99f42f40f24344a08
qid4377	SELECT 参展企业 WHERE 展位费补贴(万元） > "1" and 展位面积（平方米） > "10"	f37f6fdc453d11e99f42f40f24344a08
qid4378	SELECT 参展企业 WHERE 展位费补贴(万元） > "1" and 展位面积（平方米） > "10"	f37f6fdc453d11e99f42f40f24344a08
qid4379	SELECT 书名 , 主编 WHERE 出版社 == "北京大学出版社"	f0bb3d6b453d11e98f48f40f24344a08
qid4380	SELECT 书名 , 主编 WHERE 出版社 == "北京大学出版社"	f0bb3d6b453d11e98f48f40f24344a08
qid4381	SELECT 书名 , 主编 WHERE 出版社 == "北京大学出版社"	f0bb3d6b453d11e98f48f40f24344a08
qid4382	SELECT 活动名称 WHERE 举办城市或地区 == "徐州市"	aa7a73eb3b0611e9931cf40f24344a08
qid4383	SELECT 活动名称 WHERE 举办城市或地区 == "徐州市"	aa7a73eb3b0611e9931cf40f24344a08
qid4384	SELECT 活动名称 WHERE 举办城市或地区 == "徐州市"	aa7a73eb3b0611e9931cf40f24344a08
qid4385	SELECT 出版年代 WHERE 書名 == "“不三不四”集" and 著者 == "鲁迅著"	a905c6eb3b0611e9bfaef40f24344a08
qid4386	SELECT 出版年代 WHERE 書名 == "“不三不四”集" and 著者 == "鲁迅著"	a905c6eb3b0611e9bfaef40f24344a08
qid4387	SELECT 出版年代 WHERE 書名 == "“不三不四”集" and 著者 == "鲁迅著"	a905c6eb3b0611e9bfaef40f24344a08
qid4388	SELECT 出版者 WHERE 正题名 == "孔子家语"	f4024038453d11e99f1af40f24344a08
qid4389	SELECT 出版者 WHERE 正题名 == "孔子家语"	f4024038453d11e99f1af40f24344a08
qid4390	SELECT 出版者 WHERE 正题名 == "孔子家语"	f4024038453d11e99f1af40f24344a08
qid4391	SELECT 定价 WHERE 书名 == "把脉雅思语法"	a87113d73b0611e9beb5f40f24344a08
qid4392	SELECT 定价 WHERE 书名 == "把脉雅思语法"	a87113d73b0611e9beb5f40f24344a08
qid4393	SELECT 定价 WHERE 书名 == "把脉雅思语法"	a87113d73b0611e9beb5f40f24344a08
qid4394	SELECT 违建面积（m2） WHERE 查处对象 == "四佟市场违建"	ef5bea3d453d11e9bc14f40f24344a08
qid4395	SELECT 违建面积（m2） WHERE 查处对象 == "四佟市场违建"	ef5bea3d453d11e9bc14f40f24344a08
qid4396	SELECT 违建面积（m2） WHERE 查处对象 == "四佟市场违建"	ef5bea3d453d11e9bc14f40f24344a08
